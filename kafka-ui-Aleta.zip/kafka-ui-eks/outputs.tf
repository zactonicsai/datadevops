output "cluster_name" {
  value = module.eks.cluster_name
}

output "configure_kubectl" {
  value = "aws eks update-kubeconfig --region ${var.region} --name ${module.eks.cluster_name}"
}

output "kafka_ui_url" {
  value = try(
    "http://${kubernetes_service_v1.kafka_ui.status[0].load_balancer[0].ingress[0].hostname}",
    "pending - run: kubectl get svc kafka-ui"
  )
}
