#!/usr/bin/env bash
# Quick triage for a failed Kafka UI deployment on EKS
set -u
REGION="${1:-us-east-1}"
CLUSTER="${2:-kafka-ui-eks}"

aws eks update-kubeconfig --region "$REGION" --name "$CLUSTER" >/dev/null

echo "== Nodes (expect a node with label workload=kafka-ui, STATUS Ready) =="
kubectl get nodes -L workload -o wide

echo; echo "== Node group status =="
aws eks list-nodegroups --cluster-name "$CLUSTER" --region "$REGION" --query 'nodegroups' --output text | tr '\t' '\n' | while read -r ng; do
  aws eks describe-nodegroup --cluster-name "$CLUSTER" --nodegroup-name "$ng" --region "$REGION" \
    --query 'nodegroup.{name:nodegroupName,status:status,issues:health.issues}' --output json
done

echo; echo "== Pods =="
kubectl get pods -o wide

echo; echo "== Events (most recent last) =="
kubectl get events --sort-by=.lastTimestamp | tail -25

POD=$(kubectl get pods -l app=kafka-ui -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
if [ -n "$POD" ]; then
  echo; echo "== Describe $POD =="
  kubectl describe pod "$POD" | sed -n '/Conditions:/,$p'
  echo; echo "== Logs (last 60 lines) =="
  kubectl logs "$POD" --tail=60 --all-containers 2>/dev/null || kubectl logs "$POD" --previous --tail=60
fi

echo; echo "== Service =="
kubectl get svc kafka-ui -o wide
