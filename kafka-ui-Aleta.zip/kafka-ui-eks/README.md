# Kafka UI on EKS

Creates a VPC, an EKS cluster with one t3.small node, and deploys
Kafka UI (provectuslabs/kafka-ui) behind a public load balancer.
Configuration is done entirely through container env vars, and login is
protected by OIDC (the client secret lives in a Kubernetes Secret).

## Usage

1. Create an OIDC app in your IdP (Cognito, Okta, Entra ID, Keycloak, ...)
   with the authorization-code flow. You'll register the redirect URL after
   the first apply (see step 3).

2. Apply:

       terraform init
       terraform apply \
         -var="kafka_bootstrap_servers=broker1:9092,broker2:9092" \
         -var="oidc_issuer_uri=https://<your-issuer>" \
         -var="oidc_client_id=<client-id>" \
         -var="oidc_client_secret=<client-secret>"

   (Or put these in a `terraform.tfvars` that you keep out of git.)

3. Get the URL and register the callback in your IdP:

       terraform output kafka_ui_url
       # Redirect URI: http://<that-hostname>/login/oauth2/code/oidc

   Then open the URL and you'll be sent to your IdP to log in.

Optional vars: `oidc_scope` (default `openid,profile,email`) and
`oidc_username_attribute` (default `email`; use `cognito:username` for Cognito).

Takes ~15 min. Then:

    terraform output kafka_ui_url

If you leave `kafka_bootstrap_servers` empty, open the UI and add a
cluster there (dynamic config is enabled).

Note: the EKS nodes must have network access to your Kafka brokers
(same VPC / peering / security group rules). For MSK, put the MSK
cluster in `module.vpc.private_subnets` or peer the VPCs.

## Cleanup

    terraform destroy

## Node groups

- `system` (t3.small) – cluster add-ons.
- `kafka_ui` (t3.medium) – labeled `workload=kafka-ui` and tainted
  `workload=kafka-ui:NoSchedule`. The Kafka UI pod uses a nodeSelector +
  toleration so it only runs there.

## Debugging a failed apply

Run `./debug.sh <region> <cluster-name>` for a one-shot triage, or check
by hand:

| Symptom | Likely cause | Fix |
|---|---|---|
| `dial tcp [::1]:80: connect: connection refused` / `Kubernetes cluster unreachable` during plan | Kubernetes provider evaluated before the cluster exists | `terraform apply -target=module.eks` first, then `terraform apply` |
| `the server has asked for the client to provide credentials` | Your IAM identity isn't mapped into the cluster | Apply with the same identity that created it, or add it to `access_entries` in the eks module |
| Node group `CREATE_FAILED` / `NodeCreationFailure` | Nodes can't reach the API or pull images – usually NAT/subnet routing | `aws eks describe-nodegroup ... --query nodegroup.health`; confirm private subnets route to the NAT gateway |
| Pod stuck `Pending`, event `0/2 nodes are available: ... untolerated taint` or `didn't match node selector` | Node group hasn't joined, or label/taint mismatch | `kubectl get nodes -L workload`; compare with `node_selector`/`toleration` in `app.tf` |
| Pod `Pending`, `Insufficient memory/cpu` | Node too small for requests | Bump instance type or lower `resources.requests` |
| `ImagePullBackOff` | No outbound internet from private subnets | Check NAT gateway + route tables |
| `CrashLoopBackOff`, logs mention `issuer` / `OIDC` / `openid-configuration` | Bad `oidc_issuer_uri` or IdP unreachable | `curl <issuer>/.well-known/openid-configuration` from a pod |
| Pod `Running` but never `Ready`; Terraform times out waiting for rollout | Readiness probe failing | `kubectl describe pod` → Events; `kubectl logs` |
| Login redirects then fails with `redirect_uri_mismatch` | Callback not registered in IdP | Add `http://<lb-host>/login/oauth2/code/oidc` |
| `EXTERNAL-IP` stays `<pending>` | Public subnets missing `kubernetes.io/role/elb` tag or no IGW | Check subnet tags in `main.tf` |

Handy commands:

    kubectl get events --sort-by=.lastTimestamp
    kubectl describe pod -l app=kafka-ui
    kubectl logs -l app=kafka-ui --tail=100
    kubectl exec -it deploy/kafka-ui -- wget -qO- http://localhost:8080/actuator/health
