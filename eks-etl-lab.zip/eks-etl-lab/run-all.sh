#!/usr/bin/env bash
# Runs every CLI step in order, stopping at the first failure.
#   ./run-all.sh                      full build
#   ENV_FILE=env/prod.env ./run-all.sh
#   DRY_RUN=true ./run-all.sh         show what would happen
#   ./run-all.sh 12                   start from step 12
set -euo pipefail
cd "$(dirname "$0")"
START="${1:-0}"
for s in cli/[0-9][0-9]-*.sh; do
  n="$(basename "$s" | cut -c1-2)"
  [ "$n" = "99" ] && continue
  [ "$((10#$n))" -lt "$((10#$START))" ] && continue
  printf '\n\033[1m### %s\033[0m\n' "$s"
  bash "$s"
done
printf '\n\033[32mAll steps completed.\033[0m\n'
