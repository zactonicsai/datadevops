output "cluster_name" {
  value       = aws_eks_cluster.this.name
  description = "Feed this to: aws eks update-kubeconfig --name <this>"
}

output "kubeconfig_command" {
  value = "aws eks update-kubeconfig --name ${aws_eks_cluster.this.name} --region ${var.aws_region}"
}

output "vpc_id" {
  value = aws_vpc.this.id
}

output "private_subnet_ids" {
  value = aws_subnet.private[*].id
}

output "s3_bucket" {
  value = aws_s3_bucket.lake.id
}

output "ecr_registry" {
  value = local.registry
}

output "kafka_bootstrap" {
  value = local.kafka_bootstrap
}

output "opensearch_endpoint" {
  value = local.opensearch_endpoint
}

output "opensearch_secret_name" {
  value       = var.opensearch_enabled ? aws_secretsmanager_secret.opensearch[0].name : ""
  description = "Read the master password from Secrets Manager, never from state"
}

output "alb_hostname" {
  value       = try(kubernetes_ingress_v1.shop[0].status[0].load_balancer[0].ingress[0].hostname, "not created yet")
  description = "Open this in a browser"
}

output "app_role_arn" {
  value = aws_iam_role.app.arn
}
