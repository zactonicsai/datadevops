# 21 - The application namespace and its ServiceAccount + ConfigMap.
resource "kubernetes_namespace" "app" {
  count = var.deploy_k8s_workloads ? 1 : 0
  metadata {
    name = var.app_namespace
    labels = {
      project     = var.project
      environment = var.environment
    }
  }
  depends_on = [aws_eks_cluster.this]
}

resource "kubernetes_service_account" "app" {
  count = var.deploy_k8s_workloads ? 1 : 0
  metadata {
    name      = var.app_service_account
    namespace = kubernetes_namespace.app[0].metadata[0].name
  }
}

resource "kubernetes_config_map" "etl" {
  count = var.deploy_k8s_workloads ? 1 : 0
  metadata {
    name      = "etl-config"
    namespace = kubernetes_namespace.app[0].metadata[0].name
  }
  data = {
    AWS_REGION           = var.aws_region
    KAFKA_BOOTSTRAP      = local.kafka_bootstrap
    KAFKA_AUTH           = local.kafka_auth
    KAFKA_TOPIC_RAW      = var.kafka_topic_raw
    KAFKA_TOPIC_DLQ      = var.kafka_topic_dlq
    KAFKA_CONSUMER_GROUP = var.kafka_consumer_group
    S3_BUCKET            = aws_s3_bucket.lake.id
    S3_RAW_PREFIX        = var.s3_raw_prefix
    S3_CURATED_PREFIX    = var.s3_curated_prefix
    OPENSEARCH_ENDPOINT  = local.opensearch_endpoint
    OPENSEARCH_INDEX     = var.opensearch_index
    ENRICH_URL           = "http://enrich.${var.app_namespace}.svc.cluster.local:8080/enrich"
  }
}
