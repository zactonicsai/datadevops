# 06 - SECURITY GROUPS. Prefer "this SG may talk to that SG" over CIDRs.
resource "aws_security_group" "cluster" {
  name        = "${local.name_prefix}-cluster-sg"
  description = "EKS control plane and pods"
  vpc_id      = aws_vpc.this.id
  tags        = { Name = "${local.name_prefix}-cluster-sg" }
}

resource "aws_security_group" "kafka" {
  name        = "${local.name_prefix}-kafka-sg"
  description = "Kafka brokers"
  vpc_id      = aws_vpc.this.id
  tags        = { Name = "${local.name_prefix}-kafka-sg" }
}

resource "aws_security_group" "opensearch" {
  name        = "${local.name_prefix}-opensearch-sg"
  description = "OpenSearch domain"
  vpc_id      = aws_vpc.this.id
  tags        = { Name = "${local.name_prefix}-opensearch-sg" }
}

# Egress: everything may call out (needed to pull images and reach AWS APIs).
resource "aws_vpc_security_group_egress_rule" "cluster_all" {
  security_group_id = aws_security_group.cluster.id
  ip_protocol       = "-1"
  cidr_ipv4         = "0.0.0.0/0"
  description       = "allow all outbound"
}

resource "aws_vpc_security_group_ingress_rule" "kafka_from_cluster_iam" {
  security_group_id            = aws_security_group.kafka.id
  referenced_security_group_id = aws_security_group.cluster.id
  from_port                    = 9098
  to_port                      = 9098
  ip_protocol                  = "tcp"
  description                  = "MSK SASL/IAM from pods"
}

resource "aws_vpc_security_group_ingress_rule" "kafka_from_cluster_plain" {
  security_group_id            = aws_security_group.kafka.id
  referenced_security_group_id = aws_security_group.cluster.id
  from_port                    = 9092
  to_port                      = 9092
  ip_protocol                  = "tcp"
  description                  = "Kafka plaintext from pods"
}

resource "aws_vpc_security_group_ingress_rule" "opensearch_from_cluster" {
  security_group_id            = aws_security_group.opensearch.id
  referenced_security_group_id = aws_security_group.cluster.id
  from_port                    = 443
  to_port                      = 443
  ip_protocol                  = "tcp"
  description                  = "HTTPS from pods"
}
