# 19 - INGRESSCLASS pointing at the built-in Auto Mode ALB controller.
# Remember: in Auto Mode, alb.ingress.kubernetes.io/* annotations do nothing.
# Configuration lives in IngressClassParams below.
resource "kubernetes_manifest" "ingressclassparams" {
  count = var.deploy_k8s_workloads ? 1 : 0
  manifest = {
    apiVersion = "eks.amazonaws.com/v1"
    kind       = "IngressClassParams"
    metadata   = { name = var.alb_class_name }
    spec = {
      scheme        = var.alb_scheme
      ipAddressType = "ipv4"
      group         = { name = "${local.name_prefix}-shared" }
    }
  }
  depends_on = [aws_eks_cluster.this]
}

resource "kubernetes_manifest" "ingressclass" {
  count = var.deploy_k8s_workloads ? 1 : 0
  manifest = {
    apiVersion = "networking.k8s.io/v1"
    kind       = "IngressClass"
    metadata = {
      name        = var.alb_class_name
      annotations = { "ingressclass.kubernetes.io/is-default-class" = "true" }
    }
    spec = {
      controller = "eks.amazonaws.com/alb"
      parameters = {
        apiGroup = "eks.amazonaws.com"
        kind     = "IngressClassParams"
        name     = var.alb_class_name
      }
    }
  }
  depends_on = [kubernetes_manifest.ingressclassparams]
}
