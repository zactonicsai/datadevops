# 18 - CUSTOM NODE POOL (Kubernetes CRDs, applied through Terraform).
# NodeClass = AWS shape of a node.  NodePool = when/what to launch.
resource "kubernetes_manifest" "nodeclass" {
  count = var.deploy_k8s_workloads ? 1 : 0
  manifest = {
    apiVersion = "eks.amazonaws.com/v1"
    kind       = "NodeClass"
    metadata   = { name = "${var.nodepool_name}-class" }
    spec = {
      role = aws_iam_role.node.name
      subnetSelectorTerms = [{
        tags = {
          "kubernetes.io/cluster/${local.cluster_name}" = "shared"
          "Tier"                                        = "private"
        }
      }]
      securityGroupSelectorTerms = [{
        tags = { "Name" = "${local.name_prefix}-cluster-sg" }
      }]
      ephemeralStorage = {
        size       = "80Gi"
        iops       = 3000
        throughput = 125
      }
      tags = local.tags
    }
  }
  depends_on = [aws_eks_cluster.this]
}

resource "kubernetes_manifest" "nodepool" {
  count = var.deploy_k8s_workloads ? 1 : 0
  manifest = {
    apiVersion = "karpenter.sh/v1"
    kind       = "NodePool"
    metadata   = { name = var.nodepool_name }
    spec = {
      template = {
        metadata = { labels = { workload = "etl" } }
        spec = {
          nodeClassRef = {
            group = "eks.amazonaws.com"
            kind  = "NodeClass"
            name  = "${var.nodepool_name}-class"
          }
          taints = [{
            key    = "workload"
            value  = "etl"
            effect = "NoSchedule"
          }]
          requirements = [
            {
              key      = "karpenter.sh/capacity-type"
              operator = "In"
              values   = var.nodepool_capacity_types
            },
            {
              key      = "kubernetes.io/arch"
              operator = "In"
              values   = [var.nodepool_arch]
            },
            {
              key      = "eks.amazonaws.com/instance-category"
              operator = "In"
              values   = var.nodepool_categories
            },
            {
              key      = "eks.amazonaws.com/instance-generation"
              operator = "Gt"
              values   = ["4"]
            },
          ]
          expireAfter = var.nodepool_expire_after
        }
      }
      limits = { cpu = tostring(var.nodepool_cpu_limit) }
      disruption = {
        consolidationPolicy = "WhenEmptyOrUnderutilized"
        consolidateAfter    = "60s"
      }
    }
  }
  depends_on = [kubernetes_manifest.nodeclass]
}
