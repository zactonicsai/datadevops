# 24 - INGRESS. Creating this makes EKS Auto Mode build a real AWS ALB.
# Deleting it deletes the ALB. That is the whole contract.
resource "kubernetes_ingress_v1" "shop" {
  count = var.deploy_k8s_workloads ? 1 : 0
  metadata {
    name      = "shop-ingress"
    namespace = local.ns
  }
  spec {
    ingress_class_name = var.alb_class_name
    rule {
      http {
        path {
          path      = "/api/sales"
          path_type = "Prefix"
          backend {
            service {
              name = "producer"
              port {
                number = 80
              }
            }
          }
        }
        path {
          path      = "/"
          path_type = "Prefix"
          backend {
            service {
              name = "web"
              port {
                number = 80
              }
            }
          }
        }
      }
    }
  }
  wait_for_load_balancer = true
  depends_on             = [kubernetes_manifest.ingressclass, kubernetes_service.simple]
}
