# 07 - IAM role for the EKS control plane.
# Auto Mode needs four extra managed policies so AWS may create nodes,
# load balancers, EBS volumes and networking on your behalf.
data "aws_iam_policy_document" "cluster_assume" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole", "sts:TagSession"]
    principals {
      type        = "Service"
      identifiers = ["eks.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "cluster" {
  name               = "${local.name_prefix}-eks-cluster-role"
  assume_role_policy = data.aws_iam_policy_document.cluster_assume.json
}

locals {
  cluster_policies = concat(
    ["arn:aws:iam::aws:policy/AmazonEKSClusterPolicy"],
    var.auto_mode ? [
      "arn:aws:iam::aws:policy/AmazonEKSComputePolicy",
      "arn:aws:iam::aws:policy/AmazonEKSBlockStoragePolicy",
      "arn:aws:iam::aws:policy/AmazonEKSLoadBalancingPolicy",
      "arn:aws:iam::aws:policy/AmazonEKSNetworkingPolicy",
    ] : []
  )
}

resource "aws_iam_role_policy_attachment" "cluster" {
  for_each   = toset(local.cluster_policies)
  role       = aws_iam_role.cluster.name
  policy_arn = each.value
}
