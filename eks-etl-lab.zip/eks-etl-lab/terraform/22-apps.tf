# 22 - THE FOUR APPLICATIONS.
# We deliberately keep these as plain Kubernetes resources rather than Helm so
# you can read exactly what is happening. In a bigger shop these become a Helm
# chart or a Kustomize base, and Terraform stops at the cluster boundary.
locals {
  registry = "${data.aws_caller_identity.current.account_id}.dkr.ecr.${var.aws_region}.amazonaws.com"
  ns       = var.deploy_k8s_workloads ? kubernetes_namespace.app[0].metadata[0].name : ""

  simple_apps = {
    web = {
      replicas = var.web_replicas
      port     = 8080
      sa       = false
      config   = false
    }
    producer = {
      replicas = var.producer_replicas
      port     = 8080
      sa       = true
      config   = true
    }
    enrich = {
      replicas = 2
      port     = 8080
      sa       = false
      config   = false
    }
  }
}

resource "kubernetes_deployment" "simple" {
  for_each = var.deploy_k8s_workloads ? local.simple_apps : {}
  metadata {
    name      = each.key
    namespace = local.ns
    labels    = { app = each.key }
  }
  spec {
    replicas = each.value.replicas
    selector {
      match_labels = { app = each.key }
    }
    template {
      metadata {
        labels = { app = each.key }
      }
      spec {
        service_account_name = each.value.sa ? var.app_service_account : null
        container {
          name  = each.key
          image = "${local.registry}/${local.name_prefix}/${each.key}:${var.image_tag}"
          port {
            container_port = each.value.port
          }
          dynamic "env_from" {
            for_each = each.value.config ? [1] : []
            content {
              config_map_ref {
                name = "etl-config"
              }
            }
          }
          resources {
            requests = { cpu = "100m", memory = "256Mi" }
            limits   = { memory = "512Mi" }
          }
          readiness_probe {
            http_get {
              path = "/healthz"
              port = each.value.port
            }
            initial_delay_seconds = 5
          }
        }
      }
    }
  }
  depends_on = [kubernetes_config_map.etl]
}

resource "kubernetes_service" "simple" {
  for_each = var.deploy_k8s_workloads ? local.simple_apps : {}
  metadata {
    name      = each.key
    namespace = local.ns
  }
  spec {
    selector = { app = each.key }
    port {
      port        = each.key == "enrich" ? 8080 : 80
      target_port = each.value.port
    }
  }
}

# The worker is different enough (taints, zero replicas, batching env) to
# deserve its own resource rather than being squeezed into the loop above.
resource "kubernetes_deployment" "worker" {
  count = var.deploy_k8s_workloads ? 1 : 0
  metadata {
    name      = "worker"
    namespace = local.ns
    labels    = { app = "worker" }
  }
  spec {
    replicas = var.worker_min_replicas
    selector {
      match_labels = { app = "worker" }
    }
    template {
      metadata {
        labels = { app = "worker" }
      }
      spec {
        service_account_name             = var.app_service_account
        termination_grace_period_seconds = 60
        node_selector                    = { workload = "etl" }
        toleration {
          key      = "workload"
          operator = "Equal"
          value    = "etl"
          effect   = "NoSchedule"
        }
        container {
          name  = "worker"
          image = "${local.registry}/${local.name_prefix}/worker:${var.image_tag}"
          env_from {
            config_map_ref {
              name = "etl-config"
            }
          }
          env {
            name  = "BATCH_SIZE"
            value = "200"
          }
          env {
            name  = "BATCH_SECONDS"
            value = "30"
          }
          resources {
            requests = { cpu = "250m", memory = "512Mi" }
            limits   = { memory = "1Gi" }
          }
        }
      }
    }
  }
  lifecycle {
    # KEDA owns the replica count after creation. Without this, every
    # `terraform apply` would fight the autoscaler and reset it.
    ignore_changes = [spec[0].replicas]
  }
  depends_on = [kubernetes_manifest.nodepool]
}
