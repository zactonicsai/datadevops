# =============================================================================
# EVERY knob lives here. This file is the Terraform twin of env/config.sh.
# Copy terraform.tfvars.example -> terraform.tfvars and change what you need.
# =============================================================================

# ------------------------------------------------------------------ identity
variable "project" {
  type        = string
  default     = "shopetl"
  description = "Short name in front of every resource"
}
variable "environment" {
  type        = string
  default     = "lab"
  description = "lab | dev | stage | prod"
}
variable "owner" {
  type        = string
  default     = "platform-team"
}
variable "cost_center" {
  type        = string
  default     = "CC-1234"
}

# ------------------------------------------------------------------ location
variable "aws_region" {
  type        = string
  default     = "us-east-1"
}
variable "aws_profile" {
  type        = string
  default     = "default"
}
variable "az_count" {
  type        = number
  default     = 2
  description = "2 minimum, 3 for production"
}

# ------------------------------------------------------------------- network
variable "vpc_cidr" {
  type        = string
  default     = "10.42.0.0/16"
}
variable "public_subnet_cidrs" {
  type        = list(string)
  default     = ["10.42.0.0/20", "10.42.16.0/20", "10.42.32.0/20"]
}
variable "private_subnet_cidrs" {
  type        = list(string)
  default     = ["10.42.64.0/19", "10.42.96.0/19", "10.42.128.0/19"]
}
variable "single_nat_gateway" {
  type        = bool
  default     = true
  description = "true saves ~$32/month per extra AZ"
}
variable "enable_flow_logs" {
  type        = bool
  default     = false
}

# ------------------------------------------------------------------- cluster
variable "cluster_name_override" {
  type        = string
  default     = ""
}
variable "k8s_version" {
  type        = string
  default     = "1.34"
}
variable "auto_mode" {
  type        = bool
  default     = true
}
variable "builtin_node_pools" {
  type        = list(string)
  default     = ["general-purpose", "system"]
}
variable "endpoint_public_access" {
  type        = bool
  default     = true
}
variable "endpoint_private_access" {
  type        = bool
  default     = true
}
variable "public_access_cidrs" {
  type        = list(string)
  default     = ["0.0.0.0/0"]
  description = "LOCK DOWN IN PROD"
}
variable "cluster_log_types" {
  type        = list(string)
  default     = ["api", "audit", "authenticator"]
}
variable "admin_principal_arns" {
  type        = list(string)
  default     = []
  description = "Extra IAM roles that get kubectl admin"
}

# ----------------------------------------------------------------- node pool
variable "nodepool_name" {
  type        = string
  default     = "etl-workers"
}
variable "nodepool_capacity_types" {
  type        = list(string)
  default     = ["spot", "on-demand"]
}
variable "nodepool_arch" {
  type        = string
  default     = "amd64"
}
variable "nodepool_categories" {
  type        = list(string)
  default     = ["c", "m", "r"]
}
variable "nodepool_cpu_limit" {
  type        = number
  default     = 100
}
variable "nodepool_expire_after" {
  type        = string
  default     = "336h"
}

# ------------------------------------------------------------------- storage
variable "s3_bucket_override" {
  type        = string
  default     = ""
}
variable "s3_raw_prefix" {
  type        = string
  default     = "raw/"
}
variable "s3_curated_prefix" {
  type        = string
  default     = "curated/"
}
variable "s3_versioning" {
  type        = bool
  default     = true
}
variable "s3_glacier_after_days" {
  type        = number
  default     = 90
}
variable "s3_expire_after_days" {
  type        = number
  default     = 730
}

# --------------------------------------------------------------------- kafka
variable "kafka_backend" {
  type        = string
  default     = "in-cluster"
  description = "msk | in-cluster"
}
variable "kafka_topic_raw" {
  type        = string
  default     = "retail.sales.raw"
}
variable "kafka_topic_dlq" {
  type        = string
  default     = "retail.sales.dlq"
}
variable "kafka_partitions" {
  type        = number
  default     = 6
}
variable "kafka_consumer_group" {
  type        = string
  default     = "etl-worker"
}

# -------------------------------------------------------------------- search
variable "opensearch_enabled" {
  type        = bool
  default     = true
}
variable "opensearch_engine_version" {
  type        = string
  default     = "OpenSearch_2.19"
}
variable "opensearch_instance_type" {
  type        = string
  default     = "t3.small.search"
}
variable "opensearch_instance_count" {
  type        = number
  default     = 1
}
variable "opensearch_volume_gb" {
  type        = number
  default     = 20
}
variable "opensearch_index" {
  type        = string
  default     = "sales-events"
}
variable "opensearch_master_user" {
  type        = string
  default     = "osadmin"
}

# ---------------------------------------------------------------------- apps
variable "app_namespace" {
  type        = string
  default     = "shop-etl"
}
variable "app_service_account" {
  type        = string
  default     = "etl-app"
}
variable "image_tag" {
  type        = string
  default     = "v1"
}
variable "web_replicas" {
  type        = number
  default     = 2
}
variable "producer_replicas" {
  type        = number
  default     = 2
}
variable "worker_min_replicas" {
  type        = number
  default     = 0
}
variable "worker_max_replicas" {
  type        = number
  default     = 20
}
variable "keda_lag_threshold" {
  type        = number
  default     = 50
}
variable "keda_version" {
  type        = string
  default     = "2.17.1"
}
variable "keda_enabled" {
  type        = bool
  default     = true
}
variable "nifi_enabled" {
  type        = bool
  default     = true
}
variable "nifi_version" {
  type        = string
  default     = "2.6.0"
}
variable "nifi_storage_gb" {
  type        = number
  default     = 20
}
variable "alb_scheme" {
  type        = string
  default     = "internet-facing"
}
variable "alb_class_name" {
  type        = string
  default     = "eks-auto-alb"
}
variable "deploy_k8s_workloads" {
  type        = bool
  default     = true
  description = "false = infra only"
}
