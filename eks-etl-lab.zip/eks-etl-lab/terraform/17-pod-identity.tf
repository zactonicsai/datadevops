# 17 - Bind ServiceAccount -> IAM role. One line of glue, huge security win:
# no AWS access keys exist anywhere in the cluster.
resource "aws_eks_pod_identity_association" "app" {
  cluster_name    = aws_eks_cluster.this.name
  namespace       = var.app_namespace
  service_account = var.app_service_account
  role_arn        = aws_iam_role.app.arn
}
