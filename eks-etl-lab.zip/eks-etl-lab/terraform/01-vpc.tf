# 01 - VPC: the private network everything else lives inside.
resource "aws_vpc" "this" {
  cidr_block           = var.vpc_cidr
  enable_dns_support   = true    # required by EKS
  enable_dns_hostnames = true    # required by EKS
  tags = { Name = "${local.name_prefix}-vpc" }
}
