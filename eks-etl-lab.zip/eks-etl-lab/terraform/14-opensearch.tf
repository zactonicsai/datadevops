# 14 - OPENSEARCH. The "fast, recent, searchable" half of the storage story.
resource "random_password" "opensearch" {
  count            = var.opensearch_enabled ? 1 : 0
  length           = 20
  special          = true
  override_special = "!#$%"
  min_upper        = 1
  min_lower        = 1
  min_numeric      = 1
  min_special      = 1
}

resource "aws_secretsmanager_secret" "opensearch" {
  count                   = var.opensearch_enabled ? 1 : 0
  name                    = "${local.name_prefix}/opensearch/master"
  recovery_window_in_days = 0
}

resource "aws_secretsmanager_secret_version" "opensearch" {
  count     = var.opensearch_enabled ? 1 : 0
  secret_id = aws_secretsmanager_secret.opensearch[0].id
  secret_string = jsonencode({
    username = var.opensearch_master_user
    password = random_password.opensearch[0].result
  })
}

resource "aws_opensearch_domain" "this" {
  count          = var.opensearch_enabled ? 1 : 0
  domain_name    = "${local.name_prefix}-search"
  engine_version = var.opensearch_engine_version

  cluster_config {
    instance_type            = var.opensearch_instance_type
    instance_count           = var.opensearch_instance_count
    zone_awareness_enabled   = var.opensearch_instance_count > 1
    dedicated_master_enabled = false
  }

  ebs_options {
    ebs_enabled = true
    volume_type = "gp3"
    volume_size = var.opensearch_volume_gb
  }

  encrypt_at_rest {
    enabled = true
  }

  node_to_node_encryption {
    enabled = true
  }

  domain_endpoint_options {
    enforce_https       = true
    tls_security_policy = "Policy-Min-TLS-1-2-2019-07"
  }

  advanced_security_options {
    enabled                        = true
    internal_user_database_enabled = true
    master_user_options {
      master_user_name     = var.opensearch_master_user
      master_user_password = random_password.opensearch[0].result
    }
  }

  access_policies = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { AWS = "*" }
      Action    = "es:*"
      Resource  = "arn:aws:es:${var.aws_region}:${data.aws_caller_identity.current.account_id}:domain/${local.name_prefix}-search/*"
    }]
  })
}

locals {
  opensearch_endpoint = var.opensearch_enabled ? "https://${aws_opensearch_domain.this[0].endpoint}" : ""
  opensearch_arn      = var.opensearch_enabled ? aws_opensearch_domain.this[0].arn : "arn:aws:es:*:*:domain/none"
}
