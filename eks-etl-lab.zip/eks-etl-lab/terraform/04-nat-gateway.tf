# 04 - NAT GATEWAY: private pods can call out, internet cannot call in.
# COST: ~$32/month each plus per-GB. single_nat_gateway=true for labs.
resource "aws_eip" "nat" {
  count  = local.nat_gateway_count
  domain = "vpc"
  tags   = { Name = "${local.name_prefix}-nat-${count.index}-eip" }
}

resource "aws_nat_gateway" "this" {
  count         = local.nat_gateway_count
  allocation_id = aws_eip.nat[count.index].id
  subnet_id     = aws_subnet.public[count.index].id
  tags          = { Name = "${local.name_prefix}-nat-${count.index}" }
  depends_on    = [aws_internet_gateway.this]
}
