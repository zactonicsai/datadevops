# 16 - LEAST-PRIVILEGE ROLE FOR THE ETL PODS.
# Trust = pods.eks.amazonaws.com  ->  this is EKS Pod Identity, not IRSA.
# Pod Identity is simpler: no OIDC provider, no per-cluster trust rewriting.
data "aws_iam_policy_document" "app_assume" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole", "sts:TagSession"]
    principals {
      type        = "Service"
      identifiers = ["pods.eks.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "app" {
  name               = "${local.name_prefix}-etl-app-role"
  assume_role_policy = data.aws_iam_policy_document.app_assume.json
}

data "aws_iam_policy_document" "app" {
  statement {
    sid       = "ListTheBucket"
    actions   = ["s3:ListBucket", "s3:GetBucketLocation"]
    resources = [aws_s3_bucket.lake.arn]
  }
  statement {
    sid       = "ReadWriteObjects"
    actions   = ["s3:PutObject", "s3:GetObject", "s3:DeleteObject", "s3:AbortMultipartUpload"]
    resources = ["${aws_s3_bucket.lake.arn}/*"]
  }
  statement {
    sid       = "KafkaCluster"
    actions   = ["kafka-cluster:Connect", "kafka-cluster:DescribeCluster", "kafka-cluster:AlterCluster"]
    resources = [local.kafka_arn]
  }
  statement {
    sid       = "KafkaTopicsAndGroups"
    actions   = ["kafka-cluster:*Topic*", "kafka-cluster:WriteData", "kafka-cluster:ReadData",
                 "kafka-cluster:AlterGroup", "kafka-cluster:DescribeGroup"]
    resources = ["*"]
  }
  statement {
    sid       = "OpenSearchWrite"
    actions   = ["es:ESHttpPost", "es:ESHttpPut", "es:ESHttpGet", "es:ESHttpHead"]
    resources = ["${local.opensearch_arn}/*"]
  }
}

resource "aws_iam_role_policy" "app" {
  name   = "${local.name_prefix}-etl-access"
  role   = aws_iam_role.app.id
  policy = data.aws_iam_policy_document.app.json
}
