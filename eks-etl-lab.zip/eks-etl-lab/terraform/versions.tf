# Pin every provider. "It worked yesterday" is not a deployment strategy.
terraform {
  required_version = ">= 1.9.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.70"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.33"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 2.16"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }

  # Uncomment for team use. State in S3 = everyone sees the same truth.
  # backend "s3" {
  #   bucket       = "my-tfstate-bucket"
  #   key          = "shopetl/lab/terraform.tfstate"
  #   region       = "us-east-1"
  #   encrypt      = true
  #   use_lockfile = true      # S3 native locking, replaces DynamoDB
  # }
}
