# 20 - KEDA via Helm. The autoscaler that watches Kafka lag, not CPU.
resource "helm_release" "keda" {
  count            = var.deploy_k8s_workloads && var.keda_enabled ? 1 : 0
  name             = "keda"
  repository       = "https://kedacore.github.io/charts"
  chart            = "keda"
  version          = var.keda_version
  namespace        = "keda"
  create_namespace = true
  wait             = true
  timeout          = 600
  depends_on       = [aws_eks_cluster.this]
}
