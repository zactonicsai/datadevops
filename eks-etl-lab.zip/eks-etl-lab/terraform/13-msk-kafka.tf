# 13 - MSK SERVERLESS. Only created when kafka_backend = "msk".
# Serverless means: no broker sizing, no storage planning, IAM auth only.
resource "aws_msk_serverless_cluster" "this" {
  count        = var.kafka_backend == "msk" ? 1 : 0
  cluster_name = "${local.name_prefix}-kafka"

  vpc_config {
    subnet_ids         = aws_subnet.private[*].id
    security_group_ids = [aws_security_group.kafka.id]
  }

  client_authentication {
    sasl {
      iam {
        enabled = true
      }
    }
  }
}

data "aws_msk_bootstrap_brokers" "this" {
  count       = var.kafka_backend == "msk" ? 1 : 0
  cluster_arn = aws_msk_serverless_cluster.this[0].arn
}

locals {
  kafka_bootstrap = var.kafka_backend == "msk" ? try(data.aws_msk_bootstrap_brokers.this[0].bootstrap_brokers_sasl_iam, "") : "kafka.${var.app_namespace}.svc.cluster.local:9092"
  kafka_auth      = var.kafka_backend == "msk" ? "AWS_MSK_IAM" : "PLAINTEXT"
  kafka_arn       = var.kafka_backend == "msk" ? aws_msk_serverless_cluster.this[0].arn : "arn:aws:kafka:*:*:cluster/none/*"
}
