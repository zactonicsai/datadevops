# 23 - The ScaledObject: "size the worker deployment by Kafka backlog."
resource "kubernetes_manifest" "scaledobject" {
  count = var.deploy_k8s_workloads && var.keda_enabled ? 1 : 0
  manifest = {
    apiVersion = "keda.sh/v1alpha1"
    kind       = "ScaledObject"
    metadata = {
      name      = "worker-scaler"
      namespace = var.app_namespace
    }
    spec = {
      scaleTargetRef  = { name = "worker" }
      minReplicaCount = var.worker_min_replicas
      maxReplicaCount = var.worker_max_replicas
      pollingInterval = 15
      cooldownPeriod  = 120
      triggers = [{
        type = "kafka"
        metadata = {
          bootstrapServers  = local.kafka_bootstrap
          consumerGroup     = var.kafka_consumer_group
          topic             = var.kafka_topic_raw
          lagThreshold      = tostring(var.keda_lag_threshold)
          offsetResetPolicy = "earliest"
          allowIdleConsumers = "false"
        }
      }]
    }
  }
  depends_on = [helm_release.keda, kubernetes_deployment.worker]
}
