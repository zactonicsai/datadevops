# 09 - THE CLUSTER. Three blocks turn Auto Mode on:
#   compute_config / kubernetes_network_config / storage_config
resource "aws_eks_cluster" "this" {
  name     = local.cluster_name
  version  = var.k8s_version
  role_arn = aws_iam_role.cluster.arn

  vpc_config {
    subnet_ids              = concat(aws_subnet.private[*].id, aws_subnet.public[*].id)
    security_group_ids      = [aws_security_group.cluster.id]
    endpoint_public_access  = var.endpoint_public_access
    endpoint_private_access = var.endpoint_private_access
    public_access_cidrs     = var.public_access_cidrs
  }

  access_config {
    authentication_mode                         = "API"
    bootstrap_cluster_creator_admin_permissions = true
  }

  compute_config {
    enabled       = var.auto_mode
    node_pools    = var.auto_mode ? var.builtin_node_pools : []
    node_role_arn = var.auto_mode ? aws_iam_role.node.arn : null
  }

  kubernetes_network_config {
    elastic_load_balancing {
      enabled = var.auto_mode
    }
  }

  storage_config {
    block_storage {
      enabled = var.auto_mode
    }
  }

  enabled_cluster_log_types = var.cluster_log_types

  depends_on = [
    aws_iam_role_policy_attachment.cluster,
    aws_iam_role_policy_attachment.node,
    aws_route_table_association.private,
  ]
}
