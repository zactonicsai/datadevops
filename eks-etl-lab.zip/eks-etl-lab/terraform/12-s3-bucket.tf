# 12 - S3 DATA LAKE. Six separate resources, because AWS split the old
# monolithic bucket resource into one-concern-each pieces. That is a good
# thing: you can see at a glance whether encryption is on.
resource "aws_s3_bucket" "lake" {
  bucket = local.s3_bucket
}

resource "aws_s3_bucket_public_access_block" "lake" {
  bucket                  = aws_s3_bucket.lake.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_server_side_encryption_configuration" "lake" {
  bucket = aws_s3_bucket.lake.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
    bucket_key_enabled = true
  }
}

resource "aws_s3_bucket_versioning" "lake" {
  bucket = aws_s3_bucket.lake.id
  versioning_configuration {
    status = var.s3_versioning ? "Enabled" : "Suspended"
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "lake" {
  bucket = aws_s3_bucket.lake.id

  rule {
    id     = "raw-to-glacier"
    status = "Enabled"
    filter {
      prefix = var.s3_raw_prefix
    }
    transition {
      days          = var.s3_glacier_after_days
      storage_class = "GLACIER_IR"
    }
    expiration {
      days = var.s3_expire_after_days
    }
  }

  rule {
    id     = "abort-failed-uploads"
    status = "Enabled"
    filter {}
    abort_incomplete_multipart_upload {
      days_after_initiation = 7
    }
  }
}
