# Locals are Terraform's "computed variables": derived once, used everywhere.
data "aws_caller_identity" "current" {}
data "aws_availability_zones" "available" {
  state = "available"
  filter {
    name   = "opt-in-status"
    values = ["opt-in-not-required"]
  }
}

resource "random_string" "suffix" {
  length  = 6
  special = false
  upper   = false
}

locals {
  name_prefix  = "${var.project}-${var.environment}"
  cluster_name = var.cluster_name_override != "" ? var.cluster_name_override : "${local.name_prefix}-eks"
  s3_bucket    = var.s3_bucket_override    != "" ? var.s3_bucket_override    : "${local.name_prefix}-datalake-${random_string.suffix.result}"

  azs             = slice(data.aws_availability_zones.available.names, 0, var.az_count)
  public_cidrs    = slice(var.public_subnet_cidrs,  0, var.az_count)
  private_cidrs   = slice(var.private_subnet_cidrs, 0, var.az_count)
  nat_gateway_count = var.single_nat_gateway ? 1 : var.az_count

  tags = {
    Project     = var.project
    Environment = var.environment
    Owner       = var.owner
    CostCenter  = var.cost_center
    ManagedBy   = "terraform"
  }
}
