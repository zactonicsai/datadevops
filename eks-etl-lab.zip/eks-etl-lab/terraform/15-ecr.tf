# 15 - ECR: one private image repo per app.
locals {
  ecr_repos = ["web", "producer", "worker", "enrich"]
}

resource "aws_ecr_repository" "apps" {
  for_each             = toset(local.ecr_repos)
  name                 = "${local.name_prefix}/${each.value}"
  image_tag_mutability = "IMMUTABLE"   # a tag always means the same bytes

  image_scanning_configuration {
    scan_on_push = true
  }

  encryption_configuration {
    encryption_type = "AES256"
  }
}

resource "aws_ecr_lifecycle_policy" "apps" {
  for_each   = aws_ecr_repository.apps
  repository = each.value.name
  policy = jsonencode({
    rules = [{
      rulePriority = 1
      description  = "keep last 20 images"
      selection = {
        tagStatus   = "any"
        countType   = "imageCountMoreThan"
        countNumber = 20
      }
      action = { type = "expire" }
    }]
  })
}
