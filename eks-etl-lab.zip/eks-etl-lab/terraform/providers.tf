provider "aws" {
  region  = var.aws_region
  profile = var.aws_profile
  # Every resource gets these tags automatically. Never hand-tag again.
  default_tags {
    tags = local.tags
  }
}

# These two only work AFTER the cluster exists. Terraform figures out the
# ordering by itself because they reference aws_eks_cluster.this.
provider "kubernetes" {
  host                   = aws_eks_cluster.this.endpoint
  cluster_ca_certificate = base64decode(aws_eks_cluster.this.certificate_authority[0].data)
  exec {
    api_version = "client.authentication.k8s.io/v1beta1"
    command     = "aws"
    args        = ["eks", "get-token", "--cluster-name", aws_eks_cluster.this.name,
                   "--region", var.aws_region]
  }
}

provider "helm" {
  kubernetes {
    host                   = aws_eks_cluster.this.endpoint
    cluster_ca_certificate = base64decode(aws_eks_cluster.this.certificate_authority[0].data)
    exec {
      api_version = "client.authentication.k8s.io/v1beta1"
      command     = "aws"
      args        = ["eks", "get-token", "--cluster-name", aws_eks_cluster.this.name,
                     "--region", var.aws_region]
    }
  }
}
