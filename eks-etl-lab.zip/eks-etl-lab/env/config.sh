#!/usr/bin/env bash
# =============================================================================
# env/config.sh  --  THE ONE PLACE WHERE EVERYTHING IS NAMED
# =============================================================================
# Every CLI script starts by sourcing this file. Nothing is hard-coded anywhere
# else. To build a second, third or tenth copy of this stack you do NOT edit
# any script -- you only change variables.
#
# Three ways to change a value (highest priority wins):
#   1. Export it in your shell:   export CLUSTER_NAME=shop-prod
#   2. Use an env file:           cp env/lab.env.example env/my.env
#                                 ENV_FILE=env/my.env ./cli/01-vpc.sh
#   3. Edit the default below.
#
# The ":${VAR:=default}" syntax means "if VAR already has a value, keep it,
# otherwise use this default". That single trick is what makes this a TEMPLATE
# instead of a one-off script.
# =============================================================================

# ---- Load an optional env file FIRST so it can override these defaults ------
ENV_FILE="${ENV_FILE:-}"
if [ -n "$ENV_FILE" ] && [ -f "$ENV_FILE" ]; then
  set -a                 # auto-export everything defined in the file
  # shellcheck disable=SC1090
  . "$ENV_FILE"
  set +a
fi

# ---------------------------------------------------------------- 1. IDENTITY
: "${PROJECT:=shopetl}"          # short name, goes in front of every resource
: "${ENVIRONMENT:=lab}"          # lab | dev | stage | prod
: "${OWNER:=platform-team}"      # shows up in tags and in the billing report
: "${COST_CENTER:=CC-1234}"

# NAME_PREFIX is what every resource is called. Change PROJECT or ENVIRONMENT
# and the whole stack gets a fresh set of names -> no collisions, ever.
: "${NAME_PREFIX:=${PROJECT}-${ENVIRONMENT}}"

# ---------------------------------------------------------------- 2. LOCATION
: "${AWS_REGION:=us-east-1}"
: "${AWS_PROFILE:=default}"
export AWS_REGION AWS_PROFILE
: "${AZ_COUNT:=2}"               # 2 = minimum for EKS, 3 = production answer

# ----------------------------------------------------------------- 3. NETWORK
: "${VPC_CIDR:=10.42.0.0/16}"                       # 65,536 addresses
: "${PUBLIC_SUBNET_CIDRS:=10.42.0.0/20,10.42.16.0/20,10.42.32.0/20}"
: "${PRIVATE_SUBNET_CIDRS:=10.42.64.0/19,10.42.96.0/19,10.42.128.0/19}"
: "${SINGLE_NAT_GATEWAY:=true}"  # true = cheap (1 NAT), false = HA (1 per AZ)
: "${ENABLE_FLOW_LOGS:=false}"   # true in prod; costs money

# ----------------------------------------------------------------- 4. CLUSTER
: "${CLUSTER_NAME:=${NAME_PREFIX}-eks}"
: "${K8S_VERSION:=1.34}"
: "${AUTO_MODE:=true}"                              # EKS Auto Mode on/off
: "${BUILTIN_NODE_POOLS:=general-purpose,system}"   # comma list, or empty
: "${ENDPOINT_PUBLIC_ACCESS:=true}"                 # false = private only
: "${ENDPOINT_PRIVATE_ACCESS:=true}"
: "${PUBLIC_ACCESS_CIDRS:=0.0.0.0/0}"               # LOCK THIS DOWN IN PROD
: "${CLUSTER_LOG_TYPES:=api,audit,authenticator}"

# Your own node pool, on top of the built-in ones
: "${NODEPOOL_NAME:=etl-workers}"
: "${NODEPOOL_CAPACITY_TYPE:=spot,on-demand}"       # spot first = ~70% cheaper
: "${NODEPOOL_ARCH:=amd64}"
: "${NODEPOOL_INSTANCE_CATEGORIES:=c,m,r}"
: "${NODEPOOL_CPU_LIMIT:=100}"                      # hard ceiling, safety net
: "${NODEPOOL_EXPIRE_AFTER:=336h}"                  # recycle nodes every 14 days

# ----------------------------------------------------------------- 5. STORAGE
: "${S3_BUCKET:=${NAME_PREFIX}-datalake}"           # must be globally unique
: "${S3_RAW_PREFIX:=raw/}"
: "${S3_CURATED_PREFIX:=curated/}"
: "${S3_VERSIONING:=true}"
: "${S3_GLACIER_AFTER_DAYS:=90}"
: "${S3_EXPIRE_AFTER_DAYS:=730}"

# ------------------------------------------------------------------- 6. KAFKA
# msk        = Amazon MSK Serverless  (managed, IAM auth, ~$0.75/hr minimum)
# in-cluster = single Kafka pod       (nearly free, perfect for learning)
: "${KAFKA_BACKEND:=in-cluster}"
: "${KAFKA_CLUSTER_NAME:=${NAME_PREFIX}-kafka}"
: "${KAFKA_TOPIC_RAW:=retail.sales.raw}"
: "${KAFKA_TOPIC_DLQ:=retail.sales.dlq}"
: "${KAFKA_PARTITIONS:=6}"
: "${KAFKA_REPLICATION:=1}"                          # 3 for MSK / production
: "${KAFKA_CONSUMER_GROUP:=etl-worker}"

# ------------------------------------------------------------------ 7. SEARCH
: "${OPENSEARCH_DOMAIN:=${NAME_PREFIX}-search}"
: "${OPENSEARCH_ENGINE_VERSION:=OpenSearch_2.19}"
: "${OPENSEARCH_INSTANCE_TYPE:=t3.small.search}"
: "${OPENSEARCH_INSTANCE_COUNT:=1}"                  # 3 in production
: "${OPENSEARCH_VOLUME_GB:=20}"
: "${OPENSEARCH_INDEX:=sales-events}"
: "${OPENSEARCH_MASTER_USER:=osadmin}"
# Leave the password empty: the script generates one and stores it in AWS
# Secrets Manager. Never type a real password into a git repo.
: "${OPENSEARCH_MASTER_PASSWORD:=}"

# -------------------------------------------------------------------- 8. APPS
: "${APP_NAMESPACE:=shop-etl}"
: "${ECR_REPO_PREFIX:=${NAME_PREFIX}}"
: "${IMAGE_TAG:=v1}"
: "${WEB_REPLICAS:=2}"
: "${PRODUCER_REPLICAS:=2}"
: "${WORKER_MIN_REPLICAS:=0}"      # KEDA scales to zero -> $0 while idle
: "${WORKER_MAX_REPLICAS:=20}"
: "${KEDA_LAG_THRESHOLD:=50}"      # waiting messages per pod before scale-up
: "${KEDA_VERSION:=2.17.1}"
: "${NIFI_ENABLED:=true}"
: "${NIFI_VERSION:=2.6.0}"
: "${NIFI_STORAGE_GB:=20}"
: "${NIFI_ADMIN_USER:=nifiadmin}"

# -------------------------------------------------------------------- 9. TAGS
# Three shapes of the same tags, because different AWS commands want different
# formats. Defined with plain ifs (not ${VAR:=...}) so the braces stay safe.
if [ -z "${TAGS_INLINE:-}" ]; then
  # for: --tag-specifications "ResourceType=vpc,Tags=[{Key=Name,Value=x},$TAGS_INLINE]"
  TAGS_INLINE="{Key=Project,Value=${PROJECT}},{Key=Environment,Value=${ENVIRONMENT}},{Key=Owner,Value=${OWNER}},{Key=CostCenter,Value=${COST_CENTER}},{Key=ManagedBy,Value=aws-cli}"
fi
if [ -z "${TAGS_SPACED:-}" ]; then
  # for: --tags $TAGS_SPACED     (ec2 create-tags style)
  TAGS_SPACED="Key=Project,Value=${PROJECT} Key=Environment,Value=${ENVIRONMENT} Key=Owner,Value=${OWNER} Key=CostCenter,Value=${COST_CENTER} Key=ManagedBy,Value=aws-cli"
fi
if [ -z "${TAGS_KV:-}" ]; then
  # for: --tags Project=x,Environment=y   (eks / s3 / opensearch style)
  TAGS_KV="Project=${PROJECT},Environment=${ENVIRONMENT},Owner=${OWNER},CostCenter=${COST_CENTER},ManagedBy=aws-cli"
fi
export TAGS_INLINE TAGS_SPACED TAGS_KV

# ----------------------------------------------------------------- 10. RUNTIME
# Where scripts write down the IDs they created so the next script can read
# them. Think of it as the project's shared notebook.
: "${STATE_DIR:=${REPO_ROOT:-$PWD}/.state/${NAME_PREFIX}}"
: "${DRY_RUN:=false}"            # true = print the commands, change nothing
