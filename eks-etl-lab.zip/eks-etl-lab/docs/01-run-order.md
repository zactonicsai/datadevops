# Why this order? (dependency map)

Resources form a dependency tree. You build leaves-last going up, and delete
leaves-first coming down. If a script fails, fix the cause and re-run it —
every script is idempotent — then continue with `./run-all.sh <number>`.

```
00 preflight
01 VPC ──┬── 02 subnets ──┬── 03 IGW ── 04 NAT ── 05 routes
         │                └── (tags read later by the ALB controller)
         └── 06 security groups
07 cluster role ─┐
08 node role ────┼── 09 EKS CLUSTER ── 10 access entry ── 11 kubeconfig
02+06 ───────────┘        │
12 S3   (independent)     │
13 Kafka (needs 02,06)    │
14 OpenSearch             │
15 ECR  (independent)     │
12+13+14 ── 16 app role ──┼── 17 pod identity
                          ├── 18 nodepool      (kubectl works from 11)
                          ├── 19 ingressclass
                          ├── 20 KEDA
                          ├── 21 kafka pod + topics
                          ├── 22 NiFi
                          └── 23 apps ── (Ingress ⇒ AWS builds the ALB) ── 24 verify
```

Destroy = the same picture upside down. `99-destroy.sh` deletes the Ingress
first (so Auto Mode removes the ALB), then the cluster, then the stores, then
NAT/EIP (the money leaks), then network, then IAM.

Common failure points:
- **09 stuck CREATING >20 min** — usually bad subnet routing; check 05 ran.
- **24 no ALB hostname** — `kubectl describe ingress shop-ingress -n shop-etl`;
  most often the subnet `kubernetes.io/role/elb` tags are missing (step 02).
- **Worker pods Pending** — the nodepool taint/toleration must match; check
  `kubectl describe pod` and `kubectl get nodeclaims`.
