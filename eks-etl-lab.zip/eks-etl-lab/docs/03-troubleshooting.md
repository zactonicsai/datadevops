# Troubleshooting quick hits

| Symptom | Likely cause | Fix |
|---|---|---|
| `kubectl` says Unauthorized | Access entry missing for your role | re-run `cli/10-access-entry.sh`, or set `ADMIN_PRINCIPAL_ARN` |
| 0 nodes forever | No pods requesting capacity | deploy something; Auto Mode is demand-driven |
| Ingress has no ADDRESS | subnet tags / IngressClassParams | check step 02 tags; `kubectl describe ingress` events |
| Worker CrashLoopBackOff | Kafka not up yet, or bad OpenSearch endpoint | `kubectl logs -l app=worker -n shop-etl`; re-run 21 |
| KEDA not scaling | ScaledObject can't reach Kafka | `kubectl describe scaledobject worker-scaler -n shop-etl` |
| MSK topic auth errors | app role missing kafka-cluster perms | re-run 16 after 13 recorded `kafka_arn` |
| `terraform apply` fails on kubernetes_manifest at first run | CRDs need the cluster live | apply with `-var deploy_k8s_workloads=false` first |
| Bill higher than expected | NAT, OpenSearch, forgotten cluster | `cli/99-destroy.sh`, then check EC2 → Elastic IPs |
