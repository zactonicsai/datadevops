# Building the NiFi flow (Kafka → S3 → API → OpenSearch), click by click

NiFi is the same ETL as our Python worker, drawn as boxes. Open the UI:

```bash
kubectl -n shop-etl port-forward svc/nifi 8443:8443
# https://localhost:8443/nifi  — user/password printed by cli/22-nifi.sh
```

Drag five processors onto the canvas and connect them in order:

1. **ConsumeKafka**  — Kafka Brokers: `kafka.shop-etl.svc.cluster.local:9092`,
   Topic: `retail.sales.raw`, Group ID: `nifi-etl` (a *different* group than
   the Python worker, so both get every message — that's Kafka fan-out).
2. **JoltTransformJSON** — the "T". Example spec that renames and uppercases:
   ```json
   [{ "operation": "modify-overwrite-beta",
      "spec": { "store_id": "=toUpper", "sku": "=toUpper" } }]
   ```
3. **InvokeHTTP** — POST to `http://enrich.shop-etl.svc.cluster.local:8080/enrich`
   (wrap the record in `[]` first with ReplaceText, or use a Record-oriented
   processor set in a real build). This is the "API call" step.
4. **PutS3Object** — Bucket: your `${S3_BUCKET}`, Object Key:
   `nifi/dt=${now():format('yyyy-MM-dd')}/${uuid}.json`, Region: your region.
   Credentials: leave keys EMPTY — the pod's service account provides them
   via Pod Identity (Default Credentials chain). No keys, ever.
5. **PutElasticsearchJson** (works with OpenSearch) — URL: your
   `${OPENSEARCH_ENDPOINT}`, Index: `sales-events-nifi`, and basic auth from
   the Secrets Manager credentials.

Route each processor's `failure` relationship into a funnel or a retry loop —
in NiFi, drawing the failure path is the equivalent of our dead-letter topic.

Right-click the canvas → Start. Submit a sale on the web page and watch the
counters on each box tick up. That moving number is your data flowing.
