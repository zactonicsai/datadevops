"""
PRODUCER  --  HTTP in, Kafka out. That is the entire job.

Why so small? Because the shop till must never wait for the data warehouse.
This service answers in a few milliseconds and hands the message to Kafka.
If OpenSearch is down, or S3 is slow, or NiFi is being upgraded, the till
still works. That decoupling IS the point of a queue.
"""
import json, os, socket, time, uuid, logging
from flask import Flask, request, jsonify
from kafka import KafkaProducer

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("producer")

BOOTSTRAP = os.environ["KAFKA_BOOTSTRAP"]
AUTH      = os.environ.get("KAFKA_AUTH", "PLAINTEXT")
TOPIC     = os.environ.get("KAFKA_TOPIC_RAW", "retail.sales.raw")
REGION    = os.environ.get("AWS_REGION", "us-east-1")

def build_producer():
    common = dict(
        bootstrap_servers=BOOTSTRAP.split(","),
        value_serializer=lambda v: json.dumps(v).encode(),
        key_serializer=lambda k: k.encode() if k else None,
        acks="all",            # wait for all replicas -> do not lose sales
        retries=5,
        linger_ms=20,          # tiny wait to batch messages = big throughput win
        compression_type="gzip",
    )
    if AUTH == "AWS_MSK_IAM":
        from aws_msk_iam_sasl_signer import MSKAuthTokenProvider
        class Provider:
            def token(self):
                t, _ = MSKAuthTokenProvider.generate_auth_token(REGION)
                return t
        common.update(security_protocol="SASL_SSL", sasl_mechanism="OAUTHBEARER",
                      sasl_oauth_token_provider=Provider())
    return KafkaProducer(**common)

producer = None
app = Flask(__name__)

@app.get("/healthz")
def healthz():
    return "ok", 200

@app.post("/api/sales")
def sales():
    global producer
    if producer is None:
        producer = build_producer()

    body = request.get_json(force=True, silent=True) or {}

    # --- validation: reject bad data HERE, at the front door -----------------
    # Cleaning data at the end of a pipeline is 100x more expensive than
    # refusing it at the start. This is the "shift left" rule of data quality.
    required = ("store_id", "sku", "qty", "unit_price")
    missing = [f for f in required if f not in body]
    if missing:
        return jsonify(error="missing fields", fields=missing), 400
    try:
        qty = int(body["qty"]); price = float(body["unit_price"])
    except (TypeError, ValueError):
        return jsonify(error="qty must be an integer and unit_price a number"), 400
    if qty <= 0 or price < 0:
        return jsonify(error="qty must be > 0 and unit_price >= 0"), 400

    event = {
        "event_id":    str(uuid.uuid4()),   # lets us de-duplicate later
        "event_type":  "sale",
        "schema_version": 1,                # ALWAYS version your events
        "occurred_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "store_id":    body["store_id"],
        "sku":         body["sku"],
        "qty":         qty,
        "unit_price":  round(price, 2),
        "total":       round(qty * price, 2),
        "payment":     body.get("payment", "unknown"),
        "source_host": socket.gethostname(),
    }

    # The KEY decides the partition. Same store -> same partition -> events for
    # one store always arrive in order. Pick your key carefully: it is the one
    # design choice you cannot change later without reprocessing everything.
    fut = producer.send(TOPIC, key=event["store_id"], value=event)
    meta = fut.get(timeout=10)
    log.info("sent %s to %s[%d]@%d", event["event_id"], meta.topic, meta.partition, meta.offset)
    return jsonify(event_id=event["event_id"], partition=meta.partition, offset=meta.offset), 202
