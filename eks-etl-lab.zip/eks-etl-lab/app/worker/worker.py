"""
WORKER  --  the actual ETL job. This is the piece KEDA scales.

   Kafka  ->  clean/validate  ->  S3 raw  ->  enrich API  ->  S3 curated
                                                          ->  OpenSearch

Design rules baked in here, all of which come from real production pain:

 1. BATCH, do not stream one row at a time.
    200 rows in one S3 object beats 200 tiny objects. S3 charges per request,
    and Athena/Spark hate "small file" datasets.

 2. Commit offsets AFTER the data is safely stored, never before.
    That gives at-least-once delivery: a crash means we redo work, not lose it.
    Every event carries event_id so the destination can de-duplicate.

 3. Partition the S3 path by date: raw/dt=2026-08-03/hour=14/...
    Query engines skip whole folders. This one habit is the difference between
    a 3 second query and a 3 minute one.

 4. A poison message must not stop the pipeline.
    Anything unparseable goes to the dead-letter topic and we move on.

 5. Handle SIGTERM. Spot nodes get 2 minutes' warning; finish the batch.
"""
import json, os, io, gzip, signal, sys, time, logging, datetime as dt
from collections import defaultdict

import boto3, requests
from kafka import KafkaConsumer, KafkaProducer

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("worker")

BOOTSTRAP   = os.environ["KAFKA_BOOTSTRAP"]
AUTH        = os.environ.get("KAFKA_AUTH", "PLAINTEXT")
TOPIC       = os.environ.get("KAFKA_TOPIC_RAW", "retail.sales.raw")
DLQ         = os.environ.get("KAFKA_TOPIC_DLQ", "retail.sales.dlq")
GROUP       = os.environ.get("KAFKA_CONSUMER_GROUP", "etl-worker")
REGION      = os.environ.get("AWS_REGION", "us-east-1")
BUCKET      = os.environ["S3_BUCKET"]
RAW_PREFIX  = os.environ.get("S3_RAW_PREFIX", "raw/")
CUR_PREFIX  = os.environ.get("S3_CURATED_PREFIX", "curated/")
ENRICH_URL  = os.environ.get("ENRICH_URL", "")
OS_ENDPOINT = os.environ.get("OPENSEARCH_ENDPOINT", "")
OS_INDEX    = os.environ.get("OPENSEARCH_INDEX", "sales-events")
BATCH_SIZE  = int(os.environ.get("BATCH_SIZE", "200"))
BATCH_SECS  = int(os.environ.get("BATCH_SECONDS", "30"))

s3 = boto3.client("s3", region_name=REGION)

running = True
def stop(signum, frame):
    global running
    log.info("signal %s received - finishing current batch then exiting", signum)
    running = False
signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)


# ----------------------------------------------------------------- KAFKA ----
def kafka_common():
    cfg = {"bootstrap_servers": BOOTSTRAP.split(",")}
    if AUTH == "AWS_MSK_IAM":
        from aws_msk_iam_sasl_signer import MSKAuthTokenProvider
        class Provider:
            def token(self):
                t, _ = MSKAuthTokenProvider.generate_auth_token(REGION)
                return t
        cfg.update(security_protocol="SASL_SSL", sasl_mechanism="OAUTHBEARER",
                   sasl_oauth_token_provider=Provider())
    return cfg

consumer = KafkaConsumer(
    TOPIC, group_id=GROUP,
    enable_auto_commit=False,          # rule 2: WE decide when to commit
    auto_offset_reset="earliest",
    max_poll_records=BATCH_SIZE,
    **kafka_common())

dlq = KafkaProducer(value_serializer=lambda v: json.dumps(v).encode(), **kafka_common())


# -------------------------------------------------------------- OPENSEARCH --
def opensearch_client():
    if not OS_ENDPOINT:
        return None
    from opensearchpy import OpenSearch, RequestsHttpConnection, AWSV4SignerAuth
    import boto3 as b3
    creds = b3.Session().get_credentials()
    host = OS_ENDPOINT.replace("https://", "").replace("http://", "").rstrip("/")
    return OpenSearch(
        hosts=[{"host": host, "port": 443}],
        http_auth=AWSV4SignerAuth(creds, REGION, "es"),
        use_ssl=True, verify_certs=True,
        connection_class=RequestsHttpConnection,
        pool_maxsize=20)

os_client = None


# ------------------------------------------------------------------ STEPS ---
def transform(raw):
    """Clean one record. Returns None if the record is unusable."""
    if raw.get("event_type") != "sale":
        return None
    if raw.get("schema_version") != 1:
        raise ValueError(f"unsupported schema_version {raw.get('schema_version')}")
    qty   = int(raw["qty"])
    price = float(raw["unit_price"])
    return {
        "event_id":   raw["event_id"],
        "occurred_at": raw["occurred_at"],
        "store_id":   raw["store_id"].strip().upper(),   # normalise, always
        "sku":        raw["sku"].strip().upper(),
        "qty":        qty,
        "unit_price": round(price, 2),
        "total":      round(qty * price, 2),
        "payment":    raw.get("payment", "unknown").lower(),
        "ingested_at": dt.datetime.now(dt.timezone.utc).isoformat(),
    }


def s3_key(prefix, when, suffix):
    """raw/dt=2026-08-03/hour=14/1754234-abc.json.gz   <- rule 3"""
    return (f"{prefix}dt={when:%Y-%m-%d}/hour={when:%H}/"
            f"{int(time.time()*1000)}-{os.getpid()}{suffix}")


def put_ndjson(prefix, rows, when):
    """Write newline-delimited JSON, gzipped. NDJSON is the lingua franca of
    data lakes: every tool reads it, and it streams line by line."""
    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode="wb") as gz:
        for r in rows:
            gz.write((json.dumps(r) + "\n").encode())
    key = s3_key(prefix, when, ".json.gz")
    s3.put_object(Bucket=BUCKET, Key=key, Body=buf.getvalue(),
                  ContentType="application/x-ndjson", ContentEncoding="gzip")
    log.info("wrote s3://%s/%s (%d rows)", BUCKET, key, len(rows))
    return key


def call_enrich(rows):
    """Rule: an external API is allowed to be slow or down. Time it out and
    degrade gracefully rather than blocking the whole pipeline."""
    if not ENRICH_URL:
        return rows
    try:
        r = requests.post(ENRICH_URL, json=rows, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as exc:                      # noqa: BLE001
        log.warning("enrich failed (%s) - continuing without enrichment", exc)
        for row in rows:
            row["enriched"] = False
        return rows


def index_opensearch(rows):
    """Bulk index. event_id is used as the document _id, which makes the whole
    pipeline idempotent: replaying the same event overwrites, never duplicates."""
    global os_client
    if not OS_ENDPOINT:
        return
    if os_client is None:
        os_client = opensearch_client()
    body = []
    for r in rows:
        body.append({"index": {"_index": OS_INDEX, "_id": r["event_id"]}})
        body.append(r)
    resp = os_client.bulk(body=body, refresh=False)
    if resp.get("errors"):
        bad = [i for i in resp["items"] if i.get("index", {}).get("error")]
        log.warning("opensearch: %d of %d docs failed", len(bad), len(rows))
    else:
        log.info("indexed %d docs into %s", len(rows), OS_INDEX)


# ------------------------------------------------------------------- LOOP ---
def main():
    log.info("worker up: topic=%s group=%s bucket=%s batch=%d/%ds",
             TOPIC, GROUP, BUCKET, BATCH_SIZE, BATCH_SECS)
    while running:
        batches = consumer.poll(timeout_ms=BATCH_SECS * 1000, max_records=BATCH_SIZE)
        raw_rows, clean_rows = [], []
        for tp, messages in batches.items():
            for m in messages:
                try:
                    obj = json.loads(m.value)
                    raw_rows.append(obj)
                    row = transform(obj)
                    if row:
                        clean_rows.append(row)
                except Exception as exc:                       # rule 4
                    log.error("poison message at %s[%d]@%d: %s", m.topic, m.partition, m.offset, exc)
                    dlq.send(DLQ, {"error": str(exc), "offset": m.offset,
                                   "partition": m.partition,
                                   "payload": m.value.decode("utf-8", "replace")})

        if not raw_rows:
            continue

        now = dt.datetime.now(dt.timezone.utc)
        put_ndjson(RAW_PREFIX, raw_rows, now)          # E: exactly what arrived
        if clean_rows:
            enriched = call_enrich(clean_rows)         # T: transform + enrich
            put_ndjson(CUR_PREFIX, enriched, now)      # L: load to the lake
            index_opensearch(enriched)                 # L: load to search

        dlq.flush()
        consumer.commit()                              # rule 2: commit LAST
        log.info("batch done: %d in, %d clean", len(raw_rows), len(clean_rows))

    log.info("draining and closing")
    consumer.close(); dlq.close()
    sys.exit(0)


if __name__ == "__main__":
    main()
