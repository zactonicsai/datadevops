"""
ENRICH  --  the "call another system" step that every real ETL has.

Real examples this stands in for:
  * a product catalogue API that turns SKU -> name, category, supplier
  * a tax service that knows the VAT rate for each store's country
  * a customer API that turns a loyalty card number into a segment
  * a currency service converting every sale into one reporting currency

Here it is a lookup table so the lab works offline, but the SHAPE is real:
one HTTP call per batch, with a timeout, and a safe fallback if it fails.
"""
import os
from flask import Flask, request, jsonify

app = Flask(__name__)

CATALOGUE = {
    "APPLE-GALA-1KG":  {"name": "Gala Apples 1kg",   "category": "produce", "vat_rate": 0.00},
    "MILK-SEMI-2L":    {"name": "Semi Skimmed 2L",   "category": "dairy",   "vat_rate": 0.00},
    "CHOC-DARK-100G":  {"name": "Dark Chocolate",    "category": "snacks",  "vat_rate": 0.20},
    "COFFEE-BEAN-500G":{"name": "Coffee Beans 500g", "category": "drinks",  "vat_rate": 0.20},
}
STORES = {
    "STORE-001": {"region": "north", "city": "Leeds",      "country": "GB"},
    "STORE-002": {"region": "south", "city": "Brighton",   "country": "GB"},
    "STORE-004": {"region": "hub",   "city": "Manchester", "country": "GB"},
}

@app.get("/healthz")
def healthz():
    return "ok", 200

@app.post("/enrich")
def enrich():
    """Accepts a LIST of events, returns the same list with extra fields.
    Batching matters: 1 call for 200 rows beats 200 calls for 1 row."""
    events = request.get_json(force=True) or []
    out = []
    for e in events:
        prod  = CATALOGUE.get(e.get("sku"), {})
        store = STORES.get(e.get("store_id"), {})
        total = float(e.get("total", 0))
        vat   = prod.get("vat_rate", 0.20)
        out.append({
            **e,
            "product_name":  prod.get("name", "UNKNOWN"),
            "category":      prod.get("category", "uncategorised"),
            "region":        store.get("region", "unknown"),
            "city":          store.get("city", "unknown"),
            "country":       store.get("country", "XX"),
            "vat_amount":    round(total * vat, 2),
            "net_amount":    round(total - total * vat, 2),
            "enriched":      bool(prod) and bool(store),   # honest quality flag
        })
    return jsonify(out)
