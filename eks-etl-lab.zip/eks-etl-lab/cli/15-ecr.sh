#!/usr/bin/env bash
# 15 - ECR: private Docker image shelves, one per app.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "15 ECR repositories"

: "${ECR_REPOS:=web producer worker enrich}"
CREATED=""
for r in $ECR_REPOS; do
  NAME="${ECR_REPO_PREFIX}/${r}"
  if aws_ ecr describe-repositories --repository-names "$NAME" >/dev/null 2>&1; then
    skip "repo ${NAME} exists"
  else
    step "Creating repo ${NAME}"
    run aws_ ecr create-repository --repository-name "$NAME" \
      --image-scanning-configuration scanOnPush=true \
      --image-tag-mutability IMMUTABLE \
      --encryption-configuration encryptionType=AES256 \
      --tags "Key=Project,Value=${PROJECT}" "Key=Environment,Value=${ENVIRONMENT}" >/dev/null
    # Keep only the last 20 images so old builds do not cost money forever.
    aws_ ecr put-lifecycle-policy --repository-name "$NAME" --lifecycle-policy-text \
      '{"rules":[{"rulePriority":1,"description":"keep last 20","selection":{"tagStatus":"any","countType":"imageCountMoreThan","countNumber":20},"action":{"type":"expire"}}]}' >/dev/null
  fi
  CREATED="${CREATED:+$CREATED,}$NAME"
done

state_set ecr_registry "$(account_id).dkr.ecr.${AWS_REGION}.amazonaws.com"
state_set ecr_repos "$CREATED"
ok "Registry: $(state_get ecr_registry)"
ok "Next: ./cli/16-iam-app-role.sh"
