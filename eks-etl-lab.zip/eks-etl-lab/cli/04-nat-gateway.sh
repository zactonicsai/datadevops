#!/usr/bin/env bash
# 04 - NAT GATEWAY: lets private pods call OUT (pull images, call AWS APIs)
# without letting the internet call IN. A one-way mail slot.
# COST WARNING: ~$32/month each + data charges. SINGLE_NAT_GATEWAY=true saves money.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "04 NAT Gateway"

read_csv PUB "$(state_require public_subnet_ids)"
COUNT=1
[ "$SINGLE_NAT_GATEWAY" = "true" ] || COUNT="${#PUB[@]}"

NAT_IDS=""
for i in $(seq 0 $((COUNT-1))); do
  NAME="${NAME_PREFIX}-nat-${i}"
  ID="$(aws_ ec2 describe-nat-gateways \
        --filter "Name=tag:Name,Values=${NAME}" "Name=state,Values=available,pending" \
        --query 'NatGateways[0].NatGatewayId' --output text)"
  if [ "$ID" = "None" ] || [ -z "$ID" ]; then
    step "Allocating Elastic IP for ${NAME}"
    EIP="$(aws_ ec2 allocate-address --domain vpc \
          --tag-specifications "ResourceType=elastic-ip,Tags=[{Key=Name,Value=${NAME}-eip}]" \
          --query AllocationId --output text)"
    step "Creating NAT gateway in ${PUB[$i]}"
    ID="$(aws_ ec2 create-nat-gateway --subnet-id "${PUB[$i]}" --allocation-id "$EIP" \
          --tag-specifications "ResourceType=natgateway,Tags=[{Key=Name,Value=${NAME}}]" \
          --query 'NatGateway.NatGatewayId' --output text)"
  else
    skip "NAT ${NAME} exists: ${ID}"
  fi
  NAT_IDS="${NAT_IDS:+$NAT_IDS,}$ID"
done
state_set nat_gateway_ids "$NAT_IDS"

read_csv NATS "$NAT_IDS"
for n in "${NATS[@]}"; do
  wait_for "NAT ${n} available" 40 15 \
    "[ \"\$(aws --region $AWS_REGION --profile $AWS_PROFILE ec2 describe-nat-gateways --nat-gateway-ids $n --query 'NatGateways[0].State' --output text)\" = available ]"
done
ok "Next: ./cli/05-route-tables.sh"
