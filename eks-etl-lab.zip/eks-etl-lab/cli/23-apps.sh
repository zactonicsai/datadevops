#!/usr/bin/env bash
# 23 - BUILD AND DEPLOY THE EXAMPLE APPS.
#   web      static HTML "Store Sales Entry" page (nginx)
#   producer HTTP API -> writes each sale into Kafka
#   worker   reads Kafka -> writes S3 -> calls enrich API -> indexes OpenSearch
#   enrich   tiny API that adds tax/region info (stands in for a real service)
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "23 Example applications"
need kubectl; need envsubst

REGISTRY="$(state_require ecr_registry)"
: "${BUILD_IMAGES:=true}"

if [ "$BUILD_IMAGES" = "true" ]; then
  need docker
  step "Logging in to ECR"
  aws_ ecr get-login-password | docker login --username AWS --password-stdin "$REGISTRY"
  for app in web producer worker enrich; do
    step "Building ${app}:${IMAGE_TAG}"
    run docker build --platform linux/amd64 \
      -t "${REGISTRY}/${ECR_REPO_PREFIX}/${app}:${IMAGE_TAG}" "${REPO_ROOT}/app/${app}"
    run docker push "${REGISTRY}/${ECR_REPO_PREFIX}/${app}:${IMAGE_TAG}"
  done
else
  skip "BUILD_IMAGES=false - assuming images already in ECR"
fi

export REGISTRY IMAGE_TAG ECR_REPO_PREFIX APP_NAMESPACE ALB_CLASS_NAME="${ALB_CLASS_NAME:-eks-auto-alb}"
export WEB_REPLICAS PRODUCER_REPLICAS WORKER_MIN_REPLICAS WORKER_MAX_REPLICAS
export KAFKA_TOPIC_RAW KAFKA_TOPIC_DLQ KAFKA_CONSUMER_GROUP KEDA_LAG_THRESHOLD
export APP_SERVICE_ACCOUNT="$(state_get app_service_account)"
export KAFKA_BOOTSTRAP="$(state_require kafka_bootstrap)"
export KAFKA_AUTH="$(state_get kafka_auth)"
export S3_BUCKET="$(state_require s3_bucket)"
export OPENSEARCH_ENDPOINT="$(state_get opensearch_endpoint)"
export OPENSEARCH_INDEX S3_RAW_PREFIX S3_CURATED_PREFIX AWS_REGION

step "Applying namespace, service account, config"
for f in 00-namespace 01-serviceaccount 02-config 40-web 41-producer 42-enrich 43-worker 44-keda 45-ingress; do
  render ${f}.yaml | kubectl apply -f -
done

step "Waiting for rollouts"
kubectl -n "$APP_NAMESPACE" rollout status deploy/web      --timeout=10m
kubectl -n "$APP_NAMESPACE" rollout status deploy/producer --timeout=10m
kubectl -n "$APP_NAMESPACE" rollout status deploy/enrich   --timeout=10m

ok "Next: ./cli/24-verify.sh"
