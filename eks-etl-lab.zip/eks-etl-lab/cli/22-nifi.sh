#!/usr/bin/env bash
# 22 - APACHE NIFI: the drag-and-drop ETL tool.
# NiFi is a whiteboard where each box is a step (read Kafka -> clean -> write
# S3 -> call API -> index in OpenSearch) and arrows are the data flowing.
# Great for people who do not want to write code, and for auditing lineage.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "22 Apache NiFi ${NIFI_VERSION}"
need kubectl; need envsubst

if [ "$NIFI_ENABLED" != "true" ]; then skip "NIFI_ENABLED=false"; exit 0; fi

: "${NIFI_ADMIN_PASSWORD:=}"
if [ -z "$NIFI_ADMIN_PASSWORD" ]; then
  NIFI_ADMIN_PASSWORD="$(LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 16)"
  log "Generated NiFi password (also saved to state): ${NIFI_ADMIN_PASSWORD}"
  state_set nifi_password "$NIFI_ADMIN_PASSWORD"
fi
export NIFI_VERSION NIFI_STORAGE_GB NIFI_ADMIN_USER NIFI_ADMIN_PASSWORD APP_NAMESPACE
export APP_SERVICE_ACCOUNT="$(state_get app_service_account)"

render 30-nifi.yaml | kubectl apply -f -
kubectl -n "$APP_NAMESPACE" rollout status statefulset/nifi --timeout=15m

cat <<EOF

  NiFi UI:  kubectl -n ${APP_NAMESPACE} port-forward svc/nifi 8443:8443
            then open https://localhost:8443/nifi
  user: ${NIFI_ADMIN_USER}   password: ${NIFI_ADMIN_PASSWORD}

  Build the flow by following docs/04-nifi-flow.md
EOF
ok "Next: ./cli/23-apps.sh"
