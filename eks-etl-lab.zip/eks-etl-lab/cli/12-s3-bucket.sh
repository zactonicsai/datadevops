#!/usr/bin/env bash
# 12 - S3 BUCKET: the data lake. Where the ETL output lands forever.
# Layout we use (a real, boring, works-everywhere layout):
#   raw/dt=2026-08-03/hour=14/part-*.json      <- exactly what arrived
#   curated/dt=2026-08-03/part-*.parquet       <- cleaned, typed, queryable
# "dt=" folders are called PARTITIONS. Athena/Glue read only the folders they
# need, so a query over one day does not scan two years of data.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "12 S3 data lake bucket"

BUCKET="$S3_BUCKET"
if aws_ s3api head-bucket --bucket "$BUCKET" >/dev/null 2>&1; then
  skip "bucket ${BUCKET} exists"
else
  step "Creating bucket ${BUCKET}"
  if [ "$AWS_REGION" = "us-east-1" ]; then
    run aws_ s3api create-bucket --bucket "$BUCKET"
  else
    run aws_ s3api create-bucket --bucket "$BUCKET" \
      --create-bucket-configuration "LocationConstraint=${AWS_REGION}"
  fi
fi

step "Block ALL public access (do this before you put any data in)"
run aws_ s3api put-public-access-block --bucket "$BUCKET" \
  --public-access-block-configuration \
  "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"

step "Default encryption (SSE-S3)"
run aws_ s3api put-bucket-encryption --bucket "$BUCKET" \
  --server-side-encryption-configuration \
  '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"},"BucketKeyEnabled":true}]}'

if [ "$S3_VERSIONING" = "true" ]; then
  step "Versioning on (undo button for deletes)"
  run aws_ s3api put-bucket-versioning --bucket "$BUCKET" \
    --versioning-configuration Status=Enabled
fi

step "Lifecycle: Glacier after ${S3_GLACIER_AFTER_DAYS}d, delete after ${S3_EXPIRE_AFTER_DAYS}d"
LIFECYCLE="$(jq -nc --arg raw "$S3_RAW_PREFIX" \
  --argjson g "$S3_GLACIER_AFTER_DAYS" --argjson e "$S3_EXPIRE_AFTER_DAYS" '
{Rules:[
 {ID:"raw-to-glacier", Status:"Enabled", Filter:{Prefix:$raw},
  Transitions:[{Days:$g, StorageClass:"GLACIER_IR"}],
  Expiration:{Days:$e}},
 {ID:"abort-failed-uploads", Status:"Enabled", Filter:{Prefix:""},
  AbortIncompleteMultipartUpload:{DaysAfterInitiation:7}}
]}')"
run aws_ s3api put-bucket-lifecycle-configuration --bucket "$BUCKET" \
  --lifecycle-configuration "$LIFECYCLE"

run aws_ s3api put-bucket-tagging --bucket "$BUCKET" \
  --tagging "TagSet=[{Key=Project,Value=${PROJECT}},{Key=Environment,Value=${ENVIRONMENT}}]"

state_set s3_bucket "$BUCKET"
ok "Next: ./cli/13-kafka.sh"
