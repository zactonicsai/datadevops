#!/usr/bin/env bash
# 24 - VERIFY: prove the whole pipeline works, end to end.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "24 End-to-end verification"
need kubectl

step "1/6 Nodes (Auto Mode should have created some by now)"
kubectl get nodes -o wide

step "2/6 Pods"
kubectl -n "$APP_NAMESPACE" get pods

step "3/6 Load balancer address"
for i in $(seq 1 40); do
  ADDR="$(kubectl -n "$APP_NAMESPACE" get ingress shop-ingress -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || true)"
  [ -n "$ADDR" ] && break
  sleep 15; printf '.'
done
[ -n "${ADDR:-}" ] || die "No ALB hostname yet. kubectl -n $APP_NAMESPACE describe ingress shop-ingress"
state_set alb_hostname "$ADDR"
ok "Open http://${ADDR}/"

step "4/6 Sending a test sale through the API"
curl -fsS -X POST "http://${ADDR}/api/sales" \
  -H 'content-type: application/json' \
  -d '{"store_id":"STORE-004","sku":"APPLE-GALA-1KG","qty":3,"unit_price":2.49,"payment":"card"}' \
  && echo

step "5/6 KEDA should wake the worker up"
kubectl -n "$APP_NAMESPACE" get scaledobject,hpa
sleep 20
kubectl -n "$APP_NAMESPACE" get pods -l app=worker

step "6/6 Did the object land in S3?"
aws_ s3 ls "s3://$(state_get s3_bucket)/${S3_RAW_PREFIX}" --recursive | tail -5 \
  || warn "nothing yet - workers may still be starting"

cat <<EOF

  Web page ....... http://${ADDR}/
  OpenSearch ..... $(state_get opensearch_endpoint)/_dashboards/
  S3 bucket ...... s3://$(state_get s3_bucket)/
  Worker logs .... kubectl -n ${APP_NAMESPACE} logs -l app=worker -f

EOF
ok "Pipeline verified."
