#!/usr/bin/env bash
# 11 - KUBECONFIG: teach kubectl where the cluster is and how to log in.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "11 kubeconfig"
need kubectl

run aws_ eks update-kubeconfig --name "$CLUSTER_NAME" --alias "$CLUSTER_NAME"
step "Proof of life"
kubectl get nodes || warn "No nodes yet - that is NORMAL. Auto Mode only creates nodes when a pod needs one."
kubectl get nodepools.karpenter.sh 2>/dev/null || warn "built-in nodepools not visible yet"
ok "Next: ./cli/12-s3-bucket.sh"
