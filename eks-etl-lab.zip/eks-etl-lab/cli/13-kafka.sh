#!/usr/bin/env bash
# 13 - KAFKA: the conveyor belt between "something happened" and "process it".
#
# KAFKA_BACKEND=msk        -> Amazon MSK Serverless. Managed, IAM auth, HA.
# KAFKA_BACKEND=in-cluster -> one Kafka pod inside EKS. Cheap, for learning.
#
# Why a queue at all? Because the till in the shop must never wait for the
# data warehouse. The till writes to Kafka in 5 ms and walks away.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "13 Kafka (${KAFKA_BACKEND})"

if [ "$KAFKA_BACKEND" = "in-cluster" ]; then
  skip "KAFKA_BACKEND=in-cluster -> nothing to create in AWS."
  log  "Kafka will be deployed as a pod in step 21 (./cli/21-kafka-deploy.sh)."
  state_set kafka_bootstrap "kafka.${APP_NAMESPACE}.svc.cluster.local:9092"
  state_set kafka_auth "PLAINTEXT"
  ok "Next: ./cli/14-opensearch.sh"
  exit 0
fi

read_csv PRV "$(state_require private_subnet_ids)"
KAFKA_SG="$(state_require kafka_sg_id)"

if aws_ kafka list-clusters-v2 --cluster-name-filter "$KAFKA_CLUSTER_NAME" \
     --query 'ClusterInfoList[0].ClusterArn' --output text 2>/dev/null | grep -q '^arn:'; then
  skip "MSK cluster ${KAFKA_CLUSTER_NAME} exists"
else
  step "Creating MSK Serverless cluster ${KAFKA_CLUSTER_NAME}"
  SUBNET_JSON="$(printf '%s\n' "${PRV[@]}" | jq -R . | jq -sc .)"
  run aws_ kafka create-cluster-v2 \
    --cluster-name "$KAFKA_CLUSTER_NAME" \
    --serverless "$(jq -nc --argjson s "$SUBNET_JSON" --arg sg "$KAFKA_SG" \
      '{vpcConfigs:[{subnetIds:$s, securityGroupIds:[$sg]}],
        clientAuthentication:{sasl:{iam:{enabled:true}}}}')" \
    --tags "$(jq -nc --arg p "$PROJECT" --arg e "$ENVIRONMENT" '{Project:$p,Environment:$e}')" \
    >/dev/null
fi

ARN="$(aws_ kafka list-clusters-v2 --cluster-name-filter "$KAFKA_CLUSTER_NAME" \
  --query 'ClusterInfoList[0].ClusterArn' --output text)"
state_set kafka_arn "$ARN"

wait_for "MSK cluster ACTIVE" 60 20 \
  "[ \"\$(aws --region $AWS_REGION --profile $AWS_PROFILE kafka describe-cluster-v2 --cluster-arn $ARN --query 'ClusterInfo.State' --output text)\" = ACTIVE ]"

BOOT="$(aws_ kafka get-bootstrap-brokers --cluster-arn "$ARN" \
  --query 'BootstrapBrokerStringSaslIam' --output text)"
state_set kafka_bootstrap "$BOOT"
state_set kafka_auth "AWS_MSK_IAM"
ok "Bootstrap: ${BOOT}"
ok "Next: ./cli/14-opensearch.sh"
