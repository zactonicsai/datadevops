#!/usr/bin/env bash
# 09 - THE EKS CLUSTER ITSELF (the control plane / "the manager").
# With AUTO_MODE=true, three switches turn on AWS-managed data plane:
#   computeConfig            -> AWS creates/deletes EC2 nodes for you
#   elasticLoadBalancing     -> AWS runs the ALB controller for you
#   blockStorage             -> AWS runs the EBS CSI driver for you
# Takes 10-15 minutes. Go get a snack.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "09 EKS cluster"

CLUSTER_ROLE="$(state_require cluster_role_arn)"
NODE_ROLE="$(state_require node_role_arn)"
CLUSTER_SG="$(state_require cluster_sg_id)"
SUBNETS="$(state_require private_subnet_ids),$(state_require public_subnet_ids)"

if aws_ eks describe-cluster --name "$CLUSTER_NAME" >/dev/null 2>&1; then
  skip "cluster ${CLUSTER_NAME} already exists"
else
  # Build the JSON blobs from variables so the template stays flexible.
  if [ -n "$BUILTIN_NODE_POOLS" ]; then
    POOLS_JSON="$(printf '%s' "$BUILTIN_NODE_POOLS" | jq -R 'split(",")')"
  else
    POOLS_JSON='[]'
  fi
  COMPUTE="$(jq -nc --argjson pools "$POOLS_JSON" --arg role "$NODE_ROLE" \
    --argjson on "$([ "$AUTO_MODE" = true ] && echo true || echo false)" \
    '{enabled:$on, nodePools:$pools, nodeRoleArn:$role}')"
  NETCFG="$(jq -nc --argjson on "$([ "$AUTO_MODE" = true ] && echo true || echo false)" \
    '{elasticLoadBalancing:{enabled:$on}}')"
  STORAGE="$(jq -nc --argjson on "$([ "$AUTO_MODE" = true ] && echo true || echo false)" \
    '{blockStorage:{enabled:$on}}')"
  VPCCFG="$(jq -nc --arg subnets "$SUBNETS" --arg sg "$CLUSTER_SG" \
    --argjson pub "$([ "$ENDPOINT_PUBLIC_ACCESS" = true ] && echo true || echo false)" \
    --argjson prv "$([ "$ENDPOINT_PRIVATE_ACCESS" = true ] && echo true || echo false)" \
    --arg cidrs "$PUBLIC_ACCESS_CIDRS" \
    '{subnetIds:($subnets|split(",")), securityGroupIds:[$sg],
      endpointPublicAccess:$pub, endpointPrivateAccess:$prv,
      publicAccessCidrs:($cidrs|split(","))}')"
  LOGGING="$(jq -nc --arg t "$CLUSTER_LOG_TYPES" \
    '{clusterLogging:[{types:($t|split(",")), enabled:true}]}')"

  step "Creating cluster ${CLUSTER_NAME} (k8s ${K8S_VERSION}, auto-mode=${AUTO_MODE})"
  run aws_ eks create-cluster \
    --name "$CLUSTER_NAME" \
    --kubernetes-version "$K8S_VERSION" \
    --role-arn "$CLUSTER_ROLE" \
    --resources-vpc-config "$VPCCFG" \
    --compute-config "$COMPUTE" \
    --kubernetes-network-config "$NETCFG" \
    --storage-config "$STORAGE" \
    --logging "$LOGGING" \
    --access-config '{"authenticationMode":"API","bootstrapClusterCreatorAdminPermissions":true}' \
    --tags "$TAGS_KV" >/dev/null
fi

step "Waiting for ACTIVE (10-15 min is normal)"
run aws_ eks wait cluster-active --name "$CLUSTER_NAME"

state_set cluster_endpoint "$(aws_ eks describe-cluster --name "$CLUSTER_NAME" --query 'cluster.endpoint' --output text)"
state_set cluster_oidc     "$(aws_ eks describe-cluster --name "$CLUSTER_NAME" --query 'cluster.identity.oidc.issuer' --output text)"
state_set cluster_arn      "$(aws_ eks describe-cluster --name "$CLUSTER_NAME" --query 'cluster.arn' --output text)"
ok "Cluster is ACTIVE. Next: ./cli/10-access-entry.sh"
