#!/usr/bin/env bash
# 06 - SECURITY GROUPS: firewalls around each thing.
# Rule of thumb: never allow a CIDR when you can allow another security group.
# "Only the worker SG may talk to the database SG" beats "10.0.0.0/8 may".
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "06 Security groups"

VPC_ID="$(state_require vpc_id)"

sg_for() {                  # $1=name $2=description -> id
  local name="$1" desc="$2" id
  id="$(aws_ ec2 describe-security-groups --filters "Name=group-name,Values=${name}" \
        "Name=vpc-id,Values=${VPC_ID}" --query 'SecurityGroups[0].GroupId' --output text)"
  if [ "$id" = "None" ] || [ -z "$id" ]; then
    id="$(aws_ ec2 create-security-group --group-name "$name" --description "$desc" \
          --vpc-id "$VPC_ID" \
          --tag-specifications "ResourceType=security-group,Tags=[{Key=Name,Value=${name}}]" \
          --query GroupId --output text)"
  fi
  printf '%s' "$id"
}
allow_sg() {                # $1=target sg $2=source sg $3=port $4=note
  aws_ ec2 authorize-security-group-ingress --group-id "$1" \
    --ip-permissions "IpProtocol=tcp,FromPort=$3,ToPort=$3,UserIdGroupPairs=[{GroupId=$2,Description=\"$4\"}]" \
    >/dev/null 2>&1 || skip "rule exists: $2 -> $1 :$3"
}

step "Cluster control-plane SG"
CLUSTER_SG="$(sg_for "${NAME_PREFIX}-cluster-sg" "EKS control plane")"
state_set cluster_sg_id "$CLUSTER_SG"

step "Kafka SG (brokers)"
KAFKA_SG="$(sg_for "${NAME_PREFIX}-kafka-sg" "Kafka brokers")"
state_set kafka_sg_id "$KAFKA_SG"

step "OpenSearch SG"
OS_SG="$(sg_for "${NAME_PREFIX}-opensearch-sg" "OpenSearch domain")"
state_set opensearch_sg_id "$OS_SG"

# Pods in EKS Auto Mode get the CLUSTER security group by default, so we let
# that SG reach Kafka (9098 = IAM auth) and OpenSearch (443 = HTTPS).
step "Wiring: cluster -> kafka 9098/9092, cluster -> opensearch 443"
allow_sg "$KAFKA_SG" "$CLUSTER_SG" 9098 "MSK IAM auth from pods"
allow_sg "$KAFKA_SG" "$CLUSTER_SG" 9092 "Kafka plaintext from pods"
allow_sg "$OS_SG"    "$CLUSTER_SG" 443  "HTTPS from pods"
ok "Next: ./cli/07-iam-cluster-role.sh"
