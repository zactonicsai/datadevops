#!/usr/bin/env bash
# 03 - INTERNET GATEWAY: the front door of the VPC.
# Without it, nothing in a public subnet can reach or be reached from internet.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "03 Internet Gateway"

VPC_ID="$(state_require vpc_id)"
IGW_NAME="${NAME_PREFIX}-igw"

IGW_ID="$(aws_ ec2 describe-internet-gateways \
  --filters "Name=tag:Name,Values=${IGW_NAME}" \
  --query 'InternetGateways[0].InternetGatewayId' --output text)"

if [ "$IGW_ID" = "None" ] || [ -z "$IGW_ID" ]; then
  step "Creating internet gateway"
  IGW_ID="$(aws_ ec2 create-internet-gateway \
    --tag-specifications "ResourceType=internet-gateway,Tags=[{Key=Name,Value=${IGW_NAME}}]" \
    --query 'InternetGateway.InternetGatewayId' --output text)"
else
  skip "IGW exists: $IGW_ID"
fi
state_set igw_id "$IGW_ID"

ATTACHED="$(aws_ ec2 describe-internet-gateways --internet-gateway-ids "$IGW_ID" \
  --query 'InternetGateways[0].Attachments[0].VpcId' --output text)"
if [ "$ATTACHED" != "$VPC_ID" ]; then
  step "Attaching IGW to VPC"
  aws_ ec2 attach-internet-gateway --internet-gateway-id "$IGW_ID" --vpc-id "$VPC_ID"
fi
ok "Next: ./cli/04-nat-gateway.sh"
