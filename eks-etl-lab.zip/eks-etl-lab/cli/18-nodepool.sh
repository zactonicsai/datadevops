#!/usr/bin/env bash
# 18 - CUSTOM NODE POOL: your own rules for what machines get created.
# The built-in "general-purpose" pool is fine for web apps. ETL workers are
# bursty and interruption-tolerant, so we make a Spot-first pool for them.
# NodeClass = AWS settings (subnets, SGs, role). NodePool = scheduling rules.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "18 Custom node pool"
need kubectl; need envsubst

export NODE_ROLE_NAME="$(basename "$(state_require node_role_arn)")"
export NODEPOOL_NAME NODEPOOL_CPU_LIMIT NODEPOOL_EXPIRE_AFTER NODEPOOL_ARCH
export CLUSTER_NAME PROJECT ENVIRONMENT

CAP_JSON="$(printf '%s' "$NODEPOOL_CAPACITY_TYPE" | tr ',' '\n' | sed 's/^/    - /')"
CAT_JSON="$(printf '%s' "$NODEPOOL_INSTANCE_CATEGORIES" | tr ',' '\n' | sed 's/^/    - /')"
export CAP_LIST="$CAP_JSON" CAT_LIST="$CAT_JSON"

step "Applying NodeClass + NodePool"
render 10-nodeclass.yaml | kubectl apply -f -
# The capacity/category lists are multi-line, so we build the NodePool with a
# small here-doc instead of envsubst.
cat <<EOF | kubectl apply -f -
apiVersion: karpenter.sh/v1
kind: NodePool
metadata:
  name: ${NODEPOOL_NAME}
spec:
  template:
    metadata:
      labels:
        workload: etl
    spec:
      nodeClassRef:
        group: eks.amazonaws.com
        kind: NodeClass
        name: ${NODEPOOL_NAME}-class
      # Taint = "only pods that explicitly tolerate this may land here."
      taints:
        - key: workload
          value: etl
          effect: NoSchedule
      requirements:
        - key: "karpenter.sh/capacity-type"
          operator: In
          values:
$(printf '%s' "$NODEPOOL_CAPACITY_TYPE" | tr ',' '\n' | sed 's/^/            - "/;s/$/"/')
        - key: "kubernetes.io/arch"
          operator: In
          values: ["${NODEPOOL_ARCH}"]
        - key: "eks.amazonaws.com/instance-category"
          operator: In
          values:
$(printf '%s' "$NODEPOOL_INSTANCE_CATEGORIES" | tr ',' '\n' | sed 's/^/            - "/;s/$/"/')
        - key: "eks.amazonaws.com/instance-generation"
          operator: Gt
          values: ["4"]
      expireAfter: ${NODEPOOL_EXPIRE_AFTER}
  limits:
    cpu: "${NODEPOOL_CPU_LIMIT}"
  disruption:
    consolidationPolicy: WhenEmptyOrUnderutilized
    consolidateAfter: 60s
EOF

kubectl get nodepools
ok "Next: ./cli/19-ingressclass.sh"
