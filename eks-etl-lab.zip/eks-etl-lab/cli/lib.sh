#!/usr/bin/env bash
# =============================================================================
# cli/lib.sh  --  shared helpers. Sourced by every numbered script.
# =============================================================================
# Nothing here creates AWS resources. It only provides:
#   * safe shell settings
#   * coloured logging
#   * a tiny "state" store (remember IDs between scripts)
#   * idempotency helpers (running a script twice must be harmless)
# =============================================================================

set -euo pipefail
# -e  stop on the first error        -u  crash on typo'd variable names
# -o pipefail  a failing command inside a pipe fails the whole pipe

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export REPO_ROOT

# shellcheck disable=SC1091
source "${REPO_ROOT}/env/config.sh"

mkdir -p "$STATE_DIR"

# ------------------------------------------------------------------- LOGGING
if [ -t 1 ]; then
  C_RESET=$'\033[0m'; C_BLUE=$'\033[34m'; C_GREEN=$'\033[32m'
  C_YELLOW=$'\033[33m'; C_RED=$'\033[31m'; C_DIM=$'\033[2m'
else
  C_RESET=""; C_BLUE=""; C_GREEN=""; C_YELLOW=""; C_RED=""; C_DIM=""
fi

log()   { printf '%s[ .. ]%s %s\n' "$C_BLUE"   "$C_RESET" "$*"; }
ok()    { printf '%s[ OK ]%s %s\n' "$C_GREEN"  "$C_RESET" "$*"; }
warn()  { printf '%s[WARN]%s %s\n' "$C_YELLOW" "$C_RESET" "$*" >&2; }
die()   { printf '%s[FAIL]%s %s\n' "$C_RED"    "$C_RESET" "$*" >&2; exit 1; }
step()  { printf '\n%s==> %s%s\n' "$C_BLUE" "$*" "$C_RESET"; }
skip()  { printf '%s[skip]%s %s\n' "$C_DIM"    "$C_RESET" "$*"; }

# ------------------------------------------------------------------- DRY RUN
# Wrap any mutating command in `run` so DRY_RUN=true can preview it.
run() {
  if [ "$DRY_RUN" = "true" ]; then
    printf '%s[dry ]%s %s\n' "$C_DIM" "$C_RESET" "$*"
  else
    "$@"
  fi
}

# --------------------------------------------------------------- STATE STORE
# state_set KEY VALUE     -> writes $STATE_DIR/KEY
# state_get KEY           -> prints the value (empty if missing)
# state_has KEY           -> true/false
# state_require KEY       -> prints value or dies with a helpful message
state_set() {
  printf '%s' "$2" > "${STATE_DIR}/$1"
  printf '%s      %s = %s%s\n' "$C_DIM" "$1" "$2" "$C_RESET"
}
state_get() { cat "${STATE_DIR}/$1" 2>/dev/null || true; }
state_has() { [ -s "${STATE_DIR}/$1" ]; }
state_require() {
  local v; v="$(state_get "$1")"
  [ -n "$v" ] || die "Missing state '$1'. Run the earlier script that creates it (see docs/01-run-order.md)."
  printf '%s' "$v"
}

# --------------------------------------------------------------- AWS HELPERS
aws_() { aws --region "$AWS_REGION" --profile "$AWS_PROFILE" "$@"; }

account_id() {
  if ! state_has account_id; then
    state_set account_id "$(aws_ sts get-caller-identity --query Account --output text)"
  fi
  state_get account_id
}

# Pick the first AZ_COUNT healthy Availability Zones in this region.
azs() {
  if ! state_has azs; then
    state_set azs "$(aws_ ec2 describe-availability-zones \
      --filters Name=state,Values=available Name=zone-type,Values=availability-zone \
      --query "AvailabilityZones[0:${AZ_COUNT}].ZoneName" --output text | tr '\t' ',')"
  fi
  state_get azs
}

# Turn "a,b,c" into a bash array: read_csv MYARR "$MY_CSV"
read_csv() { local -n _arr="$1"; IFS=',' read -r -a _arr <<< "$2"; }

# Wait until a shell condition is true. wait_for "description" 60 5 'command'
wait_for() {
  local desc="$1" tries="$2" delay="$3" cmd="$4" i=0
  log "Waiting for ${desc} (up to $((tries*delay))s)..."
  while [ "$i" -lt "$tries" ]; do
    if eval "$cmd" >/dev/null 2>&1; then ok "${desc} is ready"; return 0; fi
    i=$((i+1)); sleep "$delay"; printf '.'
  done
  die "Timed out waiting for ${desc}"
}

# --------------------------------------------------------------- PRE-FLIGHT
need() { command -v "$1" >/dev/null 2>&1 || die "Required tool not found: $1"; }

banner() {
  printf '%s\n' "-------------------------------------------------------------"
  printf '  %s\n' "$1"
  printf '  %s\n' "prefix=${NAME_PREFIX}  region=${AWS_REGION}  profile=${AWS_PROFILE}"
  printf '%s\n' "-------------------------------------------------------------"
}

# ------------------------------------------------------- TEMPLATE RENDERING
# We give envsubst an EXPLICIT list of variables. Without a list it would also
# eat shell variables that belong to the YAML (like $NAME inside a script
# block) and replace them with empty strings. Explicit is safe.
TEMPLATE_VARS='${PROJECT} ${ENVIRONMENT} ${NAME_PREFIX} ${AWS_REGION} ${CLUSTER_NAME} ${APP_NAMESPACE} ${APP_SERVICE_ACCOUNT} ${REGISTRY} ${ECR_REPO_PREFIX} ${IMAGE_TAG} ${WEB_REPLICAS} ${PRODUCER_REPLICAS} ${WORKER_MIN_REPLICAS} ${WORKER_MAX_REPLICAS} ${KEDA_LAG_THRESHOLD} ${KAFKA_BOOTSTRAP} ${KAFKA_AUTH} ${KAFKA_TOPIC_RAW} ${KAFKA_TOPIC_DLQ} ${KAFKA_PARTITIONS} ${KAFKA_REPLICATION} ${KAFKA_CONSUMER_GROUP} ${S3_BUCKET} ${S3_RAW_PREFIX} ${S3_CURATED_PREFIX} ${OPENSEARCH_ENDPOINT} ${OPENSEARCH_INDEX} ${NODEPOOL_NAME} ${NODE_ROLE_NAME} ${NODEPOOL_ARCH} ${NODEPOOL_CPU_LIMIT} ${NODEPOOL_EXPIRE_AFTER} ${ALB_CLASS_NAME} ${ALB_SCHEME} ${ALB_GROUP_NAME} ${NIFI_VERSION} ${NIFI_STORAGE_GB} ${NIFI_ADMIN_USER} ${NIFI_ADMIN_PASSWORD}'
export TEMPLATE_VARS

render() { envsubst "$TEMPLATE_VARS" < "${REPO_ROOT}/k8s/$1"; }
