#!/usr/bin/env bash
# 17 - POD IDENTITY ASSOCIATION: link a Kubernetes ServiceAccount to the role.
# Translation: "the pod that logs in as serviceaccount 'etl-app' in namespace
# 'shop-etl' is allowed to wear the etl-app-role badge." No keys, no secrets.
# NOTE: EKS Auto Mode already runs the Pod Identity Agent for you.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "17 Pod Identity association"

ROLE_ARN="$(state_require app_role_arn)"
: "${APP_SERVICE_ACCOUNT:=etl-app}"

if [ "$AUTO_MODE" != "true" ]; then
  step "Installing the Pod Identity Agent add-on (Auto Mode includes it already)"
  aws_ eks create-addon --cluster-name "$CLUSTER_NAME" \
    --addon-name eks-pod-identity-agent >/dev/null 2>&1 || skip "add-on present"
fi

EXISTING="$(aws_ eks list-pod-identity-associations --cluster-name "$CLUSTER_NAME" \
  --namespace "$APP_NAMESPACE" --service-account "$APP_SERVICE_ACCOUNT" \
  --query 'associations[0].associationId' --output text 2>/dev/null || echo None)"

if [ "$EXISTING" != "None" ] && [ -n "$EXISTING" ]; then
  skip "association exists: $EXISTING"
else
  step "Associating ${APP_NAMESPACE}/${APP_SERVICE_ACCOUNT} -> ${ROLE_ARN}"
  run aws_ eks create-pod-identity-association \
    --cluster-name "$CLUSTER_NAME" \
    --namespace "$APP_NAMESPACE" \
    --service-account "$APP_SERVICE_ACCOUNT" \
    --role-arn "$ROLE_ARN" >/dev/null
fi
state_set app_service_account "$APP_SERVICE_ACCOUNT"
ok "Next: ./cli/18-nodepool.sh"
