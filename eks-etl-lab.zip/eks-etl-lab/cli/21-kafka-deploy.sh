#!/usr/bin/env bash
# 21 - IN-CLUSTER KAFKA + TOPICS.
# If KAFKA_BACKEND=msk we only create the topics. If in-cluster, we also
# deploy a single KRaft-mode Kafka pod (no ZooKeeper needed since Kafka 3.3).
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "21 Kafka deploy + topics"
need kubectl; need envsubst

export APP_NAMESPACE KAFKA_TOPIC_RAW KAFKA_TOPIC_DLQ KAFKA_PARTITIONS KAFKA_REPLICATION
kubectl create namespace "$APP_NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

if [ "$KAFKA_BACKEND" = "in-cluster" ]; then
  step "Deploying single-node Kafka (KRaft)"
  render 20-kafka.yaml | kubectl apply -f -
  kubectl -n "$APP_NAMESPACE" rollout status statefulset/kafka --timeout=10m

  step "Creating topics"
  kubectl -n "$APP_NAMESPACE" exec sts/kafka -- bash -lc "
    /opt/bitnami/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 \
      --create --if-not-exists --topic ${KAFKA_TOPIC_RAW} \
      --partitions ${KAFKA_PARTITIONS} --replication-factor ${KAFKA_REPLICATION}
    /opt/bitnami/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 \
      --create --if-not-exists --topic ${KAFKA_TOPIC_DLQ} \
      --partitions 1 --replication-factor ${KAFKA_REPLICATION}
    /opt/bitnami/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --list"
else
  step "MSK: creating topics from a one-shot admin pod"
  BOOT="$(state_require kafka_bootstrap)"
  kubectl -n "$APP_NAMESPACE" delete job kafka-admin --ignore-not-found >/dev/null
  export KAFKA_BOOTSTRAP="$BOOT"
  render 21-kafka-admin-job.yaml | kubectl apply -f -
  kubectl -n "$APP_NAMESPACE" wait --for=condition=complete job/kafka-admin --timeout=10m
  kubectl -n "$APP_NAMESPACE" logs job/kafka-admin
fi
ok "Next: ./cli/22-nifi.sh"
