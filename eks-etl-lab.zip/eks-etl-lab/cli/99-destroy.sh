#!/usr/bin/env bash
# 99 - DESTROY EVERYTHING, in the exact reverse order of creation.
# Deleting in the wrong order is the #1 cause of "DependencyViolation".
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "99 DESTROY"

printf 'This deletes the ENTIRE %s stack in %s.\nType the cluster name to confirm: ' "$NAME_PREFIX" "$AWS_REGION"
read -r CONFIRM
[ "$CONFIRM" = "$CLUSTER_NAME" ] || die "Aborted."

step "K8s objects first (this deletes the ALB that AWS created for you)"
kubectl delete ingress --all -n "$APP_NAMESPACE" --ignore-not-found 2>/dev/null || true
kubectl delete namespace "$APP_NAMESPACE" --ignore-not-found 2>/dev/null || true
kubectl delete nodepool "$NODEPOOL_NAME" --ignore-not-found 2>/dev/null || true
sleep 60   # give AWS time to remove the load balancer + nodes

step "Pod identity associations"
for a in $(aws_ eks list-pod-identity-associations --cluster-name "$CLUSTER_NAME" \
           --query 'associations[].associationId' --output text 2>/dev/null); do
  aws_ eks delete-pod-identity-association --cluster-name "$CLUSTER_NAME" --association-id "$a" >/dev/null
done

step "EKS cluster"
aws_ eks delete-cluster --name "$CLUSTER_NAME" >/dev/null 2>&1 || skip "no cluster"
aws_ eks wait cluster-deleted --name "$CLUSTER_NAME" 2>/dev/null || true

step "OpenSearch"
aws_ opensearch delete-domain --domain-name "$OPENSEARCH_DOMAIN" >/dev/null 2>&1 || skip "no domain"

step "MSK"
[ -n "$(state_get kafka_arn)" ] && aws_ kafka delete-cluster --cluster-arn "$(state_get kafka_arn)" >/dev/null 2>&1 || skip "no MSK"

step "ECR"
for r in $(printf '%s' "$(state_get ecr_repos)" | tr ',' ' '); do
  aws_ ecr delete-repository --repository-name "$r" --force >/dev/null 2>&1 || true
done

step "S3 (emptying first - versioned buckets need every version removed)"
aws_ s3 rm "s3://$(state_get s3_bucket)" --recursive >/dev/null 2>&1 || true
aws_ s3api delete-bucket --bucket "$(state_get s3_bucket)" >/dev/null 2>&1 || skip "bucket busy or gone"

step "NAT gateways + EIPs (the expensive bits - always confirm these are gone)"
for n in $(printf '%s' "$(state_get nat_gateway_ids)" | tr ',' ' '); do
  aws_ ec2 delete-nat-gateway --nat-gateway-id "$n" >/dev/null 2>&1 || true
done
sleep 90
for a in $(aws_ ec2 describe-addresses --filters "Name=tag:Name,Values=${NAME_PREFIX}-*" \
           --query 'Addresses[].AllocationId' --output text); do
  aws_ ec2 release-address --allocation-id "$a" >/dev/null 2>&1 || true
done

step "Subnets, route tables, IGW, VPC"
VPC_ID="$(state_get vpc_id)"
if [ -n "$VPC_ID" ]; then
  for s in $(aws_ ec2 describe-subnets --filters "Name=vpc-id,Values=$VPC_ID" --query 'Subnets[].SubnetId' --output text); do
    aws_ ec2 delete-subnet --subnet-id "$s" >/dev/null 2>&1 || true
  done
  for r in $(aws_ ec2 describe-route-tables --filters "Name=vpc-id,Values=$VPC_ID" \
             --query 'RouteTables[?Associations[0].Main!=`true`].RouteTableId' --output text); do
    aws_ ec2 delete-route-table --route-table-id "$r" >/dev/null 2>&1 || true
  done
  IGW="$(state_get igw_id)"
  [ -n "$IGW" ] && aws_ ec2 detach-internet-gateway --internet-gateway-id "$IGW" --vpc-id "$VPC_ID" >/dev/null 2>&1 || true
  [ -n "$IGW" ] && aws_ ec2 delete-internet-gateway --internet-gateway-id "$IGW" >/dev/null 2>&1 || true
  for g in $(aws_ ec2 describe-security-groups --filters "Name=vpc-id,Values=$VPC_ID" \
             --query 'SecurityGroups[?GroupName!=`default`].GroupId' --output text); do
    aws_ ec2 delete-security-group --group-id "$g" >/dev/null 2>&1 || true
  done
  aws_ ec2 delete-vpc --vpc-id "$VPC_ID" >/dev/null 2>&1 || warn "VPC still has dependencies"
fi

step "IAM roles"
for ROLE in "${NAME_PREFIX}-eks-cluster-role" "${NAME_PREFIX}-eks-node-role" "${NAME_PREFIX}-etl-app-role"; do
  for p in $(aws_ iam list-attached-role-policies --role-name "$ROLE" --query 'AttachedPolicies[].PolicyArn' --output text 2>/dev/null); do
    aws_ iam detach-role-policy --role-name "$ROLE" --policy-arn "$p" || true
  done
  for p in $(aws_ iam list-role-policies --role-name "$ROLE" --query 'PolicyNames[]' --output text 2>/dev/null); do
    aws_ iam delete-role-policy --role-name "$ROLE" --policy-name "$p" || true
  done
  aws_ iam delete-role --role-name "$ROLE" >/dev/null 2>&1 || skip "no role $ROLE"
done

rm -rf "$STATE_DIR"
ok "Destroyed. Check the AWS bill page tomorrow to be sure."
