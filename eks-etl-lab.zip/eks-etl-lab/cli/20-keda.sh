#!/usr/bin/env bash
# 20 - KEDA: the autoscaler that watches the QUEUE, not the CPU.
# Plain Kubernetes HPA asks "are pods busy?". That is too late for ETL: the
# backlog is already 4 hours deep before CPU moves. KEDA asks "how many
# messages are waiting in Kafka?" and can scale from 0 to 20 in seconds.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "20 KEDA ${KEDA_VERSION}"
need helm; need kubectl

helm repo add kedacore https://kedacore.github.io/charts >/dev/null 2>&1 || true
helm repo update kedacore >/dev/null

step "Installing/upgrading KEDA into namespace 'keda'"
run helm upgrade --install keda kedacore/keda \
  --namespace keda --create-namespace \
  --version "$KEDA_VERSION" \
  --set podIdentity.aws.irsa.enabled=false \
  --wait --timeout 10m

kubectl -n keda get pods
ok "Next: ./cli/21-kafka-deploy.sh"
