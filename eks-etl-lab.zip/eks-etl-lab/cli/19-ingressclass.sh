#!/usr/bin/env bash
# 19 - INGRESSCLASS: tells EKS Auto Mode "make me a real AWS load balancer".
# In Auto Mode you do NOT install the AWS Load Balancer Controller yourself --
# it is already running. You just declare an IngressClass pointing at it.
# IMPORTANT: in Auto Mode most alb.ingress.* annotations are ignored. Settings
# live in IngressClassParams instead.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "19 IngressClass (ALB)"
need kubectl; need envsubst

: "${ALB_SCHEME:=internet-facing}"     # or internal
: "${ALB_CLASS_NAME:=eks-auto-alb}"
: "${ALB_GROUP_NAME:=${NAME_PREFIX}-shared}"
export ALB_SCHEME ALB_CLASS_NAME ALB_GROUP_NAME

render 11-ingressclass.yaml | kubectl apply -f -
kubectl get ingressclass
ok "Next: ./cli/20-keda.sh"
