#!/usr/bin/env bash
# 05 - ROUTE TABLES: the signposts. "Traffic for the internet? Go this way."
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "05 Route tables"

VPC_ID="$(state_require vpc_id)"
IGW_ID="$(state_require igw_id)"
read_csv PUB  "$(state_require public_subnet_ids)"
read_csv PRV  "$(state_require private_subnet_ids)"
read_csv NATS "$(state_require nat_gateway_ids)"

rt_for() {                  # $1 = name -> creates or finds a route table
  local name="$1" id
  id="$(aws_ ec2 describe-route-tables --filters "Name=tag:Name,Values=${name}" \
        "Name=vpc-id,Values=${VPC_ID}" --query 'RouteTables[0].RouteTableId' --output text)"
  if [ "$id" = "None" ] || [ -z "$id" ]; then
    id="$(aws_ ec2 create-route-table --vpc-id "$VPC_ID" \
          --tag-specifications "ResourceType=route-table,Tags=[{Key=Name,Value=${name}}]" \
          --query 'RouteTable.RouteTableId' --output text)"
  fi
  printf '%s' "$id"
}
associate() {               # $1 = route table, $2 = subnet
  aws_ ec2 associate-route-table --route-table-id "$1" --subnet-id "$2" >/dev/null 2>&1 \
    || skip "subnet $2 already associated"
}

step "Public route table -> internet gateway"
PUB_RT="$(rt_for "${NAME_PREFIX}-rt-public")"
aws_ ec2 create-route --route-table-id "$PUB_RT" \
  --destination-cidr-block 0.0.0.0/0 --gateway-id "$IGW_ID" >/dev/null 2>&1 \
  || skip "default route already present"
for s in "${PUB[@]}"; do associate "$PUB_RT" "$s"; done
state_set public_route_table_id "$PUB_RT"

step "Private route tables -> NAT gateway"
PRV_RTS=""
i=0
for s in "${PRV[@]}"; do
  RT="$(rt_for "${NAME_PREFIX}-rt-private-${i}")"
  NAT="${NATS[$i]:-${NATS[0]}}"     # share NAT #0 when SINGLE_NAT_GATEWAY=true
  aws_ ec2 create-route --route-table-id "$RT" \
    --destination-cidr-block 0.0.0.0/0 --nat-gateway-id "$NAT" >/dev/null 2>&1 \
    || skip "default route already present on $RT"
  associate "$RT" "$s"
  PRV_RTS="${PRV_RTS:+$PRV_RTS,}$RT"
  i=$((i+1))
done
state_set private_route_table_ids "$PRV_RTS"
ok "Next: ./cli/06-security-groups.sh"
