#!/usr/bin/env bash
# 14 - OPENSEARCH: the search + dashboard layer.
# S3 answers "give me every sale in July" (slow, cheap, complete).
# OpenSearch answers "show me refunds over $200 in the last 15 minutes" (fast).
# You almost always want BOTH. This is the classic "warm store + cold store".
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "14 OpenSearch domain"
need jq

DOMAIN="$OPENSEARCH_DOMAIN"
[ "${#DOMAIN}" -le 28 ] || die "OPENSEARCH_DOMAIN must be <= 28 chars: $DOMAIN"

if aws_ opensearch describe-domain --domain-name "$DOMAIN" >/dev/null 2>&1; then
  skip "domain ${DOMAIN} exists"
else
  PASS="$OPENSEARCH_MASTER_PASSWORD"
  if [ -z "$PASS" ]; then
    step "Generating master password and storing it in Secrets Manager"
    PASS="$(LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 20)Aa1!"
    aws_ secretsmanager create-secret \
      --name "${NAME_PREFIX}/opensearch/master" \
      --secret-string "$(jq -nc --arg u "$OPENSEARCH_MASTER_USER" --arg p "$PASS" \
        '{username:$u,password:$p}')" >/dev/null 2>&1 \
    || aws_ secretsmanager put-secret-value \
      --secret-id "${NAME_PREFIX}/opensearch/master" \
      --secret-string "$(jq -nc --arg u "$OPENSEARCH_MASTER_USER" --arg p "$PASS" \
        '{username:$u,password:$p}')" >/dev/null
  fi

  step "Creating domain ${DOMAIN} (takes ~15 min)"
  run aws_ opensearch create-domain \
    --domain-name "$DOMAIN" \
    --engine-version "$OPENSEARCH_ENGINE_VERSION" \
    --cluster-config "$(jq -nc --arg t "$OPENSEARCH_INSTANCE_TYPE" \
        --argjson c "$OPENSEARCH_INSTANCE_COUNT" \
        '{InstanceType:$t, InstanceCount:$c, DedicatedMasterEnabled:false, ZoneAwarenessEnabled:false}')" \
    --ebs-options "$(jq -nc --argjson v "$OPENSEARCH_VOLUME_GB" \
        '{EBSEnabled:true, VolumeType:"gp3", VolumeSize:$v}')" \
    --node-to-node-encryption-options '{"Enabled":true}' \
    --encryption-at-rest-options '{"Enabled":true}' \
    --domain-endpoint-options '{"EnforceHTTPS":true,"TLSSecurityPolicy":"Policy-Min-TLS-1-2-2019-07"}' \
    --advanced-security-options "$(jq -nc --arg u "$OPENSEARCH_MASTER_USER" --arg p "$PASS" \
        '{Enabled:true, InternalUserDatabaseEnabled:true,
          MasterUserOptions:{MasterUserName:$u, MasterUserPassword:$p}}')" \
    --access-policies "$(jq -nc --arg acct "$(account_id)" --arg r "$AWS_REGION" --arg d "$DOMAIN" \
        '{Version:"2012-10-17",Statement:[{Effect:"Allow",Principal:{AWS:"*"},Action:"es:*",
          Resource:("arn:aws:es:"+$r+":"+$acct+":domain/"+$d+"/*")}]}')" \
    --tag-list "Key=Project,Value=${PROJECT}" "Key=Environment,Value=${ENVIRONMENT}" >/dev/null
fi

wait_for "OpenSearch domain to finish processing" 90 20 \
  "[ \"\$(aws --region $AWS_REGION --profile $AWS_PROFILE opensearch describe-domain --domain-name $DOMAIN --query 'DomainStatus.Processing' --output text)\" = False ]"

EP="$(aws_ opensearch describe-domain --domain-name "$DOMAIN" \
  --query 'DomainStatus.Endpoint' --output text)"
state_set opensearch_endpoint "https://${EP}"
state_set opensearch_arn "$(aws_ opensearch describe-domain --domain-name "$DOMAIN" --query 'DomainStatus.ARN' --output text)"
ok "Dashboards: https://${EP}/_dashboards/"
ok "Next: ./cli/15-ecr.sh"
