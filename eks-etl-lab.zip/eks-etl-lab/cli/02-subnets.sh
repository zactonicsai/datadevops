#!/usr/bin/env bash
# 02 - SUBNETS: slices of the VPC, one per Availability Zone.
# Public subnets  = rooms with a door to the street (load balancers live here).
# Private subnets = back rooms with no street door (your pods live here).
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "02 Subnets"

VPC_ID="$(state_require vpc_id)"
read_csv AZ_LIST "$(azs)"
read_csv PUB_CIDRS "$PUBLIC_SUBNET_CIDRS"
read_csv PRV_CIDRS "$PRIVATE_SUBNET_CIDRS"

create_subnet() {           # $1=name $2=cidr $3=az $4=public|private
  local name="$1" cidr="$2" az="$3" kind="$4" id
  id="$(aws_ ec2 describe-subnets --filters "Name=tag:Name,Values=${name}" \
        "Name=vpc-id,Values=${VPC_ID}" --query 'Subnets[0].SubnetId' --output text)"
  if [ "$id" != "None" ] && [ -n "$id" ]; then
    skip "subnet ${name} exists: ${id}"; printf '%s' "$id"; return
  fi
  id="$(aws_ ec2 create-subnet --vpc-id "$VPC_ID" --cidr-block "$cidr" \
        --availability-zone "$az" \
        --tag-specifications "ResourceType=subnet,Tags=[{Key=Name,Value=${name}}]" \
        --query 'Subnet.SubnetId' --output text)"

  # ---- The tags below are NOT decoration. AWS reads them. -------------------
  # kubernetes.io/role/elb        -> "put internet load balancers here"
  # kubernetes.io/role/internal-elb -> "put internal load balancers here"
  # kubernetes.io/cluster/<name>  -> "this subnet belongs to that cluster"
  if [ "$kind" = "public" ]; then
    aws_ ec2 create-tags --resources "$id" --tags \
      Key=kubernetes.io/role/elb,Value=1 \
      "Key=kubernetes.io/cluster/${CLUSTER_NAME},Value=shared" \
      Key=Tier,Value=public
    aws_ ec2 modify-subnet-attribute --subnet-id "$id" --map-public-ip-on-launch
  else
    aws_ ec2 create-tags --resources "$id" --tags \
      Key=kubernetes.io/role/internal-elb,Value=1 \
      "Key=kubernetes.io/cluster/${CLUSTER_NAME},Value=shared" \
      Key=Tier,Value=private
  fi
  printf '%s' "$id"
}

PUB_IDS=""; PRV_IDS=""
i=0
for az in "${AZ_LIST[@]}"; do
  step "AZ ${az}"
  p="$(create_subnet "${NAME_PREFIX}-public-${az}"  "${PUB_CIDRS[$i]}" "$az" public)"
  q="$(create_subnet "${NAME_PREFIX}-private-${az}" "${PRV_CIDRS[$i]}" "$az" private)"
  PUB_IDS="${PUB_IDS:+$PUB_IDS,}$p"
  PRV_IDS="${PRV_IDS:+$PRV_IDS,}$q"
  i=$((i+1))
done

state_set public_subnet_ids  "$PUB_IDS"
state_set private_subnet_ids "$PRV_IDS"
ok "Next: ./cli/03-internet-gateway.sh"
