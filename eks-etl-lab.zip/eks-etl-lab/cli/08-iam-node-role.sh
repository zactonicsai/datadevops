#!/usr/bin/env bash
# 08 - IAM ROLE FOR THE NODES (each EC2 machine's badge).
# In Auto Mode this role is much SMALLER than the old node role: AWS handles
# the CNI and most of the plumbing, so nodes only need the container runtime
# permissions plus ECR pull.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "08 IAM node role"

ROLE="${NAME_PREFIX}-eks-node-role"
TRUST='{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"ec2.amazonaws.com"},"Action":["sts:AssumeRole"]}]}'

if aws_ iam get-role --role-name "$ROLE" >/dev/null 2>&1; then
  skip "role ${ROLE} exists"
else
  step "Creating role ${ROLE}"
  aws_ iam create-role --role-name "$ROLE" \
    --assume-role-policy-document "$TRUST" \
    --description "EKS node role for ${CLUSTER_NAME}" \
    --tags "Key=Project,Value=${PROJECT}" "Key=Environment,Value=${ENVIRONMENT}" >/dev/null
fi

if [ "$AUTO_MODE" = "true" ]; then
  POLICIES="arn:aws:iam::aws:policy/AmazonEKSWorkerNodeMinimalPolicy
arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryPullOnly"
else
  POLICIES="arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy
arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy
arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
fi

for p in $POLICIES; do
  step "Attaching $(basename "$p")"
  aws_ iam attach-role-policy --role-name "$ROLE" --policy-arn "$p"
done

state_set node_role_arn "$(aws_ iam get-role --role-name "$ROLE" --query 'Role.Arn' --output text)"
ok "Next: ./cli/09-eks-cluster.sh"
