#!/usr/bin/env bash
# 00 - PRE-FLIGHT: check tools, credentials and quotas. Creates nothing.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "00 Pre-flight checks"

for t in aws jq kubectl helm envsubst; do
  if command -v "$t" >/dev/null 2>&1; then ok "found $t"; else warn "missing $t"; fi
done
need aws; need jq

CLI_VER="$(aws --version 2>&1 | awk '{print $1}')"
ok "aws cli: $CLI_VER   (need aws-cli/2.x for EKS Auto Mode flags)"

step "Who am I?"
aws_ sts get-caller-identity --output table || die "AWS credentials are not working. Run: aws configure --profile $AWS_PROFILE"
state_set account_id "$(aws_ sts get-caller-identity --query Account --output text)"

step "Availability Zones"
ok "using: $(azs)"

step "Elastic IP quota (NAT gateways need one each)"
aws_ ec2 describe-account-attributes --attribute-names supported-platforms >/dev/null && ok "EC2 API reachable"

step "Config that will be used"
cat <<EOF
  PROJECT ............ $PROJECT
  ENVIRONMENT ........ $ENVIRONMENT
  NAME_PREFIX ........ $NAME_PREFIX
  AWS_REGION ......... $AWS_REGION
  CLUSTER_NAME ....... $CLUSTER_NAME
  K8S_VERSION ........ $K8S_VERSION
  AUTO_MODE .......... $AUTO_MODE
  VPC_CIDR ........... $VPC_CIDR
  KAFKA_BACKEND ...... $KAFKA_BACKEND
  S3_BUCKET .......... $S3_BUCKET
  OPENSEARCH_DOMAIN .. $OPENSEARCH_DOMAIN
  STATE_DIR .......... $STATE_DIR
EOF
ok "Pre-flight complete. Next: ./cli/01-vpc.sh"
