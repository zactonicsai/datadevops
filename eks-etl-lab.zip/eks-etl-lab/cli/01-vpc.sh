#!/usr/bin/env bash
# 01 - VPC: the private network that holds everything else.
# Real world: your shop's own building. Nothing gets in unless you open a door.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "01 VPC"

VPC_NAME="${NAME_PREFIX}-vpc"

EXISTING="$(aws_ ec2 describe-vpcs --filters "Name=tag:Name,Values=${VPC_NAME}" \
  --query 'Vpcs[0].VpcId' --output text)"

if [ "$EXISTING" != "None" ] && [ -n "$EXISTING" ]; then
  skip "VPC ${VPC_NAME} already exists: ${EXISTING}"
  state_set vpc_id "$EXISTING"
else
  step "Creating VPC ${VPC_NAME} (${VPC_CIDR})"
  VPC_ID="$(aws_ ec2 create-vpc \
    --cidr-block "$VPC_CIDR" \
    --tag-specifications "ResourceType=vpc,Tags=[{Key=Name,Value=${VPC_NAME}},${TAGS_INLINE}]" \
    --query 'Vpc.VpcId' --output text)"
  state_set vpc_id "$VPC_ID"

  # DNS is required by EKS: pods find each other and AWS services by name.
  aws_ ec2 modify-vpc-attribute --vpc-id "$VPC_ID" --enable-dns-support   '{"Value":true}'
  aws_ ec2 modify-vpc-attribute --vpc-id "$VPC_ID" --enable-dns-hostnames '{"Value":true}'
  ok "VPC created: $VPC_ID"
fi

if [ "$ENABLE_FLOW_LOGS" = "true" ]; then
  step "Enabling VPC flow logs (who talked to whom)"
  aws_ ec2 create-flow-logs \
    --resource-type VPC --resource-ids "$(state_get vpc_id)" \
    --traffic-type ALL --log-destination-type cloud-watch-logs \
    --log-group-name "/aws/vpc/${NAME_PREFIX}" \
    --deliver-logs-permission-arn "arn:aws:iam::$(account_id):role/${NAME_PREFIX}-flowlogs" \
    >/dev/null 2>&1 || warn "flow logs skipped (create the IAM role first)"
fi

ok "Next: ./cli/02-subnets.sh"
