#!/usr/bin/env bash
# 07 - IAM ROLE FOR THE CLUSTER (the control plane's badge).
# A role = "a job you can borrow". The trust policy says WHO may borrow it.
# EKS Auto Mode needs two policies: the classic cluster policy plus the new
# compute/networking/loadbalancing/blockstorage policies for managing nodes.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "07 IAM cluster role"

ROLE="${NAME_PREFIX}-eks-cluster-role"
TRUST='{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"eks.amazonaws.com"},"Action":["sts:AssumeRole","sts:TagSession"]}]}'

if aws_ iam get-role --role-name "$ROLE" >/dev/null 2>&1; then
  skip "role ${ROLE} exists"
else
  step "Creating role ${ROLE}"
  aws_ iam create-role --role-name "$ROLE" \
    --assume-role-policy-document "$TRUST" \
    --description "EKS control plane role for ${CLUSTER_NAME}" \
    --tags "Key=Project,Value=${PROJECT}" "Key=Environment,Value=${ENVIRONMENT}" >/dev/null
fi

POLICIES="arn:aws:iam::aws:policy/AmazonEKSClusterPolicy"
if [ "$AUTO_MODE" = "true" ]; then
  POLICIES="$POLICIES
arn:aws:iam::aws:policy/AmazonEKSComputePolicy
arn:aws:iam::aws:policy/AmazonEKSBlockStoragePolicy
arn:aws:iam::aws:policy/AmazonEKSLoadBalancingPolicy
arn:aws:iam::aws:policy/AmazonEKSNetworkingPolicy"
fi

for p in $POLICIES; do
  step "Attaching $(basename "$p")"
  aws_ iam attach-role-policy --role-name "$ROLE" --policy-arn "$p"
done

state_set cluster_role_arn "$(aws_ iam get-role --role-name "$ROLE" --query 'Role.Arn' --output text)"
ok "Next: ./cli/08-iam-node-role.sh"
