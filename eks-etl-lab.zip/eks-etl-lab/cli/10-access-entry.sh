#!/usr/bin/env bash
# 10 - ACCESS ENTRY: who is allowed to run kubectl.
# The old way was editing a scary ConfigMap called aws-auth. The new way is an
# API call, which means it is auditable and it can be code. Always use this.
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "10 Cluster access entry"

: "${ADMIN_PRINCIPAL_ARN:=}"
if [ -z "$ADMIN_PRINCIPAL_ARN" ]; then
  ADMIN_PRINCIPAL_ARN="$(aws_ sts get-caller-identity --query Arn --output text)"
  # An assumed-role ARN must be converted back to the plain role ARN.
  case "$ADMIN_PRINCIPAL_ARN" in
    *:assumed-role/*)
      ROLE_NAME="$(printf '%s' "$ADMIN_PRINCIPAL_ARN" | cut -d/ -f2)"
      ADMIN_PRINCIPAL_ARN="arn:aws:iam::$(account_id):role/${ROLE_NAME}" ;;
  esac
fi
log "Granting cluster-admin to: ${ADMIN_PRINCIPAL_ARN}"

if aws_ eks describe-access-entry --cluster-name "$CLUSTER_NAME" \
     --principal-arn "$ADMIN_PRINCIPAL_ARN" >/dev/null 2>&1; then
  skip "access entry exists"
else
  run aws_ eks create-access-entry --cluster-name "$CLUSTER_NAME" \
    --principal-arn "$ADMIN_PRINCIPAL_ARN" --type STANDARD >/dev/null
fi

run aws_ eks associate-access-policy --cluster-name "$CLUSTER_NAME" \
  --principal-arn "$ADMIN_PRINCIPAL_ARN" \
  --policy-arn arn:aws:eks::aws:cluster-access-policy/AmazonEKSClusterAdminPolicy \
  --access-scope '{"type":"cluster"}' >/dev/null 2>&1 || skip "policy already associated"

ok "Next: ./cli/11-kubeconfig.sh"
