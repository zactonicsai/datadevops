#!/usr/bin/env bash
# 16 - IAM ROLE FOR THE APPS (least privilege, per workload).
# This is the role the ETL worker pod borrows so it can:
#   * write objects to ONE bucket (not all buckets)
#   * read/write ONE Kafka cluster's topics
#   * write documents into ONE OpenSearch domain
# Trust policy points at pods.eks.amazonaws.com -> "EKS Pod Identity".
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
banner "16 IAM application role"

ROLE="${NAME_PREFIX}-etl-app-role"
ACCT="$(account_id)"
BUCKET="$(state_require s3_bucket)"

TRUST='{"Version":"2012-10-17","Statement":[{"Effect":"Allow",
  "Principal":{"Service":"pods.eks.amazonaws.com"},
  "Action":["sts:AssumeRole","sts:TagSession"]}]}'

if aws_ iam get-role --role-name "$ROLE" >/dev/null 2>&1; then
  skip "role ${ROLE} exists"
else
  step "Creating ${ROLE}"
  run aws_ iam create-role --role-name "$ROLE" \
    --assume-role-policy-document "$TRUST" \
    --description "ETL app role for ${CLUSTER_NAME}" >/dev/null
fi

KAFKA_ARN="$(state_get kafka_arn)"
OS_ARN="$(state_get opensearch_arn)"

POLICY="$(jq -nc --arg b "$BUCKET" --arg k "${KAFKA_ARN:-arn:aws:kafka:*:*:cluster/none/*}" \
  --arg o "${OS_ARN:-arn:aws:es:*:*:domain/none}" '
{Version:"2012-10-17", Statement:[
 {Sid:"ListTheBucket",   Effect:"Allow", Action:["s3:ListBucket","s3:GetBucketLocation"],
  Resource:["arn:aws:s3:::"+$b]},
 {Sid:"ReadWriteObjects",Effect:"Allow", Action:["s3:PutObject","s3:GetObject","s3:DeleteObject","s3:AbortMultipartUpload"],
  Resource:["arn:aws:s3:::"+$b+"/*"]},
 {Sid:"KafkaConnect",    Effect:"Allow", Action:["kafka-cluster:Connect","kafka-cluster:DescribeCluster","kafka-cluster:AlterCluster"],
  Resource:[$k]},
 {Sid:"KafkaTopics",     Effect:"Allow", Action:["kafka-cluster:*Topic*","kafka-cluster:WriteData","kafka-cluster:ReadData"],
  Resource:["*"]},
 {Sid:"KafkaGroups",     Effect:"Allow", Action:["kafka-cluster:AlterGroup","kafka-cluster:DescribeGroup"],
  Resource:["*"]},
 {Sid:"OpenSearchWrite", Effect:"Allow", Action:["es:ESHttpPost","es:ESHttpPut","es:ESHttpGet","es:ESHttpHead"],
  Resource:[$o+"/*"]}
]}')"

step "Attaching inline least-privilege policy"
run aws_ iam put-role-policy --role-name "$ROLE" \
  --policy-name "${NAME_PREFIX}-etl-access" --policy-document "$POLICY"

state_set app_role_arn "$(aws_ iam get-role --role-name "$ROLE" --query Role.Arn --output text)"
ok "Next: ./cli/17-pod-identity.sh"
