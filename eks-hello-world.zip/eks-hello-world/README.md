# EKS Hello World

Creates a VPC, an EKS cluster with one t3.small node, and deploys a
hello-world HTTP pod behind a public load balancer.

## Usage

    terraform init
    terraform apply

Takes ~15 min. Then:

    aws eks update-kubeconfig --region us-east-1 --name hello-eks
    kubectl get pods
    kubectl get svc hello-world      # grab the EXTERNAL-IP
    curl http://<EXTERNAL-IP>

## Cleanup

    terraform destroy

Note: EKS costs ~$0.10/hr for the control plane plus the node and NAT gateway.
