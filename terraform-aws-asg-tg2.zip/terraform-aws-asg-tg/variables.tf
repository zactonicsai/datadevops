###############################################################################
# Naming
###############################################################################

variable "name_prefix" {
  description = "Prefix applied to every resource this module creates."
  type        = string

  validation {
    condition     = can(regex("^[a-zA-Z0-9][a-zA-Z0-9-]{0,24}$", var.name_prefix))
    error_message = "name_prefix must be 1-25 alphanumeric/hyphen characters and start with alphanumeric."
  }
}

###############################################################################
# Networking (existing)
###############################################################################

variable "vpc_id" {
  description = "VPC that the target group is created in."
  type        = string
}

variable "subnet_ids" {
  description = "Existing subnet IDs the ASG launches instances into."
  type        = list(string)

  validation {
    condition     = length(var.subnet_ids) > 0
    error_message = "At least one subnet ID is required."
  }
}

variable "security_group_ids" {
  description = <<-EOT
    Existing security group IDs attached to the instances.
    Only applied when create_derived_launch_template = true, because security
    groups are an attribute of the launch template, not the ASG.
  EOT
  type        = list(string)
  default     = []
}

###############################################################################
# IAM (existing)
###############################################################################

variable "iam_role_name" {
  description = "Name of the existing IAM role used by the instances."
  type        = string
}

variable "iam_policy_arns" {
  description = "ARNs of existing IAM policies to attach to iam_role_name."
  type        = list(string)
  default     = []
}

variable "iam_instance_profile_name" {
  description = <<-EOT
    Existing instance profile to put on the instances. If null, the profile
    already defined on the source launch template is reused.
  EOT
  type        = string
  default     = null
}

###############################################################################
# Launch template (existing)
###############################################################################

variable "launch_template_id" {
  description = "ID of the existing launch template to launch instances from."
  type        = string
}

variable "launch_template_version" {
  description = "Version of the existing launch template ($Latest, $Default or a number)."
  type        = string
  default     = "$Latest"
}

variable "create_derived_launch_template" {
  description = <<-EOT
    When true (default) the module copies the core settings of the existing
    launch template into a new one it owns, so it can override the security
    groups and instance profile. Set to false to launch straight from the
    existing template unchanged (security_group_ids and
    iam_instance_profile_name are then ignored).
  EOT
  type        = bool
  default     = true
}

###############################################################################
# Auto Scaling Group
###############################################################################

variable "min_size" {
  description = "Minimum instance count."
  type        = number
  default     = 1
}

variable "max_size" {
  description = "Maximum instance count."
  type        = number
  default     = 2
}

variable "desired_capacity" {
  description = "Desired instance count. Null lets the ASG manage it after creation."
  type        = number
  default     = null
}

variable "health_check_type" {
  description = "ASG health check type: EC2 or ELB."
  type        = string
  default     = "ELB"

  validation {
    condition     = contains(["EC2", "ELB"], var.health_check_type)
    error_message = "health_check_type must be EC2 or ELB."
  }
}

variable "health_check_grace_period" {
  description = "Seconds before the ASG starts health checking a new instance."
  type        = number
  default     = 300
}

variable "capacity_rebalance" {
  description = "Enable capacity rebalancing (useful with Spot)."
  type        = bool
  default     = false
}

variable "enable_instance_refresh" {
  description = "Roll instances automatically when the launch template changes."
  type        = bool
  default     = true
}

variable "instance_refresh_min_healthy_percentage" {
  description = "Minimum healthy percentage kept during an instance refresh."
  type        = number
  default     = 90
}

variable "termination_policies" {
  description = "Order in which instances are terminated on scale-in."
  type        = list(string)
  default     = ["Default"]
}

variable "wait_for_capacity_timeout" {
  description = "How long Terraform waits for instances to become healthy. Use \"0\" to skip waiting."
  type        = string
  default     = "10m"
}

###############################################################################
# Target Group
###############################################################################

variable "target_group_port" {
  description = "Port the target group forwards to."
  type        = number
  default     = 80
}

variable "target_group_protocol" {
  description = "Target group protocol (HTTP, HTTPS, TCP, TLS, UDP, TCP_UDP, GENEVE)."
  type        = string
  default     = "HTTP"
}

variable "target_type" {
  description = "Target type: instance, ip, alb or lambda."
  type        = string
  default     = "instance"
}

variable "deregistration_delay" {
  description = "Seconds to wait before deregistering a target."
  type        = number
  default     = 60
}

variable "slow_start" {
  description = "Seconds a newly registered target is given to warm up. 0 disables it."
  type        = number
  default     = 0
}

variable "stickiness_enabled" {
  description = "Enable target group stickiness."
  type        = bool
  default     = false
}

variable "stickiness_type" {
  description = "Stickiness type, e.g. lb_cookie or app_cookie."
  type        = string
  default     = "lb_cookie"
}

variable "stickiness_duration" {
  description = "Stickiness cookie duration in seconds."
  type        = number
  default     = 86400
}

variable "health_check" {
  description = "Target group health check settings."
  type = object({
    enabled             = optional(bool, true)
    path                = optional(string, "/")
    port                = optional(string, "traffic-port")
    protocol            = optional(string, "HTTP")
    matcher             = optional(string, "200-399")
    interval            = optional(number, 30)
    timeout             = optional(number, 5)
    healthy_threshold   = optional(number, 3)
    unhealthy_threshold = optional(number, 3)
  })
  default = {}
}

###############################################################################
# Tagging
###############################################################################

variable "tags" {
  description = "Tags applied to all resources. ASG tags propagate at launch."
  type        = map(string)
  default     = {}
}
