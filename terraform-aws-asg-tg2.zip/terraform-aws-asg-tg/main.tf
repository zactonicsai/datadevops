###############################################################################
# Locals
###############################################################################

locals {
  # Instance profile to place on the derived launch template: caller value
  # first, otherwise whatever the source template already carries.
  source_instance_profile = try(
    one(data.aws_launch_template.source.iam_instance_profile).name,
    null
  )

  instance_profile_name = try(
    coalesce(var.iam_instance_profile_name, local.source_instance_profile),
    null
  )

  # Point the ASG at the template this module owns, or at the caller's.
  launch_template_id = var.create_derived_launch_template ? aws_launch_template.this[0].id : var.launch_template_id

  launch_template_version = (
    var.create_derived_launch_template
    ? tostring(aws_launch_template.this[0].latest_version)
    : var.launch_template_version
  )

  # Health check path is only valid for HTTP/HTTPS health checks.
  health_check_path = contains(["HTTP", "HTTPS"], upper(var.health_check.protocol)) ? var.health_check.path : null

  health_check_matcher = contains(["HTTP", "HTTPS"], upper(var.health_check.protocol)) ? var.health_check.matcher : null

  asg_tags = merge({ Name = "${var.name_prefix}-asg" }, var.tags)
}

###############################################################################
# Existing launch template
###############################################################################

data "aws_launch_template" "source" {
  id = var.launch_template_id
}

###############################################################################
# Attach existing IAM policies to the existing instance role
###############################################################################

resource "aws_iam_role_policy_attachment" "this" {
  for_each = toset(var.iam_policy_arns)

  role       = var.iam_role_name
  policy_arn = each.value
}

###############################################################################
# Derived launch template
#
# The ASG API cannot override security groups or the instance profile, so when
# those need to change we copy the source template's core settings into a
# template this module owns.
###############################################################################

resource "aws_launch_template" "this" {
  count = var.create_derived_launch_template ? 1 : 0

  name_prefix = "${var.name_prefix}-"
  description = "Derived from ${var.launch_template_id} by the ${var.name_prefix} ASG module"

  update_default_version = true

  image_id      = data.aws_launch_template.source.image_id
  instance_type = data.aws_launch_template.source.instance_type
  key_name      = try(data.aws_launch_template.source.key_name, "") != "" ? data.aws_launch_template.source.key_name : null
  user_data     = try(data.aws_launch_template.source.user_data, "") != "" ? data.aws_launch_template.source.user_data : null
  ebs_optimized = try(tobool(data.aws_launch_template.source.ebs_optimized), null)

  vpc_security_group_ids = var.security_group_ids

  dynamic "iam_instance_profile" {
    for_each = local.instance_profile_name != null ? [local.instance_profile_name] : []

    content {
      name = iam_instance_profile.value
    }
  }

  dynamic "block_device_mappings" {
    for_each = data.aws_launch_template.source.block_device_mappings

    content {
      device_name  = block_device_mappings.value.device_name
      no_device    = try(block_device_mappings.value.no_device, "") != "" ? block_device_mappings.value.no_device : null
      virtual_name = try(block_device_mappings.value.virtual_name, "") != "" ? block_device_mappings.value.virtual_name : null

      dynamic "ebs" {
        for_each = try(block_device_mappings.value.ebs, [])

        content {
          delete_on_termination = try(tobool(ebs.value.delete_on_termination), null)
          encrypted             = try(tobool(ebs.value.encrypted), null)
          iops                  = try(ebs.value.iops, 0) > 0 ? ebs.value.iops : null
          throughput            = try(ebs.value.throughput, 0) > 0 ? ebs.value.throughput : null
          kms_key_id            = try(ebs.value.kms_key_id, "") != "" ? ebs.value.kms_key_id : null
          snapshot_id           = try(ebs.value.snapshot_id, "") != "" ? ebs.value.snapshot_id : null
          volume_size           = try(ebs.value.volume_size, 0) > 0 ? ebs.value.volume_size : null
          volume_type           = try(ebs.value.volume_type, "") != "" ? ebs.value.volume_type : null
        }
      }
    }
  }

  dynamic "metadata_options" {
    for_each = data.aws_launch_template.source.metadata_options

    content {
      http_endpoint               = try(metadata_options.value.http_endpoint, null)
      http_tokens                 = try(metadata_options.value.http_tokens, null)
      http_put_response_hop_limit = try(metadata_options.value.http_put_response_hop_limit, null)
      http_protocol_ipv6          = try(metadata_options.value.http_protocol_ipv6, null)
      instance_metadata_tags      = try(metadata_options.value.instance_metadata_tags, null)
    }
  }

  dynamic "monitoring" {
    for_each = data.aws_launch_template.source.monitoring

    content {
      enabled = try(tobool(monitoring.value.enabled), null)
    }
  }

  tag_specifications {
    resource_type = "instance"
    tags          = local.asg_tags
  }

  tag_specifications {
    resource_type = "volume"
    tags          = local.asg_tags
  }

  tags = merge({ Name = "${var.name_prefix}-lt" }, var.tags)

  lifecycle {
    create_before_destroy = true
  }

  depends_on = [aws_iam_role_policy_attachment.this]
}

###############################################################################
# Target group
###############################################################################

resource "aws_lb_target_group" "this" {
  name_prefix = substr("${var.name_prefix}-", 0, 6)

  vpc_id      = var.vpc_id
  port        = var.target_group_port
  protocol    = upper(var.target_group_protocol)
  target_type = var.target_type

  deregistration_delay = var.deregistration_delay
  slow_start           = var.slow_start > 0 ? var.slow_start : null

  health_check {
    enabled             = var.health_check.enabled
    path                = local.health_check_path
    port                = var.health_check.port
    protocol            = upper(var.health_check.protocol)
    matcher             = local.health_check_matcher
    interval            = var.health_check.interval
    timeout             = var.health_check.timeout
    healthy_threshold   = var.health_check.healthy_threshold
    unhealthy_threshold = var.health_check.unhealthy_threshold
  }

  dynamic "stickiness" {
    for_each = var.stickiness_enabled ? [1] : []

    content {
      enabled         = true
      type            = var.stickiness_type
      cookie_duration = var.stickiness_duration
    }
  }

  tags = merge({ Name = "${var.name_prefix}-tg" }, var.tags)

  lifecycle {
    create_before_destroy = true
  }
}

###############################################################################
# Auto Scaling Group
###############################################################################

resource "aws_autoscaling_group" "this" {
  name_prefix = "${var.name_prefix}-"

  vpc_zone_identifier = var.subnet_ids

  min_size         = var.min_size
  max_size         = var.max_size
  desired_capacity = var.desired_capacity

  health_check_type         = var.health_check_type
  health_check_grace_period = var.health_check_grace_period
  capacity_rebalance        = var.capacity_rebalance
  termination_policies      = var.termination_policies

  target_group_arns         = [aws_lb_target_group.this.arn]
  wait_for_capacity_timeout = var.wait_for_capacity_timeout

  launch_template {
    id      = local.launch_template_id
    version = local.launch_template_version
  }

  dynamic "instance_refresh" {
    for_each = var.enable_instance_refresh ? [1] : []

    content {
      strategy = "Rolling"

      preferences {
        min_healthy_percentage = var.instance_refresh_min_healthy_percentage
      }

      triggers = ["launch_template"]
    }
  }

  dynamic "tag" {
    for_each = local.asg_tags

    content {
      key                 = tag.key
      value               = tag.value
      propagate_at_launch = true
    }
  }

  lifecycle {
    create_before_destroy = true

    # Leave desired_capacity alone once scaling policies take over.
    ignore_changes = [desired_capacity]
  }

  depends_on = [aws_iam_role_policy_attachment.this]
}
