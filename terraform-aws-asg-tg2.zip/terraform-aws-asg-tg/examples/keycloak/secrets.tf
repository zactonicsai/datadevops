###############################################################################
# Generated credentials
###############################################################################

resource "random_password" "db" {
  length           = 32
  override_special = "!#$%&*()-_=+[]{}<>:?"
}

resource "random_password" "admin" {
  length           = 24
  override_special = "!#$%&*()-_=+"
}

###############################################################################
# Database credentials secret
#
# Stored in the standard RDS secret shape so rotation lambdas and other tooling
# can read it without translation.
###############################################################################

resource "aws_secretsmanager_secret" "db" {
  name_prefix             = "${var.name_prefix}/db-"
  description             = "Keycloak PostgreSQL master credentials"
  kms_key_id              = var.kms_key_id
  recovery_window_in_days = var.secret_recovery_window_days

  tags = merge(var.tags, { Name = "${var.name_prefix}-db-secret" })
}

resource "aws_secretsmanager_secret_version" "db" {
  secret_id = aws_secretsmanager_secret.db.id

  secret_string = jsonencode({
    engine   = "postgres"
    username = var.db_username
    password = random_password.db.result
    host     = aws_db_instance.this.address
    port     = aws_db_instance.this.port
    dbname   = var.db_name
  })
}

###############################################################################
# Keycloak bootstrap admin secret
###############################################################################

resource "aws_secretsmanager_secret" "admin" {
  name_prefix             = "${var.name_prefix}/admin-"
  description             = "Keycloak bootstrap admin credentials"
  kms_key_id              = var.kms_key_id
  recovery_window_in_days = var.secret_recovery_window_days

  tags = merge(var.tags, { Name = "${var.name_prefix}-admin-secret" })
}

resource "aws_secretsmanager_secret_version" "admin" {
  secret_id = aws_secretsmanager_secret.admin.id

  secret_string = jsonencode({
    username = var.keycloak_admin_username
    password = random_password.admin.result
  })
}
