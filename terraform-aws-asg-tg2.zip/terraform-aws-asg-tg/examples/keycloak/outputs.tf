output "keycloak_url" {
  description = "Public Keycloak URL. Point var.hostname at alb_dns_name."
  value       = "https://${var.hostname}"
}

output "alb_dns_name" {
  description = "ALB DNS name to create the CNAME/alias record against."
  value       = aws_lb.this.dns_name
}

output "alb_zone_id" {
  description = "ALB hosted zone ID, for a Route 53 alias record."
  value       = aws_lb.this.zone_id
}

output "autoscaling_group_name" {
  description = "Name of the Keycloak ASG."
  value       = module.keycloak_asg.autoscaling_group_name
}

output "target_group_arn" {
  description = "Target group serving Keycloak."
  value       = module.keycloak_asg.target_group_arn
}

output "db_endpoint" {
  description = "RDS endpoint."
  value       = aws_db_instance.this.endpoint
}

output "db_security_group_id" {
  description = "Security group created for RDS."
  value       = aws_security_group.rds.id
}

output "keycloak_security_group_id" {
  description = "Security group created for the Keycloak instances."
  value       = aws_security_group.keycloak.id
}

output "db_secret_arn" {
  description = "Secret holding the PostgreSQL credentials."
  value       = aws_secretsmanager_secret.db.arn
}

output "admin_secret_arn" {
  description = "Secret holding the Keycloak bootstrap admin credentials."
  value       = aws_secretsmanager_secret.admin.arn
}
