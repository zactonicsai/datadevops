# Example: Keycloak on the ASG module

Runs Keycloak as a Docker container on an EC2 Auto Scaling Group behind an ALB,
backed by RDS PostgreSQL, with credentials in Secrets Manager.

## What this example creates

- Security groups for the ALB, the Keycloak instances, and **RDS**
- `aws_db_instance` PostgreSQL, encrypted, private, optionally Multi-AZ
- Two Secrets Manager secrets: DB credentials and the bootstrap admin
- A launch template that runs the Keycloak container from user data
- The ASG + target group, via the parent module
- An ALB with an HTTPS listener and an HTTP→HTTPS redirect

## What it expects to already exist

- A VPC with public, private and (optionally) database subnets
- An **existing IAM role and instance profile** — this example does not create them
- **Existing managed policy ARNs** passed via `existing_policy_arns`; the module
  attaches them to the role
- An ACM certificate and a DNS name you control

## Credential flow

Nothing sensitive lands in the launch template. User data holds only the secret
ARNs; each instance calls `secretsmanager:GetSecretValue` at boot using the
instance role, exports the values as container environment variables, and
unsets its shell copies.

That means one of your `existing_policy_arns` must grant read access. Minimum:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": ["secretsmanager:GetSecretValue"],
      "Resource": [
        "arn:aws:secretsmanager:us-east-1:123456789012:secret:keycloak/db-*",
        "arn:aws:secretsmanager:us-east-1:123456789012:secret:keycloak/admin-*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": ["kms:Decrypt"],
      "Resource": "arn:aws:kms:us-east-1:123456789012:key/YOUR-KEY-ID",
      "Condition": {
        "StringEquals": { "kms:ViaService": "secretsmanager.us-east-1.amazonaws.com" }
      }
    }
  ]
}
```

The `kms:Decrypt` statement is only needed if you set `kms_key_id`.

## Usage

```bash
cp terraform.tfvars.example terraform.tfvars
# edit terraform.tfvars
terraform init
terraform apply
```

Then create a DNS alias for `var.hostname` pointing at the `alb_dns_name` output,
and read the admin password:

```bash
aws secretsmanager get-secret-value \
  --secret-id "$(terraform output -raw admin_secret_arn)" \
  --query SecretString --output text | jq -r .password
```

## Health checks

Keycloak 25+ serves `/health/ready` on management port **9000**, not on 8080, so
the target group health checks port 9000 while traffic goes to 8080. Both ports
are open from the ALB security group only.

First boot runs the database migration, so `health_check_grace_period` is 600s
and `wait_for_capacity_timeout` is 20m. Lower them once you bake an AMI.

## Clustering

Multiple instances need Infinispan discovery. `keycloak_cache_stack` defaults to
`jdbc-ping`, which uses the shared database and requires **Keycloak 26.1+**. On
older images, set `keycloak_cache_stack = null` and run `min_size = 1`, or supply
your own cache configuration.

## Production notes

- `start --optimized=false` re-augments on every boot, which costs 30–60s. For
  production, build an image with `kc.sh build` baked in and use `--optimized`.
- Set `db_deletion_protection = true` (the default) and leave
  `db_skip_final_snapshot = false` outside sandboxes.
- The example sets both `KEYCLOAK_ADMIN*` and `KC_BOOTSTRAP_ADMIN*` so the same
  user data works on Keycloak 24 through 26. Drop the pair you don't need.
- Bootstrap admin credentials are only used to create the first account. Rotate
  or remove them once real admin users exist.
- Rotating `db_secret` will not restart running containers; trigger an ASG
  instance refresh afterwards.
