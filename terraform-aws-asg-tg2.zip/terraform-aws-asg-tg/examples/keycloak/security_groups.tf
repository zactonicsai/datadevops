###############################################################################
# ALB security group
###############################################################################

resource "aws_security_group" "alb" {
  name_prefix = "${var.name_prefix}-alb-"
  description = "Ingress to the Keycloak load balancer"
  vpc_id      = var.vpc_id

  tags = merge(var.tags, { Name = "${var.name_prefix}-alb" })

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_vpc_security_group_ingress_rule" "alb_https" {
  for_each = toset(var.alb_ingress_cidrs)

  security_group_id = aws_security_group.alb.id
  description       = "HTTPS from ${each.value}"
  cidr_ipv4         = each.value
  from_port         = 443
  to_port           = 443
  ip_protocol       = "tcp"
}

resource "aws_vpc_security_group_ingress_rule" "alb_http_redirect" {
  for_each = toset(var.alb_ingress_cidrs)

  security_group_id = aws_security_group.alb.id
  description       = "HTTP from ${each.value}, redirected to HTTPS"
  cidr_ipv4         = each.value
  from_port         = 80
  to_port           = 80
  ip_protocol       = "tcp"
}

resource "aws_vpc_security_group_egress_rule" "alb_to_keycloak_http" {
  security_group_id            = aws_security_group.alb.id
  description                  = "Forward to Keycloak HTTP"
  referenced_security_group_id = aws_security_group.keycloak.id
  from_port                    = 8080
  to_port                      = 8080
  ip_protocol                  = "tcp"
}

resource "aws_vpc_security_group_egress_rule" "alb_to_keycloak_health" {
  security_group_id            = aws_security_group.alb.id
  description                  = "Health check on the Keycloak management port"
  referenced_security_group_id = aws_security_group.keycloak.id
  from_port                    = 9000
  to_port                      = 9000
  ip_protocol                  = "tcp"
}

###############################################################################
# Keycloak instance security group
###############################################################################

resource "aws_security_group" "keycloak" {
  name_prefix = "${var.name_prefix}-app-"
  description = "Keycloak application instances"
  vpc_id      = var.vpc_id

  tags = merge(var.tags, { Name = "${var.name_prefix}-app" })

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_vpc_security_group_ingress_rule" "keycloak_http" {
  security_group_id            = aws_security_group.keycloak.id
  description                  = "HTTP from the ALB"
  referenced_security_group_id = aws_security_group.alb.id
  from_port                    = 8080
  to_port                      = 8080
  ip_protocol                  = "tcp"
}

resource "aws_vpc_security_group_ingress_rule" "keycloak_health" {
  security_group_id            = aws_security_group.keycloak.id
  description                  = "Health checks from the ALB"
  referenced_security_group_id = aws_security_group.alb.id
  from_port                    = 9000
  to_port                      = 9000
  ip_protocol                  = "tcp"
}

resource "aws_vpc_security_group_egress_rule" "keycloak_all" {
  security_group_id = aws_security_group.keycloak.id
  description       = "Outbound for image pulls, Secrets Manager and SSM"
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"
}

###############################################################################
# RDS security group — created here, only reachable from Keycloak
###############################################################################

resource "aws_security_group" "rds" {
  name_prefix = "${var.name_prefix}-rds-"
  description = "PostgreSQL access for Keycloak"
  vpc_id      = var.vpc_id

  tags = merge(var.tags, { Name = "${var.name_prefix}-rds" })

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_vpc_security_group_ingress_rule" "rds_from_keycloak" {
  security_group_id            = aws_security_group.rds.id
  description                  = "PostgreSQL from the Keycloak instances"
  referenced_security_group_id = aws_security_group.keycloak.id
  from_port                    = 5432
  to_port                      = 5432
  ip_protocol                  = "tcp"
}
