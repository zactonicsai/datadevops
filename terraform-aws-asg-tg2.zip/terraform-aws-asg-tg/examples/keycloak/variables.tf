###############################################################################
# General
###############################################################################

variable "region" {
  description = "AWS region."
  type        = string
  default     = "us-east-1"
}

variable "name_prefix" {
  description = "Prefix for all resource names."
  type        = string
  default     = "keycloak"
}

variable "tags" {
  description = "Tags applied to everything."
  type        = map(string)
  default = {
    Application = "keycloak"
    ManagedBy   = "terraform"
  }
}

###############################################################################
# Existing network
###############################################################################

variable "vpc_id" {
  description = "Existing VPC ID."
  type        = string
}

variable "public_subnet_ids" {
  description = "Existing public subnets for the ALB."
  type        = list(string)
}

variable "private_subnet_ids" {
  description = "Existing private subnets for the Keycloak instances."
  type        = list(string)
}

variable "database_subnet_ids" {
  description = "Existing subnets for RDS. Defaults to private_subnet_ids."
  type        = list(string)
  default     = []
}

variable "alb_ingress_cidrs" {
  description = "CIDRs allowed to reach the ALB."
  type        = list(string)
  default     = ["0.0.0.0/0"]
}

###############################################################################
# Existing IAM (roles and policies are NOT created here)
###############################################################################

variable "instance_role_name" {
  description = "Existing IAM role name used by the Keycloak instances."
  type        = string
}

variable "instance_profile_name" {
  description = "Existing IAM instance profile that wraps instance_role_name."
  type        = string
}

variable "existing_policy_arns" {
  description = <<-EOT
    Existing managed policy ARNs attached to instance_role_name by the module.
    Must include something that grants secretsmanager:GetSecretValue on the
    Keycloak secrets, plus SSM access if you want Session Manager.
  EOT
  type        = list(string)
  default = [
    "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore",
    "arn:aws:iam::aws:policy/CloudWatchAgentServerPolicy",
  ]
}

###############################################################################
# TLS
###############################################################################

variable "certificate_arn" {
  description = "ACM certificate ARN for the HTTPS listener."
  type        = string
}

variable "hostname" {
  description = "Public hostname Keycloak is served on, e.g. auth.example.com."
  type        = string
}

###############################################################################
# Keycloak container
###############################################################################

variable "keycloak_image" {
  description = "Keycloak container image."
  type        = string
  default     = "quay.io/keycloak/keycloak:26.0"
}

variable "keycloak_cache_stack" {
  description = <<-EOT
    Infinispan discovery stack for clustering across ASG instances.
    "jdbc-ping" requires Keycloak 26.1+. On older versions set this to null and
    run a single instance, or supply your own cache config.
  EOT
  type        = string
  default     = "jdbc-ping"
}

variable "keycloak_admin_username" {
  description = "Bootstrap admin username."
  type        = string
  default     = "kcadmin"
}

variable "min_size" {
  description = "Minimum Keycloak instances."
  type        = number
  default     = 2
}

variable "max_size" {
  description = "Maximum Keycloak instances."
  type        = number
  default     = 4
}

variable "instance_type" {
  description = "EC2 instance type for Keycloak."
  type        = string
  default     = "t3.medium"
}

variable "root_volume_size" {
  description = "Root volume size in GiB."
  type        = number
  default     = 30
}

###############################################################################
# RDS PostgreSQL
###############################################################################

variable "db_name" {
  description = "Database name."
  type        = string
  default     = "keycloak"
}

variable "db_username" {
  description = "Master username."
  type        = string
  default     = "keycloak"
}

variable "db_engine_version" {
  description = "PostgreSQL engine version."
  type        = string
  default     = "16.4"
}

variable "db_instance_class" {
  description = "RDS instance class."
  type        = string
  default     = "db.t4g.medium"
}

variable "db_allocated_storage" {
  description = "Allocated storage in GiB."
  type        = number
  default     = 20
}

variable "db_max_allocated_storage" {
  description = "Storage autoscaling ceiling in GiB."
  type        = number
  default     = 100
}

variable "db_multi_az" {
  description = "Run RDS Multi-AZ."
  type        = bool
  default     = true
}

variable "db_backup_retention_period" {
  description = "Days of automated backups."
  type        = number
  default     = 7
}

variable "db_deletion_protection" {
  description = "Protect the database from deletion."
  type        = bool
  default     = true
}

variable "db_skip_final_snapshot" {
  description = "Skip the final snapshot on destroy. Leave false outside sandboxes."
  type        = bool
  default     = false
}

variable "kms_key_id" {
  description = "KMS key for RDS and Secrets Manager encryption. Null uses AWS managed keys."
  type        = string
  default     = null
}

variable "secret_recovery_window_days" {
  description = "Secrets Manager recovery window. 0 deletes immediately (sandbox only)."
  type        = number
  default     = 7
}
