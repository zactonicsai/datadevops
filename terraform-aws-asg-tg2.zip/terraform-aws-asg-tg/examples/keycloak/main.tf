###############################################################################
# Base AMI
###############################################################################

data "aws_ssm_parameter" "al2023" {
  name = "/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64"
}

###############################################################################
# Launch template
#
# The ASG module expects a launch template to already exist. It reads this one
# and derives its own copy so it can apply the security group and instance
# profile passed below.
###############################################################################

resource "aws_launch_template" "keycloak" {
  name_prefix   = "${var.name_prefix}-src-"
  description   = "Keycloak container host"
  image_id      = data.aws_ssm_parameter.al2023.value
  instance_type = var.instance_type

  user_data = base64encode(templatefile("${path.module}/user_data.sh.tftpl", {
    region           = var.region
    db_secret_arn    = aws_secretsmanager_secret.db.arn
    admin_secret_arn = aws_secretsmanager_secret.admin.arn
    db_host          = aws_db_instance.this.address
    db_port          = aws_db_instance.this.port
    db_name          = var.db_name
    keycloak_image   = var.keycloak_image
    hostname         = var.hostname
    cache_stack      = var.keycloak_cache_stack
  }))

  block_device_mappings {
    device_name = "/dev/xvda"

    ebs {
      volume_size           = var.root_volume_size
      volume_type           = "gp3"
      encrypted             = true
      delete_on_termination = true
    }
  }

  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = "required"
    http_put_response_hop_limit = 2
  }

  monitoring {
    enabled = true
  }

  tags = merge(var.tags, { Name = "${var.name_prefix}-lt" })

  lifecycle {
    create_before_destroy = true
  }

  # Secret values must exist before an instance tries to read them.
  depends_on = [
    aws_secretsmanager_secret_version.db,
    aws_secretsmanager_secret_version.admin,
  ]
}

###############################################################################
# ASG + target group
###############################################################################

module "keycloak_asg" {
  source = "../../"

  name_prefix = var.name_prefix

  vpc_id             = var.vpc_id
  subnet_ids         = var.private_subnet_ids
  security_group_ids = [aws_security_group.keycloak.id]

  # Existing role and profile; the module only attaches existing policies.
  iam_role_name             = var.instance_role_name
  iam_instance_profile_name = var.instance_profile_name
  iam_policy_arns           = var.existing_policy_arns

  launch_template_id            = aws_launch_template.keycloak.id
  create_derived_launch_template = true

  min_size         = var.min_size
  max_size         = var.max_size
  desired_capacity = var.min_size

  # Keycloak takes a while to build and migrate the schema on first boot.
  health_check_type         = "ELB"
  health_check_grace_period = 600
  wait_for_capacity_timeout  = "20m"

  target_group_port     = 8080
  target_group_protocol = "HTTP"
  deregistration_delay  = 30

  # Keycloak 25+ serves health endpoints on the management port.
  health_check = {
    path                = "/health/ready"
    port                = "9000"
    protocol            = "HTTP"
    interval            = 15
    timeout             = 5
    healthy_threshold   = 2
    unhealthy_threshold = 5
  }

  tags = merge(var.tags, { Role = "keycloak" })
}

###############################################################################
# Load balancer
###############################################################################

resource "aws_lb" "this" {
  name_prefix        = substr("${var.name_prefix}-", 0, 6)
  load_balancer_type = "application"
  internal           = false
  subnets            = var.public_subnet_ids
  security_groups    = [aws_security_group.alb.id]

  drop_invalid_header_fields = true
  enable_deletion_protection = false

  tags = merge(var.tags, { Name = "${var.name_prefix}-alb" })
}

resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.this.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"
  certificate_arn   = var.certificate_arn

  default_action {
    type             = "forward"
    target_group_arn = module.keycloak_asg.target_group_arn
  }
}

resource "aws_lb_listener" "http_redirect" {
  load_balancer_arn = aws_lb.this.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type = "redirect"

    redirect {
      port        = "443"
      protocol    = "HTTPS"
      status_code = "HTTP_301"
    }
  }
}
