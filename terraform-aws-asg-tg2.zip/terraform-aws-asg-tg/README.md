# terraform-aws-asg-tg

A small module that creates an EC2 Auto Scaling Group and an ALB/NLB Target Group
on top of resources you already own: an IAM role and policies, subnets, security
groups, and a launch template.

## What it creates

- `aws_lb_target_group` — with health check and optional stickiness
- `aws_autoscaling_group` — registered against that target group, with rolling instance refresh
- `aws_iam_role_policy_attachment` — attaches your existing policies to your existing role
- `aws_launch_template` — optional, derived from your existing template (see below)

## What it expects to already exist

| Input | Purpose |
|---|---|
| `vpc_id` | VPC for the target group |
| `subnet_ids` | Where the ASG places instances |
| `security_group_ids` | Attached to instances |
| `iam_role_name` | Instance role |
| `iam_policy_arns` | Managed policies attached to that role |
| `iam_instance_profile_name` | Profile placed on instances (optional) |
| `launch_template_id` | Source launch template |

## Usage

```hcl
module "web_asg" {
  source = "./terraform-aws-asg-tg"

  name_prefix = "web-prod"

  vpc_id             = "vpc-0abc123"
  subnet_ids         = ["subnet-0aaa", "subnet-0bbb", "subnet-0ccc"]
  security_group_ids = ["sg-0app", "sg-0egress"]

  iam_role_name             = "web-instance-role"
  iam_instance_profile_name = "web-instance-profile"
  iam_policy_arns = [
    "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore",
    "arn:aws:iam::aws:policy/CloudWatchAgentServerPolicy",
  ]

  launch_template_id = "lt-0123456789abcdef0"

  min_size         = 2
  max_size         = 6
  desired_capacity = 2

  target_group_port     = 8080
  target_group_protocol = "HTTP"

  health_check = {
    path                = "/healthz"
    interval            = 15
    healthy_threshold   = 2
    unhealthy_threshold = 3
  }

  tags = {
    Environment = "prod"
    Owner       = "platform"
  }
}

resource "aws_lb_listener_rule" "web" {
  listener_arn = aws_lb_listener.https.arn
  priority     = 100

  action {
    type             = "forward"
    target_group_arn = module.web_asg.target_group_arn
  }

  condition {
    path_pattern {
      values = ["/app/*"]
    }
  }
}
```

## About `create_derived_launch_template`

Security groups and the instance profile live on the **launch template**, not on
the ASG — the ASG API cannot override them. So there are two modes:

**`true` (default)** — the module reads your launch template and copies its core
settings (AMI, instance type, key pair, user data, block devices, metadata
options, monitoring) into a template it owns, then applies your
`security_group_ids` and `iam_instance_profile_name`. Fields outside that list
(network interface config, placement, capacity reservations, license
specifications, hibernation, CPU options, enclave options) are **not** copied.

**`false`** — the ASG launches straight from your template at
`launch_template_version`, unchanged. `security_group_ids` and
`iam_instance_profile_name` are ignored, and your template must already carry
them. Prefer this when the source template is nontrivial.

## Notes

- `desired_capacity` is in `ignore_changes` so scaling policies can move it without Terraform reverting.
- Target group `name_prefix` is capped at 6 characters by AWS, so the module truncates `name_prefix` for that resource only.
- `health_check.path` and `matcher` are dropped automatically for TCP/UDP/TLS health checks.
- Set `wait_for_capacity_timeout = "0"` if you don't want `terraform apply` to block on instances passing health checks.
- Attaching policies to a role you own elsewhere can conflict with an `aws_iam_role_policy_attachments_exclusive` resource or another module attaching the same role. Pass an empty `iam_policy_arns` if that's already managed.
