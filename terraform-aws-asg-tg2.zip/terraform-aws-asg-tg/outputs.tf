output "autoscaling_group_name" {
  description = "Name of the Auto Scaling Group."
  value       = aws_autoscaling_group.this.name
}

output "autoscaling_group_arn" {
  description = "ARN of the Auto Scaling Group."
  value       = aws_autoscaling_group.this.arn
}

output "target_group_arn" {
  description = "ARN of the target group. Wire this into an ALB/NLB listener rule."
  value       = aws_lb_target_group.this.arn
}

output "target_group_arn_suffix" {
  description = "ARN suffix of the target group, for CloudWatch metrics."
  value       = aws_lb_target_group.this.arn_suffix
}

output "target_group_name" {
  description = "Name of the target group."
  value       = aws_lb_target_group.this.name
}

output "launch_template_id" {
  description = "Launch template the ASG actually uses."
  value       = local.launch_template_id
}

output "launch_template_version" {
  description = "Launch template version the ASG actually uses."
  value       = local.launch_template_version
}

output "attached_policy_arns" {
  description = "IAM policy ARNs attached to the instance role by this module."
  value       = [for a in aws_iam_role_policy_attachment.this : a.policy_arn]
}
