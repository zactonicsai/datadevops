# ---------------------------------------------------------------------------
# Root module: wires existing infrastructure (from tfvars) into two child
# modules — one that builds the launch template, one that deploys EC2 from it.
# ---------------------------------------------------------------------------

# Resolve AMI: use the one given in tfvars, or find the latest that matches.
data "aws_ami" "selected" {
  count       = var.ami_id == null ? 1 : 0
  most_recent = true
  owners      = var.ami_filter.owners

  filter {
    name   = "name"
    values = [var.ami_filter.name_pattern]
  }
  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

# Validate that the supplied existing resources really exist — Terraform
# fails at plan time with a clear message instead of a cryptic API error.
data "aws_subnet" "existing" {
  for_each = toset(var.subnet_ids)
  id       = each.value
}

data "aws_security_group" "existing" {
  for_each = toset(var.security_group_ids)
  id       = each.value
}

data "aws_iam_instance_profile" "existing" {
  count = var.iam_instance_profile_name == null ? 0 : 1
  name  = var.iam_instance_profile_name
}

data "aws_key_pair" "existing" {
  count    = var.key_name == null ? 0 : 1
  key_name = var.key_name
}

locals {
  ami_id = var.ami_id != null ? var.ami_id : data.aws_ami.selected[0].id

  user_data = var.user_data_file == null ? null : templatefile(var.user_data_file, var.user_data_vars)
}

# ---------------------------------------------------------------------------
# 1. Launch template
# ---------------------------------------------------------------------------
module "launch_template" {
  source = "./modules/launch_template"

  name_prefix               = var.name_prefix
  ami_id                    = local.ami_id
  instance_type             = var.instance_type
  key_name                  = var.key_name
  iam_instance_profile_name = var.iam_instance_profile_name
  security_group_ids        = var.security_group_ids
  associate_public_ip       = var.associate_public_ip
  root_volume               = var.root_volume
  kms_key_id                = var.kms_key_id
  user_data_base64          = local.user_data == null ? null : base64encode(local.user_data)
  enable_detailed_monitoring = var.enable_detailed_monitoring
  metadata_options          = var.metadata_options
  tags                      = var.common_tags
}

# ---------------------------------------------------------------------------
# 2. EC2 instances launched from the template
# ---------------------------------------------------------------------------
module "ec2" {
  source = "./modules/ec2_instance"

  name_prefix             = var.name_prefix
  instance_count          = var.instance_count
  launch_template_id      = module.launch_template.id
  launch_template_version = var.launch_template_version
  subnet_ids              = var.subnet_ids
  private_ips             = var.private_ips
  tags                    = merge(var.common_tags, var.instance_tags)

  depends_on = [module.launch_template]
}
