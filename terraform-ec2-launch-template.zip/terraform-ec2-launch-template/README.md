# EC2 Launch Template + Instances (Terraform)

Builds an **AWS Launch Template** and deploys **EC2 instances** from it.
Nothing else is created: VPC, subnets, security groups, IAM instance profile,
key pair, KMS key and AMI are **existing resources** whose IDs/names you supply
in `terraform.tfvars`. Data sources verify each one exists at plan time.

```
.
├── versions.tf                  # provider + optional S3 backend
├── variables.tf                 # every input, with descriptions
├── main.tf                      # data lookups + calls the two modules
├── outputs.tf
├── terraform.tfvars.example     # copy -> terraform.tfvars
├── templates/user_data.sh.tftpl # sample bootstrap (installs Java 21, systemd unit)
└── modules/
    ├── launch_template/         # aws_launch_template
    └── ec2_instance/            # aws_instance x N from the template
```

## Usage

```bash
cp terraform.tfvars.example terraform.tfvars   # fill in your existing resource IDs
terraform init
terraform plan
terraform apply
```

## Inputs (root)

| Variable | Required | Notes |
|---|---|---|
| `aws_region`, `name_prefix` | yes | |
| `subnet_ids` | yes | Instances spread round-robin across the list |
| `security_group_ids` | yes | Attached via LT network interface |
| `ami_id` | no | `null` → latest AMI matching `ami_filter` (default Amazon Linux 2023) |
| `iam_instance_profile_name`, `key_name`, `kms_key_id` | no | `null` to omit |
| `instance_type`, `root_volume`, `associate_public_ip`, `enable_detailed_monitoring` | no | LT settings |
| `user_data_file`, `user_data_vars` | no | Rendered with `templatefile()` and base64-encoded |
| `metadata_options` | no | Defaults enforce **IMDSv2** |
| `instance_count`, `launch_template_version`, `private_ips`, `instance_tags` | no | EC2 settings |

## Design notes

* **Launch template module** — `name_prefix` + `create_before_destroy` so a new
  version is created before the old one goes away; `update_default_version = true`
  keeps `$Default` in sync; EBS encryption always on; `tag_specifications` tag the
  instance, volume and ENI automatically.
* **EC2 module** — instances inherit everything from the template and only set
  subnet / private IP / Name. `ignore_changes = [launch_template[0].version]`
  prevents Terraform from replacing running instances every time the template
  gets a new version; roll them deliberately with `terraform taint` or
  `-replace`, or switch to an Auto Scaling Group for rolling updates.
* Swap `modules/ec2_instance` for an `aws_autoscaling_group` that references the
  same `module.launch_template.id` if you need scaling — the LT module is reusable.
