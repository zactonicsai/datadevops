# ---------------------------------------------------------------------------
# Root variables. Everything that already exists in AWS is passed in here.
# ---------------------------------------------------------------------------

variable "aws_region" {
  description = "AWS region to deploy into"
  type        = string
}

variable "name_prefix" {
  description = "Prefix used for naming the launch template and instances"
  type        = string
}

variable "common_tags" {
  description = "Tags applied to every resource via provider default_tags"
  type        = map(string)
  default     = {}
}

# ---- Existing resources (looked up / referenced, never created) ----------

variable "ami_id" {
  description = "Existing AMI ID. Leave null to resolve the latest AMI matching ami_filter."
  type        = string
  default     = null
}

variable "ami_filter" {
  description = "Used only when ami_id is null. Name pattern + owner to find latest AMI."
  type = object({
    name_pattern = string
    owners       = list(string)
  })
  default = {
    name_pattern = "al2023-ami-2023.*-x86_64"
    owners       = ["amazon"]
  }
}

variable "subnet_ids" {
  description = "Existing subnet IDs. Instances are spread round-robin across them."
  type        = list(string)
}

variable "security_group_ids" {
  description = "Existing security group IDs attached to the instances"
  type        = list(string)
}

variable "iam_instance_profile_name" {
  description = "Existing IAM instance profile name (null = none)"
  type        = string
  default     = null
}

variable "key_name" {
  description = "Existing EC2 key pair name (null = none)"
  type        = string
  default     = null
}

variable "kms_key_id" {
  description = "Existing KMS key ARN for EBS encryption (null = AWS-managed key)"
  type        = string
  default     = null
}

# ---- Launch template settings --------------------------------------------

variable "instance_type" {
  description = "EC2 instance type"
  type        = string
  default     = "t3.micro"
}

variable "root_volume" {
  description = "Root EBS volume settings"
  type = object({
    size_gb     = number
    type        = string
    iops        = optional(number)
    throughput  = optional(number)
    device_name = optional(string, "/dev/xvda")
  })
  default = {
    size_gb = 20
    type    = "gp3"
  }
}

variable "associate_public_ip" {
  description = "Assign a public IP to instances"
  type        = bool
  default     = false
}

variable "enable_detailed_monitoring" {
  description = "Enable 1-minute CloudWatch metrics"
  type        = bool
  default     = false
}

variable "user_data_file" {
  description = "Path to a user-data script template (rendered with user_data_vars). Null = no user data."
  type        = string
  default     = null
}

variable "user_data_vars" {
  description = "Variables injected into user_data_file via templatefile()"
  type        = map(string)
  default     = {}
}

variable "metadata_options" {
  description = "IMDS settings. Defaults enforce IMDSv2."
  type = object({
    http_tokens                 = optional(string, "required")
    http_put_response_hop_limit = optional(number, 1)
    http_endpoint               = optional(string, "enabled")
    instance_metadata_tags      = optional(string, "enabled")
  })
  default = {}
}

# ---- EC2 deployment settings ---------------------------------------------

variable "instance_count" {
  description = "Number of instances to launch from the template"
  type        = number
  default     = 1
}

variable "launch_template_version" {
  description = "Which launch template version instances should use: \"$Latest\", \"$Default\" or a number"
  type        = string
  default     = "$Latest"
}

variable "private_ips" {
  description = "Optional fixed private IPs, one per instance (index-aligned). Empty = auto-assign."
  type        = list(string)
  default     = []
}

variable "instance_tags" {
  description = "Extra tags applied only to the EC2 instances (merged over common_tags)"
  type        = map(string)
  default     = {}
}
