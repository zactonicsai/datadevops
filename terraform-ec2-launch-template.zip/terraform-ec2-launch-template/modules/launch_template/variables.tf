variable "name_prefix" { type = string }
variable "ami_id" { type = string }
variable "instance_type" { type = string }

variable "key_name" {
  type    = string
  default = null
}

variable "iam_instance_profile_name" {
  type    = string
  default = null
}

variable "security_group_ids" { type = list(string) }

variable "associate_public_ip" {
  type    = bool
  default = false
}

variable "root_volume" {
  type = object({
    size_gb     = number
    type        = string
    iops        = optional(number)
    throughput  = optional(number)
    device_name = optional(string, "/dev/xvda")
  })
}

variable "kms_key_id" {
  type    = string
  default = null
}

variable "user_data_base64" {
  type    = string
  default = null
}

variable "enable_detailed_monitoring" {
  type    = bool
  default = false
}

variable "metadata_options" {
  type = object({
    http_tokens                 = optional(string, "required")
    http_put_response_hop_limit = optional(number, 1)
    http_endpoint               = optional(string, "enabled")
    instance_metadata_tags      = optional(string, "enabled")
  })
  default = {}
}

variable "tags" {
  type    = map(string)
  default = {}
}
