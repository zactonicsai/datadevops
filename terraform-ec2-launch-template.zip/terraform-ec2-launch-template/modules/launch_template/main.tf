resource "aws_launch_template" "this" {
  name_prefix   = "${var.name_prefix}-"
  description   = "Managed by Terraform"
  image_id      = var.ami_id
  instance_type = var.instance_type
  key_name      = var.key_name
  user_data     = var.user_data_base64

  update_default_version = true # every apply that changes the LT becomes the $Default

  dynamic "iam_instance_profile" {
    for_each = var.iam_instance_profile_name == null ? [] : [1]
    content {
      name = var.iam_instance_profile_name
    }
  }

  network_interfaces {
    device_index                = 0
    associate_public_ip_address = var.associate_public_ip
    security_groups             = var.security_group_ids
    delete_on_termination       = true
  }

  block_device_mappings {
    device_name = var.root_volume.device_name
    ebs {
      volume_size           = var.root_volume.size_gb
      volume_type           = var.root_volume.type
      iops                  = var.root_volume.iops
      throughput            = var.root_volume.throughput
      encrypted             = true
      kms_key_id            = var.kms_key_id
      delete_on_termination = true
    }
  }

  monitoring {
    enabled = var.enable_detailed_monitoring
  }

  metadata_options {
    http_endpoint               = var.metadata_options.http_endpoint
    http_tokens                 = var.metadata_options.http_tokens # "required" = IMDSv2 only
    http_put_response_hop_limit = var.metadata_options.http_put_response_hop_limit
    instance_metadata_tags      = var.metadata_options.instance_metadata_tags
  }

  # Tags that AWS stamps on resources created FROM this template
  dynamic "tag_specifications" {
    for_each = ["instance", "volume", "network-interface"]
    content {
      resource_type = tag_specifications.value
      tags          = merge(var.tags, { Name = var.name_prefix })
    }
  }

  tags = merge(var.tags, { Name = "${var.name_prefix}-lt" })

  lifecycle {
    create_before_destroy = true
  }
}
