output "id" {
  value = aws_launch_template.this.id
}

output "arn" {
  value = aws_launch_template.this.arn
}

output "name" {
  value = aws_launch_template.this.name
}

output "latest_version" {
  value = aws_launch_template.this.latest_version
}

output "default_version" {
  value = aws_launch_template.this.default_version
}
