# Instances are created from the launch template. Everything about the machine
# (AMI, type, SGs, volumes, user data, IAM profile) is inherited from the LT;
# only placement (subnet / IP) and naming are decided here.
resource "aws_instance" "this" {
  count = var.instance_count

  launch_template {
    id      = var.launch_template_id
    version = var.launch_template_version
  }

  subnet_id  = element(var.subnet_ids, count.index)
  private_ip = length(var.private_ips) > 0 ? var.private_ips[count.index] : null

  tags = merge(var.tags, {
    Name = format("%s-%02d", var.name_prefix, count.index + 1)
  })

  lifecycle {
    # A new LT version should not silently replace running instances on
    # every plan; bump launch_template_version explicitly or taint to roll.
    ignore_changes = [launch_template[0].version]
  }
}
