variable "name_prefix" { type = string }

variable "instance_count" {
  type    = number
  default = 1
}

variable "launch_template_id" { type = string }

variable "launch_template_version" {
  type    = string
  default = "$Latest"
}

variable "subnet_ids" {
  description = "Instances are distributed across these subnets round-robin"
  type        = list(string)
}

variable "private_ips" {
  description = "Empty, or exactly one IP per instance (index-aligned with subnet_ids)"
  type        = list(string)
  default     = []
}

variable "tags" {
  type    = map(string)
  default = {}
}
