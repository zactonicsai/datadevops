output "launch_template_id" {
  value = module.launch_template.id
}

output "launch_template_latest_version" {
  value = module.launch_template.latest_version
}

output "ami_id_used" {
  value = local.ami_id
}

output "instance_ids" {
  value = module.ec2.instance_ids
}

output "private_ips" {
  value = module.ec2.private_ips
}

output "public_ips" {
  value = module.ec2.public_ips
}
