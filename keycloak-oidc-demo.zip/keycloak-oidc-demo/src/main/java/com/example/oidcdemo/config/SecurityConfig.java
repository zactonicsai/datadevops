package com.example.oidcdemo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.oauth2.client.oidc.web.logout.OidcClientInitiatedLogoutSuccessHandler;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Central Spring Security configuration.
 *
 * What this does:
 *  1. Public pages:   "/", "/index.html", "/error", static assets -> anyone can see them.
 *  2. Everything else (e.g. "/me") -> user must be logged in.
 *  3. Login is delegated to Keycloak using OpenID Connect (Authorization Code flow + PKCE).
 *  4. Logout also logs the user out of Keycloak (RP-Initiated Logout), not only the local session.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final ClientRegistrationRepository clientRegistrationRepository;

    public SecurityConfig(ClientRegistrationRepository clientRegistrationRepository) {
        this.clientRegistrationRepository = clientRegistrationRepository;
    }

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/", "/index.html", "/error", "/css/**", "/js/**", "/favicon.ico").permitAll()
                .anyRequest().authenticated()
            )
            // Enables the OAuth2/OIDC login flow. Spring auto-registers:
            //   /oauth2/authorization/{registrationId}   -> starts login (redirects to Keycloak)
            //   /login/oauth2/code/{registrationId}      -> callback ("redirect URI") Keycloak returns to
            .oauth2Login(oauth2 -> oauth2
                .loginPage("/oauth2/authorization/keycloak")   // skip Spring's generic login page, go straight to Keycloak
                .defaultSuccessUrl("/me", true)                // where to land after successful login
            )
            .logout(logout -> logout
                .logoutSuccessHandler(oidcLogoutSuccessHandler())
                .invalidateHttpSession(true)
                .clearAuthentication(true)
                .deleteCookies("JSESSIONID")
            );

        return http.build();
    }

    /**
     * After the local session is destroyed, redirect the browser to Keycloak's
     * end_session_endpoint so the Keycloak SSO session is closed too.
     * {baseUrl} is replaced with e.g. http://localhost:8081 at runtime.
     */
    private OidcClientInitiatedLogoutSuccessHandler oidcLogoutSuccessHandler() {
        var handler = new OidcClientInitiatedLogoutSuccessHandler(clientRegistrationRepository);
        handler.setPostLogoutRedirectUri("{baseUrl}/");
        return handler;
    }
}
