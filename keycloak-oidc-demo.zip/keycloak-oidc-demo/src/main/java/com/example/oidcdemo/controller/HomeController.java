package com.example.oidcdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * "/" is served by the static index.html in src/main/resources/static,
 * so no mapping is needed for it. This controller only provides a friendly
 * "/login" alias that forwards to the Keycloak authorization endpoint.
 */
@Controller
public class HomeController {

    @GetMapping("/login")
    public String login() {
        return "redirect:/oauth2/authorization/keycloak";
    }
}
