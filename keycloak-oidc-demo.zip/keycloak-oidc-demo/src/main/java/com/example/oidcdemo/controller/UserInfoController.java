package com.example.oidcdemo.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.annotation.RegisteredOAuth2AuthorizedClient;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Map;
import java.util.TreeMap;

/**
 * Shows everything Keycloak told us about the logged-in user.
 *
 * Where the data comes from:
 *  - ID Token claims      : signed JWT returned at login (sub, name, email, preferred_username, ...)
 *  - UserInfo endpoint    : Spring calls /userinfo after login and merges those claims
 *  - Authorities          : Spring maps scopes -> SCOPE_xxx and adds OIDC_USER
 *  - Access token         : the bearer token you'd use to call other APIs
 */
@Controller
public class UserInfoController {

    @GetMapping("/me")
    public String me(@AuthenticationPrincipal OidcUser user,
                     @RegisteredOAuth2AuthorizedClient("keycloak") OAuth2AuthorizedClient client,
                     Authentication authentication,
                     Model model) {

        // All claims (ID token + userinfo), sorted for readability
        Map<String, Object> claims = new TreeMap<>(user.getClaims());

        model.addAttribute("username", user.getPreferredUsername());
        model.addAttribute("fullName", user.getFullName());
        model.addAttribute("email", user.getEmail());
        model.addAttribute("subject", user.getSubject());
        model.addAttribute("claims", claims);
        model.addAttribute("authorities", authentication.getAuthorities());
        model.addAttribute("idToken", user.getIdToken().getTokenValue());
        model.addAttribute("accessToken", client.getAccessToken().getTokenValue());
        model.addAttribute("accessTokenExpiry", client.getAccessToken().getExpiresAt());
        model.addAttribute("scopes", client.getAccessToken().getScopes());
        model.addAttribute("issuer", user.getIssuer());
        return "userinfo";
    }

    /** Same data as JSON - useful for debugging with curl or the browser. */
    @GetMapping("/api/me")
    @ResponseBody
    public Map<String, Object> meJson(@AuthenticationPrincipal OidcUser user) {
        return new TreeMap<>(user.getClaims());
    }
}
