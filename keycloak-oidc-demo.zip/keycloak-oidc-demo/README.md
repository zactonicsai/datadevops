# Keycloak OIDC Demo — Java 21 + Spring Boot 3.5

A minimal web app that:

1. Serves a **public static page** (`/`) with a *Login with Keycloak* button.
2. Authenticates the user with **OpenID Connect (OIDC)** against Keycloak
   (Authorization Code flow with PKCE).
3. Shows **all user information** Keycloak returned (`/me` as HTML, `/api/me` as JSON).
4. Logs the user out of both the app **and** Keycloak.

> Companion document: [`docs/keycloak-onboarding-tutorial.md`](docs/keycloak-onboarding-tutorial.md)
> walks through creating the realm, client and user in Keycloak step by step.

---

## 1. Project layout

```
keycloak-oidc-demo/
├── pom.xml                              # Maven build, Java 21, Spring Boot 3.5.x
├── docker-compose.yml                   # one-command local Keycloak
├── docs/keycloak-onboarding-tutorial.md # Keycloak side, step by step
└── src/main/
    ├── java/com/example/oidcdemo/
    │   ├── OidcDemoApplication.java     # Spring Boot entry point
    │   ├── config/SecurityConfig.java   # what is public, what needs login, logout
    │   └── controller/
    │       ├── HomeController.java      # /login alias -> Keycloak
    │       └── UserInfoController.java  # /me and /api/me
    └── resources/
        ├── application.yml              # ALL OIDC settings live here
        ├── static/index.html            # public landing page
        └── templates/userinfo.html      # Thymeleaf page listing every claim
```

## 2. Quick start

```bash
# 1. Start Keycloak (admin/admin at http://localhost:8080)
docker compose up -d

# 2. Onboard the app in Keycloak — see docs/keycloak-onboarding-tutorial.md
#    realm = demo, client id = spring-demo-app, copy the client secret

# 3. Run the app
export KEYCLOAK_CLIENT_SECRET=<paste secret here>
./mvnw spring-boot:run          # or: mvn spring-boot:run

# 4. Open http://localhost:8081 and click "Login with Keycloak"
```

Requirements: JDK 21, Maven 3.9+, Docker (only for the bundled Keycloak).

## 3. How the login flow works (Authorization Code + PKCE)

```
Browser            Spring app (8081)                 Keycloak (8080)
  |  GET /me            |                                  |
  |-------------------->| not logged in                    |
  |  302 -> /oauth2/authorization/keycloak                 |
  |<--------------------|                                  |
  |  302 -> /realms/demo/protocol/openid-connect/auth      |
  |            ?client_id=spring-demo-app&redirect_uri=...&scope=openid profile email
  |            &state=...&code_challenge=...&response_type=code
  |------------------------------------------------------->|
  |  Keycloak login form, user enters credentials          |
  |<------------------------------------------------------>|
  |  302 -> http://localhost:8081/login/oauth2/code/keycloak?code=XYZ&state=...
  |<-------------------------------------------------------|
  |-------------------->| POST /token (code + client_secret + code_verifier)
  |                     |--------------------------------->|
  |                     |  { id_token, access_token, refresh_token }
  |                     |<---------------------------------|
  |                     | verify ID token signature (JWKS) |
  |                     | GET /userinfo (Bearer access_token)
  |                     |--------------------------------->|
  |  302 -> /me + session cookie (JSESSIONID)              |
  |<--------------------|                                  |
```

Key points:

* The **browser never sees the tokens** — only the short-lived `code`. Tokens are
  exchanged server-to-server and stored in the HTTP session.
* `state` protects against CSRF; `nonce` (in the ID token) protects against replay;
  PKCE (`code_challenge`/`code_verifier`) protects the code if it leaks.
* The **ID token** says *who the user is*. The **access token** is what you would
  send to other APIs (e.g. a resource server) as `Authorization: Bearer …`.

## 4. Configuration details, line by line

### 4.1 `pom.xml`

| Dependency | Why it is there |
|---|---|
| `spring-boot-starter-web` | Spring MVC + embedded Tomcat, serves `/` and controllers. |
| `spring-boot-starter-thymeleaf` | Renders `userinfo.html` on the server. |
| `spring-boot-starter-security` | The security filter chain, sessions, CSRF, logout. |
| `spring-boot-starter-oauth2-client` | Adds OIDC login: `ClientRegistration`, the `/oauth2/authorization/*` and `/login/oauth2/code/*` endpoints, token exchange, JWT validation via Nimbus. |
| `thymeleaf-extras-springsecurity6` | `sec:` dialect for templates (optional). |

`<java.version>21</java.version>` makes Maven compile with `--release 21`.
Spring Boot 3.x requires Java 17+, so 21 (LTS) is the recommended choice.

### 4.2 `application.yml` — the heart of the OIDC setup

Spring Security's client support is driven entirely by two blocks:
**`registration`** (how *this app* identifies itself) and
**`provider`** (where the identity provider lives).

```yaml
spring.security.oauth2.client.registration.keycloak:
```

| Property | Value | Meaning |
|---|---|---|
| *(map key)* `keycloak` | — | The **registrationId**. It appears in `/oauth2/authorization/keycloak` and `/login/oauth2/code/keycloak`. Any name works, but it must match `@RegisteredOAuth2AuthorizedClient("keycloak")` and the `loginPage()` URL in `SecurityConfig`. |
| `provider` | `keycloak` | Which `provider.*` block to use. |
| `client-id` | `spring-demo-app` | Must be **identical** to the *Client ID* you typed in Keycloak. |
| `client-secret` | `${KEYCLOAK_CLIENT_SECRET}` | From Keycloak → Clients → *spring-demo-app* → **Credentials**. Only needed for *confidential* clients (Client authentication = ON). Injected via environment variable so it never sits in Git. |
| `client-name` | `Keycloak` | Cosmetic label on Spring's auto-generated login page (we bypass that page anyway). |
| `authorization-grant-type` | `authorization_code` | The only grant you should use for browser login. Implicit and password grants are deprecated in OAuth 2.1. |
| `client-authentication-method` | `client_secret_basic` | Sends `client_id:client_secret` in the HTTP `Authorization: Basic` header of the token request. Alternative: `client_secret_post` (in the body) or `none` (public client + PKCE only). Keycloak accepts all three. |
| `redirect-uri` | `{baseUrl}/login/oauth2/code/{registrationId}` | Where Keycloak sends the browser back. Resolves to `http://localhost:8081/login/oauth2/code/keycloak`. **This exact string must be in Keycloak's *Valid redirect URIs*.** |
| `scope` | `openid profile email roles` | `openid` is mandatory — without it you get plain OAuth2, no ID token, and `@AuthenticationPrincipal OidcUser` would be `null`. `profile` and `email` are standard OIDC scopes; `roles` is a Keycloak default scope that adds `realm_access` / `resource_access` claims. |

```yaml
spring.security.oauth2.client.provider.keycloak:
```

| Property | Value | Meaning |
|---|---|---|
| `issuer-uri` | `http://localhost:8080/realms/demo` | Spring downloads `<issuer-uri>/.well-known/openid-configuration` **at startup** and fills in `authorization-uri`, `token-uri`, `user-info-uri`, `jwk-set-uri` and `end_session_endpoint` automatically. The `iss` claim inside every token is checked against this value, so it must match Keycloak's *frontend URL* exactly (scheme, host, port, no trailing slash). If Keycloak is down when the app starts, the app fails fast — by design. |
| `user-name-attribute` | `preferred_username` | Which claim becomes `Authentication.getName()`. Default is `sub` (a UUID). |

You *could* replace `issuer-uri` with the five explicit URLs (`authorization-uri`,
`token-uri`, `user-info-uri`, `jwk-set-uri`, `user-info-authentication-method`), but
discovery is less error-prone and picks up endpoint changes automatically.

**Keycloak URL pattern** (v17+ "Quarkus" distribution — no `/auth` prefix):

```
http://<host>:<port>/realms/<realm>                                 <- issuer
http://<host>:<port>/realms/<realm>/.well-known/openid-configuration <- discovery
http://<host>:<port>/realms/<realm>/protocol/openid-connect/auth     <- authorization
http://<host>:<port>/realms/<realm>/protocol/openid-connect/token    <- token
http://<host>:<port>/realms/<realm>/protocol/openid-connect/userinfo <- userinfo
http://<host>:<port>/realms/<realm>/protocol/openid-connect/certs    <- JWKS
http://<host>:<port>/realms/<realm>/protocol/openid-connect/logout   <- end_session
```

Other settings:

* `server.port: 8081` — avoids colliding with Keycloak on 8080.
* `logging.level.org.springframework.security.oauth2: DEBUG` — prints every
  redirect and token exchange; switch to `TRACE` when something goes wrong.

### 4.3 `SecurityConfig.java`

```java
.authorizeHttpRequests(auth -> auth
    .requestMatchers("/", "/index.html", "/error", "/css/**", "/js/**", "/favicon.ico").permitAll()
    .anyRequest().authenticated())
```
Whitelists the landing page and static assets; everything else needs a session.
`/error` must be public or a failed login shows a second error.

```java
.oauth2Login(oauth2 -> oauth2
    .loginPage("/oauth2/authorization/keycloak")
    .defaultSuccessUrl("/me", true))
```
* `oauth2Login()` is the switch that turns on the whole OIDC client machinery.
* With **one** registration Spring would already auto-redirect to Keycloak; with more
  than one it shows a chooser page. `loginPage(...)` pins it to Keycloak regardless.
* `defaultSuccessUrl("/me", true)` — the `true` means *always* go to `/me`, even if
  the user originally asked for another protected page. Set to `false` to return
  them to the page they wanted.

```java
.logout(logout -> logout
    .logoutSuccessHandler(oidcLogoutSuccessHandler())
    .invalidateHttpSession(true).clearAuthentication(true).deleteCookies("JSESSIONID"))
```
Spring's default logout only kills the **local** session; the Keycloak SSO cookie
would still be valid and the next click would log you straight back in.
`OidcClientInitiatedLogoutSuccessHandler` implements **RP-Initiated Logout**: it
redirects to Keycloak's `end_session_endpoint` with `id_token_hint` and
`post_logout_redirect_uri`. That second URL must be listed in Keycloak under
*Valid post logout redirect URIs* (`{baseUrl}/` → `http://localhost:8081/`).

Not configured here (deliberately kept default):

* **CSRF** — on. That is why the logout button is a `<form method="post">`;
  Thymeleaf's `th:action` injects the `_csrf` token.
* **PKCE** — Spring Security adds it automatically for the authorization-code grant
  since 6.x, even for confidential clients.
* **Session fixation protection**, secure headers — Spring defaults.

### 4.4 `UserInfoController.java`

| Injected type | What you get |
|---|---|
| `@AuthenticationPrincipal OidcUser` | ID-token claims + UserInfo claims merged. Typed getters: `getSubject()`, `getPreferredUsername()`, `getEmail()`, `getFullName()`, `getIdToken()`, `getClaims()`. |
| `@RegisteredOAuth2AuthorizedClient("keycloak") OAuth2AuthorizedClient` | The **access token** (and refresh token) for that registration. Use `client.getAccessToken().getTokenValue()` when calling downstream APIs. |
| `Authentication` | `getAuthorities()` → `OIDC_USER`, `SCOPE_openid`, `SCOPE_profile`, … |

Claims you will typically see from Keycloak:

| Claim | Source | Example |
|---|---|---|
| `sub` | ID token | `f1c2…` (Keycloak user UUID) |
| `iss` | ID token | `http://localhost:8080/realms/demo` |
| `aud` | ID token | `spring-demo-app` |
| `azp` | ID token | authorized party = client id |
| `exp`, `iat`, `auth_time` | ID token | timestamps |
| `nonce`, `sid`, `session_state` | ID token | replay protection / session ids |
| `preferred_username` | `profile` scope | `alice` |
| `name`, `given_name`, `family_name` | `profile` scope | `Alice Smith` |
| `email`, `email_verified` | `email` scope | `alice@example.com`, `true` |
| `realm_access.roles`, `resource_access.*.roles` | `roles` scope | `["user","offline_access"]` |
| `acr` | ID token | authentication context class (`1` = password) |

Anything you add as a **Client scope → Mapper** in Keycloak (department, phone,
custom attributes, groups) shows up in this same map with no code changes.

### 4.5 Templates

* `static/index.html` — plain HTML, served directly by Spring MVC's resource handler.
  The login link simply points at `/oauth2/authorization/keycloak`.
* `templates/userinfo.html` — Thymeleaf; iterates `${claims}` so **every** claim is
  listed automatically.

## 5. Optional: map Keycloak roles to Spring `ROLE_*` authorities

By default Spring only produces `SCOPE_*` authorities. To use `hasRole("admin")`
add a `GrantedAuthoritiesMapper` bean:

```java
@Bean
GrantedAuthoritiesMapper keycloakAuthoritiesMapper() {
    return authorities -> {
        Set<GrantedAuthority> mapped = new HashSet<>(authorities);
        for (GrantedAuthority a : authorities) {
            if (a instanceof OidcUserAuthority oidc) {
                Map<String, Object> realmAccess = oidc.getIdToken().getClaimAsMap("realm_access");
                if (realmAccess != null && realmAccess.get("roles") instanceof Collection<?> roles) {
                    roles.forEach(r -> mapped.add(new SimpleGrantedAuthority("ROLE_" + r)));
                }
            }
        }
        return mapped;
    };
}
```

## 6. Production checklist

| Dev value in this demo | Production |
|---|---|
| `http://localhost:8080` | HTTPS only; Keycloak refuses non-TLS in `start` mode. |
| `start-dev`, H2 | `start` with PostgreSQL, `KC_HOSTNAME` set, behind a reverse proxy. |
| Secret in env var | Vault / Kubernetes Secret / cloud secret manager. |
| Wildcard-free redirect URIs | Keep them exact; never `*`. |
| In-memory session | Spring Session (Redis/JDBC) if you run more than one instance. |
| `roles` scope on every token | Only request scopes you need; keep tokens small. |
| DEBUG logging | INFO — DEBUG logs can leak token values. |

## 7. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `Invalid parameter: redirect_uri` on Keycloak page | Redirect URI in Keycloak doesn't match `http://localhost:8081/login/oauth2/code/keycloak` exactly. |
| `[invalid_client] Invalid client or Invalid client credentials` | Wrong `client-secret`, or *Client authentication* is OFF in Keycloak (then remove the secret and set `client-authentication-method: none`). |
| App won't start: `Unable to resolve Configuration with the provided Issuer` | Keycloak not running, wrong realm name, or wrong port in `issuer-uri`. |
| `[invalid_id_token] The iss claim is not valid` | Keycloak's hostname setting differs from `issuer-uri` (e.g. `localhost` vs `127.0.0.1`). |
| `OidcUser` is `null` in controller | `openid` scope missing. |
| Logout returns you to Keycloak's error page | `http://localhost:8081/` missing from *Valid post logout redirect URIs*. |
| Logged out of app but next login is instant | Logout handler not wired — Keycloak SSO session still alive. |
