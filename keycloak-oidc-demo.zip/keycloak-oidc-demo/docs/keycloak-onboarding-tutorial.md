# Onboarding an OIDC Application to Keycloak — Step-by-Step Tutorial

This tutorial shows you, click by click, how to register (“onboard”) a web
application in **Keycloak** so users can log in with **OpenID Connect (OIDC)**.
The example app is the Spring Boot project in this repository, but the Keycloak
steps are the same for any OIDC app (React, .NET, Python, Node…).

---

## Part 1 — Quick setup: one complete example

### Step 0. What you need

* Docker (or a downloaded Keycloak ZIP and Java 21)
* A browser
* 15 minutes

### Step 1. Start Keycloak

```bash
docker run -d --name keycloak -p 8080:8080 \
  -e KC_BOOTSTRAP_ADMIN_USERNAME=admin \
  -e KC_BOOTSTRAP_ADMIN_PASSWORD=admin \
  quay.io/keycloak/keycloak:26.3 start-dev
```

or, from this repo: `docker compose up -d`.

Open **http://localhost:8080** → *Administration Console* → log in `admin` / `admin`.

> `start-dev` is a development mode: HTTP is allowed, data is kept in a local
> H2 file, and the theme cache is off. Never use it in production.

### Step 2. Create a realm

A **realm** is an isolated space with its own users, clients and settings
(think of it as a separate "company" or "tenant").

1. Top-left dropdown (shows *master*) → **Create realm**.
2. **Realm name:** `demo`
3. Click **Create**.

You are now inside the `demo` realm. Everything below happens here — never put
application clients in the `master` realm; it is for administering Keycloak itself.

### Step 3. Create the client (this is the "onboarding")

A **client** is Keycloak's word for an application that wants to authenticate users.

1. Left menu → **Clients** → **Create client**.

2. **General settings**

   | Field | Value | Notes |
   |---|---|---|
   | Client type | `OpenID Connect` | The other option is SAML. |
   | Client ID | `spring-demo-app` | Copy this **exactly** into `client-id` in the app. |
   | Name | `Spring Demo App` | Display only. |
   | Description | optional | |
   | Always display in UI | off | |

   Click **Next**.

3. **Capability config**

   | Field | Value | Notes |
   |---|---|---|
   | Client authentication | **ON** | ON = *confidential* client (server-side app that can keep a secret). OFF = *public* client (SPA / mobile). |
   | Authorization | OFF | Only for Keycloak's fine-grained policy engine (UMA). |
   | Standard flow | **ON** | = Authorization Code flow. This is the one browser apps use. |
   | Direct access grants | **OFF** | = Resource Owner Password grant. Deprecated; turn off. |
   | Implicit flow | OFF | Deprecated. |
   | Service accounts roles | OFF | = Client Credentials grant, for machine-to-machine only. |
   | OAuth 2.0 Device Authorization Grant | OFF | For TVs / CLI tools. |
   | OIDC CIBA Grant | OFF | Rare. |

   Click **Next**.

4. **Login settings**

   | Field | Value | Notes |
   |---|---|---|
   | Root URL | `http://localhost:8081` | Optional; lets you use relative URLs below. |
   | Home URL | `http://localhost:8081` | Link shown in the account console. |
   | Valid redirect URIs | `http://localhost:8081/login/oauth2/code/keycloak` | **Most important field.** Keycloak will only send codes to URLs listed here. |
   | Valid post logout redirect URIs | `http://localhost:8081/*` | Where the browser may land after logout. |
   | Web origins | `http://localhost:8081` | CORS. Use `+` to mirror the redirect URIs. |

   Click **Save**.

### Step 4. Copy the client secret

1. Open the client you just created → tab **Credentials**.
2. **Client Authenticator:** `Client Id and Secret` (default).
3. Copy the **Client secret** value.

You will pass this to the app as `KEYCLOAK_CLIENT_SECRET`. Treat it like a password.

### Step 5. (Optional) Turn on PKCE enforcement

Client → **Advanced** tab → *Advanced settings* →
**Proof Key for Code Exchange Code Challenge Method:** `S256` → **Save**.

Spring already sends PKCE; this setting makes Keycloak *reject* clients that don't.

### Step 6. Create a test user

1. Left menu → **Users** → **Create new user**.
2. Fill in:

   | Field | Value |
   |---|---|
   | Username | `alice` |
   | Email | `alice@example.com` |
   | Email verified | ON (so you aren't forced to verify) |
   | First name | `Alice` |
   | Last name | `Smith` |

3. **Create**, then tab **Credentials** → **Set password** →
   password `alice`, **Temporary: OFF** → Save.

### Step 7. (Optional) Give the user a role

1. **Realm roles** → **Create role** → name `app-user` → Save.
2. **Users** → `alice` → **Role mapping** → **Assign role** → pick `app-user`.

Because the `roles` client scope is on by default, the role will appear in the
token under `realm_access.roles`.

### Step 8. Verify with the discovery document

Open in your browser:

```
http://localhost:8080/realms/demo/.well-known/openid-configuration
```

You should see JSON with `issuer`, `authorization_endpoint`, `token_endpoint`,
`userinfo_endpoint`, `jwks_uri`, `end_session_endpoint`. If this URL 404s, the
realm name is wrong.

### Step 9. Run the app and log in

```bash
export KEYCLOAK_CLIENT_SECRET=<secret from step 4>
./mvnw spring-boot:run
```

Browse to **http://localhost:8081** → *Login with Keycloak* → sign in as
`alice` / `alice` → you land on `/me` with every claim listed.

Done — the app is onboarded.

---

## Part 2 — Background: what just happened?

### What is OIDC?

**OAuth 2.0** is a protocol for *delegated access* — letting an app get a token
to call an API on your behalf. It says nothing about *who you are*.

**OpenID Connect (OIDC)** is a thin layer on top of OAuth 2.0 that adds identity:

* a special scope `openid`,
* an **ID token** (a signed JWT with claims like `sub`, `name`, `email`),
* a **UserInfo endpoint**,
* a **discovery document** (`/.well-known/openid-configuration`) so clients can
  configure themselves,
* standard **logout**.

Keycloak is an open-source **OpenID Provider (OP)**. Your app is the
**Relying Party (RP)** — it *relies* on Keycloak to say who the user is.

### The three tokens

| Token | Format | Purpose | Lifetime (Keycloak default) |
|---|---|---|---|
| ID token | JWT | Proves *who logged in*. Read by the app. | 5 min (same as access) |
| Access token | JWT (in Keycloak) | Sent as `Bearer` to APIs. | 5 min |
| Refresh token | opaque JWT | Get a new access token without asking the user again. | 30 min idle / 10 h max (SSO session) |

Change them under **Realm settings → Sessions** and **Tokens**, or per client
under **Advanced → Advanced settings**.

### Anatomy of a JWT

```
eyJhbGciOiJSUzI1NiIs...  .  eyJleHAiOjE3MjU...  .  SflKxwRJSMeKKF2QT4...
       header                   payload                 signature
```

The payload is just Base64-URL JSON. The signature is RSA/EC and is verified with
the realm's public key from `jwks_uri`. Anyone can *read* a JWT; only Keycloak can
*create* a valid one.

---

## Part 3 — Key properties explained

### 3.1 Realm-level

| Where | Property | What it controls | Best-practice value |
|---|---|---|---|
| Realm settings → General | Frontend URL | The `iss` value in tokens. Must match what the app uses in `issuer-uri`. | Set explicitly behind a proxy. |
| Realm settings → Login | User registration | Self sign-up form. | OFF unless you want it. |
| Realm settings → Login | Remember me / Forgot password | Login page features. | As needed. |
| Realm settings → Tokens | Access Token Lifespan | How long access tokens live. | 5–15 min. |
| Realm settings → Sessions | SSO Session Idle / Max | How long the Keycloak login cookie lasts. | 30 min / 10 h. |
| Realm settings → Security defenses | Brute force detection | Locks accounts after N failures. | ON. |
| Authentication → Required actions | Configure OTP, Verify email… | What a user must do at first login. | Enable *Verify email* in prod. |

### 3.2 Client-level

| Tab | Property | What it controls | Best practice |
|---|---|---|---|
| Settings | Client ID | Identifier sent as `client_id`. | Short, lowercase, no spaces. |
| Settings | Client authentication | Confidential (ON) vs public (OFF). | ON for server apps; OFF + PKCE for SPAs/mobile. |
| Settings | Standard flow | Authorization Code grant. | ON. |
| Settings | Direct access grants | Password grant. | OFF. |
| Settings | Implicit flow | Token in URL fragment. | OFF (insecure). |
| Settings | Service accounts roles | Client-credentials grant for backend jobs. | Only for machine clients. |
| Settings | Valid redirect URIs | Whitelist of callback URLs. | Exact URLs, no `*`. |
| Settings | Valid post logout redirect URIs | Where users may go after logout. | Your app's home. |
| Settings | Web origins | CORS allowed origins. | `+` or explicit list. |
| Settings | Front channel logout | Keycloak loads an iframe to your logout URL. | ON (default) or use back-channel. |
| Settings | Backchannel logout URL | Keycloak POSTs a logout token to your server when a session ends. | Recommended for real apps. |
| Settings | Consent required | Show an "Allow app X to access…" screen. | OFF for first-party apps. |
| Credentials | Client Authenticator | Secret, signed JWT, X.509 mTLS. | Secret for simple; JWT/mTLS for high security. |
| Client scopes | Default vs Optional scopes | Which claims go in tokens without / with asking. | Keep defaults; add custom mappers. |
| Client scopes → Dedicated scope | Mappers | Add custom claims (attributes, groups, hard-coded values). | Use *user attribute* / *group membership* mappers. |
| Advanced | Access Token Lifespan | Override realm value for this client. | Leave blank unless needed. |
| Advanced | PKCE Code Challenge Method | Enforce PKCE. | `S256`. |
| Advanced | Access Token Signature Algorithm | RS256 / ES256… | RS256 (default) or ES256. |

### 3.3 App-side properties (Spring Boot)

| Spring property | Keycloak field it must match |
|---|---|
| `client-id` | Client ID |
| `client-secret` | Credentials → Client secret |
| `redirect-uri` | Valid redirect URIs |
| `issuer-uri` | `http://<host>/realms/<realm>` (= Frontend URL + `/realms/<realm>`) |
| `scope` | Must exist in Client scopes (default or optional) |
| `client-authentication-method` | Credentials → Client Authenticator |

---

## Part 4 — Options and trade-offs

### Confidential vs public client

| | Confidential (Client auth ON) | Public (Client auth OFF) |
|---|---|---|
| Who | Server-side apps (Spring, Django, .NET) | SPAs, mobile, CLI |
| Secret | Yes | No |
| PKCE | Recommended | **Required** |
| Pros | Tokens never reach browser; refresh tokens safe | No secret to leak |
| Cons | Must protect the secret | Tokens live in the browser; XSS risk |

### Where to keep the session

| Option | Pros | Cons |
|---|---|---|
| HTTP session in the app (this demo) | Simple, tokens hidden from browser | Needs sticky sessions or Spring Session for scaling |
| Tokens in browser (SPA) | Stateless backend | XSS exposure, larger attack surface |

### Configuring endpoints

| Option | Pros | Cons |
|---|---|---|
| `issuer-uri` (discovery) | One line, auto-updates, validates `iss` | App needs Keycloak reachable at startup |
| Explicit five URLs | Starts without Keycloak | More to maintain, easy to mistype |

### Logout strategies

| Strategy | How | Pros | Cons |
|---|---|---|---|
| Local only | Spring default | Simple | User still logged into Keycloak SSO |
| RP-initiated | Redirect to `end_session_endpoint` (this demo) | Ends SSO session | Needs post-logout URI whitelist |
| Back-channel | Keycloak POSTs to your app | Works when user logs out elsewhere | Extra endpoint to implement |

### Roles: realm vs client roles

| | Realm role | Client role |
|---|---|---|
| Scope | Whole realm | One application |
| Token claim | `realm_access.roles` | `resource_access.<client>.roles` |
| Use when | Same role means the same thing in every app (e.g. `admin`) | Role only matters for one app |

### Keycloak deployment

| Option | Pros | Cons |
|---|---|---|
| `start-dev` + H2 | Zero config | Data lost on container removal, HTTP only |
| `start` + PostgreSQL + TLS | Production-grade, clustered | Must set `KC_HOSTNAME`, certificates, DB |
| Managed (Red Hat build, Phase Two, cloud) | No ops | Cost, less control |

---

## Part 5 — Best practices checklist

- [ ] One realm per environment or tenant; never use `master` for apps.
- [ ] Authorization Code + PKCE only; disable implicit and password grants.
- [ ] Exact redirect URIs — no wildcards.
- [ ] Rotate client secrets; store them in a vault, not in Git.
- [ ] Short access tokens (≤15 min), rely on refresh tokens.
- [ ] Enable brute-force protection and email verification.
- [ ] Use HTTPS everywhere outside `localhost`.
- [ ] Request only the scopes you need.
- [ ] Add custom claims through mappers instead of extra API calls.
- [ ] Implement back-channel logout for real applications.
- [ ] Export the realm (`kc.sh export`) and keep it in version control for reproducible setups.

---

## Part 6 — Automating onboarding (optional)

Instead of clicking, you can import a realm on start-up. Save this as
`realm-export/demo-realm.json` and run Keycloak with
`--import-realm` and the file mounted at `/opt/keycloak/data/import/`:

```json
{
  "realm": "demo",
  "enabled": true,
  "clients": [
    {
      "clientId": "spring-demo-app",
      "name": "Spring Demo App",
      "protocol": "openid-connect",
      "publicClient": false,
      "secret": "dev-secret-change-me",
      "standardFlowEnabled": true,
      "directAccessGrantsEnabled": false,
      "implicitFlowEnabled": false,
      "redirectUris": ["http://localhost:8081/login/oauth2/code/keycloak"],
      "webOrigins": ["http://localhost:8081"],
      "attributes": {
        "pkce.code.challenge.method": "S256",
        "post.logout.redirect.uris": "http://localhost:8081/*"
      }
    }
  ],
  "users": [
    {
      "username": "alice",
      "email": "alice@example.com",
      "emailVerified": true,
      "firstName": "Alice",
      "lastName": "Smith",
      "enabled": true,
      "credentials": [{ "type": "password", "value": "alice", "temporary": false }]
    }
  ]
}
```

The same can be done with the **Admin REST API**, the `kcadm.sh` CLI, or the
Terraform Keycloak provider — all useful when you onboard many apps.
