###############################################################################
# outputs.tf
# -----------------------------------------------------------------------------
# PURPOSE
#   Outputs are the module's return values. They serve two audiences:
#     1. YOU, after `terraform apply` - the IDs and URLs you need next.
#     2. OTHER Terraform code that calls this as a module.
#
#   Anything marked `sensitive = true` is hidden from console output but is
#   still stored in plain text in the state file. Nothing secret is emitted here.
###############################################################################


# =============================================================================
# THE LAUNCH TEMPLATE - the primary deliverable
# =============================================================================

output "launch_template_id" {
  description = "ID of the launch template. Pass this to an ASG, an EKS managed node group, or `aws ec2 run-instances --launch-template LaunchTemplateId=...`."
  value       = aws_launch_template.this.id
}

output "launch_template_arn" {
  description = "ARN of the launch template. Needed when granting another account or service permission to use it."
  value       = aws_launch_template.this.arn
}

output "launch_template_name" {
  description = "Generated name of the launch template (name_prefix plus a random suffix)."
  value       = aws_launch_template.this.name
}

output "launch_template_latest_version" {
  description = "Version number Terraform just created. Every apply that changes something increments this. Roll back by pointing your ASG at an earlier number."
  value       = aws_launch_template.this.latest_version
}

output "launch_template_default_version" {
  description = "Version that new launches use when they do not ask for a specific one."
  value       = aws_launch_template.this.default_version
}


# =============================================================================
# WHAT THE MODULE DECIDED FOR YOU
# =============================================================================

output "resolved_ami_id" {
  description = "The AMI actually baked into the template - either yours, or the Amazon Linux 2023 image that was looked up."
  value       = local.ami_id
}

output "iam_role_arn" {
  description = "ARN of the IAM role in use. Empty when you supplied an existing instance profile."
  value       = local.create_iam_role ? one(aws_iam_role.this[*].arn) : ""
}

output "iam_instance_profile_name" {
  description = "Instance profile name attached to the template."
  value       = local.instance_profile_name
}

output "security_group_ids" {
  description = "Security group IDs attached to the template - either yours or the generated one."
  value       = local.security_group_ids
}


# =============================================================================
# OPTIONAL AUTO SCALING GROUP
# =============================================================================

output "autoscaling_group_name" {
  description = "Name of the ASG, or empty string when create_autoscaling_group is false."
  value       = var.create_autoscaling_group ? one(aws_autoscaling_group.this[*].name) : ""
}

output "autoscaling_group_arn" {
  description = "ARN of the ASG, or empty string when not created."
  value       = var.create_autoscaling_group ? one(aws_autoscaling_group.this[*].arn) : ""
}


# =============================================================================
# ENDPOINTS - what to point your EKS workloads at
# -----------------------------------------------------------------------------
# <HOST> is the private IP or the DNS name of your internal load balancer.
# These are printed as templates because the actual address depends on how you
# front the instance (ALB, NLB, Route 53 record, or raw private IP).
# =============================================================================

output "endpoints" {
  description = "Cheat sheet of every endpoint the stack exposes. Replace <HOST> with the instance's private IP or your load balancer DNS name."
  value = {
    grafana_ui       = var.install_grafana ? "http://<HOST>:${var.grafana_port}" : "disabled"
    metrics_write    = local.metrics_write_url
    metrics_query    = local.metrics_query_url
    logs_write       = var.install_loki ? "http://<HOST>:${var.loki_port}/loki/api/v1/push" : "disabled"
    traces_otlp_grpc = var.install_alloy ? "<HOST>:${var.alloy_otlp_grpc_port}" : "disabled"
    traces_otlp_http = var.install_alloy ? "http://<HOST>:${var.alloy_otlp_http_port}" : "disabled"
    alloy_ui         = var.install_alloy ? "http://<HOST>:${var.alloy_http_port}" : "disabled"
    pyroscope        = var.install_pyroscope ? "http://<HOST>:${var.pyroscope_port}" : "disabled"
  }
}


# =============================================================================
# COPY-PASTE HELPERS
# =============================================================================

output "eks_otlp_env_vars" {
  description = "Drop these environment variables into your EKS Deployments and any OpenTelemetry-instrumented app will start sending traces to this stack."
  value = var.install_alloy ? {
    OTEL_EXPORTER_OTLP_ENDPOINT = "http://<HOST>:${var.alloy_otlp_http_port}"
    OTEL_EXPORTER_OTLP_PROTOCOL = "http/protobuf"
    OTEL_SERVICE_NAME           = "<your-service-name>"
    OTEL_RESOURCE_ATTRIBUTES    = "deployment.environment=<env>,k8s.cluster.name=${var.eks_cluster_name}"
  } : {}
}

output "run_instance_command" {
  description = "Ready-to-run AWS CLI command that launches one instance from this template. Only valid when create_autoscaling_group = false, because that is when the template carries its own subnet."
  value = var.create_autoscaling_group ? "N/A - launch through the Auto Scaling Group instead" : join(" ", [
    "aws ec2 run-instances",
    "--launch-template LaunchTemplateId=${aws_launch_template.this.id},Version=${aws_launch_template.this.latest_version}",
    "--region ${local.region}",
    "--count 1",
  ])
}

output "session_manager_hint" {
  description = "How to get a shell on the host without SSH or an open port 22."
  value       = "aws ssm start-session --target <INSTANCE_ID> --region ${local.region}   # then: sudo tail -f /var/log/user-data.log"
}
