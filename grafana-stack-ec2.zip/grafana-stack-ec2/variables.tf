###############################################################################
# variables.tf
# -----------------------------------------------------------------------------
# PURPOSE
#   Every knob you can turn lives here. Nothing in this module is hard-coded to
#   one account or one environment - you point it at YOUR existing AWS
#   resources by filling in terraform.tfvars.
#
# HOW TO READ A VARIABLE BLOCK
#   description = human explanation (shows up in `terraform console` and docs)
#   type        = the shape of the value (string, number, bool, list, map...)
#   default     = used when tfvars does not set it. NO default = required.
#   validation  = a rule Terraform checks BEFORE calling AWS, so you get a
#                 clear error in 2 seconds instead of a cryptic API error in
#                 2 minutes.
#
# CONVENTION USED BELOW
#   Any variable whose name looks like `existing_*` or `*_id` / `*_name` refers
#   to something that ALREADY EXISTS in your account. This module looks it up
#   with a `data` source and never tries to create or delete it.
###############################################################################


# =============================================================================
# SECTION 1 - GENERAL / NAMING
# =============================================================================

variable "aws_region" {
  description = "AWS region to deploy into, e.g. us-east-1. Must be the same region as your existing VPC, subnets, S3 buckets and KMS key."
  type        = string
}

variable "name_prefix" {
  description = "Short string prepended to every resource name so you can find things later. Example: 'obs-prod' produces 'obs-prod-grafana-stack-lt'."
  type        = string
  default     = "grafana-stack"

  validation {
    # AWS names are picky. Lower-case letters, digits and hyphens only,
    # and it must start with a letter. Keeping it <= 24 chars leaves room
    # for the suffixes this module appends.
    condition     = can(regex("^[a-z][a-z0-9-]{1,23}$", var.name_prefix))
    error_message = "name_prefix must start with a lower-case letter, contain only lower-case letters, digits and hyphens, and be 2-24 characters long."
  }
}

variable "tags" {
  description = "Map of tags applied to EVERY resource. Add cost-allocation tags here (Owner, CostCenter, Environment)."
  type        = map(string)
  default = {
    Project   = "grafana-observability-stack"
    ManagedBy = "terraform"
  }
}


# =============================================================================
# SECTION 2 - EXISTING NETWORK RESOURCES
# -----------------------------------------------------------------------------
# The module does NOT build a VPC. You supply IDs of things you already run.
# =============================================================================

variable "vpc_id" {
  description = "ID of the EXISTING VPC the observability host will live in. Example: vpc-0123456789abcdef0."
  type        = string

  validation {
    condition     = can(regex("^vpc-[0-9a-f]{8,17}$", var.vpc_id))
    error_message = "vpc_id must look like vpc-0123456789abcdef0."
  }
}

variable "subnet_ids" {
  description = <<-EOT
    List of EXISTING subnet IDs.
      * If you also create the Auto Scaling Group (create_autoscaling_group = true),
        the ASG spreads instances across all of these subnets. Give it at least two,
        in two different Availability Zones, for resilience.
      * If you only build the launch template, the first subnet is used as the
        default network interface subnet.
    Use PRIVATE subnets and reach Grafana through an ALB or SSM port-forward.
  EOT
  type        = list(string)

  validation {
    condition     = length(var.subnet_ids) > 0
    error_message = "You must supply at least one subnet ID."
  }
}

variable "security_group_ids" {
  description = <<-EOT
    List of EXISTING security group IDs to attach to the instance.
    Leave this as an empty list [] and the module will CREATE a security group
    for you using the ingress_cidr_blocks variable below. Supplying your own is
    the safer production choice because your security team already reviewed it.
  EOT
  type        = list(string)
  default     = []
}

variable "ingress_cidr_blocks" {
  description = "Only used when security_group_ids is empty. CIDR ranges allowed to reach the stack's ports. NEVER put 0.0.0.0/0 here in production."
  type        = list(string)
  default     = []
}

variable "associate_public_ip_address" {
  description = "Attach a public IPv4 address to the instance? Keep false. Public observability endpoints are a common breach path."
  type        = bool
  default     = false
}


# =============================================================================
# SECTION 3 - EXISTING COMPUTE / IDENTITY RESOURCES
# =============================================================================

variable "ami_id" {
  description = <<-EOT
    AMI to boot. Leave as "" (empty string) and the module looks up the newest
    Amazon Linux 2023 AMI for your region and architecture automatically.
    Set an explicit ami-xxxx if your organisation requires a hardened
    golden image (CIS benchmark image, etc).
  EOT
  type        = string
  default     = ""
}

variable "architecture" {
  description = "CPU architecture for the auto-looked-up AMI: 'x86_64' or 'arm64'. Must match instance_type. Graviton (arm64) is ~20% cheaper per vCPU."
  type        = string
  default     = "arm64"

  validation {
    condition     = contains(["x86_64", "arm64"], var.architecture)
    error_message = "architecture must be either x86_64 or arm64."
  }
}

variable "instance_type" {
  description = "EC2 instance type. m7g.xlarge (4 vCPU / 16 GiB, Graviton) is a sensible all-in-one starting point. Use m7i.xlarge for x86_64."
  type        = string
  default     = "m7g.xlarge"
}

variable "key_name" {
  description = "Name of an EXISTING EC2 key pair for SSH. Leave \"\" to disable SSH entirely and use AWS Systems Manager Session Manager instead (recommended - no open port 22, full audit log)."
  type        = string
  default     = ""
}

variable "iam_instance_profile_name" {
  description = <<-EOT
    Name of an EXISTING IAM instance profile to attach.
    Leave "" and the module creates a role + profile with least-privilege
    access to exactly the S3 buckets, KMS key, SSM parameter and AMP workspace
    you named in this tfvars file.
  EOT
  type        = string
  default     = ""
}


# =============================================================================
# SECTION 4 - STORAGE (EBS VOLUMES)
# -----------------------------------------------------------------------------
# Two volumes:
#   root  = operating system + the Grafana/Mimir/Loki/Tempo binaries
#   data  = hot path. Write-ahead logs, ingester chunks not yet flushed to S3,
#           Loki's local index cache. Keeping this separate means you can grow
#           or snapshot it independently of the OS.
# =============================================================================

variable "root_volume_size_gb" {
  description = "Root EBS volume size in GiB. 30 is comfortable for the OS plus all binaries."
  type        = number
  default     = 30
}

variable "root_volume_type" {
  description = "EBS type for root. gp3 is the modern default - cheaper than gp2 and you can tune IOPS separately from size."
  type        = string
  default     = "gp3"
}

variable "data_volume_enabled" {
  description = "Attach a second EBS volume for WAL / hot data? Strongly recommended for anything beyond a demo."
  type        = bool
  default     = true
}

variable "data_volume_size_gb" {
  description = "Size in GiB of the data volume. 200 GiB handles a few hundred thousand active series plus a day of un-flushed logs."
  type        = number
  default     = 200
}

variable "data_volume_type" {
  description = "EBS type for the data volume. gp3 for most people; io2 only if you have measured IOPS starvation."
  type        = string
  default     = "gp3"
}

variable "data_volume_iops" {
  description = "Provisioned IOPS for the data volume. gp3 includes 3000 free; going higher costs extra."
  type        = number
  default     = 3000
}

variable "data_volume_throughput_mbps" {
  description = "Provisioned throughput (MiB/s) for gp3. 125 is free; ingesters flushing to S3 benefit from 250."
  type        = number
  default     = 125
}

variable "data_volume_device_name" {
  description = "Block device name Linux will see. On Nitro instances this is remapped to /dev/nvme1n1, which the boot script handles automatically."
  type        = string
  default     = "/dev/xvdf"
}

variable "ebs_kms_key_id" {
  description = "ARN or key-id of an EXISTING KMS key used to encrypt both EBS volumes. Leave \"\" to use the AWS-managed aws/ebs key. Encryption itself is always ON."
  type        = string
  default     = ""
}


# =============================================================================
# SECTION 5 - EXISTING S3 BUCKETS (long-term storage)
# -----------------------------------------------------------------------------
# Mimir, Loki, Tempo and Pyroscope are all "object storage native": they keep
# only a small hot window on disk and push everything else to S3. You point
# them at buckets you already own and control the lifecycle rules for.
#
# You may use ONE bucket for all four (separate prefixes) or four buckets.
# Four buckets makes per-signal cost reporting and lifecycle tuning easier.
# =============================================================================

variable "mimir_bucket_name" {
  description = "EXISTING S3 bucket for Mimir metric blocks. Required when install_mimir = true."
  type        = string
  default     = ""
}

variable "mimir_bucket_prefix" {
  description = "Key prefix inside the Mimir bucket. Lets you share one bucket across signals or environments."
  type        = string
  default     = "mimir/"
}

variable "loki_bucket_name" {
  description = "EXISTING S3 bucket for Loki log chunks and TSDB index. Required when install_loki = true."
  type        = string
  default     = ""
}

variable "loki_bucket_prefix" {
  description = "Key prefix inside the Loki bucket."
  type        = string
  default     = "loki/"
}

variable "tempo_bucket_name" {
  description = "EXISTING S3 bucket for Tempo trace blocks. Required when install_tempo = true."
  type        = string
  default     = ""
}

variable "tempo_bucket_prefix" {
  description = "Key prefix inside the Tempo bucket."
  type        = string
  default     = "tempo/"
}

variable "pyroscope_bucket_name" {
  description = "EXISTING S3 bucket for Pyroscope profiles. Required when install_pyroscope = true."
  type        = string
  default     = ""
}

variable "pyroscope_bucket_prefix" {
  description = "Key prefix inside the Pyroscope bucket."
  type        = string
  default     = "pyroscope/"
}

variable "s3_sse_kms_key_arn" {
  description = "ARN of an EXISTING KMS key used for SSE-KMS on those buckets. Leave \"\" if the buckets use SSE-S3 (AES256). If set, the generated IAM policy grants kms:Encrypt/Decrypt/GenerateDataKey on it."
  type        = string
  default     = ""
}


# =============================================================================
# SECTION 6 - WHICH COMPONENTS TO INSTALL, AND WHICH VERSIONS
# -----------------------------------------------------------------------------
# Turn a component off and the boot script skips its download, its config file
# and its systemd unit entirely. Turn Mimir off and use AMP instead - see
# SECTION 8.
# =============================================================================

variable "install_grafana" {
  description = "Install Grafana OSS (the dashboard and alerting UI)."
  type        = bool
  default     = true
}

variable "install_mimir" {
  description = "Install Grafana Mimir (long-term Prometheus-compatible metrics). Set false if you use Amazon Managed Service for Prometheus."
  type        = bool
  default     = true
}

variable "install_loki" {
  description = "Install Grafana Loki (logs)."
  type        = bool
  default     = true
}

variable "install_tempo" {
  description = "Install Grafana Tempo (distributed traces)."
  type        = bool
  default     = true
}

variable "install_pyroscope" {
  description = "Install Grafana Pyroscope (continuous profiling). Optional - most teams add this later."
  type        = bool
  default     = false
}

variable "install_alloy" {
  description = "Install Grafana Alloy, the collector. It scrapes the host itself, receives OTLP from your EKS workloads, and forwards to the backends."
  type        = bool
  default     = true
}

# --- Versions -----------------------------------------------------------------
# Pin these. "latest" is not a version - it makes rebuilds non-reproducible.
# Check https://github.com/grafana/<project>/releases for current tags.

variable "grafana_version" {
  description = "Grafana OSS version to install from the official RPM repository."
  type        = string
  default     = "11.6.0"
}

variable "mimir_version" {
  description = "Mimir release tag (without the leading 'mimir-')."
  type        = string
  default     = "2.15.0"
}

variable "loki_version" {
  description = "Loki release tag (without the leading 'v')."
  type        = string
  default     = "3.4.2"
}

variable "tempo_version" {
  description = "Tempo release tag (without the leading 'v')."
  type        = string
  default     = "2.7.1"
}

variable "pyroscope_version" {
  description = "Pyroscope release tag (without the leading 'v')."
  type        = string
  default     = "1.13.0"
}

variable "alloy_version" {
  description = "Alloy release tag (without the leading 'v')."
  type        = string
  default     = "1.7.1"
}


# =============================================================================
# SECTION 7 - PORTS AND RETENTION
# =============================================================================

variable "grafana_port" {
  description = "TCP port Grafana listens on."
  type        = number
  default     = 3000
}

variable "mimir_port" {
  description = "Mimir HTTP port. Push endpoint is /api/v1/push, query endpoint is /prometheus."
  type        = number
  default     = 9009
}

variable "loki_port" {
  description = "Loki HTTP port. Push endpoint is /loki/api/v1/push."
  type        = number
  default     = 3100
}

variable "tempo_http_port" {
  description = "Tempo HTTP API port used by Grafana to query traces."
  type        = number
  default     = 3200
}

variable "tempo_otlp_grpc_port" {
  description = "Port Tempo itself listens on for OTLP/gRPC. Deliberately NOT 4317, because Alloy owns 4317 as the front door."
  type        = number
  default     = 14317
}

variable "alloy_otlp_grpc_port" {
  description = "Port Alloy exposes for OTLP/gRPC. This is the endpoint your EKS pods send traces to."
  type        = number
  default     = 4317
}

variable "alloy_otlp_http_port" {
  description = "Port Alloy exposes for OTLP/HTTP."
  type        = number
  default     = 4318
}

variable "alloy_http_port" {
  description = "Alloy's own web UI and metrics port."
  type        = number
  default     = 12345
}

variable "pyroscope_port" {
  description = "Pyroscope HTTP port."
  type        = number
  default     = 4040
}

variable "metrics_retention_period" {
  description = "How long Mimir keeps metrics before the compactor deletes the blocks. Go-duration string. 90d = 2160h."
  type        = string
  default     = "2160h"
}

variable "logs_retention_period" {
  description = "How long Loki keeps logs. 30d = 720h. Logs are usually the biggest bill, so start short."
  type        = string
  default     = "720h"
}

variable "traces_retention_period" {
  description = "How long Tempo keeps traces. Traces are high volume and low re-read; 7d = 168h is typical."
  type        = string
  default     = "168h"
}


# =============================================================================
# SECTION 8 - INTEGRATION WITH EXISTING AWS OBSERVABILITY SERVICES
# =============================================================================

variable "amp_workspace_id" {
  description = <<-EOT
    ID of an EXISTING Amazon Managed Service for Prometheus workspace, e.g. ws-abc12345-....
    When set:
      * Alloy remote-writes metrics to AMP (SigV4-signed) instead of local Mimir.
      * The generated IAM policy gains aps:RemoteWrite / aps:Query on it.
    Leave "" to keep everything on the self-hosted Mimir.
  EOT
  type        = string
  default     = ""
}

variable "eks_cluster_name" {
  description = "Name of an EXISTING EKS cluster this stack observes. Used to label metrics and to build the Grafana CloudWatch data source. Purely informational if left \"\"."
  type        = string
  default     = ""
}

variable "cloudwatch_log_group_name" {
  description = "EXISTING CloudWatch Logs group to ship this host's own systemd logs to, so you can debug the observability box even when the observability box is down. Leave \"\" to disable."
  type        = string
  default     = ""
}

variable "enable_cloudwatch_datasource" {
  description = "Provision a CloudWatch data source in Grafana so you can chart RDS, ALB, NAT Gateway, MSK etc. next to your Kubernetes metrics."
  type        = bool
  default     = true
}

variable "enable_xray_datasource" {
  description = "Provision an AWS X-Ray data source in Grafana (useful when Lambda in your request path is instrumented with X-Ray rather than OTLP)."
  type        = bool
  default     = false
}


# =============================================================================
# SECTION 9 - GRAFANA CONFIGURATION
# =============================================================================

variable "grafana_admin_password_ssm_parameter" {
  description = <<-EOT
    Name of an EXISTING SSM Parameter Store SecureString holding the initial
    Grafana admin password, e.g. /obs/prod/grafana/admin-password.
    The password is fetched AT BOOT by the instance, so it never appears in
    Terraform state, in the launch template, or in your git history.
    Leave "" to keep Grafana's default admin/admin (demo only!).
  EOT
  type        = string
  default     = ""
}

variable "grafana_root_url" {
  description = "Public URL users type in the browser, e.g. https://grafana.example.com. Needed so that alert notifications contain working links. Leave \"\" to use the instance IP."
  type        = string
  default     = ""
}

variable "grafana_additional_datasources_yaml" {
  description = "Raw YAML appended to Grafana's provisioned datasource file. Use for extra sources such as Athena (for Cost and Usage Reports) or a Timestream database."
  type        = string
  default     = ""
}


# =============================================================================
# SECTION 10 - LAUNCH TEMPLATE BEHAVIOUR
# =============================================================================

variable "enforce_imdsv2" {
  description = "Require IMDSv2 (token-based instance metadata). Leave true. IMDSv1 is the mechanism behind several famous cloud credential thefts."
  type        = bool
  default     = true
}

variable "http_put_response_hop_limit" {
  description = "How many network hops the metadata token may travel. 1 blocks containers on the host from reading instance credentials. Raise to 2 only if you run Docker on this host and need it."
  type        = number
  default     = 1
}

variable "enable_detailed_monitoring" {
  description = "Enable 1-minute CloudWatch EC2 metrics instead of the free 5-minute ones. Small extra cost, much better graphs."
  type        = bool
  default     = true
}

variable "enable_nitro_encryption_in_transit" {
  description = "Placeholder for EBS-optimized flag. Modern instance types are always EBS-optimized, so this simply sets ebs_optimized = true."
  type        = bool
  default     = true
}

variable "update_default_version" {
  description = "When Terraform creates a new launch template version, should it become the default? true means new ASG instances immediately pick it up."
  type        = bool
  default     = true
}

variable "extra_user_data_script" {
  description = "Extra bash appended to the very end of the boot script. Handy for joining a config-management tool or installing a corporate agent."
  type        = string
  default     = ""
}


# =============================================================================
# SECTION 11 - OPTIONAL AUTO SCALING GROUP
# -----------------------------------------------------------------------------
# A launch template on its own launches nothing. Set this to true and the
# module also creates a small ASG that keeps exactly one healthy host alive
# and replaces it automatically if it dies.
# =============================================================================

variable "create_autoscaling_group" {
  description = "Also create an Auto Scaling Group that uses this launch template."
  type        = bool
  default     = false
}

variable "asg_min_size" {
  description = "Minimum instances in the ASG."
  type        = number
  default     = 1
}

variable "asg_max_size" {
  description = "Maximum instances. Keep at 1 for a monolithic single-binary stack - two hosts would each hold half the data."
  type        = number
  default     = 1
}

variable "asg_desired_capacity" {
  description = "Instances to run right now."
  type        = number
  default     = 1
}

variable "target_group_arns" {
  description = "ARNs of EXISTING ALB/NLB target groups to register instances with. Point an existing internal ALB at Grafana this way."
  type        = list(string)
  default     = []
}

variable "asg_health_check_type" {
  description = "'EC2' (is the VM alive?) or 'ELB' (is Grafana answering HTTP?). Use ELB when target_group_arns is set."
  type        = string
  default     = "EC2"
}
