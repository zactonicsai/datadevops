###############################################################################
# launch_template.tf
# -----------------------------------------------------------------------------
# PURPOSE
#   THIS IS THE MAIN DELIVERABLE.
#
#   A launch template is a saved recipe for an EC2 instance: which image,
#   which size, which disks, which firewall, which IAM role, and which script
#   to run on first boot. It launches nothing by itself. You then point an Auto
#   Scaling Group, an EKS managed node group, a Spot fleet, or a plain
#   `aws ec2 run-instances` at it.
#
#   Launch templates are VERSIONED. Every `terraform apply` that changes
#   anything here creates a NEW version rather than mutating the old one, so
#   rollback is one API call away.
###############################################################################


resource "aws_launch_template" "this" {

  # ===========================================================================
  # IDENTITY
  # ===========================================================================

  # name_prefix instead of name: AWS appends a random suffix, so Terraform can
  # create a replacement before destroying the old one if a change ever forces
  # replacement rather than a new version.
  name_prefix = "${local.name}-lt-"

  description = "Grafana LGTM observability stack (Grafana + Mimir + Loki + Tempo + Alloy)"

  # Shown in the console next to each version number. Including a timestamp
  # makes "which version was deployed on Tuesday?" answerable at a glance.
  # Note: this alone will not force a new version - Terraform only makes one
  # when a real attribute changes.
  update_default_version = var.update_default_version


  # ===========================================================================
  # IMAGE AND SIZE
  # ===========================================================================

  # Either the AMI you pinned, or the newest Amazon Linux 2023 (see data.tf).
  image_id = local.ami_id

  instance_type = var.instance_type

  # Existing EC2 key pair name, or null to disable SSH key injection entirely.
  # `null` (not "") is required - an empty string is a valid-but-wrong key name.
  key_name = var.key_name != "" ? var.key_name : null

  # Modern instance families are EBS-optimized by default and this is free.
  ebs_optimized = var.enable_nitro_encryption_in_transit


  # ===========================================================================
  # IAM
  # ===========================================================================

  iam_instance_profile {
    # Either the profile you already own, or the one built in iam.tf.
    name = local.instance_profile_name
  }


  # ===========================================================================
  # NETWORKING
  # ---------------------------------------------------------------------------
  # AWS does not allow a subnet to be specified in TWO places. So:
  #
  #   * create_autoscaling_group = true
  #       -> the ASG owns subnet selection (vpc_zone_identifier).
  #          The template must therefore NOT contain a network_interfaces
  #          block with a subnet. We set vpc_security_group_ids instead.
  #
  #   * create_autoscaling_group = false
  #       -> the template is self-contained, so it carries the subnet and the
  #          public-IP setting inside a network_interfaces block. This is what
  #          you want for `aws ec2 run-instances --launch-template ...`.
  #
  # Getting this wrong produces the classic error:
  #   "Network interfaces and an instance-level subnet ID may not be specified
  #    on the same request."
  # ===========================================================================

  vpc_security_group_ids = var.create_autoscaling_group ? local.security_group_ids : null

  dynamic "network_interfaces" {
    for_each = var.create_autoscaling_group ? [] : [1]
    content {
      device_index                = 0 # the primary NIC (eth0)
      subnet_id                   = var.subnet_ids[0]
      security_groups             = local.security_group_ids
      associate_public_ip_address = var.associate_public_ip_address
      delete_on_termination       = true # do not leak orphaned ENIs
    }
  }


  # ===========================================================================
  # STORAGE
  # ===========================================================================

  # --- Root volume: OS + binaries -------------------------------------------
  block_device_mappings {
    # /dev/xvda is the root device name for Amazon Linux 2023.
    # Ubuntu images use /dev/sda1. Get this wrong and you silently create an
    # extra unused volume while the root stays at its default size.
    device_name = "/dev/xvda"

    ebs {
      volume_size = var.root_volume_size_gb
      volume_type = var.root_volume_type

      # Encryption is ALWAYS on. The value is a string "true", not a bool,
      # because the launch template API models it that way.
      encrypted = "true"

      # null here means "use the account's default aws/ebs key".
      kms_key_id = local.ebs_kms_key_arn

      # Root disk dies with the instance - it holds nothing precious.
      delete_on_termination = "true"
    }
  }

  # --- Data volume: WAL, hot chunks, index cache ----------------------------
  # `dynamic` so the block vanishes completely when data_volume_enabled = false.
  dynamic "block_device_mappings" {
    for_each = var.data_volume_enabled ? [1] : []
    content {
      device_name = var.data_volume_device_name

      ebs {
        volume_size = var.data_volume_size_gb
        volume_type = var.data_volume_type

        # iops and throughput are only legal on gp3/io1/io2. Setting them on a
        # gp2 volume is an API error, so they are nulled out conditionally.
        iops       = contains(["gp3", "io1", "io2"], var.data_volume_type) ? var.data_volume_iops : null
        throughput = var.data_volume_type == "gp3" ? var.data_volume_throughput_mbps : null

        encrypted  = "true"
        kms_key_id = local.ebs_kms_key_arn

        # true because the durable copy of everything lives in S3. If you would
        # rather keep the un-flushed WAL across an instance replacement, set
        # this to false and manage re-attachment yourself.
        delete_on_termination = "true"
      }
    }
  }


  # ===========================================================================
  # INSTANCE METADATA SERVICE (IMDS) HARDENING
  # ---------------------------------------------------------------------------
  # IMDS is the 169.254.169.254 endpoint that hands out the role's temporary
  # credentials. IMDSv1 answers any GET request, which is why a single SSRF bug
  # in a web app used to mean total account compromise. IMDSv2 requires a PUT
  # to obtain a session token first, which SSRF cannot do.
  # ===========================================================================

  metadata_options {
    http_endpoint = "enabled"

    # "required" = IMDSv2 only. "optional" = v1 still allowed. Keep required.
    http_tokens = var.enforce_imdsv2 ? "required" : "optional"

    # TTL on the token, in network hops. 1 means the token cannot leave the
    # instance - a container on a bridge network is 1 hop away and gets blocked.
    http_put_response_hop_limit = var.http_put_response_hop_limit

    # Lets the boot script read its own tags from metadata without an API call.
    instance_metadata_tags = "enabled"
  }


  # ===========================================================================
  # MONITORING
  # ===========================================================================

  monitoring {
    # true = 1-minute EC2 metrics (small charge). false = free 5-minute.
    enabled = var.enable_detailed_monitoring
  }


  # ===========================================================================
  # BOOT SCRIPT (user_data)
  # ---------------------------------------------------------------------------
  # This is the script cloud-init runs as root on first boot. It installs every
  # component, writes every config file, and starts every systemd unit.
  #
  # It MUST be base64-encoded - that is what the EC2 API expects.
  #
  # HARD LIMIT: EC2 accepts 16 KB of user data in raw form.
  #
  # `base64gzip()` GZIPs the script and then base64-encodes it. cloud-init
  # detects the gzip magic bytes and transparently decompresses before running.
  # Shell and YAML compress roughly 4-6x, which buys plenty of headroom for the
  # embedded config files. checks.tf still verifies the size at plan time.
  # ===========================================================================

  user_data = base64gzip(local.user_data)


  # ===========================================================================
  # SHUTDOWN AND CAPACITY BEHAVIOUR
  # ===========================================================================

  # "stop" preserves the instance and its data on an OS-level shutdown.
  # "terminate" would throw it away. Stop is the safer default here.
  instance_initiated_shutdown_behavior = "stop"

  # Burstable (t3/t4g) instances only: "unlimited" stops the CPU being throttled
  # to a crawl during a query storm, at the cost of surcharge billing.
  # The dynamic block only appears for t-family instance types.
  dynamic "credit_specification" {
    for_each = startswith(var.instance_type, "t") ? [1] : []
    content {
      cpu_credits = "unlimited"
    }
  }


  # ===========================================================================
  # TAG PROPAGATION
  # ---------------------------------------------------------------------------
  # Tags on the launch template itself do NOT flow to the things it launches.
  # You must declare them per resource type. Forgetting the "volume" block is
  # the most common cause of untagged, unattributable EBS spend.
  # ===========================================================================

  tag_specifications {
    resource_type = "instance"
    tags = merge(var.tags, {
      Name      = "${local.name}-observability"
      Component = "grafana-lgtm-stack"
    })
  }

  tag_specifications {
    resource_type = "volume"
    tags = merge(var.tags, {
      Name = "${local.name}-observability-volume"
    })
  }

  tag_specifications {
    resource_type = "network-interface"
    tags = merge(var.tags, {
      Name = "${local.name}-observability-eni"
    })
  }

  # Tags on the launch template resource itself.
  tags = merge(var.tags, { Name = "${local.name}-lt" })


  # ===========================================================================
  # LIFECYCLE
  # ===========================================================================

  lifecycle {
    # Pairs with name_prefix so an unavoidable replacement never leaves a gap.
    create_before_destroy = true

    # Fail the plan early with a readable message rather than a 400 from AWS.
    precondition {
      condition     = !(var.install_mimir && var.mimir_bucket_name == "")
      error_message = "install_mimir is true, so mimir_bucket_name must name an existing S3 bucket."
    }

    precondition {
      condition     = !(var.install_loki && var.loki_bucket_name == "")
      error_message = "install_loki is true, so loki_bucket_name must name an existing S3 bucket."
    }

    precondition {
      condition     = !(var.install_tempo && var.tempo_bucket_name == "")
      error_message = "install_tempo is true, so tempo_bucket_name must name an existing S3 bucket."
    }

    precondition {
      condition     = !(var.install_pyroscope && var.pyroscope_bucket_name == "")
      error_message = "install_pyroscope is true, so pyroscope_bucket_name must name an existing S3 bucket."
    }

    # A Graviton AMI will not boot on an Intel instance type and vice versa.
    precondition {
      condition = var.ami_id != "" || (
        var.architecture == "arm64" ? can(regex("^[a-z]+[0-9]+g", var.instance_type)) : true
      )
      error_message = "architecture is arm64 but instance_type does not look like a Graviton type (e.g. m7g.xlarge, c7g.large, t4g.medium). Set architecture = \"x86_64\" or pick a Graviton instance type."
    }
  }
}
