# Grafana LGTM Stack on EC2 — Terraform Launch Template

Build one EC2 machine that runs **Grafana + Mimir + Loki + Tempo + Alloy**, all wired together, using S3 buckets and IAM roles you already have. Everything is controlled from a single `terraform.tfvars` file.

---

## Part 1 — Background: what is this thing?

### The problem

When something breaks in your EKS cluster, you usually ask three questions:

1. **"Is it slow?"** → you need **metrics** (numbers over time, like CPU or request latency)
2. **"What happened?"** → you need **logs** (text lines your app printed)
3. **"Where exactly did it break?"** → you need **traces** (a map of one request as it travels through ten services)

Most teams end up with three different tools that do not talk to each other. You see a latency spike in one tab, then hunt for the matching logs in another tab by copy-pasting timestamps. That is slow and frustrating.

### The solution

Grafana Labs makes four open-source databases, one per signal, plus a UI that stitches them together:

| Nickname | Tool | Stores | Think of it as |
|---|---|---|---|
| **L** | **Loki** | Logs | "Prometheus, but for log lines" |
| **G** | **Grafana** | Nothing! | The website you look at |
| **T** | **Tempo** | Traces | The map of one request's journey |
| **M** | **Mimir** | Metrics | Prometheus that never runs out of room |

People call this **"the LGTM stack."**

Two extras this module also supports:

- **Alloy** — the *collector*. It is the front door. Your apps send data to Alloy, and Alloy sorts it into the right database. It is Grafana's version of the OpenTelemetry Collector.
- **Pyroscope** — *continuous profiling*. Tells you which exact function is eating your CPU.

### The clever bit: they all use S3

Mimir, Loki, Tempo and Pyroscope keep only a few hours of recent data on the local disk. Everything older gets compressed and pushed to **Amazon S3**.

Why this matters:

- S3 costs about **$0.023 per GB per month**. EBS disk costs about **$0.08**. Roughly 3.5× cheaper.
- If your EC2 instance explodes, your data is safe. A replacement instance reads it straight back out of S3.
- You never have to resize a disk because you kept too much data.

### The other clever bit: correlation

This is what makes it a *stack* instead of four separate products.

```
   You see a latency spike on a graph
                 ↓  (click the little diamond — an "exemplar")
   You are now looking at one slow trace
                 ↓  (click "Logs for this span")
   You are now reading that exact pod's logs
                 ↓  (click "Profiles")
   You are looking at the flame graph of the function that was slow
```

Four clicks, no copy-pasting timestamps. The configuration that makes this work is already written for you in `templates/grafana-datasources.yaml.tftpl`.

---

## Part 2 — Step-by-step: your first deployment

We will deploy the whole stack in about 15 minutes. Follow along exactly, then read Part 3 to understand what you did.

### Step 0 — What you need before you start

| You need | How to check |
|---|---|
| Terraform 1.5 or newer | `terraform version` |
| AWS CLI, logged in | `aws sts get-caller-identity` |
| An existing VPC with private subnets | `aws ec2 describe-vpcs` |
| An EKS cluster to watch (optional) | `aws eks list-clusters` |

### Step 1 — Create three S3 buckets

This module does **not** create buckets, on purpose — buckets outlive stacks, and you probably have naming and lifecycle rules of your own. Make them now:

```bash
export REGION=us-east-1
export ACCOUNT=$(aws sts get-caller-identity --query Account --output text)

for signal in metrics logs traces; do
  aws s3api create-bucket \
    --bucket "$ACCOUNT-observability-$signal" \
    --region "$REGION"

  # Block all public access — four separate settings, all must be on.
  aws s3api put-public-access-block \
    --bucket "$ACCOUNT-observability-$signal" \
    --public-access-block-configuration \
      "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"

  # Encrypt everything at rest.
  aws s3api put-bucket-encryption \
    --bucket "$ACCOUNT-observability-$signal" \
    --server-side-encryption-configuration \
      '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'
done
```

> **Do NOT turn on bucket versioning.** Mimir, Loki and Tempo delete their own expired blocks. With versioning on, the "deleted" data sticks around as old versions and your bill quietly doubles.

### Step 2 — Create the Grafana admin password

Put it in Parameter Store, not in your code:

```bash
aws ssm put-parameter \
  --name /obs/prod/grafana/admin-password \
  --type SecureString \
  --value "$(openssl rand -base64 24)" \
  --region "$REGION"
```

The EC2 instance fetches this at boot using its IAM role. The password never touches Terraform state, the launch template, or your git history.

### Step 3 — Fill in your variables

```bash
cd grafana-stack-ec2
cp terraform.tfvars.example terraform.tfvars
```

Now edit `terraform.tfvars`. At minimum, replace these:

```hcl
aws_region  = "us-east-1"
name_prefix = "obs-prod"

vpc_id     = "vpc-0abc123..."                    # your VPC
subnet_ids = ["subnet-0aaa...", "subnet-0bbb..."] # two PRIVATE subnets, different AZs

ingress_cidr_blocks = ["10.0.0.0/16"]            # your VPC CIDR, NOT 0.0.0.0/0

mimir_bucket_name = "111122223333-observability-metrics"
loki_bucket_name  = "111122223333-observability-logs"
tempo_bucket_name = "111122223333-observability-traces"

grafana_admin_password_ssm_parameter = "/obs/prod/grafana/admin-password"
eks_cluster_name                     = "my-eks-cluster"

create_autoscaling_group = true
```

Everything else has a sensible default.

### Step 4 — Deploy

```bash
terraform init      # downloads the AWS provider
terraform plan      # shows exactly what will be created — READ THIS
terraform apply     # type "yes" when prompted
```

`terraform plan` will refuse to continue if a bucket name is wrong or a subnet is in the wrong VPC. It will also print **warnings** (from `checks.tf`) for things that are legal but unwise, like a public IP address.

### Step 5 — Watch it boot

Apply finishes in about 90 seconds, but the instance needs 5–8 minutes to download and start everything.

```bash
# Find the instance
INSTANCE=$(aws ec2 describe-instances \
  --filters "Name=tag:Name,Values=obs-prod-observability" "Name=instance-state-name,Values=running" \
  --query 'Reservations[0].Instances[0].InstanceId' --output text)

# Get a shell — no SSH key, no open port 22
aws ssm start-session --target "$INSTANCE"

# Inside the session:
sudo tail -f /var/log/user-data.log
```

When it finishes you will see a summary:

```
=== Bootstrap finished at ... Service status: ===
mimir            active
loki             active
tempo            active
alloy            active
grafana-server   active
```

### Step 6 — Open Grafana

The instance has no public IP (good!). Tunnel to it:

```bash
aws ssm start-session \
  --target "$INSTANCE" \
  --document-name AWS-StartPortForwardingSession \
  --parameters '{"portNumber":["3000"],"localPortNumber":["3000"]}'
```

Now open **http://localhost:3000**, log in as `admin` with the password you generated in Step 2, and go to **Connections → Data sources**. Metrics, Logs and Traces should all be there already, provisioned automatically.

### Step 7 — Send data from EKS

Get the private IP of the host, then install Alloy in your cluster pointing at it. See `examples/eks-alloy-values.yaml` in this directory for a ready-made Helm values file.

For applications, three environment variables are all it takes:

```yaml
env:
  - name: OTEL_EXPORTER_OTLP_ENDPOINT
    value: "http://10.0.1.42:4318"      # the observability host's private IP
  - name: OTEL_EXPORTER_OTLP_PROTOCOL
    value: "http/protobuf"
  - name: OTEL_SERVICE_NAME
    value: "checkout-api"
```

**You are done.** Everything below is detail and background.

---

## Part 3 — What every file does

```
grafana-stack-ec2/
├── README.md                    ← you are here
├── versions.tf                  Pins Terraform and AWS provider versions
├── providers.tf                 Region + tags applied to everything
├── variables.tf                 Every knob you can turn (read this second)
├── terraform.tfvars.example     Copy to terraform.tfvars and fill in
├── data.tf                      Looks up your EXISTING VPC, buckets, keys, AMI
├── locals.tf                    Computed values; renders all config templates
├── iam.tf                       Least-privilege role (skipped if you supply one)
├── security_group.tf            Firewall rules (skipped if you supply your own)
├── launch_template.tf           ★ THE MAIN FILE — the EC2 recipe
├── asg.tf                       Optional Auto Scaling Group for self-healing
├── checks.tf                    Warnings for legal-but-unwise settings
├── outputs.tf                   IDs, URLs and copy-paste commands
├── Makefile                     Shortcuts: make plan, make apply, make logs
├── examples/
│   └── eks-alloy-values.yaml    Helm values to ship EKS data to this host
└── templates/
    ├── user_data.sh.tftpl       The boot script that installs everything
    ├── mimir.yaml.tftpl         Metrics config
    ├── loki.yaml.tftpl          Logs config
    ├── tempo.yaml.tftpl         Traces config
    ├── pyroscope.yaml.tftpl     Profiling config
    ├── alloy.river.tftpl        Collector pipeline
    └── grafana-datasources.yaml.tftpl   Auto-wired data sources
```

Every file is commented line by line. If you want to understand one thing deeply, open `launch_template.tf` — it is the heart of the module.

### The "use existing or create it" pattern

Several variables follow the same rule:

> **Give me a name and I will use yours. Leave it empty and I will build one.**

| Leave empty and the module creates… | Set it and the module uses yours |
|---|---|
| `iam_instance_profile_name` → builds a least-privilege role | your existing profile |
| `security_group_ids` → builds a firewall from `ingress_cidr_blocks` | your existing SGs |
| `ami_id` → looks up the newest Amazon Linux 2023 | your golden AMI |
| `ebs_kms_key_id` → uses the AWS-managed `aws/ebs` key | your customer-managed key |

This is why the module works out of the box in a lab account but drops cleanly into a locked-down enterprise account too.

---

## Part 4 — How the pieces connect

```
   Your EKS pods
        │  OTLP traces, logs, metrics
        ▼
   ┌──────────────────── EC2 instance ────────────────────┐
   │                                                      │
   │   Alloy  :4317 gRPC  :4318 HTTP  :12345 UI           │
   │     │         │            │                         │
   │     │metrics  │logs        │traces                   │
   │     ▼         ▼            ▼                         │
   │   Mimir     Loki        Tempo       Pyroscope        │
   │   :9009     :3100       :3200        :4040           │
   │     │         │            │            │            │
   │     └─────────┴────────────┴────────────┘            │
   │                    │                                 │
   │                    ▼                                 │
   │              Grafana :3000  ◄── you                  │
   └──────────────────────┼───────────────────────────────┘
                          ▼
                    Amazon S3  (three buckets)
```

**Why does Alloy sit in front?** Because it gives you one place to add sampling, redact PII, or fan out to a second destination — without touching a single application. Change the collector, not your code.

**Why is Tempo on port 14317 instead of 4317?** Two programs cannot listen on the same port. Alloy claims the well-known OTLP ports (4317/4318) as the front door, so Tempo listens behind it on 14317.

---

## Part 5 — Options and trade-offs

### Option A: self-hosted Mimir vs Amazon Managed Prometheus (AMP)

|  | Self-hosted Mimir (default) | Amazon Managed Prometheus |
|---|---|---|
| **Cost model** | EC2 + S3 storage | Per sample ingested + per sample queried |
| **Cheap when** | Volume is high and steady | Volume is low or spiky |
| **Ops burden** | You own compaction, upgrades, tuning | AWS owns it |
| **Scales past one node?** | Only by moving to Kubernetes | Automatically |
| **Works if the EC2 host dies?** | No (until it reboots) | Yes |

**How to switch to AMP:**

```hcl
install_mimir    = false
amp_workspace_id = "ws-abc12345-6789-..."
```

The module then signs every request with AWS SigV4 using the instance role, adds `aps:RemoteWrite` to the IAM policy, and points Grafana's Prometheus data source at AMP instead. Nothing else changes.

### Option B: Loki vs CloudWatch Logs

| | Loki on S3 | CloudWatch Logs |
|---|---|---|
| **Ingest price** | S3 PUT requests, effectively pennies | ~$0.50 per GB ingested |
| **Storage price** | ~$0.023 per GB/month | ~$0.03 per GB/month |
| **Query language** | LogQL (same shape as PromQL) | Logs Insights |
| **Correlation with traces** | Built in, one click | Manual |
| **Ops burden** | Yours | AWS's |
| **AWS-native log sources** | Needs a forwarder | Automatic |

**Common compromise:** application logs → Loki, control-plane and audit logs → CloudWatch. You get the cost savings where volume is high and keep the AWS-native integration where it matters.

### Option C: one instance vs a real cluster

This module deliberately runs everything in **monolithic mode** on one host.

**Good, because:**
- One machine to patch, one config to read
- Costs roughly $150–250/month all-in for a mid-size setup
- Genuinely fine for tens of thousands of active series and a few hundred GB of logs per month

**Bad, because:**
- It is a single point of failure. If the box dies, you cannot query anything until the ASG replaces it (~8 minutes). *Data already in S3 is never lost.*
- `asg_max_size` must stay at **1**. Two hosts would not form a cluster — they use an in-memory hash ring and would each hold half your recent data with no idea the other exists.
- No read/write isolation. A giant dashboard query can slow down ingestion.

**When to graduate to Kubernetes:** when you consistently exceed ~1 million active series, ~1 TB of logs per month, or when a few minutes of query downtime becomes unacceptable. The same binaries run in microservices mode via the `mimir-distributed`, `loki-distributed` and `tempo-distributed` Helm charts. Your configs and dashboards carry over.

### Option D: Graviton (arm64) vs Intel/AMD (x86_64)

Every Grafana component publishes arm64 builds and they are well tested. Graviton is typically **~20% cheaper for equivalent throughput**. The default here is `arm64` with `m7g.xlarge`.

To use x86_64 instead, change **both**:

```hcl
architecture  = "x86_64"
instance_type = "m7i.xlarge"
```

The launch template has a precondition that fails the plan if you change one and forget the other.

---

## Part 6 — Best practices baked in

| Practice | Where | Why |
|---|---|---|
| **IMDSv2 required** | `launch_template.tf` | Blocks the SSRF-to-credential-theft attack path |
| **No credentials anywhere** | every config | Instance profile supplies short-lived, auto-rotated keys |
| **Password from SSM at boot** | `user_data.sh.tftpl` | Never enters state, git, or the launch template |
| **Least-privilege IAM** | `iam.tf` | Policy is scoped to your exact bucket ARNs, not `*` |
| **Encryption always on** | `launch_template.tf` | Both EBS volumes, no way to turn it off |
| **Separate data volume** | `launch_template.tf` | A log burst cannot fill `/` and wedge the host |
| **Mount by UUID** | `user_data.sh.tftpl` | Nitro device names are not stable across reboots |
| **One user per service** | `user_data.sh.tftpl` | A Loki compromise cannot read Tempo's data |
| **systemd hardening** | `user_data.sh.tftpl` | `NoNewPrivileges`, `ProtectSystem`, `PrivateTmp` |
| **Pinned versions** | `variables.tf` | "latest" is not a version; rebuilds must be reproducible |
| **Ingestion limits set** | `mimir.yaml.tftpl` | One bad deploy fails loudly instead of OOM-ing the host |
| **Retention actually enforced** | `loki.yaml.tftpl` | `retention_enabled: true` — without it, limits are ignored |
| **Tags on volumes and ENIs** | `launch_template.tf` | Untagged EBS is the #1 source of unattributable spend |
| **Phone-home disabled** | all configs | No usage analytics leaving your VPC |

### Things you should still add yourself

1. **Put an internal ALB in front of Grafana** with ACM TLS and OIDC authentication. Set `target_group_arns` and `asg_health_check_type = "ELB"`.
2. **Create an S3 Gateway VPC Endpoint.** It is free and it keeps all your S3 traffic off the NAT Gateway — which otherwise charges you ~$0.045/GB for every block Mimir uploads. This is often the single largest hidden cost of running this stack.
3. **Add S3 lifecycle rules** to abort incomplete multipart uploads after 7 days.
4. **Set up alerting** on the stack itself: if Mimir stops ingesting, nothing else will tell you.
5. **Bake a golden AMI** with the binaries pre-installed once you are past experimenting. Boot time drops from 8 minutes to under 60 seconds, and you no longer need internet egress at boot.

---

## Part 7 — Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| A service is `failed` in the boot summary | Bad config or missing S3 permission | `sudo journalctl -u mimir -n 100 --no-pager` |
| `AccessDenied` writing to S3 | Bucket uses SSE-KMS but `s3_sse_kms_key_arn` is empty | Set it — the error message will **not** mention KMS |
| Grafana shows "no data" | Alloy is not sending, or is sending to the wrong place | Open the Alloy UI on :12345 — it draws the live pipeline with sample counts |
| Traces arrive, logs do not correlate | Log lines have no trace ID | Your app must log the trace ID; the regex in the Loki data source looks for `trace_id=<32 hex chars>` |
| Boot script never finishes | No internet egress for GitHub / `rpm.grafana.com` | Check NAT Gateway, or bake a golden AMI |
| ASG keeps replacing the instance | `health_check_grace_period` too short | It is 600s here; raise it if you added a lot to `extra_user_data_script` |
| `terraform plan` says subnet is in the wrong VPC | Copy-paste error in tfvars | The postcondition in `data.tf` tells you which subnet |

Useful commands:

```bash
make plan          # terraform plan
make apply         # terraform apply
make endpoints     # print every URL
make logs          # tail the boot log via Session Manager
make grafana       # port-forward Grafana to localhost:3000
```

---

## Part 8 — Rolling back

Launch templates are **versioned**. Every `terraform apply` that changes anything creates a new version rather than overwriting the old one.

```bash
# See every version
aws ec2 describe-launch-template-versions \
  --launch-template-id lt-0abc123 \
  --query 'LaunchTemplateVersions[].[VersionNumber,CreateTime,VersionDescription]' \
  --output table

# Roll the ASG back to version 3
aws autoscaling update-auto-scaling-group \
  --auto-scaling-group-name obs-prod-asg-xxxx \
  --launch-template LaunchTemplateId=lt-0abc123,Version=3

# Replace the running instance with one built from version 3
aws autoscaling start-instance-refresh \
  --auto-scaling-group-name obs-prod-asg-xxxx
```

Your data is untouched by any of this — it lives in S3.

---

## A note on versions

The component versions pinned in `variables.tf` were current as of early 2026. Grafana Labs releases frequently. Before deploying to production, check the current releases and read the changelogs, especially for Loki (schema changes need planning) and Mimir (config format occasionally shifts between minor versions):

- https://github.com/grafana/mimir/releases
- https://github.com/grafana/loki/releases
- https://github.com/grafana/tempo/releases
- https://github.com/grafana/alloy/releases
- https://github.com/grafana/grafana/releases

Terraform's `plan` output is your friend — always read it before typing `yes`.
