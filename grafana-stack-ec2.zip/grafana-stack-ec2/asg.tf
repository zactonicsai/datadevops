###############################################################################
# asg.tf
# -----------------------------------------------------------------------------
# PURPOSE
#   OPTIONAL. A launch template is only a recipe - it launches nothing.
#   Setting create_autoscaling_group = true adds a small Auto Scaling Group
#   that keeps exactly one healthy observability host alive and rebuilds it
#   automatically if the instance or the AZ fails.
#
# WHY AN ASG FOR A SINGLE INSTANCE?
#   Self-healing. If the host dies at 3am, the ASG replaces it, the boot script
#   reinstalls everything, and the new host picks the data back up from S3.
#   You get most of the benefit of a cluster with none of the complexity.
#
# WHY max_size SHOULD STAY AT 1
#   These components are running in monolithic mode with an in-memory hash
#   ring. Two instances would NOT form a cluster - they would each hold half
#   your recent data with no idea the other exists. To scale out properly you
#   move to microservices mode with memberlist gossip, which is a different
#   (Kubernetes-shaped) deployment.
###############################################################################


resource "aws_autoscaling_group" "this" {
  count = var.create_autoscaling_group ? 1 : 0

  name_prefix = "${local.name}-asg-"

  # Which subnets instances may be placed in. The ASG picks one per launch and
  # balances across AZs. This is why the launch template must NOT also specify
  # a subnet - see the long comment in launch_template.tf.
  vpc_zone_identifier = var.subnet_ids

  min_size         = var.asg_min_size
  max_size         = var.asg_max_size
  desired_capacity = var.asg_desired_capacity

  # --- Which recipe to launch ------------------------------------------------
  launch_template {
    id = aws_launch_template.this.id
    # "$Latest" always uses the newest version, so a terraform apply that
    # changes user_data takes effect on the next instance replacement.
    # Use "$Default" instead if you want to promote versions deliberately.
    version = "$Latest"
  }

  # --- Health checking -------------------------------------------------------
  # "EC2"  = only asks the hypervisor whether the VM is running.
  # "ELB"  = also asks the load balancer whether Grafana returns HTTP 200.
  #          Much better, because a hung Grafana on a healthy VM is invisible
  #          to EC2 health checks.
  health_check_type = var.asg_health_check_type

  # Grace period before health checks start counting. The boot script installs
  # five services and downloads several hundred MB, so give it real time. Too
  # short a grace period causes an infinite loop of terminate-and-relaunch.
  health_check_grace_period = 600

  # --- Load balancer registration -------------------------------------------
  # ARNs of EXISTING target groups. Point an internal ALB at Grafana this way
  # and you get TLS termination, OIDC auth and a stable DNS name for free.
  target_group_arns = var.target_group_arns

  # --- Rolling replacement on template change --------------------------------
  instance_refresh {
    strategy = "Rolling"
    preferences {
      # 0% means: terminate the old instance FIRST, then launch the new one.
      # Correct for a single stateful node - two instances would fight over
      # the same S3 prefixes and the same target group.
      min_healthy_percentage = 0
      instance_warmup        = 600
    }
    # Only refresh when these actually change, not on every apply.
    triggers = ["launch_template"]
  }

  # --- Termination behaviour -------------------------------------------------
  # Kill the oldest instance first so a refresh converges predictably.
  termination_policies = ["OldestInstance"]

  # Wait for instances to reach "InService" before apply returns. Combined with
  # ELB health checks this means `terraform apply` fails if the stack does not
  # actually come up - which is what you want in CI.
  wait_for_capacity_timeout = "15m"

  # --- Tags ------------------------------------------------------------------
  # ASG tags are a different shape from normal tags: each needs
  # propagate_at_launch, which decides whether launched instances inherit it.
  dynamic "tag" {
    for_each = merge(var.tags, { Name = "${local.name}-observability" })
    content {
      key                 = tag.key
      value               = tag.value
      propagate_at_launch = true
    }
  }

  lifecycle {
    create_before_destroy = true

    precondition {
      condition     = length(var.subnet_ids) >= 1
      error_message = "create_autoscaling_group requires at least one subnet; two in different AZs is strongly recommended."
    }

    precondition {
      condition     = !(var.asg_health_check_type == "ELB" && length(var.target_group_arns) == 0)
      error_message = "asg_health_check_type = \"ELB\" requires at least one target group ARN in target_group_arns."
    }
  }
}
