###############################################################################
# providers.tf
# -----------------------------------------------------------------------------
# PURPOSE
#   Configures the AWS provider: which region to talk to, and which tags to
#   stamp on to every single resource this module creates.
#
# CREDENTIALS
#   This file deliberately contains NO access keys. Terraform picks up
#   credentials in this order:
#     1. Environment variables (AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY)
#     2. The shared config file (~/.aws/credentials, selected with AWS_PROFILE)
#     3. An IAM role attached to the machine running Terraform (best practice
#        in CI/CD pipelines - no long-lived keys to leak).
###############################################################################

provider "aws" {
  # Region comes from the tfvars file so the same code can be deployed to
  # us-east-1, eu-west-1, etc. without editing any .tf file.
  region = var.aws_region

  # `default_tags` is applied automatically to every taggable resource created
  # by this provider. This is much safer than remembering to add tags to each
  # resource by hand - untagged resources are the #1 cause of cost sprawl.
  default_tags {
    tags = var.tags
  }
}
