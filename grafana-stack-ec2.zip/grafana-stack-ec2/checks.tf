###############################################################################
# checks.tf
# -----------------------------------------------------------------------------
# PURPOSE
#   `check` blocks (Terraform 1.5+) run assertions during plan and apply.
#   Unlike a precondition, a FAILED CHECK IS A WARNING, NOT AN ERROR - it does
#   not block the apply. That makes them perfect for "this is probably wrong,
#   look at it" situations where a hard failure would be too aggressive.
#
#   Everything here is a guard rail learned from a real production mistake.
###############################################################################


# -----------------------------------------------------------------------------
# CHECK 1 - user_data size
# EC2 rejects user data over 16,384 bytes in raw form. Because the launch
# template gzips it first, the real ceiling is much higher, but if the RAW
# script is already near 16 KB you are one config change away from surprises
# on any tool that does not gzip.
# -----------------------------------------------------------------------------
check "user_data_size" {
  assert {
    condition     = length(local.user_data) < 60000
    error_message = "The rendered boot script is ${length(local.user_data)} bytes. It is gzipped before upload so this still fits, but consider baking the binaries into a golden AMI or fetching configs from S3 instead of embedding them."
  }
}


# -----------------------------------------------------------------------------
# CHECK 2 - do not expose observability to the whole internet
# Grafana's login page, an unauthenticated Loki push endpoint and an open OTLP
# receiver on 0.0.0.0/0 is a genuinely bad day waiting to happen.
# -----------------------------------------------------------------------------
check "no_public_ingress" {
  assert {
    condition     = !contains(var.ingress_cidr_blocks, "0.0.0.0/0")
    error_message = "ingress_cidr_blocks contains 0.0.0.0/0. Loki's push API and the OTLP receivers have NO authentication. Restrict this to your VPC CIDR or your VPN range and front Grafana with an internal ALB."
  }
}

check "no_public_ip" {
  assert {
    condition     = var.associate_public_ip_address == false
    error_message = "associate_public_ip_address is true. Prefer a private subnet plus an internal load balancer or SSM Session Manager."
  }
}


# -----------------------------------------------------------------------------
# CHECK 3 - do not run with the default Grafana password
# -----------------------------------------------------------------------------
check "grafana_password_is_managed" {
  assert {
    condition     = !var.install_grafana || var.grafana_admin_password_ssm_parameter != ""
    error_message = "Grafana will start with the default admin/admin credentials. Create an SSM SecureString parameter and set grafana_admin_password_ssm_parameter."
  }
}


# -----------------------------------------------------------------------------
# CHECK 4 - single AZ is a single point of failure
# -----------------------------------------------------------------------------
check "multi_az_subnets" {
  assert {
    condition     = !var.create_autoscaling_group || length(distinct([for s in data.aws_subnet.selected : s.availability_zone])) >= 2
    error_message = "All supplied subnets are in one Availability Zone. If that AZ has an outage the ASG cannot relaunch the host anywhere. Add a subnet in a second AZ."
  }
}


# -----------------------------------------------------------------------------
# CHECK 5 - Mimir and AMP both configured
# Not fatal (you might be migrating), but it means you are paying for storage
# twice and only one of them is receiving data.
# -----------------------------------------------------------------------------
check "not_both_mimir_and_amp" {
  assert {
    condition     = !(var.install_mimir && local.use_amp)
    error_message = "Both install_mimir and amp_workspace_id are set. Alloy will write to AMP, so the local Mimir will run and cost money while receiving nothing. Pick one, unless you are mid-migration."
  }
}


# -----------------------------------------------------------------------------
# CHECK 6 - retention windows that will surprise the finance team
# Logs are almost always the largest line item. 90 days of unsampled EKS logs
# is a lot of S3.
# -----------------------------------------------------------------------------
check "log_retention_sanity" {
  assert {
    # `can()` swallows the error if someone writes "30d" instead of "720h",
    # so a non-hour format produces no warning rather than a crash.
    condition = !var.install_loki || !can(tonumber(replace(var.logs_retention_period, "h", ""))) || tonumber(replace(var.logs_retention_period, "h", "")) <= 2160
    error_message = "logs_retention_period is longer than 90 days (2160h). Confirm this is intentional - logs are usually the biggest storage cost. Consider an S3 lifecycle rule to Glacier Instant Retrieval instead of long Loki retention."
  }
}


# -----------------------------------------------------------------------------
# CHECK 7 - data volume disabled
# Without a separate volume, the WAL competes with the OS for the root disk and
# a log burst can fill / and wedge the whole host.
# -----------------------------------------------------------------------------
check "data_volume_present" {
  assert {
    condition     = var.data_volume_enabled || var.root_volume_size_gb >= 100
    error_message = "data_volume_enabled is false and the root volume is small. Write-ahead logs and un-flushed chunks will land on the root disk and can fill it. Enable the data volume or raise root_volume_size_gb."
  }
}
