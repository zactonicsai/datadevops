###############################################################################
# data.tf
# -----------------------------------------------------------------------------
# PURPOSE
#   `data` blocks READ existing infrastructure. They never create, change or
#   destroy anything. Every one below exists so the module can (a) confirm the
#   resource you named really exists, and (b) pull its ARN for IAM policies.
#
#   If you typo a bucket name in tfvars, `terraform plan` fails here with a
#   clear message instead of the instance booting and silently failing later.
###############################################################################


# -----------------------------------------------------------------------------
# Who am I / where am I?
# Used to build ARNs by hand and to work correctly in GovCloud or China
# partitions, where the ARN prefix is aws-us-gov / aws-cn instead of aws.
# -----------------------------------------------------------------------------
data "aws_caller_identity" "current" {}

data "aws_partition" "current" {}

data "aws_region" "current" {}


# -----------------------------------------------------------------------------
# Existing VPC.
# Confirms the VPC exists and gives us its CIDR block, which the auto-created
# security group uses as a sane default source range.
# -----------------------------------------------------------------------------
data "aws_vpc" "selected" {
  id = var.vpc_id
}


# -----------------------------------------------------------------------------
# Existing subnets.
# `for_each` over the list turns it into a map so each lookup gets its own
# address in state. We mainly want the availability_zone for the outputs.
# -----------------------------------------------------------------------------
data "aws_subnet" "selected" {
  for_each = toset(var.subnet_ids)
  id       = each.value

  # A guard rail: fail loudly if someone passes a subnet from a different VPC.
  lifecycle {
    postcondition {
      condition     = self.vpc_id == var.vpc_id
      error_message = "Subnet ${self.id} belongs to VPC ${self.vpc_id}, not to the vpc_id you specified."
    }
  }
}


# -----------------------------------------------------------------------------
# Newest Amazon Linux 2023 AMI.
# `count` makes this conditional: it only runs when var.ami_id is empty.
# most_recent = true plus an owner filter of "amazon" is the standard safe way
# to always boot a patched image. Never filter by name alone without the owner
# filter - anyone can publish an AMI with a matching name.
# -----------------------------------------------------------------------------
data "aws_ami" "al2023" {
  count       = var.ami_id == "" ? 1 : 0
  most_recent = true
  owners      = ["amazon"]

  filter {
    name = "name"
    # al2023-ami-2023.*-kernel-6.1-arm64 (or -x86_64)
    values = ["al2023-ami-2023.*-kernel-6.1-${var.architecture}"]
  }

  filter {
    name   = "state"
    values = ["available"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}


# -----------------------------------------------------------------------------
# Existing S3 buckets.
# One conditional lookup per component. We need the bucket ARN so the IAM
# policy can be scoped to exactly these buckets and nothing else.
# -----------------------------------------------------------------------------
data "aws_s3_bucket" "mimir" {
  count  = var.install_mimir && var.mimir_bucket_name != "" ? 1 : 0
  bucket = var.mimir_bucket_name
}

data "aws_s3_bucket" "loki" {
  count  = var.install_loki && var.loki_bucket_name != "" ? 1 : 0
  bucket = var.loki_bucket_name
}

data "aws_s3_bucket" "tempo" {
  count  = var.install_tempo && var.tempo_bucket_name != "" ? 1 : 0
  bucket = var.tempo_bucket_name
}

data "aws_s3_bucket" "pyroscope" {
  count  = var.install_pyroscope && var.pyroscope_bucket_name != "" ? 1 : 0
  bucket = var.pyroscope_bucket_name
}


# -----------------------------------------------------------------------------
# Existing KMS keys.
# `aws_kms_key` accepts an ID, an alias or an ARN in key_id, so users can pass
# whichever form they have handy.
# -----------------------------------------------------------------------------
data "aws_kms_key" "ebs" {
  count  = var.ebs_kms_key_id != "" ? 1 : 0
  key_id = var.ebs_kms_key_id
}

data "aws_kms_key" "s3" {
  count  = var.s3_sse_kms_key_arn != "" ? 1 : 0
  key_id = var.s3_sse_kms_key_arn
}


# -----------------------------------------------------------------------------
# Existing IAM instance profile (only when the user supplied one).
# Looking it up proves the name is right before we bake it into the template.
# -----------------------------------------------------------------------------
data "aws_iam_instance_profile" "existing" {
  count = var.iam_instance_profile_name != "" ? 1 : 0
  name  = var.iam_instance_profile_name
}


# -----------------------------------------------------------------------------
# Existing Amazon Managed Prometheus workspace.
# NOTE: we read metadata only. We never read the password or any secret.
# -----------------------------------------------------------------------------
data "aws_prometheus_workspace" "amp" {
  count        = var.amp_workspace_id != "" ? 1 : 0
  workspace_id = var.amp_workspace_id
}


# -----------------------------------------------------------------------------
# Existing EKS cluster (metadata only, used for labelling and outputs).
# -----------------------------------------------------------------------------
data "aws_eks_cluster" "observed" {
  count = var.eks_cluster_name != "" ? 1 : 0
  name  = var.eks_cluster_name
}


# -----------------------------------------------------------------------------
# Existing CloudWatch log group.
# -----------------------------------------------------------------------------
data "aws_cloudwatch_log_group" "host" {
  count = var.cloudwatch_log_group_name != "" ? 1 : 0
  name  = var.cloudwatch_log_group_name
}


# -----------------------------------------------------------------------------
# IMPORTANT - what we deliberately DO NOT look up:
#   aws_ssm_parameter for the Grafana admin password.
#   Reading it here would copy the plaintext password into terraform.tfstate,
#   which is then sitting in an S3 bucket forever. Instead we pass only the
#   PARAMETER NAME to the instance, and the instance fetches the value at boot
#   using its IAM role.
# -----------------------------------------------------------------------------
