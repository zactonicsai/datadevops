###############################################################################
# locals.tf
# -----------------------------------------------------------------------------
# PURPOSE
#   `locals` are named expressions - like variables you compute rather than
#   type in. Putting the logic here keeps the resource blocks short and makes
#   the decisions ("did the user give me a profile or do I build one?")
#   readable in one place.
#
#   The second half renders every service's YAML config file from a template
#   and base64-encodes it, ready to be embedded in the boot script.
###############################################################################

locals {

  # ===========================================================================
  # 1 - NAMING
  # ===========================================================================

  # Every resource name starts with this.
  name = var.name_prefix

  # Convenience copies so ARNs can be built by string interpolation.
  partition  = data.aws_partition.current.partition
  account_id = data.aws_caller_identity.current.account_id
  region     = data.aws_region.current.name


  # ===========================================================================
  # 2 - "USE EXISTING OR CREATE?" DECISIONS
  # ---------------------------------------------------------------------------
  # Pattern: if the user named an existing resource, use it. Otherwise create
  # one. `create_*` booleans drive the `count` on the matching resource.
  # ===========================================================================

  # AMI: user-supplied wins, else the looked-up Amazon Linux 2023 image.
  # `one()` safely unwraps a count-based list that has 0 or 1 element.
  ami_id = var.ami_id != "" ? var.ami_id : one(data.aws_ami.al2023[*].id)

  # IAM: build a role only when no existing profile name was given.
  create_iam_role = var.iam_instance_profile_name == ""

  # The profile name that finally goes into the launch template.
  # `one()` is used instead of [0] because Terraform can evaluate BOTH sides of
  # a ternary; [0] on a zero-count resource would raise an index error.
  instance_profile_name = local.create_iam_role ? one(aws_iam_instance_profile.this[*].name) : var.iam_instance_profile_name

  # Security group: build one only when the user gave us no existing IDs.
  create_security_group = length(var.security_group_ids) == 0

  security_group_ids = local.create_security_group ? compact(aws_security_group.this[*].id) : var.security_group_ids

  # EBS KMS key: "" tells the AWS API "use the account default aws/ebs key".
  ebs_kms_key_arn = var.ebs_kms_key_id != "" ? one(data.aws_kms_key.ebs[*].arn) : null


  # ===========================================================================
  # 3 - AMP / METRICS ROUTING
  # ---------------------------------------------------------------------------
  # If an AMP workspace was supplied, Alloy writes there (SigV4-signed).
  # Otherwise it writes to the local Mimir on 127.0.0.1.
  # ===========================================================================

  use_amp = var.amp_workspace_id != ""

  # aws_prometheus_workspace exposes prometheus_endpoint, which already ends
  # in a "/", e.g. https://aps-workspaces.<region>.amazonaws.com/workspaces/ws-xxx/
  amp_endpoint = local.use_amp ? one(data.aws_prometheus_workspace.amp[*].prometheus_endpoint) : ""

  amp_remote_write_url = local.use_amp ? "${local.amp_endpoint}api/v1/remote_write" : ""
  amp_query_url        = local.use_amp ? local.amp_endpoint : ""

  # The single URL Alloy pushes metrics to.
  metrics_write_url = local.use_amp ? local.amp_remote_write_url : "http://127.0.0.1:${var.mimir_port}/api/v1/push"

  # The URL Grafana's Prometheus data source reads from.
  metrics_query_url = local.use_amp ? local.amp_query_url : "http://127.0.0.1:${var.mimir_port}/prometheus"


  # ===========================================================================
  # 4 - RENDERED SERVICE CONFIGURATION FILES
  # ---------------------------------------------------------------------------
  # `templatefile()` reads a file from templates/ and substitutes ${...}
  # placeholders with the map given as the second argument.
  #
  # Each is rendered only when its component is enabled, using the
  # `condition ? templatefile(...) : ""` pattern, so we never try to render a
  # Mimir config that references an empty bucket name.
  # ===========================================================================

  mimir_config = var.install_mimir ? templatefile("${path.module}/templates/mimir.yaml.tftpl", {
    http_port        = var.mimir_port
    bucket_name      = var.mimir_bucket_name
    bucket_prefix    = var.mimir_bucket_prefix
    region           = local.region
    retention_period = var.metrics_retention_period
    sse_kms_key_arn  = var.s3_sse_kms_key_arn
  }) : ""

  loki_config = var.install_loki ? templatefile("${path.module}/templates/loki.yaml.tftpl", {
    http_port        = var.loki_port
    bucket_name      = var.loki_bucket_name
    bucket_prefix    = var.loki_bucket_prefix
    region           = local.region
    retention_period = var.logs_retention_period
    sse_kms_key_arn  = var.s3_sse_kms_key_arn
  }) : ""

  tempo_config = var.install_tempo ? templatefile("${path.module}/templates/tempo.yaml.tftpl", {
    http_port         = var.tempo_http_port
    otlp_grpc_port    = var.tempo_otlp_grpc_port
    bucket_name       = var.tempo_bucket_name
    bucket_prefix     = var.tempo_bucket_prefix
    region            = local.region
    retention_period  = var.traces_retention_period
    metrics_write_url = "http://127.0.0.1:${var.mimir_port}/api/v1/push"
    generate_metrics  = var.install_mimir
  }) : ""

  pyroscope_config = var.install_pyroscope ? templatefile("${path.module}/templates/pyroscope.yaml.tftpl", {
    http_port     = var.pyroscope_port
    bucket_name   = var.pyroscope_bucket_name
    bucket_prefix = var.pyroscope_bucket_prefix
    region        = local.region
  }) : ""

  alloy_config = var.install_alloy ? templatefile("${path.module}/templates/alloy.river.tftpl", {
    metrics_write_url = local.metrics_write_url
    use_sigv4         = local.use_amp
    region            = local.region
    logs_write_url    = "http://127.0.0.1:${var.loki_port}/loki/api/v1/push"
    traces_write_url  = "127.0.0.1:${var.tempo_otlp_grpc_port}"
    otlp_grpc_port    = var.alloy_otlp_grpc_port
    otlp_http_port    = var.alloy_otlp_http_port
    install_loki      = var.install_loki
    install_tempo     = var.install_tempo
    cluster_name      = var.eks_cluster_name
  }) : ""

  grafana_datasources = var.install_grafana ? templatefile("${path.module}/templates/grafana-datasources.yaml.tftpl", {
    metrics_query_url = local.metrics_query_url
    use_sigv4         = local.use_amp
    region            = local.region
    loki_url          = "http://127.0.0.1:${var.loki_port}"
    tempo_url         = "http://127.0.0.1:${var.tempo_http_port}"
    pyroscope_url     = "http://127.0.0.1:${var.pyroscope_port}"
    install_loki      = var.install_loki
    install_tempo     = var.install_tempo
    install_pyroscope = var.install_pyroscope
    install_metrics   = var.install_mimir || local.use_amp
    enable_cloudwatch = var.enable_cloudwatch_datasource
    enable_xray       = var.enable_xray_datasource
    extra_yaml        = var.grafana_additional_datasources_yaml
  }) : ""


  # ===========================================================================
  # 5 - THE BOOT SCRIPT (user_data)
  # ---------------------------------------------------------------------------
  # Configs are base64-encoded and passed in as strings. The boot script
  # decodes them to /etc/<service>/. Doing it this way avoids the nightmare of
  # escaping YAML inside a bash heredoc inside a Terraform template.
  # ===========================================================================

  user_data = templatefile("${path.module}/templates/user_data.sh.tftpl", {
    # --- what to install ---
    install_grafana   = var.install_grafana
    install_mimir     = var.install_mimir
    install_loki      = var.install_loki
    install_tempo     = var.install_tempo
    install_pyroscope = var.install_pyroscope
    install_alloy     = var.install_alloy

    # --- versions ---
    grafana_version   = var.grafana_version
    mimir_version     = var.mimir_version
    loki_version      = var.loki_version
    tempo_version     = var.tempo_version
    pyroscope_version = var.pyroscope_version
    alloy_version     = var.alloy_version

    # Go binaries are published as linux-amd64 / linux-arm64.
    go_arch = var.architecture == "arm64" ? "arm64" : "amd64"

    # --- storage ---
    data_volume_enabled     = var.data_volume_enabled
    data_volume_device_name = var.data_volume_device_name

    # --- base64 configs ---
    mimir_config_b64        = base64encode(local.mimir_config)
    loki_config_b64         = base64encode(local.loki_config)
    tempo_config_b64        = base64encode(local.tempo_config)
    pyroscope_config_b64    = base64encode(local.pyroscope_config)
    alloy_config_b64        = base64encode(local.alloy_config)
    grafana_datasources_b64 = base64encode(local.grafana_datasources)

    # --- grafana ---
    grafana_port          = var.grafana_port
    grafana_root_url      = var.grafana_root_url
    grafana_admin_ssm_param = var.grafana_admin_password_ssm_parameter

    # --- aws context ---
    region                    = local.region
    cloudwatch_log_group_name = var.cloudwatch_log_group_name

    # --- escape hatch ---
    extra_user_data_script = var.extra_user_data_script
  })


  # ===========================================================================
  # 6 - IAM POLICY BUILDING BLOCKS
  # ---------------------------------------------------------------------------
  # Collect only the bucket ARNs that are actually in use, so the generated
  # policy is least-privilege by construction.
  # ===========================================================================

  s3_bucket_arns = compact([
    one(data.aws_s3_bucket.mimir[*].arn),
    one(data.aws_s3_bucket.loki[*].arn),
    one(data.aws_s3_bucket.tempo[*].arn),
    one(data.aws_s3_bucket.pyroscope[*].arn),
  ])

  # Object-level ARNs need the /* suffix. Bucket-level actions (ListBucket)
  # need the bare ARN. They are two different resource formats.
  s3_object_arns = [for arn in local.s3_bucket_arns : "${arn}/*"]

  # ARN of the SSM parameter holding the Grafana password, built by hand
  # because we never read the parameter itself.
  grafana_ssm_param_arn = var.grafana_admin_password_ssm_parameter != "" ? format(
    "arn:%s:ssm:%s:%s:parameter/%s",
    local.partition,
    local.region,
    local.account_id,
    # SSM parameter names start with "/" but the ARN must not double it up.
    trimprefix(var.grafana_admin_password_ssm_parameter, "/")
  ) : ""
}
