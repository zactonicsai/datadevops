###############################################################################
# iam.tf
# -----------------------------------------------------------------------------
# PURPOSE
#   Gives the EC2 instance permission to do its job WITHOUT any access keys on
#   disk. The instance assumes a role through its instance profile and gets
#   short-lived, automatically-rotated credentials from the metadata service.
#
#   EVERYTHING in this file is conditional on `local.create_iam_role`, which is
#   true only when you left iam_instance_profile_name empty in tfvars. If you
#   supplied an existing profile, none of these resources are created.
#
#   Least privilege is enforced by scoping each statement to the exact ARNs
#   built in locals.tf - not to "*".
###############################################################################


# -----------------------------------------------------------------------------
# TRUST POLICY (a.k.a. assume-role policy)
# Answers the question "WHO is allowed to become this role?"
# Answer: the EC2 service, on behalf of instances that carry the profile.
# -----------------------------------------------------------------------------
data "aws_iam_policy_document" "assume_role" {
  count = local.create_iam_role ? 1 : 0

  statement {
    sid     = "EC2AssumeRole"
    effect  = "Allow"
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}


# -----------------------------------------------------------------------------
# THE ROLE ITSELF
# -----------------------------------------------------------------------------
resource "aws_iam_role" "this" {
  count = local.create_iam_role ? 1 : 0

  name               = "${local.name}-role"
  description        = "Role for the Grafana LGTM observability host"
  assume_role_policy = data.aws_iam_policy_document.assume_role[0].json

  # Belt and braces: even if a policy is attached later that grants more, this
  # boundary caps what the role can ever do. Left null by default because
  # boundaries are org-specific; set one if your account requires it.
  permissions_boundary = null

  tags = merge(var.tags, { Name = "${local.name}-role" })
}


# -----------------------------------------------------------------------------
# PERMISSION POLICY - built statement by statement.
# `dynamic` blocks let a statement disappear entirely when it is not needed,
# which keeps the policy small (IAM policies have a 6,144 character limit).
# -----------------------------------------------------------------------------
data "aws_iam_policy_document" "instance" {
  count = local.create_iam_role ? 1 : 0

  # --- S3 bucket-level: list objects so components can discover blocks ------
  dynamic "statement" {
    # `for_each` over a list with 0 or 1 element = conditional statement.
    for_each = length(local.s3_bucket_arns) > 0 ? [1] : []
    content {
      sid    = "S3BucketLevel"
      effect = "Allow"
      actions = [
        "s3:ListBucket",           # enumerate keys (compactor, index lookups)
        "s3:GetBucketLocation",    # SDK region discovery
        "s3:ListBucketMultipartUploads",
      ]
      resources = local.s3_bucket_arns
    }
  }

  # --- S3 object-level: read/write/delete the actual blocks and chunks ------
  dynamic "statement" {
    for_each = length(local.s3_object_arns) > 0 ? [1] : []
    content {
      sid    = "S3ObjectLevel"
      effect = "Allow"
      actions = [
        "s3:GetObject",            # queriers read blocks
        "s3:PutObject",            # ingesters flush blocks
        "s3:DeleteObject",         # compactor removes expired blocks
        "s3:AbortMultipartUpload", # clean up failed large uploads
        "s3:ListMultipartUploadParts",
      ]
      resources = local.s3_object_arns
    }
  }

  # --- KMS: only when the buckets use SSE-KMS ------------------------------
  # Without these four actions, PutObject to an SSE-KMS bucket returns
  # AccessDenied and the error message does NOT mention KMS. Classic trap.
  dynamic "statement" {
    for_each = var.s3_sse_kms_key_arn != "" ? [1] : []
    content {
      sid    = "S3KmsAccess"
      effect = "Allow"
      actions = [
        "kms:Encrypt",
        "kms:Decrypt",
        "kms:ReEncrypt*",
        "kms:GenerateDataKey*",
        "kms:DescribeKey",
      ]
      resources = [var.s3_sse_kms_key_arn]
    }
  }

  # --- Amazon Managed Service for Prometheus -------------------------------
  dynamic "statement" {
    for_each = local.use_amp ? [1] : []
    content {
      sid    = "AmpReadWrite"
      effect = "Allow"
      actions = [
        "aps:RemoteWrite",    # Alloy pushes metrics
        "aps:QueryMetrics",   # Grafana reads them back
        "aps:GetSeries",
        "aps:GetLabels",
        "aps:GetMetricMetadata",
      ]
      resources = [one(data.aws_prometheus_workspace.amp[*].arn)]
    }
  }

  # --- SSM Parameter Store: fetch the Grafana admin password at boot -------
  dynamic "statement" {
    for_each = local.grafana_ssm_param_arn != "" ? [1] : []
    content {
      sid       = "ReadGrafanaAdminPassword"
      effect    = "Allow"
      actions   = ["ssm:GetParameter"]
      resources = [local.grafana_ssm_param_arn]
    }
  }

  # Decrypting a SecureString parameter needs KMS on the key that encrypted it.
  # alias/aws/ssm is the default; scoping by ViaService is the safe way to
  # allow the AWS-managed key without naming its rotating key id.
  dynamic "statement" {
    for_each = local.grafana_ssm_param_arn != "" ? [1] : []
    content {
      sid       = "DecryptSsmSecureString"
      effect    = "Allow"
      actions   = ["kms:Decrypt"]
      resources = ["*"]
      condition {
        test     = "StringEquals"
        variable = "kms:ViaService"
        values   = ["ssm.${local.region}.amazonaws.com"]
      }
    }
  }

  # --- CloudWatch data source (read AWS service metrics into Grafana) ------
  dynamic "statement" {
    for_each = var.enable_cloudwatch_datasource ? [1] : []
    content {
      sid    = "CloudWatchRead"
      effect = "Allow"
      actions = [
        "cloudwatch:DescribeAlarmsForMetric",
        "cloudwatch:DescribeAlarmHistory",
        "cloudwatch:DescribeAlarms",
        "cloudwatch:ListMetrics",
        "cloudwatch:GetMetricData",       # the efficient batch API Grafana uses
        "cloudwatch:GetMetricStatistics",
        "cloudwatch:GetInsightRuleReport",
        "logs:DescribeLogGroups",
        "logs:GetLogGroupFields",
        "logs:StartQuery",                # CloudWatch Logs Insights
        "logs:StopQuery",
        "logs:GetQueryResults",
        "logs:GetLogEvents",
        "ec2:DescribeTags",               # used to resolve dimension values
        "ec2:DescribeInstances",
        "ec2:DescribeRegions",
        "tag:GetResources",
      ]
      # These are all read-only, account-wide describe calls that do not accept
      # resource-level restriction, so "*" is unavoidable here.
      resources = ["*"]
    }
  }

  # --- X-Ray data source ---------------------------------------------------
  dynamic "statement" {
    for_each = var.enable_xray_datasource ? [1] : []
    content {
      sid    = "XRayRead"
      effect = "Allow"
      actions = [
        "xray:BatchGetTraces",
        "xray:GetServiceGraph",
        "xray:GetTraceGraph",
        "xray:GetTraceSummaries",
        "xray:GetGroups",
        "xray:GetTimeSeriesServiceStatistics",
        "xray:GetInsightSummaries",
        "xray:GetInsight",
      ]
      resources = ["*"]
    }
  }

  # --- Ship this host's own logs to an existing CloudWatch log group -------
  dynamic "statement" {
    for_each = var.cloudwatch_log_group_name != "" ? [1] : []
    content {
      sid    = "WriteHostLogs"
      effect = "Allow"
      actions = [
        "logs:CreateLogStream",
        "logs:PutLogEvents",
        "logs:DescribeLogStreams",
      ]
      resources = [
        one(data.aws_cloudwatch_log_group.host[*].arn),
        "${one(data.aws_cloudwatch_log_group.host[*].arn)}:*",
      ]
    }
  }

  # --- EC2 describe for Alloy's service discovery --------------------------
  statement {
    sid    = "Ec2DiscoveryRead"
    effect = "Allow"
    actions = [
      "ec2:DescribeInstances",
      "ec2:DescribeAvailabilityZones",
    ]
    resources = ["*"]
  }
}


# -----------------------------------------------------------------------------
# Attach the generated policy to the role.
# `inline` (aws_iam_role_policy) is used rather than a managed policy because
# it cannot be accidentally attached to another principal.
# -----------------------------------------------------------------------------
resource "aws_iam_role_policy" "this" {
  count = local.create_iam_role ? 1 : 0

  name   = "${local.name}-policy"
  role   = aws_iam_role.this[0].id
  policy = data.aws_iam_policy_document.instance[0].json
}


# -----------------------------------------------------------------------------
# AWS-managed policy for Systems Manager Session Manager.
# This is what lets you get a shell on the box with:
#     aws ssm start-session --target i-0123...
# ...with no SSH key, no port 22 and a full CloudTrail audit record.
# -----------------------------------------------------------------------------
resource "aws_iam_role_policy_attachment" "ssm_core" {
  count = local.create_iam_role ? 1 : 0

  role       = aws_iam_role.this[0].name
  policy_arn = "arn:${local.partition}:iam::aws:policy/AmazonSSMManagedInstanceCore"
}


# -----------------------------------------------------------------------------
# AWS-managed policy for the CloudWatch agent (metrics + log shipping).
# Only attached when a log group was supplied.
# -----------------------------------------------------------------------------
resource "aws_iam_role_policy_attachment" "cw_agent" {
  count = local.create_iam_role && var.cloudwatch_log_group_name != "" ? 1 : 0

  role       = aws_iam_role.this[0].name
  policy_arn = "arn:${local.partition}:iam::aws:policy/CloudWatchAgentServerPolicy"
}


# -----------------------------------------------------------------------------
# INSTANCE PROFILE
# An instance profile is just a container that lets an EC2 instance wear a
# role. You cannot attach a role to an instance directly.
# -----------------------------------------------------------------------------
resource "aws_iam_instance_profile" "this" {
  count = local.create_iam_role ? 1 : 0

  name = "${local.name}-profile"
  role = aws_iam_role.this[0].name

  tags = merge(var.tags, { Name = "${local.name}-profile" })

  # Creating a profile and immediately launching an instance with it can race
  # against IAM's eventual consistency. Terraform normally handles this, but
  # create_before_destroy keeps replacements clean.
  lifecycle {
    create_before_destroy = true
  }
}
