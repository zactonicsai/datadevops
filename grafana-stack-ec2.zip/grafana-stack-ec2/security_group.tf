###############################################################################
# security_group.tf
# -----------------------------------------------------------------------------
# PURPOSE
#   A security group is a stateful virtual firewall around the instance.
#   "Stateful" means you only write the inbound rule - the reply traffic is
#   allowed automatically.
#
#   This whole file is skipped when you supply security_group_ids in tfvars.
#   Supplying your own is the production-grade choice; this generated one
#   exists so the module works out of the box in a lab account.
###############################################################################


resource "aws_security_group" "this" {
  count = local.create_security_group ? 1 : 0

  # `name_prefix` (not `name`) lets Terraform create the replacement SG before
  # deleting the old one, avoiding a "resource in use" failure on updates.
  name_prefix = "${local.name}-sg-"
  description = "Grafana LGTM observability stack - ingest and query ports"
  vpc_id      = var.vpc_id

  tags = merge(var.tags, { Name = "${local.name}-sg" })

  lifecycle {
    create_before_destroy = true
  }
}


# -----------------------------------------------------------------------------
# INGRESS RULES
# -----------------------------------------------------------------------------
# Written as individual `aws_vpc_security_group_ingress_rule` resources rather
# than inline `ingress {}` blocks. This is the modern approach: each rule gets
# its own ID, so changing one rule does not churn the others, and each rule can
# carry its own description that shows up in the console.
#
# `local.ingress_rules` is a map so `for_each` gives stable addresses. If you
# reorder the list nothing is recreated.
# -----------------------------------------------------------------------------

locals {
  # Fall back to the VPC's own CIDR if the user did not narrow it down.
  # That means "anything inside this VPC can reach the stack", which is a
  # reasonable default and is never internet-open.
  effective_ingress_cidrs = length(var.ingress_cidr_blocks) > 0 ? var.ingress_cidr_blocks : [data.aws_vpc.selected.cidr_block]

  # Build the rule set from the ports that are actually in use.
  # merge() of conditional maps: a disabled component contributes {}.
  ingress_rules = merge(
    var.install_grafana ? {
      grafana = { port = var.grafana_port, description = "Grafana web UI" }
    } : {},
    var.install_mimir ? {
      mimir = { port = var.mimir_port, description = "Mimir HTTP - push and PromQL" }
    } : {},
    var.install_loki ? {
      loki = { port = var.loki_port, description = "Loki HTTP - push and LogQL" }
    } : {},
    var.install_tempo ? {
      tempo_http = { port = var.tempo_http_port, description = "Tempo HTTP - TraceQL queries" }
    } : {},
    var.install_pyroscope ? {
      pyroscope = { port = var.pyroscope_port, description = "Pyroscope HTTP - profiles" }
    } : {},
    var.install_alloy ? {
      alloy_otlp_grpc = { port = var.alloy_otlp_grpc_port, description = "OTLP gRPC ingest from EKS workloads" }
      alloy_otlp_http = { port = var.alloy_otlp_http_port, description = "OTLP HTTP ingest from EKS workloads" }
      alloy_ui        = { port = var.alloy_http_port, description = "Alloy UI and self-metrics" }
    } : {},
    # SSH only when an EC2 key pair was supplied. With Session Manager you
    # never need this.
    var.key_name != "" ? {
      ssh = { port = 22, description = "SSH (prefer SSM Session Manager instead)" }
    } : {},
  )

  # Cross-product of every rule and every allowed CIDR, flattened into one map.
  # Key looks like "grafana|10.0.0.0/16" so it stays unique and readable.
  ingress_rule_cidr_pairs = {
    for pair in flatten([
      for rule_key, rule in local.ingress_rules : [
        for cidr in local.effective_ingress_cidrs : {
          key         = "${rule_key}|${cidr}"
          port        = rule.port
          description = rule.description
          cidr        = cidr
        }
      ]
    ]) : pair.key => pair
  }
}


resource "aws_vpc_security_group_ingress_rule" "this" {
  # Only create rules when we own the security group.
  for_each = local.create_security_group ? local.ingress_rule_cidr_pairs : {}

  security_group_id = aws_security_group.this[0].id
  description       = each.value.description
  cidr_ipv4         = each.value.cidr
  ip_protocol       = "tcp"
  from_port         = each.value.port
  to_port           = each.value.port

  tags = merge(var.tags, { Name = "${local.name}-in-${each.key}" })
}


# -----------------------------------------------------------------------------
# EGRESS RULE
# -----------------------------------------------------------------------------
# The host must reach out to:
#   * S3            (block storage - use a Gateway VPC Endpoint, it is free)
#   * SSM / KMS     (fetch the admin password, Session Manager)
#   * CloudWatch    (metrics and logs)
#   * github.com and the Grafana RPM repo, AT BOOT ONLY, to download binaries
#
# Allowing all egress is the pragmatic default. To lock it down, replace this
# with rules referencing your VPC endpoints' prefix lists and pre-bake the
# binaries into a golden AMI so no internet egress is needed at all.
# -----------------------------------------------------------------------------
resource "aws_vpc_security_group_egress_rule" "all" {
  count = local.create_security_group ? 1 : 0

  security_group_id = aws_security_group.this[0].id
  description       = "Allow all outbound (S3, SSM, KMS, package downloads)"
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1" # -1 means every protocol and every port

  tags = merge(var.tags, { Name = "${local.name}-egress-all" })
}
