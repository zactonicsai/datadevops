###############################################################################
# versions.tf
# -----------------------------------------------------------------------------
# PURPOSE
#   Pins the Terraform CLI version and the provider plugin versions.
#   Pinning is a best practice: it stops a future provider release from
#   silently changing how your infrastructure is built.
###############################################################################

terraform {
  # Minimum Terraform CLI version.
  # 1.5 is required because this module uses `check` blocks and
  # `lifecycle { precondition }`, which were added in 1.5.
  required_version = ">= 1.5.0"

  required_providers {
    # The AWS provider talks to the AWS APIs.
    aws = {
      source = "hashicorp/aws"
      # "~> 5.60" means: any 5.x release at or above 5.60, but never 6.0.
      # Major versions of the AWS provider contain breaking changes.
      version = "~> 5.60"
    }
  }
}
