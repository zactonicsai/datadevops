# Architecture

## 1. The request path (example 1: EC2 + ASG)

```
        user browser
             |  https://sso.example.com
             v
   +---------------------------+   TLS terminates here (ACM certificate)
   |  Application Load Balancer|   public subnets, 2-3 AZs
   +---------------------------+
             |  http :8080          health check -> :9000 /health/ready
             v
   +---------------------------+
   |  Auto Scaling group       |   private subnets
   |  Keycloak node 1 .. n     |<--> JGroups :7800 (Infinispan cache)
   +---------------------------+
             |  postgres :5432 (TLS enforced)
             v
   +---------------------------+
   |  Aurora PostgreSQL        |   isolated database subnets, no internet route
   |  writer + reader          |
   +---------------------------+
```

Two ports matter on every Keycloak node:

| Port | Purpose | Who may reach it |
|---|---|---|
| 8080 | Application traffic (HTTP inside the VPC) | The ALB only |
| 9000 | Management: `/health/live`, `/health/ready`, `/metrics` | The ALB health check and your monitoring only — never the internet |
| 7800 | JGroups cluster traffic | Other Keycloak nodes only |

## 2. The request path (example 2: EKS)

```
   user browser -> ALB (created by the AWS Load Balancer Controller
                        from the Ingress object, target-type: ip)
                -> Keycloak pods :8080   (StatefulSet, spread across AZs)
                -> Aurora PostgreSQL :5432
```

The controller watches Ingress objects and builds the ALB for you, so the load
balancer configuration lives in annotations instead of Terraform `aws_lb`
resources.

## 3. State: what lives where

| Data | Where it lives | Survives a node dying? |
|---|---|---|
| Users, realms, clients, roles | Aurora PostgreSQL | Yes |
| Active login sessions | Infinispan distributed cache in memory, replicated to other nodes | Yes, if 2+ nodes are up |
| Authentication sessions (mid-login) | Same cache | Yes |
| Realm/keys cache | Local memory, rebuilt on demand | Yes |

Because sessions live in memory and not in the database, **losing every node at
once logs everyone out.** That is the reason for at least 2 (ideally 3) nodes
across different AZs, and for a conservative scale-in policy.

## 4. Cluster discovery: how nodes find each other

| Method | Used in | How it works | Trade-off |
|---|---|---|---|
| `jdbc-ping` | Example 1 (EC2) | Each node writes its address to a table in the shared database and reads the others | Simple, zero extra infra, needs Keycloak 26.2+. A little database chatter. |
| `kubernetes` (DNS_PING) | Example 2 (EKS) | Nodes resolve a headless service's DNS A records to find pod IPs | Idiomatic on Kubernetes, no database traffic. Kubernetes only. |
| `TCPPING` (static list) | Neither | Hard-coded IP list | Breaks the moment autoscaling changes the fleet. Avoid. |
| Multicast (`UDP`) | Neither | Broadcast discovery | **Does not work on AWS at all.** VPCs do not forward multicast. |

## 5. Failure modes and what happens

| Failure | Result | Why |
|---|---|---|
| One Keycloak node dies | Users on it are re-routed; sessions survive | Cache is replicated to other nodes; ALB health check pulls the node out |
| One AZ fails | Service continues on the remaining AZs | Nodes and database instances span AZs |
| Aurora writer fails | ~30–60 s of errors, then automatic failover to a reader | Aurora promotes a reader; Keycloak reconnects |
| All Keycloak nodes restart | Everyone must log in again; no data lost | Sessions are in memory only |
| Certificate expires | Total outage | ACM auto-renews, but only if the DNS validation record still exists — do not delete it |
| `KC_HOSTNAME` wrong | Redirect loops, "invalid redirect_uri", broken discovery | Tokens and redirects are built from that value |

## 6. Sticky sessions: why they are on

Any node can serve any user, because the cache is distributed. But the node
that *owns* a session entry answers fastest; other nodes must fetch it over the
network. Sticky sessions (`lb_cookie`) keep a user on one node, which cuts
cross-node traffic noticeably on busy realms. If the node disappears, the user
lands elsewhere and the session is still found. It is an optimisation, not a
correctness requirement.

## 7. Separating the admin console

Production setups usually publish two hostnames:

* `sso.example.com` — end-user login, open to the world.
* `sso-admin.example.com` — the admin console, restricted to the office/VPN CIDR.

That is what `KC_HOSTNAME_ADMIN` and the `admin_hostname` variable do. If you
do not use a second hostname, example 1 adds an ALB listener rule that returns
404 for `/admin*` when the ALB is open to `0.0.0.0/0` — a blunt but effective
safeguard you should replace with a proper CIDR restriction.
