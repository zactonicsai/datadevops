# GitLab CI/CD pipeline

## 1. What the pipeline does

```
merge request      ->  fmt  |  validate  |  checkov  ->  plan:dev
merge to main      ->  fmt  |  validate             ->  plan:dev  -> apply:dev (auto)
                                                    ->  plan:prod -> apply:prod (manual button)
```

* `plan` writes `tfplan` as a job artifact.
* `apply` runs **that artifact**, so what you reviewed is what runs.
* `resource_group` stops two applies touching the same state at once.
* `parallel:matrix` runs the same job for all three stacks.

## 2. No AWS keys — use OIDC

GitLab gives each job a signed JWT. AWS trusts GitLab as an OIDC provider and
swaps that JWT for temporary credentials. Nothing long-lived is stored anywhere.

### Register GitLab as an identity provider (once per AWS account)

```bash
aws iam create-open-id-connect-provider \
  --url https://gitlab.com \
  --client-id-list https://gitlab.com
```

### Create the CI role

`trust-policy.json` — note how the condition pins the exact project and, for
production, the exact branch:

```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": { "Federated": "arn:aws:iam::123456789012:oidc-provider/gitlab.com" },
    "Action": "sts:AssumeRoleWithWebIdentity",
    "Condition": {
      "StringEquals": {
        "gitlab.com:aud": "https://gitlab.com"
      },
      "StringLike": {
        "gitlab.com:sub": "project_path:acme/platform-keycloak:ref_type:branch:ref:main"
      }
    }
  }]
}
```

```bash
aws iam create-role \
  --role-name gitlab-ci-keycloak \
  --assume-role-policy-document file://trust-policy.json

# Start with PowerUserAccess in dev, then tighten to a least-privilege policy.
aws iam attach-role-policy \
  --role-name gitlab-ci-keycloak \
  --policy-arn arn:aws:iam::aws:policy/PowerUserAccess
```

For dev you usually want a looser `sub` pattern such as
`project_path:acme/platform-keycloak:ref_type:branch:ref:*`, and a separate,
stricter role for production.

## 3. CI/CD variables to create

| Variable | Type | Protected | Masked |
|---|---|---|---|
| `AWS_ROLE_ARN_DEV` | plain | no | no |
| `AWS_ROLE_ARN_PROD` | plain | **yes** | no |
| `TF_VAR_smtp_password` | plain | yes | **yes** |

Mark the `main` branch as protected so protected variables are only exposed to
pipelines running on it.

## 4. Least-privilege state access

The CI role needs, at minimum:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": ["s3:ListBucket"],
      "Resource": "arn:aws:s3:::acme-tfstate-eu-west-1"
    },
    {
      "Effect": "Allow",
      "Action": ["s3:GetObject", "s3:PutObject", "s3:DeleteObject"],
      "Resource": "arn:aws:s3:::acme-tfstate-eu-west-1/keycloak/*"
    },
    {
      "Effect": "Allow",
      "Action": ["kms:Encrypt", "kms:Decrypt", "kms:GenerateDataKey"],
      "Resource": "arn:aws:kms:eu-west-1:123456789012:key/<state-key-id>"
    }
  ]
}
```

## 5. EKS specifics in CI

The `kubernetes` and `helm` providers call `aws eks get-token`, so the CI role
must have an **EKS access entry**. That is what `admin_principal_arns` in
`examples/02-eks/*.tfvars` is for — put the CI role ARN there.

The CI image must contain the AWS CLI; the pipeline installs it with
`apk add aws-cli` in `before_script`.

## 6. Realm pipeline (example 3)

The realm stack needs to reach Keycloak's admin API over HTTPS.

* If the ALB is internet-facing: works from GitLab.com shared runners.
* If it is internal: run a **self-hosted GitLab runner inside the VPC**, or
  peer/VPN into it. This is the usual reason teams end up with a private runner.

Create the Terraform service account client once, by hand, in the `master` realm:

1. Clients -> Create client -> `terraform-automation`, client authentication ON.
2. Turn off Standard flow, turn **on** Service accounts roles.
3. Service account roles -> Assign role -> filter by clients -> `realm-management`
   -> grant `realm-admin` (or narrower: `manage-clients`, `manage-realm`,
   `view-realm`, `manage-users`).
4. Store `{client_id, client_secret}` in Secrets Manager and point
   `terraform_client_secret_arn` at it.

Never let Terraform log in as a human admin account.

## 7. Things that will bite you

| Symptom | Cause | Fix |
|---|---|---|
| `Error acquiring the state lock` | A previous job was cancelled mid-apply | `terraform force-unlock <id>` after confirming nothing is running |
| `no valid credential sources` | `id_tokens` missing on the job, or `sub` does not match the trust policy | Check the branch and project path in the condition |
| Plan is clean but apply fails on EKS | Cluster created in the same run; providers were configured against nothing | Split the stacks, or use the two-phase `-target` apply documented in example 2 |
| `Provider produced inconsistent final plan` on the realm stack | Keycloak was mid-restart | Re-run; add a readiness gate before the stack |
