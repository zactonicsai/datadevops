# Keycloak on AWS — best practices, with trade-offs

Each item says what to do, why, and what you give up.

---

## 1. Configuration essentials

### Always run `start`, never `start-dev`
`start-dev` uses an in-memory H2 database and disables hostname checks. It is a
laptop tool. Every example here uses `start`.

### Set the hostname explicitly
```
KC_HOSTNAME=https://sso.example.com
KC_HOSTNAME_STRICT=true
```
Keycloak builds issuer URLs, redirects and metadata from this. Guessing it from
the `Host` header is how host-header injection attacks work.
*Trade-off:* one hostname per deployment. Multi-tenant hostnames need a proxy
in front or separate deployments.

### Tell Keycloak it is behind a proxy
```
KC_PROXY_HEADERS=xforwarded    # ALB sends X-Forwarded-For / -Proto / -Port
KC_HTTP_ENABLED=true           # plain HTTP inside the VPC
```
Only enable this when a trusted load balancer really is in front. Trusting
`X-Forwarded-*` from arbitrary clients lets them spoof source IPs, which
defeats brute-force detection.
*Alternative:* end-to-end TLS (`KC_HTTPS_CERTIFICATE_FILE`) with the ALB
re-encrypting. More secure inside the VPC, more certificate rotation work.

### Bake an optimized image for production
`kc.sh build` freezes the database driver and feature flags into the image, so
`start --optimized` skips the build step at boot (see `docker/Dockerfile`).
*Trade-off:* you now own an image build pipeline and an ECR repository.
*Benefit:* boot time drops from ~60 s to ~15 s, which matters when the ASG is
replacing nodes.

### Pin the image tag
`quay.io/keycloak/keycloak:26.4.0`, never `:latest`. Keycloak makes breaking
changes between minor versions and runs database migrations on startup — an
accidental upgrade is a one-way trip.

---

## 2. Database

* **Aurora PostgreSQL** for production. Multi-AZ, automatic failover, backups.
  MySQL/MariaDB are supported but PostgreSQL is what most of the community runs.
* **Never H2.** It is the default and it is for development only.
* **Force TLS**: `rds.force_ssl=1` on the cluster parameter group and
  `?sslmode=require` in the JDBC URL.
* **Connection pool sizing**: `KC_DB_POOL_MAX_SIZE` × number of nodes must stay
  under the database `max_connections`. Ten nodes × 30 connections = 300; a
  small Aurora instance will refuse that.
* **Backups**: 30-day retention in production. Test a restore at least once —
  an untested backup is a rumour.
* **Serverless v2 vs provisioned**: serverless scales to your traffic and suits
  spiky or dev workloads; provisioned (`db.r6g.large`) is cheaper at steady high
  load and has more predictable latency.

**Upgrade order matters.** Keycloak migrates the schema on first boot of a new
version. Take a snapshot first, and never run two different Keycloak versions
against one database at the same time — so do not do a blue/green rollout
across a major version boundary.

---

## 3. Secrets

Ranked from best to worst:

| Approach | Where the plaintext ends up | Verdict |
|---|---|---|
| Instance fetches from Secrets Manager at boot (example 1) | Only on the instance, in a `0600` file | **Best.** Nothing in state, nothing in Git. |
| Secrets Store CSI driver / External Secrets Operator on EKS | Only in the pod | **Best for Kubernetes.** Replace the `data.aws_secretsmanager_secret_version` block in `modules/keycloak-k8s` with this when you go to production. |
| Terraform data source -> Kubernetes secret (example 2 as shipped) | Terraform state | Acceptable only with an encrypted, access-controlled state bucket. |
| `TF_VAR_*` from a masked CI variable | Terraform state + CI logs if unmasked | Use only for values that cannot be generated, e.g. an SMTP password. |
| Plaintext in `*.tfvars` | Git, forever | **Never.** |

Also: rotate the Aurora master password on a schedule, and delete the
bootstrap admin account as soon as a real admin exists.

---

## 4. Networking and access

* Keycloak instances/pods go in **private subnets**. Only the ALB is public.
* Database subnets have **no route to the internet at all**.
* Reach instances with **SSM Session Manager**, not SSH. No key pairs, no
  bastion, and every session is logged.
* **IMDSv2 required** (`http_tokens = "required"`) — this closes the SSRF path
  that leaks instance credentials.
* Restrict `/admin*` by CIDR, or publish it on a separate internal hostname.
* Use **VPC endpoints** for Secrets Manager, SSM, Logs and KMS so that traffic
  never leaves the VPC and does not pay NAT gateway charges.
  *Trade-off:* each interface endpoint costs about $7/month per AZ.

---

## 5. Scaling

* **Scale out, not up.** Keycloak is horizontal; 3 medium nodes beat 1 large one.
* **Scale in slowly.** Removing a node triggers Infinispan rebalancing. The HPA
  in example 2 uses a 10-minute stabilisation window and removes one pod at a
  time; the ASG uses a lifecycle hook for the same reason.
* **Target CPU around 55–60%.** JVM warm-up means a node that just joined is
  slower than a warm one.
* **Give the JVM room**: `-XX:MaxRAMPercentage=70` so the JVM sizes its heap
  from the container limit instead of the host's memory.
* **Watch out for token bursts.** A client library that requests a token per
  request instead of caching it can multiply your load tenfold. Check
  `/metrics` before adding nodes.

---

## 6. Availability

* Minimum **2 nodes**, ideally **3 across 3 AZs**.
* `min_available = 2` in the PodDisruptionBudget so a node drain cannot take the
  cluster to one replica.
* `min_healthy_percentage = 100` on ASG instance refresh: add the new node
  before removing the old one.
* Health checks belong on **`/health/ready` on port 9000**, not on `/` — the
  root path returns a redirect and would hide a broken instance.
* **Multi-region active/active is hard.** Keycloak supports it only as a
  documented multi-site setup with an external Infinispan cluster and Aurora
  Global Database. Unless you have a hard RTO requirement, run one region and
  keep a warm standby with database replication.

---

## 7. Observability

* `KC_HEALTH_ENABLED=true` and `KC_METRICS_ENABLED=true`.
* Scrape `:9000/metrics` (Prometheus format) with the AWS Managed Prometheus
  agent or the CloudWatch agent.
* `KC_LOG_CONSOLE_OUTPUT=json` so CloudWatch Logs Insights can query fields.
* Turn on **admin events with details** in the realm — this is your audit trail
  for "who changed that client at 2 a.m.".
* Alarms worth having: unhealthy host count > 0, target 5xx rate, Aurora CPU and
  free storage, ACM certificate expiry, and a synthetic login canary.
* `events_expiration` keeps the event tables from growing without limit.

---

## 8. Terraform hygiene

* **One state file per stack per environment.** Network + cluster + workload in
  one giant state means one bad plan can destroy the database.
* **Pin provider versions** (`~> 6.0`) and commit `.terraform.lock.hcl`.
* **Partial backend config** (`-backend-config=backend-prod.hcl`) so the same
  code serves every environment.
* **S3 native locking** (`use_lockfile = true`, Terraform ≥ 1.10) — no DynamoDB
  table needed any more.
* `prevent_destroy` on the Aurora cluster is worth adding once you go live.
* Keep **realm configuration in its own state** (example 3). App teams change
  clients often; infrastructure changes rarely. Different blast radius,
  different pipeline, different reviewers.
* `terraform plan -out=tfplan` in CI, then apply that exact artifact. Applying a
  fresh plan means applying something nobody reviewed.

---

## 9. Keycloak realm settings worth setting on day one

| Setting | Recommended | Why |
|---|---|---|
| `ssl_required` | `external` | Refuse non-HTTPS logins from outside |
| Brute force detection | on | Slows password spraying |
| Password policy | length 12+, `hashAlgorithm(argon2)` | Argon2 is the modern default in Keycloak 24+ |
| Implicit flow | **off** | Deprecated and leaks tokens in URLs |
| PKCE (`S256`) | on for all clients | Mandatory for public clients, harmless for confidential ones |
| Access token lifespan | 5 minutes | Short tokens limit the damage from a leak |
| SSO session idle | 30 minutes | Balance between security and users complaining |
| Refresh token reuse | 0 | Enables rotation, detects replay |
| Registration | off, unless you truly want self-signup | |
| Realm | never use `master` for apps | `master` is for administering Keycloak itself |

---

## 10. Upgrades

1. Read the release notes for **every** version you skip.
2. Snapshot Aurora.
3. Apply in dev with the same data volume shape as production if possible.
4. Change `keycloak_image` in `prod.tfvars`, merge, let the pipeline plan it.
5. Apply — ASG instance refresh or StatefulSet rolling update handles the roll.
6. Watch `/health/ready`, error rate, and login latency for an hour.

Roll back by pointing the image back **only if the schema did not migrate**.
Once Keycloak has migrated the database, rolling back means restoring the
snapshot. This is the single most important thing to remember about Keycloak
upgrades.
