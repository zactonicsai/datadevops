# Keycloak on AWS with Terraform

A complete, copy-and-run reference for running **Keycloak** on AWS, managed by
**Terraform**, driven by a **GitLab CI/CD pipeline**.

Three separate examples, each in its own folder, each with its own `.tfvars`
files so nothing is hard-coded:

| Folder | What it builds |
|---|---|
| `examples/01-ec2-asg-alb` | Keycloak on EC2 Auto Scaling behind an Application Load Balancer + Aurora PostgreSQL |
| `examples/02-eks` | An EKS cluster + Keycloak as a StatefulSet + ALB via the AWS Load Balancer Controller |
| `examples/03-realm-config` | The realm, clients, roles and groups *inside* Keycloak, as code |

---

## 1. Background: what is Keycloak and why does the setup look like this?

**Keycloak is a login server.** Instead of every app you build writing its own
"username and password" screen, all of them hand the job to Keycloak. Keycloak
checks who the person is, then gives the app a signed token that says
"this really is Sara, and she is in the finance group". That handoff uses two
standard protocols: **OIDC** (modern) and **SAML** (older, still common).

Some words you will see everywhere in this repo:

| Word | Plain meaning |
|---|---|
| **Realm** | A sealed container of users, groups and apps. Realm A cannot see realm B. |
| **Client** | One application that trusts Keycloak (a website, a mobile app, an API). |
| **Role / Group** | Labels on a user that apps use to decide what she may do. |
| **Token** | A short-lived signed note proving who the user is. |
| **IdP** | Identity Provider — the thing doing the proving. Keycloak is one. |

**Three facts drive the whole architecture:**

1. **Keycloak keeps almost nothing on its own disk.** Users, realms and clients
   live in a PostgreSQL database. So the database is the thing that must be
   backed up and highly available — not the servers.
2. **Keycloak nodes talk to each other.** They share a memory cache
   (Infinispan) so a login on node 1 is visible on node 2. Nodes must be able
   to find each other, and that is why cluster discovery appears in both
   examples.
3. **Keycloak must know its own public URL.** Every redirect and every token it
   issues contains that URL. If Keycloak thinks it is
   `http://10.0.1.23:8080` but users arrive at `https://sso.example.com`,
   logins break in confusing ways. That is what `KC_HOSTNAME` is for.

Everything else — the load balancer, the Auto Scaling group, the health checks
— is ordinary AWS plumbing arranged around those three facts.

---

## 2. Step-by-step: deploy example 1 (EC2 + Auto Scaling + ALB)

This is the shortest path to a working Keycloak. Follow it end to end once,
then read the rest of the document.

### Step 0 — What you need first

* An AWS account and the AWS CLI logged in (`aws sts get-caller-identity` works).
* Terraform **1.9 or newer** installed.
* A **public Route 53 hosted zone**, for example `example.com`. Terraform will
  add the DNS records and the TLS certificate itself.
* An **S3 bucket for Terraform state**, with versioning and encryption on.

Create the state bucket once, by hand:

```bash
aws s3api create-bucket \
  --bucket acme-tfstate-eu-west-1 \
  --region eu-west-1 \
  --create-bucket-configuration LocationConstraint=eu-west-1

aws s3api put-bucket-versioning \
  --bucket acme-tfstate-eu-west-1 \
  --versioning-configuration Status=Enabled

aws s3api put-bucket-encryption \
  --bucket acme-tfstate-eu-west-1 \
  --server-side-encryption-configuration \
  '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"aws:kms"}}]}'
```

### Step 1 — Get the code

```bash
unzip keycloak-aws-terraform.zip
cd keycloak-aws-terraform/examples/01-ec2-asg-alb
```

### Step 2 — Edit `dev.tfvars`

Open it and change four things:

```hcl
route53_zone_name = "example.com"       # your real hosted zone
hostname          = "sso-dev.example.com"
azs               = ["eu-west-1a", "eu-west-1b"]
region            = "eu-west-1"
```

There are **no passwords in this file, and there never will be.** Terraform
generates the database password and the first admin password itself and stores
them in AWS Secrets Manager.

### Step 3 — Point the backend at your bucket

Edit `backend-dev.hcl`:

```hcl
bucket = "acme-tfstate-eu-west-1"
key    = "keycloak/dev/ec2-asg/terraform.tfstate"
region = "eu-west-1"
```

### Step 4 — Initialise, plan, apply

```bash
terraform init -backend-config=backend-dev.hcl
terraform plan  -var-file=dev.tfvars
terraform apply -var-file=dev.tfvars
```

The first apply takes roughly 15–20 minutes; most of that is Aurora.

### Step 5 — Get the first admin password

```bash
ARN=$(terraform output -raw bootstrap_admin_secret_arn)
aws secretsmanager get-secret-value --secret-id "$ARN" \
  --query SecretString --output text | jq .
```

### Step 6 — Log in and check the health endpoints

Open `https://sso-dev.example.com` and sign in with those credentials.

Then confirm the machine-readable endpoints work:

```bash
curl -s https://sso-dev.example.com/realms/master/.well-known/openid-configuration | jq .issuer
```

The `issuer` must be exactly `https://sso-dev.example.com/realms/master`. If it
shows an internal IP, `KC_HOSTNAME` is wrong.

### Step 7 — Replace the bootstrap admin

The bootstrap admin exists only to let you in the first time.

1. In the admin console, create a personal admin user with a real password and MFA.
2. Delete the bootstrap admin user.
3. Remove the `KC_BOOTSTRAP_ADMIN_*` lines from the user data (or the Kubernetes
   secret) and roll the instances:
   ```bash
   aws autoscaling start-instance-refresh --auto-scaling-group-name keycloak-dev
   ```

### Step 8 — Tear it down when you are done experimenting

```bash
terraform destroy -var-file=dev.tfvars
```

`deletion_protection = false` in `dev.tfvars` is what makes this possible.
In `prod.tfvars` it is `true`, on purpose.

---

## 3. What each folder contains

```
keycloak-aws-terraform/
├── .gitlab-ci.yml                  # OIDC auth, fmt/validate/scan, plan, manual apply
├── docker/Dockerfile               # optimized Keycloak image for production
├── docs/
│   ├── 01-architecture.md          # how the pieces fit, with diagrams
│   ├── 02-best-practices.md        # the long list, with pros and cons
│   └── 03-gitlab-pipeline.md       # IAM trust policy, variables, workflow
├── modules/
│   ├── vpc/                        # 3-tier VPC, NAT, endpoints, flow logs
│   ├── rds-aurora-postgres/        # Aurora PostgreSQL + KMS + Secrets Manager
│   ├── keycloak-ec2-asg/           # launch template, ASG, ALB, alarms
│   ├── eks-cluster/                # EKS, node group, addons, IRSA for the ALB controller
│   ├── keycloak-k8s/               # StatefulSet, services, ingress, PDB, HPA
│   └── keycloak-realm/             # realm, clients, roles, groups
└── examples/
    ├── 01-ec2-asg-alb/
    ├── 02-eks/
    └── 03-realm-config/
```

Every example folder has the same shape, so they are interchangeable in CI:

```
versions.tf      providers.tf   main.tf   variables.tf   outputs.tf
dev.tfvars       prod.tfvars
backend-dev.hcl  backend-prod.hcl
README.md
```

---

## 4. EC2 Auto Scaling vs EKS — which should you pick?

| | **EC2 + ASG + ALB** (example 1) | **EKS** (example 2) |
|---|---|---|
| Best when | Keycloak is the only thing you are running, or you have no Kubernetes team | You already run EKS for other workloads |
| Learning curve | Low — EC2, ALB, ASG | High — cluster, controllers, RBAC, addons |
| Baseline cost | Lower: no $73/month control plane | Higher, but shared across many workloads |
| Scaling speed | Minutes (new instance boots) | Seconds (new pod starts) |
| Rolling upgrades | ASG instance refresh | StatefulSet rolling update |
| Cluster discovery | JDBC_PING through the database | DNS_PING through a headless service |
| Blast radius | Small and isolated | Shares a cluster with everything else |
| Ops burden | Patch AMIs, manage user data | Patch cluster + nodes + controllers |

**Rule of thumb:** if you have to ask, take example 1. Identity is the service
everything else depends on — the boring option is the right one. Move to EKS
when you already have the platform and the people to run it.

---

## 5. The tfvars pattern (and why secrets are not in it)

```
dev.tfvars   ->  small, cheap, deletable
prod.tfvars  ->  3 AZs, HA database, deletion protection on
```

```bash
terraform init  -backend-config=backend-prod.hcl
terraform plan  -var-file=prod.tfvars
```

Three kinds of value, three homes:

| Kind of value | Where it lives | Example |
|---|---|---|
| Non-secret, per environment | `*.tfvars`, committed to Git | `instance_type`, `hostname`, CIDRs |
| Secret, generated by Terraform | Secrets Manager, created by Terraform | database password, bootstrap admin |
| Secret, supplied by a human | GitLab masked CI variable as `TF_VAR_x` | SMTP password |

Never write `db_password = "..."` in a tfvars file. Once it is in Git it is in
Git forever, in every clone, on every laptop.

---

## 6. Where to go next

* `docs/01-architecture.md` — the request path, the cluster caches, failure modes.
* `docs/02-best-practices.md` — hostname, proxy, database, secrets, scaling,
  upgrades, monitoring, each with the trade-off spelled out.
* `docs/03-gitlab-pipeline.md` — the IAM trust policy for GitLab OIDC and how
  the plan/apply flow works.
