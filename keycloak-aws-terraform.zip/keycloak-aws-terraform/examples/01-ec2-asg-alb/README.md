# Example 1 — Keycloak on EC2 Auto Scaling + ALB

## What gets created

* 3-tier VPC (public / private / database) across 2–3 AZs, NAT, VPC endpoints, flow logs
* ACM certificate with DNS validation in your Route 53 zone
* Aurora PostgreSQL (KMS-encrypted, TLS enforced, password in Secrets Manager)
* Launch template running the Keycloak container, IMDSv2 required, SSM enabled
* Auto Scaling group with ELB health checks, instance refresh and CPU target tracking
* ALB: HTTPS 443 with TLS 1.3 policy, HTTP 80 redirect, sticky sessions,
  health check on `/health/ready:9000`
* CloudWatch log group and alarms for unhealthy hosts and target 5xx

## Run it

```bash
terraform init  -backend-config=backend-dev.hcl
terraform plan  -var-file=dev.tfvars
terraform apply -var-file=dev.tfvars
```

Production:

```bash
terraform init  -backend-config=backend-prod.hcl -reconfigure
terraform plan  -var-file=prod.tfvars
terraform apply -var-file=prod.tfvars
```

## First login

```bash
aws secretsmanager get-secret-value \
  --secret-id "$(terraform output -raw bootstrap_admin_secret_arn)" \
  --query SecretString --output text | jq .
```

Then create a real admin, delete the bootstrap admin, and roll the fleet.

## Operating it

```bash
# shell on a node - no SSH key, no bastion
aws ssm start-session --target <instance-id>

# what is Keycloak doing?
aws logs tail /keycloak/keycloak-prod --follow

# roll the fleet after changing the image or config
aws autoscaling start-instance-refresh --auto-scaling-group-name keycloak-prod
```

## Notes

* Nodes discover each other with **JDBC_PING** through the shared database.
  This needs **Keycloak 26.2 or newer**.
* `min_size = 1` in dev is fine; use **3** in production so a single AZ failure
  cannot drop you below two nodes.
* The `dev.tfvars` file sets `deletion_protection = false` so you can destroy
  it. `prod.tfvars` sets it to `true`.
