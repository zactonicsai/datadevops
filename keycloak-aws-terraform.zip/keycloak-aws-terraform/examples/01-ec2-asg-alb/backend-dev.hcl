bucket       = "acme-tfstate-eu-west-1"
key          = "keycloak/dev/ec2-asg/terraform.tfstate"
region       = "eu-west-1"
encrypt      = true
kms_key_id   = "alias/tfstate"
use_lockfile = true # S3-native locking (Terraform >= 1.10), no DynamoDB table needed
