###############################################################################
# EXAMPLE 1 - Keycloak on EC2 Auto Scaling behind an ALB
#
#   terraform init -backend-config=backend-dev.hcl
#   terraform plan  -var-file=dev.tfvars
#   terraform apply -var-file=dev.tfvars
###############################################################################

locals {
  name = "${var.project}-${var.environment}"

  tags = {
    Project     = var.project
    Environment = var.environment
    Owner       = var.owner
    CostCenter  = var.cost_center
    ManagedBy   = "terraform"
    Repo        = "gitlab.com/acme/platform-keycloak"
  }
}

# ------------------------------ network -------------------------------------
module "vpc" {
  source = "../../modules/vpc"

  name                  = local.name
  cidr_block            = var.vpc_cidr
  azs                   = var.azs
  public_subnet_cidrs   = var.public_subnet_cidrs
  private_subnet_cidrs  = var.private_subnet_cidrs
  database_subnet_cidrs = var.database_subnet_cidrs
  single_nat_gateway    = var.single_nat_gateway
  tags                  = local.tags
}

# ------------------------------ TLS certificate -----------------------------
data "aws_route53_zone" "this" {
  name         = var.route53_zone_name
  private_zone = false
}

resource "aws_acm_certificate" "this" {
  domain_name       = var.hostname
  validation_method = "DNS"

  subject_alternative_names = var.admin_hostname == "" ? [] : [var.admin_hostname]

  lifecycle { create_before_destroy = true }
  tags = local.tags
}

resource "aws_route53_record" "cert_validation" {
  for_each = {
    for dvo in aws_acm_certificate.this.domain_validation_options : dvo.domain_name => {
      name   = dvo.resource_record_name
      record = dvo.resource_record_value
      type   = dvo.resource_record_type
    }
  }

  zone_id         = data.aws_route53_zone.this.zone_id
  name            = each.value.name
  type            = each.value.type
  records         = [each.value.record]
  ttl             = 60
  allow_overwrite = true
}

resource "aws_acm_certificate_validation" "this" {
  certificate_arn         = aws_acm_certificate.this.arn
  validation_record_fqdns = [for r in aws_route53_record.cert_validation : r.fqdn]
}

# ------------------------------ database ------------------------------------
module "database" {
  source = "../../modules/rds-aurora-postgres"

  name                = local.name
  vpc_id              = module.vpc.vpc_id
  database_subnet_ids = module.vpc.database_subnet_ids
  # The ingress rule lives in the root module (below) so the two modules do
  # not reference each other's outputs and create a dependency cycle.

  engine_version          = var.db_engine_version
  instance_class          = var.db_instance_class
  instance_count          = var.db_instance_count
  serverless_min_capacity = var.db_min_capacity
  serverless_max_capacity = var.db_max_capacity
  backup_retention_days   = var.db_backup_retention_days
  deletion_protection     = var.deletion_protection
  skip_final_snapshot     = var.environment != "prod"

  tags = local.tags
}

# Keycloak nodes -> Aurora on 5432
resource "aws_vpc_security_group_ingress_rule" "db_from_keycloak" {
  security_group_id            = module.database.security_group_id
  referenced_security_group_id = module.keycloak.node_security_group_id
  from_port                    = 5432
  to_port                      = 5432
  ip_protocol                  = "tcp"
  description                  = "PostgreSQL from Keycloak nodes"
}

# ------------------------------ bootstrap admin -----------------------------
# Temporary admin used only for the very first login. Create a named admin
# account, then delete this one and roll the ASG.
resource "random_password" "admin" {
  length           = 32
  special          = true
  override_special = "!#%*-_=+"
}

resource "aws_secretsmanager_secret" "admin" {
  name                    = "${local.name}/keycloak/bootstrap-admin"
  recovery_window_in_days = 7
  tags                    = local.tags
}

resource "aws_secretsmanager_secret_version" "admin" {
  secret_id = aws_secretsmanager_secret.admin.id
  secret_string = jsonencode({
    username = "kc-bootstrap-admin"
    password = random_password.admin.result
  })
}

# ------------------------------ keycloak ------------------------------------
module "keycloak" {
  source = "../../modules/keycloak-ec2-asg"

  name               = local.name
  vpc_id             = module.vpc.vpc_id
  public_subnet_ids  = module.vpc.public_subnet_ids
  private_subnet_ids = module.vpc.private_subnet_ids

  certificate_arn = aws_acm_certificate_validation.this.certificate_arn
  hostname        = var.hostname
  admin_hostname  = var.admin_hostname
  ingress_cidrs   = var.ingress_cidrs

  keycloak_image   = var.keycloak_image
  instance_type    = var.instance_type
  min_size         = var.min_size
  max_size         = var.max_size
  desired_capacity = var.desired_capacity

  db_jdbc_url      = module.database.jdbc_url
  db_secret_arn    = module.database.secret_arn
  db_kms_key_arn   = module.database.kms_key_arn
  admin_secret_arn = aws_secretsmanager_secret.admin.arn

  enable_deletion_protection = var.deletion_protection

  tags = local.tags
}

# ------------------------------ DNS -----------------------------------------
resource "aws_route53_record" "keycloak" {
  zone_id = data.aws_route53_zone.this.zone_id
  name    = var.hostname
  type    = "A"

  alias {
    name                   = module.keycloak.alb_dns_name
    zone_id                = module.keycloak.alb_zone_id
    evaluate_target_health = true
  }
}

resource "aws_route53_record" "keycloak_admin" {
  count   = var.admin_hostname == "" ? 0 : 1
  zone_id = data.aws_route53_zone.this.zone_id
  name    = var.admin_hostname
  type    = "A"

  alias {
    name                   = module.keycloak.alb_dns_name
    zone_id                = module.keycloak.alb_zone_id
    evaluate_target_health = true
  }
}
