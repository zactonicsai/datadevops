###############################################################################
# prod - 3 AZs, HA database, deletion protection on
###############################################################################
region      = "eu-west-1"
environment = "prod"
project     = "keycloak"
owner       = "platform-team"
cost_center = "CC-1234"

# ---- network ----
vpc_cidr              = "10.50.0.0/16"
azs                   = ["eu-west-1a", "eu-west-1b", "eu-west-1c"]
public_subnet_cidrs   = ["10.50.0.0/24", "10.50.1.0/24", "10.50.2.0/24"]
private_subnet_cidrs  = ["10.50.10.0/24", "10.50.11.0/24", "10.50.12.0/24"]
database_subnet_cidrs = ["10.50.20.0/24", "10.50.21.0/24", "10.50.22.0/24"]
single_nat_gateway    = false # NAT per AZ - no cross-AZ single point of failure

# ---- dns / tls ----
route53_zone_name = "example.com"
hostname          = "sso.example.com"
admin_hostname    = "sso-admin.example.com"
ingress_cidrs     = ["0.0.0.0/0"]

# ---- keycloak ----
keycloak_image   = "123456789012.dkr.ecr.eu-west-1.amazonaws.com/keycloak:26.4.0-1"
instance_type    = "m7i-flex.large"
min_size         = 3
max_size         = 9
desired_capacity = 3

# ---- database ----
db_engine_version        = "16.6"
db_instance_class        = "db.r6g.large"
db_instance_count        = 2
db_backup_retention_days = 30

deletion_protection = true
