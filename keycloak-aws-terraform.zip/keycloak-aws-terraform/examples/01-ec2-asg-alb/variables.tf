variable "region" {
  type    = string
  default = "eu-west-1"
}

variable "environment" {
  description = "dev | staging | prod"
  type        = string

  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "environment must be dev, staging or prod."
  }
}

variable "project" {
  type    = string
  default = "keycloak"
}

variable "owner" {
  type    = string
  default = "platform-team"
}

variable "cost_center" {
  type    = string
  default = "unset"
}

# ------------------------------ network -------------------------------------
variable "vpc_cidr" { type = string }
variable "azs" { type = list(string) }
variable "public_subnet_cidrs" { type = list(string) }
variable "private_subnet_cidrs" { type = list(string) }
variable "database_subnet_cidrs" { type = list(string) }
variable "single_nat_gateway" {
  type    = bool
  default = false
}

# ------------------------------ dns / tls -----------------------------------
variable "route53_zone_name" {
  description = "Public hosted zone, e.g. example.com (must already exist)."
  type        = string
}

variable "hostname" {
  description = "FQDN for Keycloak, e.g. sso.example.com."
  type        = string
}

variable "admin_hostname" {
  type    = string
  default = ""
}

variable "ingress_cidrs" {
  description = "Who may reach the ALB. Restrict this for internal IdPs."
  type        = list(string)
  default     = ["0.0.0.0/0"]
}

# ------------------------------ keycloak ------------------------------------
variable "keycloak_image" { type = string }
variable "instance_type" { type = string }
variable "min_size" { type = number }
variable "max_size" { type = number }
variable "desired_capacity" { type = number }

# ------------------------------ database ------------------------------------
variable "db_engine_version" { type = string }
variable "db_instance_class" { type = string }
variable "db_instance_count" { type = number }
variable "db_min_capacity" {
  type    = number
  default = 0.5
}
variable "db_max_capacity" {
  type    = number
  default = 8
}
variable "db_backup_retention_days" { type = number }
variable "deletion_protection" {
  type    = bool
  default = true
}
