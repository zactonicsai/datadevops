output "keycloak_url" {
  value = "https://${var.hostname}"
}

output "oidc_discovery_url_example" {
  description = "Well-known endpoint for a realm named 'corp'."
  value       = "https://${var.hostname}/realms/corp/.well-known/openid-configuration"
}

output "alb_dns_name" { value = module.keycloak.alb_dns_name }
output "autoscaling_group_name" { value = module.keycloak.autoscaling_group_name }
output "database_endpoint" { value = module.database.cluster_endpoint }
output "database_secret_arn" { value = module.database.secret_arn }

output "bootstrap_admin_secret_arn" {
  description = "Read it with: aws secretsmanager get-secret-value --secret-id <arn>"
  value       = aws_secretsmanager_secret.admin.arn
}

output "log_group_name" { value = module.keycloak.log_group_name }
