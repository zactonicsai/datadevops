###############################################################################
# dev - small, cheap, disposable
# Secrets NEVER go in this file. They come from Secrets Manager or CI variables.
###############################################################################
region      = "eu-west-1"
environment = "dev"
project     = "keycloak"
owner       = "platform-team"
cost_center = "CC-1234"

# ---- network ----
vpc_cidr              = "10.40.0.0/16"
azs                   = ["eu-west-1a", "eu-west-1b"]
public_subnet_cidrs   = ["10.40.0.0/24", "10.40.1.0/24"]
private_subnet_cidrs  = ["10.40.10.0/24", "10.40.11.0/24"]
database_subnet_cidrs = ["10.40.20.0/24", "10.40.21.0/24"]
single_nat_gateway    = true # one NAT to save ~$35/month

# ---- dns / tls ----
route53_zone_name = "example.com"
hostname          = "sso-dev.example.com"
admin_hostname    = ""
ingress_cidrs     = ["0.0.0.0/0"]

# ---- keycloak ----
keycloak_image   = "quay.io/keycloak/keycloak:26.4.0"
instance_type    = "t3.medium"
min_size         = 1
max_size         = 2
desired_capacity = 1

# ---- database ----
db_engine_version        = "16.6"
db_instance_class        = "db.serverless"
db_instance_count        = 1
db_min_capacity          = 0.5
db_max_capacity          = 2
db_backup_retention_days = 1

deletion_protection = false
