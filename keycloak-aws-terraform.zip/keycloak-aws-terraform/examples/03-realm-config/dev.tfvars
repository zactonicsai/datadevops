region      = "eu-west-1"
environment = "dev"

keycloak_url                = "https://sso-dev.example.com"
terraform_client_secret_arn = "arn:aws:secretsmanager:eu-west-1:123456789012:secret:keycloak/dev/terraform-client-AbCdEf"

realm_name   = "corp"
display_name = "ACME Corp (dev)"
login_theme  = "keycloak"

sso_session_idle_timeout = "60m"
sso_session_max_lifespan = "10h"
access_token_lifespan    = "15m"
password_policy          = "length(8) and notUsername"

realm_roles = {
  "platform-admin" = "Full administrative access to internal platform tools"
  "app-user"       = "Standard end user"
  "auditor"        = "Read-only access to audit views"
}

groups = {
  "platform-team" = ["platform-admin", "app-user"]
  "employees"     = ["app-user"]
  "security"      = ["auditor"]
}

clients = {
  "web-portal" = {
    name                            = "Customer Web Portal"
    description                     = "React SPA - public client, PKCE only"
    access_type                     = "PUBLIC"
    root_url                        = "https://portal-dev.example.com"
    valid_redirect_uris             = ["https://portal-dev.example.com/*", "http://localhost:3000/*"]
    valid_post_logout_redirect_uris = ["https://portal-dev.example.com/"]
    web_origins                     = ["https://portal-dev.example.com", "http://localhost:3000"]
    client_roles                    = ["portal-admin", "portal-viewer"]
  }

  "orders-api" = {
    name                     = "Orders API"
    description              = "Backend service - machine-to-machine only"
    access_type              = "CONFIDENTIAL"
    standard_flow_enabled    = false
    service_accounts_enabled = true
    client_roles             = ["orders-read", "orders-write"]
  }

  "internal-admin" = {
    name                = "Internal Admin Console"
    description         = "Server-rendered app, confidential client"
    access_type         = "CONFIDENTIAL"
    root_url            = "https://admin-dev.example.com"
    valid_redirect_uris = ["https://admin-dev.example.com/oauth2/callback"]
    web_origins         = ["https://admin-dev.example.com"]
  }
}

smtp_host     = ""
smtp_from     = "no-reply@example.com"
smtp_username = ""
# smtp_password comes from the CI variable TF_VAR_smtp_password
