provider "aws" {
  region = var.region
}

# Terraform authenticates as a *service account client* in the master realm,
# not as a human admin. Create it once (see README) and store its secret in
# Secrets Manager.
data "aws_secretsmanager_secret_version" "tf_client" {
  secret_id = var.terraform_client_secret_arn
}

locals {
  tf_client = jsondecode(data.aws_secretsmanager_secret_version.tf_client.secret_string)
}

provider "keycloak" {
  client_id     = local.tf_client.client_id
  client_secret = local.tf_client.client_secret
  url           = var.keycloak_url
  realm         = "master" # realm used for authentication, not the target realm
  base_path     = ""

  # Give the admin API a little slack; it can be slow on large realms.
  client_timeout = 30
}
