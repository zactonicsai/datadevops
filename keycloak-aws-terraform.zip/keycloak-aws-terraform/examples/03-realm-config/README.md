# Example 3 — Realm, clients, roles and groups as code

This stack talks to a **running** Keycloak, so apply example 1 or example 2
first.

## One-time manual setup

Terraform authenticates as a service account client, never as a human admin.

1. Log in to the admin console, switch to the **master** realm.
2. Clients -> Create client -> client ID `terraform-automation`,
   **Client authentication ON**.
3. Turn **off** Standard flow and Direct access grants. Turn **on**
   Service accounts roles.
4. Tab "Service account roles" -> Assign role -> Filter by clients ->
   `realm-management` -> assign `realm-admin`
   (or narrower: `manage-realm`, `manage-clients`, `manage-users`, `view-realm`).
5. Copy the client secret and store it:

```bash
aws secretsmanager create-secret \
  --name keycloak/dev/terraform-client \
  --secret-string '{"client_id":"terraform-automation","client_secret":"REPLACE_ME"}'
```

6. Put the resulting ARN in `dev.tfvars` as `terraform_client_secret_arn`.

## Run it

```bash
terraform init  -backend-config=backend-dev.hcl
terraform plan  -var-file=dev.tfvars
terraform apply -var-file=dev.tfvars
```

## What the tfvars control

```hcl
realm_roles = { "platform-admin" = "..." }        # realm-wide roles
groups      = { "platform-team" = ["platform-admin"] }  # group -> roles
clients     = { "web-portal" = { access_type = "PUBLIC", ... } }
```

Three client shapes are shown:

| Client | Type | Flows | Use it for |
|---|---|---|---|
| `web-portal` | PUBLIC | Authorization code + PKCE | SPAs and mobile apps that cannot keep a secret |
| `orders-api` | CONFIDENTIAL | Client credentials only | Service-to-service calls |
| `internal-admin` | CONFIDENTIAL | Authorization code | Server-rendered web apps |

## Client secrets

Each confidential client's secret is written to Secrets Manager at
`<env>/keycloak/<realm>/clients/<client-id>` together with the issuer and
discovery URLs. Applications read it from there at runtime — nobody copies a
secret by hand, and rotating it is a Terraform change.

`terraform output client_secrets` is marked sensitive; do not echo it in CI.

## Verify

```bash
curl -s https://sso.example.com/realms/corp/.well-known/openid-configuration | jq .
```
