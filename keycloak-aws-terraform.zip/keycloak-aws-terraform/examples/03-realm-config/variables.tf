variable "region" {
  type    = string
  default = "eu-west-1"
}

variable "environment" { type = string }

variable "keycloak_url" {
  description = "Base URL, e.g. https://sso.example.com."
  type        = string
}

variable "terraform_client_secret_arn" {
  description = "Secrets Manager secret holding {client_id, client_secret} of the Terraform service account client."
  type        = string
}

variable "realm_name" { type = string }
variable "display_name" { type = string }
variable "login_theme" {
  type    = string
  default = "keycloak"
}

variable "sso_session_idle_timeout" { type = string }
variable "sso_session_max_lifespan" { type = string }
variable "access_token_lifespan" { type = string }
variable "password_policy" { type = string }

variable "realm_roles" {
  type    = map(string)
  default = {}
}

variable "groups" {
  type    = map(list(string))
  default = {}
}

variable "clients" {
  type = map(object({
    name                            = string
    description                     = optional(string, "")
    access_type                     = optional(string, "CONFIDENTIAL")
    valid_redirect_uris             = optional(list(string), [])
    valid_post_logout_redirect_uris = optional(list(string), [])
    web_origins                     = optional(list(string), [])
    root_url                        = optional(string, "")
    standard_flow_enabled           = optional(bool, true)
    direct_access_grants_enabled    = optional(bool, false)
    service_accounts_enabled        = optional(bool, false)
    pkce_code_challenge_method      = optional(string, "S256")
    default_scopes                  = optional(list(string), ["profile", "email", "roles", "web-origins", "acr", "basic"])
    optional_scopes                 = optional(list(string), ["address", "phone", "offline_access"])
    client_roles                    = optional(list(string), [])
  }))
  default = {}
}

variable "smtp_host" {
  type    = string
  default = ""
}
variable "smtp_from" {
  type    = string
  default = ""
}
variable "smtp_username" {
  type    = string
  default = ""
}

# Set through the CI variable TF_VAR_smtp_password - never in a tfvars file.
variable "smtp_password" {
  type      = string
  default   = ""
  sensitive = true
}

variable "store_client_secrets_in_secretsmanager" {
  description = "Write each confidential client secret to Secrets Manager so apps can fetch it."
  type        = bool
  default     = true
}
