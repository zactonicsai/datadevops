region      = "eu-west-1"
environment = "prod"

keycloak_url                = "https://sso.example.com"
terraform_client_secret_arn = "arn:aws:secretsmanager:eu-west-1:123456789012:secret:keycloak/prod/terraform-client-AbCdEf"

realm_name   = "corp"
display_name = "ACME Corp"
login_theme  = "keycloak"

sso_session_idle_timeout = "30m"
sso_session_max_lifespan = "10h"
access_token_lifespan    = "5m"
password_policy          = "length(14) and upperCase(1) and lowerCase(1) and digits(1) and specialChars(1) and notUsername and passwordHistory(5) and hashAlgorithm(argon2)"

realm_roles = {
  "platform-admin" = "Full administrative access to internal platform tools"
  "app-user"       = "Standard end user"
  "auditor"        = "Read-only access to audit views"
}

groups = {
  "platform-team" = ["platform-admin", "app-user"]
  "employees"     = ["app-user"]
  "security"      = ["auditor"]
}

clients = {
  "web-portal" = {
    name                            = "Customer Web Portal"
    description                     = "React SPA - public client, PKCE only"
    access_type                     = "PUBLIC"
    root_url                        = "https://portal.example.com"
    valid_redirect_uris             = ["https://portal.example.com/*"]
    valid_post_logout_redirect_uris = ["https://portal.example.com/"]
    web_origins                     = ["https://portal.example.com"]
    client_roles                    = ["portal-admin", "portal-viewer"]
  }

  "orders-api" = {
    name                     = "Orders API"
    description              = "Backend service - machine-to-machine only"
    access_type              = "CONFIDENTIAL"
    standard_flow_enabled    = false
    service_accounts_enabled = true
    client_roles             = ["orders-read", "orders-write"]
  }

  "internal-admin" = {
    name                = "Internal Admin Console"
    description         = "Server-rendered app, confidential client"
    access_type         = "CONFIDENTIAL"
    root_url            = "https://admin.example.com"
    valid_redirect_uris = ["https://admin.example.com/oauth2/callback"]
    web_origins         = ["https://admin.example.com"]
  }
}

smtp_host     = "email-smtp.eu-west-1.amazonaws.com"
smtp_from     = "no-reply@example.com"
smtp_username = ""
# smtp_password comes from the CI variable TF_VAR_smtp_password
