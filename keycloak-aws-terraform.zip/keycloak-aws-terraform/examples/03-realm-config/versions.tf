terraform {
  required_version = ">= 1.9.0"

  required_providers {
    keycloak = {
      # Official provider (formerly mrparkers/keycloak).
      source  = "keycloak/keycloak"
      version = "~> 5.0"
    }
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.0"
    }
  }

  backend "s3" {}
}
