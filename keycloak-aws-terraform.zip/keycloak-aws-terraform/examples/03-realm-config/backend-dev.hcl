bucket       = "acme-tfstate-eu-west-1"
key          = "keycloak/dev/realm/terraform.tfstate"
region       = "eu-west-1"
encrypt      = true
kms_key_id   = "alias/tfstate"
use_lockfile = true
