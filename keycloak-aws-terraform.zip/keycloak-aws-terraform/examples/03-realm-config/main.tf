###############################################################################
# EXAMPLE 3 - Realm, clients, roles and groups as code
#
#   terraform init  -backend-config=backend-dev.hcl
#   terraform plan  -var-file=dev.tfvars
#
# Runs against a live Keycloak, so example 1 or 2 must be applied first.
###############################################################################

module "realm" {
  source = "../../modules/keycloak-realm"

  realm_name   = var.realm_name
  display_name = var.display_name
  login_theme  = var.login_theme

  sso_session_idle_timeout = var.sso_session_idle_timeout
  sso_session_max_lifespan = var.sso_session_max_lifespan
  access_token_lifespan    = var.access_token_lifespan
  password_policy          = var.password_policy

  realm_roles = var.realm_roles
  groups      = var.groups
  clients     = var.clients

  smtp = var.smtp_host == "" ? null : {
    host              = var.smtp_host
    port              = "587"
    from              = var.smtp_from
    from_display_name = var.display_name
    ssl               = false
    starttls          = true
    username          = var.smtp_username
    password          = var.smtp_password
  }
}

# ---------------------------------------------------------------------------
# Hand the generated client secrets to the applications through Secrets
# Manager. Applications read them at runtime; nobody copies them by hand.
# ---------------------------------------------------------------------------
resource "aws_secretsmanager_secret" "client" {
  for_each = var.store_client_secrets_in_secretsmanager ? var.clients : {}

  name                    = "${var.environment}/keycloak/${var.realm_name}/clients/${each.key}"
  recovery_window_in_days = 7

  tags = {
    Environment = var.environment
    Realm       = var.realm_name
    ManagedBy   = "terraform"
  }
}

resource "aws_secretsmanager_secret_version" "client" {
  for_each = var.store_client_secrets_in_secretsmanager ? var.clients : {}

  secret_id = aws_secretsmanager_secret.client[each.key].id
  secret_string = jsonencode({
    client_id     = each.key
    client_secret = module.realm.client_secrets[each.key]
    issuer        = "${var.keycloak_url}/realms/${var.realm_name}"
    discovery_url = "${var.keycloak_url}/realms/${var.realm_name}/.well-known/openid-configuration"
  })
}
