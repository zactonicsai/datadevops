output "realm_id" { value = module.realm.realm_id }

output "issuer" {
  value = "${var.keycloak_url}/realms/${var.realm_name}"
}

output "discovery_url" {
  value = "${var.keycloak_url}/realms/${var.realm_name}/.well-known/openid-configuration"
}

output "client_secret_arns" {
  value = { for k, v in aws_secretsmanager_secret.client : k => v.arn }
}
