bucket       = "acme-tfstate-eu-west-1"
key          = "keycloak/prod/eks/terraform.tfstate"
region       = "eu-west-1"
encrypt      = true
kms_key_id   = "alias/tfstate"
use_lockfile = true
