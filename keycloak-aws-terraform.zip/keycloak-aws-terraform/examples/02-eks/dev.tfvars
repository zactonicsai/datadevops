region      = "eu-west-1"
environment = "dev"
project     = "keycloak"
owner       = "platform-team"
cost_center = "CC-1234"

# ---- network ----
vpc_cidr              = "10.60.0.0/16"
azs                   = ["eu-west-1a", "eu-west-1b"]
public_subnet_cidrs   = ["10.60.0.0/24", "10.60.1.0/24"]
private_subnet_cidrs  = ["10.60.10.0/23", "10.60.12.0/23"]
database_subnet_cidrs = ["10.60.20.0/24", "10.60.21.0/24"]
single_nat_gateway    = true

# ---- eks ----
kubernetes_version           = "1.33"
node_instance_types          = ["t3.large"]
node_min_size                = 2
node_max_size                = 4
node_desired_size            = 2
endpoint_public_access       = true
public_access_cidrs          = ["0.0.0.0/0"]
admin_principal_arns         = ["arn:aws:iam::123456789012:role/gitlab-ci-keycloak"]
alb_controller_chart_version = "1.13.0"

# ---- dns / tls ----
route53_zone_name = "example.com"
hostname          = "sso-eks-dev.example.com"
ingress_cidrs     = ["0.0.0.0/0"]

# ---- keycloak ----
keycloak_image    = "quay.io/keycloak/keycloak:26.4.0"
keycloak_replicas = 2
enable_hpa        = false

# ---- database ----
db_engine_version        = "16.6"
db_instance_class        = "db.serverless"
db_instance_count        = 1
db_backup_retention_days = 1

deletion_protection = false
