region      = "eu-west-1"
environment = "prod"
project     = "keycloak"
owner       = "platform-team"
cost_center = "CC-1234"

# ---- network ----
vpc_cidr              = "10.70.0.0/16"
azs                   = ["eu-west-1a", "eu-west-1b", "eu-west-1c"]
public_subnet_cidrs   = ["10.70.0.0/24", "10.70.1.0/24", "10.70.2.0/24"]
private_subnet_cidrs  = ["10.70.10.0/23", "10.70.12.0/23", "10.70.14.0/23"]
database_subnet_cidrs = ["10.70.20.0/24", "10.70.21.0/24", "10.70.22.0/24"]
single_nat_gateway    = false

# ---- eks ----
kubernetes_version     = "1.33"
node_instance_types    = ["m7i-flex.large"]
node_min_size          = 3
node_max_size          = 9
node_desired_size      = 3
endpoint_public_access = false # private API endpoint; reach it via VPN or an SSM bastion
admin_principal_arns   = ["arn:aws:iam::123456789012:role/gitlab-ci-keycloak"]
alb_controller_chart_version = "1.13.0"

# ---- dns / tls ----
route53_zone_name = "example.com"
hostname          = "sso.example.com"
admin_hostname    = "sso-admin.example.com"
ingress_cidrs     = ["0.0.0.0/0"]

# ---- keycloak ----
keycloak_image    = "123456789012.dkr.ecr.eu-west-1.amazonaws.com/keycloak:26.4.0-1"
keycloak_replicas = 3
enable_hpa        = true

# ---- database ----
db_engine_version        = "16.6"
db_instance_class        = "db.r6g.large"
db_instance_count        = 2
db_backup_retention_days = 30

deletion_protection = true
