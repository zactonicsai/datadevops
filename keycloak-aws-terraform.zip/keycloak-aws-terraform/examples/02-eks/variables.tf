variable "region" {
  type    = string
  default = "eu-west-1"
}

variable "environment" {
  type = string
  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "environment must be dev, staging or prod."
  }
}

variable "project" {
  type    = string
  default = "keycloak"
}

variable "owner" {
  type    = string
  default = "platform-team"
}

variable "cost_center" {
  type    = string
  default = "unset"
}

# ---- network ----
variable "vpc_cidr" { type = string }
variable "azs" { type = list(string) }
variable "public_subnet_cidrs" { type = list(string) }
variable "private_subnet_cidrs" { type = list(string) }
variable "database_subnet_cidrs" { type = list(string) }
variable "single_nat_gateway" {
  type    = bool
  default = false
}

# ---- eks ----
variable "kubernetes_version" { type = string }
variable "node_instance_types" { type = list(string) }
variable "node_min_size" { type = number }
variable "node_max_size" { type = number }
variable "node_desired_size" { type = number }
variable "endpoint_public_access" {
  type    = bool
  default = true
}
variable "public_access_cidrs" {
  type    = list(string)
  default = ["0.0.0.0/0"]
}
variable "admin_principal_arns" {
  description = "IAM roles that get cluster-admin (your GitLab CI role, your SSO admin role)."
  type        = list(string)
  default     = []
}
variable "alb_controller_chart_version" {
  type    = string
  default = "1.13.0"
}

# ---- dns / tls ----
variable "route53_zone_name" { type = string }
variable "hostname" { type = string }
variable "admin_hostname" {
  type    = string
  default = ""
}
variable "ingress_cidrs" {
  type    = list(string)
  default = ["0.0.0.0/0"]
}

# ---- keycloak ----
variable "keycloak_image" { type = string }
variable "keycloak_replicas" { type = number }
variable "enable_hpa" {
  type    = bool
  default = false
}

# ---- database ----
variable "db_engine_version" { type = string }
variable "db_instance_class" { type = string }
variable "db_instance_count" { type = number }
variable "db_backup_retention_days" { type = number }
variable "deletion_protection" {
  type    = bool
  default = true
}
