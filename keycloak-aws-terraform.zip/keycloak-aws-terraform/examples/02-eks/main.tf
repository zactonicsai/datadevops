###############################################################################
# EXAMPLE 2 - Keycloak on EKS with the AWS Load Balancer Controller
#
# Two-phase apply the first time, because the kubernetes/helm providers need a
# cluster that does not exist yet:
#
#   terraform init  -backend-config=backend-dev.hcl
#   terraform apply -var-file=dev.tfvars -target=module.vpc -target=module.eks
#   terraform apply -var-file=dev.tfvars
#
# In a mature setup, split this into two state files (cluster stack, workload
# stack) instead of using -target. See docs/02-best-practices.md.
###############################################################################

locals {
  name         = "${var.project}-${var.environment}"
  cluster_name = "${var.project}-${var.environment}-eks"

  tags = {
    Project     = var.project
    Environment = var.environment
    Owner       = var.owner
    CostCenter  = var.cost_center
    ManagedBy   = "terraform"
  }
}

module "vpc" {
  source = "../../modules/vpc"

  name                  = local.name
  cidr_block            = var.vpc_cidr
  azs                   = var.azs
  public_subnet_cidrs   = var.public_subnet_cidrs
  private_subnet_cidrs  = var.private_subnet_cidrs
  database_subnet_cidrs = var.database_subnet_cidrs
  single_nat_gateway    = var.single_nat_gateway
  eks_cluster_name      = local.cluster_name
  tags                  = local.tags
}

module "eks" {
  source = "../../modules/eks-cluster"

  cluster_name       = local.cluster_name
  kubernetes_version = var.kubernetes_version
  vpc_id             = module.vpc.vpc_id
  private_subnet_ids = module.vpc.private_subnet_ids
  public_subnet_ids  = module.vpc.public_subnet_ids

  endpoint_public_access = var.endpoint_public_access
  public_access_cidrs    = var.public_access_cidrs
  admin_principal_arns   = var.admin_principal_arns

  node_instance_types = var.node_instance_types
  node_min_size       = var.node_min_size
  node_max_size       = var.node_max_size
  node_desired_size   = var.node_desired_size

  tags = local.tags
}

# ------------------------------ ALB controller ------------------------------
resource "helm_release" "alb_controller" {
  name       = "aws-load-balancer-controller"
  repository = "https://aws.github.io/eks-charts"
  chart      = "aws-load-balancer-controller"
  version    = var.alb_controller_chart_version
  namespace  = "kube-system"

  set {
    name  = "clusterName"
    value = module.eks.cluster_name
  }
  set {
    name  = "region"
    value = var.region
  }
  set {
    name  = "vpcId"
    value = module.vpc.vpc_id
  }
  set {
    name  = "serviceAccount.create"
    value = "true"
  }
  set {
    name  = "serviceAccount.name"
    value = "aws-load-balancer-controller"
  }
  set {
    name  = "serviceAccount.annotations.eks\\.amazonaws\\.com/role-arn"
    value = module.eks.alb_controller_role_arn
  }
  set {
    name  = "enableServiceMutatorWebhook"
    value = "false"
  }

  depends_on = [module.eks]
}

# ------------------------------ TLS certificate -----------------------------
data "aws_route53_zone" "this" {
  name         = var.route53_zone_name
  private_zone = false
}

resource "aws_acm_certificate" "this" {
  domain_name               = var.hostname
  validation_method         = "DNS"
  subject_alternative_names = var.admin_hostname == "" ? [] : [var.admin_hostname]

  lifecycle { create_before_destroy = true }
  tags = local.tags
}

resource "aws_route53_record" "cert_validation" {
  for_each = {
    for dvo in aws_acm_certificate.this.domain_validation_options : dvo.domain_name => {
      name   = dvo.resource_record_name
      record = dvo.resource_record_value
      type   = dvo.resource_record_type
    }
  }

  zone_id         = data.aws_route53_zone.this.zone_id
  name            = each.value.name
  type            = each.value.type
  records         = [each.value.record]
  ttl             = 60
  allow_overwrite = true
}

resource "aws_acm_certificate_validation" "this" {
  certificate_arn         = aws_acm_certificate.this.arn
  validation_record_fqdns = [for r in aws_route53_record.cert_validation : r.fqdn]
}

# ------------------------------ database ------------------------------------
module "database" {
  source = "../../modules/rds-aurora-postgres"

  name                = local.name
  vpc_id              = module.vpc.vpc_id
  database_subnet_ids = module.vpc.database_subnet_ids

  engine_version        = var.db_engine_version
  instance_class        = var.db_instance_class
  instance_count        = var.db_instance_count
  backup_retention_days = var.db_backup_retention_days
  deletion_protection   = var.deletion_protection
  skip_final_snapshot   = var.environment != "prod"

  tags = local.tags
}

# Worker nodes -> Aurora
resource "aws_vpc_security_group_ingress_rule" "db_from_nodes" {
  security_group_id            = module.database.security_group_id
  referenced_security_group_id = module.eks.cluster_security_group_id
  from_port                    = 5432
  to_port                      = 5432
  ip_protocol                  = "tcp"
  description                  = "PostgreSQL from EKS nodes"
}

# ------------------------------ bootstrap admin -----------------------------
resource "random_password" "admin" {
  length           = 32
  special          = true
  override_special = "!#%*-_=+"
}

resource "aws_secretsmanager_secret" "admin" {
  name                    = "${local.name}/keycloak/bootstrap-admin-eks"
  recovery_window_in_days = 7
  tags                    = local.tags
}

resource "aws_secretsmanager_secret_version" "admin" {
  secret_id = aws_secretsmanager_secret.admin.id
  secret_string = jsonencode({
    username = "kc-bootstrap-admin"
    password = random_password.admin.result
  })
}

# ------------------------------ keycloak ------------------------------------
module "keycloak" {
  source = "../../modules/keycloak-k8s"

  name           = "keycloak"
  namespace      = "keycloak"
  keycloak_image = var.keycloak_image
  replicas       = var.keycloak_replicas
  enable_hpa     = var.enable_hpa

  hostname        = var.hostname
  admin_hostname  = var.admin_hostname
  certificate_arn = aws_acm_certificate_validation.this.certificate_arn
  ingress_cidrs   = var.ingress_cidrs

  db_jdbc_url      = module.database.jdbc_url
  db_secret_arn    = module.database.secret_arn
  admin_secret_arn = aws_secretsmanager_secret.admin.arn

  depends_on = [
    helm_release.alb_controller,
    aws_vpc_security_group_ingress_rule.db_from_nodes,
  ]
}

# ------------------------------ DNS -----------------------------------------
resource "aws_route53_record" "keycloak" {
  zone_id = data.aws_route53_zone.this.zone_id
  name    = var.hostname
  type    = "CNAME"
  ttl     = 60
  records = [module.keycloak.alb_hostname]
}
