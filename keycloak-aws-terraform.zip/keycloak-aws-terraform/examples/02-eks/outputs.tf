output "cluster_name" { value = module.eks.cluster_name }

output "kubeconfig_command" {
  value = "aws eks update-kubeconfig --name ${module.eks.cluster_name} --region ${var.region}"
}

output "keycloak_url" { value = "https://${var.hostname}" }
output "ingress_alb_hostname" { value = module.keycloak.alb_hostname }
output "database_endpoint" { value = module.database.cluster_endpoint }
output "bootstrap_admin_secret_arn" { value = aws_secretsmanager_secret.admin.arn }
