# Example 2 — Keycloak on EKS

## What gets created

* The same 3-tier VPC, tagged for the AWS Load Balancer Controller
* EKS cluster: API-mode access entries, KMS envelope encryption for secrets,
  control-plane logs, managed node group in private subnets, core addons
* IRSA role for the AWS Load Balancer Controller + the Helm release
* Aurora PostgreSQL
* Keycloak StatefulSet (3 replicas), headless service for DNS_PING cluster
  discovery, PodDisruptionBudget, optional HPA
* Ingress -> ALB with the ACM certificate, sticky sessions and
  `/health/ready:9000` health checks

## Run it (first time: two phases)

The `kubernetes` and `helm` providers need a cluster that does not exist yet,
so create the cluster first:

```bash
terraform init  -backend-config=backend-dev.hcl
terraform apply -var-file=dev.tfvars -target=module.vpc -target=module.eks
terraform apply -var-file=dev.tfvars
```

Afterwards a plain `terraform apply -var-file=dev.tfvars` is enough.

> In a mature setup, split this into two stacks with two state files — a
> cluster stack and a workload stack — instead of using `-target`.

## Access the cluster

```bash
aws eks update-kubeconfig --name keycloak-dev-eks --region eu-west-1
kubectl -n keycloak get pods -o wide
kubectl -n keycloak logs sts/keycloak -f
kubectl -n keycloak get ingress keycloak
```

Confirm the cluster formed (you should see the other members listed):

```bash
kubectl -n keycloak logs sts/keycloak | grep -i "ISPN000094\|view accepted"
```

## Notes

* Put your **CI role ARN** in `admin_principal_arns`, or the pipeline cannot
  authenticate to the cluster.
* The shipped module reads the database secret through a Terraform data source,
  which places it in state. Before production, switch to the **Secrets Store CSI
  driver** or **External Secrets Operator** — see `docs/02-best-practices.md`.
* `endpoint_public_access = false` in `prod.tfvars` means you need a VPN, a
  private runner or an SSM port-forward to reach the Kubernetes API.
* The ALB controller IAM policy is fetched from the upstream repo at plan time.
  If your CI has no internet egress, vendor `iam_policy.json` next to the module
  and swap the `data.http` block for `file(...)`.
