output "cluster_endpoint" { value = aws_rds_cluster.this.endpoint }
output "reader_endpoint" { value = aws_rds_cluster.this.reader_endpoint }
output "database_name" { value = aws_rds_cluster.this.database_name }
output "master_username" { value = aws_rds_cluster.this.master_username }
output "security_group_id" { value = aws_security_group.db.id }
output "kms_key_arn" { value = aws_kms_key.db.arn }

output "secret_arn" {
  description = "Secrets Manager secret holding the DB credentials JSON."
  value       = aws_secretsmanager_secret.db.arn
}

output "jdbc_url" {
  value = "jdbc:postgresql://${aws_rds_cluster.this.endpoint}:5432/${aws_rds_cluster.this.database_name}"
}
