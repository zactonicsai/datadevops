variable "name" {
  description = "Name prefix, e.g. keycloak-prod."
  type        = string
}

variable "vpc_id" { type = string }

variable "database_subnet_ids" {
  description = "Isolated subnets for the Aurora cluster (>= 2 AZs)."
  type        = list(string)
}

variable "allowed_security_group_ids" {
  description = "Security groups allowed to reach port 5432 (Keycloak nodes / EKS nodes)."
  type        = list(string)
  default     = []
}

variable "database_name" {
  type    = string
  default = "keycloak"
}

variable "master_username" {
  type    = string
  default = "kcadmin"
}

variable "engine_version" {
  description = "Aurora PostgreSQL version. Keycloak 26 supports PostgreSQL 13-17."
  type        = string
  default     = "16.6"
}

variable "instance_class" {
  description = "db.serverless for Aurora Serverless v2, or e.g. db.r6g.large."
  type        = string
  default     = "db.serverless"
}

variable "instance_count" {
  description = "1 writer + (n-1) readers. Use >= 2 in production for Multi-AZ failover."
  type        = number
  default     = 2
}

variable "serverless_min_capacity" {
  type    = number
  default = 0.5
}

variable "serverless_max_capacity" {
  type    = number
  default = 8
}

variable "backup_retention_days" {
  type    = number
  default = 14
}

variable "deletion_protection" {
  type    = bool
  default = true
}

variable "skip_final_snapshot" {
  type    = bool
  default = false
}

variable "performance_insights_enabled" {
  type    = bool
  default = true
}

variable "tags" {
  type    = map(string)
  default = {}
}
