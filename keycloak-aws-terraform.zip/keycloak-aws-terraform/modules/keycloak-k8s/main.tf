###############################################################################
# Keycloak on EKS
#  - StatefulSet: stable pod identities make Infinispan rebalancing predictable
#  - Headless service + DNS_PING (KC_CACHE_STACK=kubernetes) for cluster discovery
#  - Ingress -> AWS Load Balancer Controller -> ALB with the ACM cert
#  - Health checks on the management port 9000 (/health/ready)
###############################################################################

locals {
  labels = merge({
    "app.kubernetes.io/name"       = var.name
    "app.kubernetes.io/component"  = "sso"
    "app.kubernetes.io/managed-by" = "terraform"
  }, var.labels)
}

resource "kubernetes_namespace_v1" "this" {
  metadata {
    name   = var.namespace
    labels = local.labels
  }
}

# ---------------------------------------------------------------------------
# Credentials
#
# NOTE: reading secrets through a Terraform data source puts the plaintext in
# Terraform state. Use an encrypted S3 backend, or better, replace this block
# with the Secrets Store CSI driver / External Secrets Operator so the value
# never touches Terraform at all. See docs/02-best-practices.md.
# ---------------------------------------------------------------------------
data "aws_secretsmanager_secret_version" "db" {
  secret_id = var.db_secret_arn
}

data "aws_secretsmanager_secret_version" "admin" {
  secret_id = var.admin_secret_arn
}

resource "kubernetes_secret_v1" "keycloak" {
  metadata {
    name      = "${var.name}-credentials"
    namespace = kubernetes_namespace_v1.this.metadata[0].name
    labels    = local.labels
  }

  data = {
    KC_DB_USERNAME              = jsondecode(data.aws_secretsmanager_secret_version.db.secret_string)["username"]
    KC_DB_PASSWORD              = jsondecode(data.aws_secretsmanager_secret_version.db.secret_string)["password"]
    KC_BOOTSTRAP_ADMIN_USERNAME = jsondecode(data.aws_secretsmanager_secret_version.admin.secret_string)["username"]
    KC_BOOTSTRAP_ADMIN_PASSWORD = jsondecode(data.aws_secretsmanager_secret_version.admin.secret_string)["password"]
  }

  type = "Opaque"
}

resource "kubernetes_service_account_v1" "this" {
  metadata {
    name      = var.name
    namespace = kubernetes_namespace_v1.this.metadata[0].name
    labels    = local.labels
  }
}

# ------------------------------ services ------------------------------------
# Headless service: its DNS A records are how JGroups finds the other pods.
resource "kubernetes_service_v1" "headless" {
  metadata {
    name      = "${var.name}-headless"
    namespace = kubernetes_namespace_v1.this.metadata[0].name
    labels    = local.labels
  }

  spec {
    cluster_ip                  = "None"
    publish_not_ready_addresses = true
    selector                    = { "app.kubernetes.io/name" = var.name }

    port {
      name        = "jgroups"
      port        = 7800
      target_port = 7800
    }
  }
}

resource "kubernetes_service_v1" "this" {
  metadata {
    name      = var.name
    namespace = kubernetes_namespace_v1.this.metadata[0].name
    labels    = local.labels
  }

  spec {
    type     = "ClusterIP"
    selector = { "app.kubernetes.io/name" = var.name }

    port {
      name        = "http"
      port        = 8080
      target_port = 8080
    }

    port {
      name        = "management"
      port        = 9000
      target_port = 9000
    }
  }
}

# ------------------------------ workload ------------------------------------
resource "kubernetes_stateful_set_v1" "this" {
  metadata {
    name      = var.name
    namespace = kubernetes_namespace_v1.this.metadata[0].name
    labels    = local.labels
  }

  spec {
    service_name          = kubernetes_service_v1.headless.metadata[0].name
    replicas              = var.replicas
    pod_management_policy = "Parallel"

    selector {
      match_labels = { "app.kubernetes.io/name" = var.name }
    }

    update_strategy {
      type = "RollingUpdate"
    }

    template {
      metadata {
        labels = merge(local.labels, { "app.kubernetes.io/name" = var.name })
      }

      spec {
        service_account_name             = kubernetes_service_account_v1.this.metadata[0].name
        termination_grace_period_seconds = 60

        # Spread pods across AZs so one AZ failure cannot take the cluster down.
        topology_spread_constraint {
          max_skew           = 1
          topology_key       = "topology.kubernetes.io/zone"
          when_unsatisfiable = "ScheduleAnyway"
          label_selector {
            match_labels = { "app.kubernetes.io/name" = var.name }
          }
        }

        security_context {
          run_as_non_root = true
          run_as_user     = 1000
          fs_group        = 1000
          seccomp_profile { type = "RuntimeDefault" }
        }

        container {
          name  = "keycloak"
          image = var.keycloak_image
          args  = ["start"] # use ["start","--optimized"] with a pre-built image

          security_context {
            allow_privilege_escalation = false
            read_only_root_filesystem  = false
            capabilities { drop = ["ALL"] }
          }

          port {
            name           = "http"
            container_port = 8080
          }
          port {
            name           = "management"
            container_port = 9000
          }
          port {
            name           = "jgroups"
            container_port = 7800
          }

          env_from {
            secret_ref { name = kubernetes_secret_v1.keycloak.metadata[0].name }
          }

          env {
            name  = "KC_DB"
            value = "postgres"
          }
          env {
            name  = "KC_DB_URL"
            value = "${var.db_jdbc_url}?sslmode=require"
          }
          env {
            name  = "KC_HOSTNAME"
            value = "https://${var.hostname}"
          }
          dynamic "env" {
            for_each = var.admin_hostname == "" ? [] : [1]
            content {
              name  = "KC_HOSTNAME_ADMIN"
              value = "https://${var.admin_hostname}"
            }
          }
          env {
            name  = "KC_HOSTNAME_STRICT"
            value = "true"
          }
          env {
            name  = "KC_PROXY_HEADERS"
            value = "xforwarded"
          }
          env {
            name  = "KC_HTTP_ENABLED"
            value = "true"
          }
          env {
            name  = "KC_HEALTH_ENABLED"
            value = "true"
          }
          env {
            name  = "KC_METRICS_ENABLED"
            value = "true"
          }
          env {
            name  = "KC_CACHE"
            value = "ispn"
          }
          env {
            name  = "KC_CACHE_STACK"
            value = "kubernetes" # DNS_PING against the headless service
          }
          env {
            name  = "JAVA_OPTS_APPEND"
            value = "-Djgroups.dns.query=${kubernetes_service_v1.headless.metadata[0].name}.${var.namespace}.svc.cluster.local -XX:MaxRAMPercentage=70"
          }
          env {
            name  = "KC_LOG_CONSOLE_OUTPUT"
            value = "json"
          }
          env {
            name = "KC_CACHE_EMBEDDED_NETWORK_BIND_ADDRESS"
            value_from {
              field_ref { field_path = "status.podIP" }
            }
          }

          resources {
            requests = {
              cpu    = var.resources.requests_cpu
              memory = var.resources.requests_memory
            }
            limits = {
              cpu    = var.resources.limits_cpu
              memory = var.resources.limits_memory
            }
          }

          # Startup probe gives the JVM room to boot before liveness kicks in.
          startup_probe {
            http_get {
              path = "/health/started"
              port = 9000
            }
            period_seconds    = 10
            failure_threshold = 60
          }

          readiness_probe {
            http_get {
              path = "/health/ready"
              port = 9000
            }
            period_seconds    = 10
            failure_threshold = 3
          }

          liveness_probe {
            http_get {
              path = "/health/live"
              port = 9000
            }
            period_seconds    = 15
            failure_threshold = 5
          }
        }
      }
    }
  }

  timeouts { create = "20m" }
}

resource "kubernetes_pod_disruption_budget_v1" "this" {
  metadata {
    name      = var.name
    namespace = kubernetes_namespace_v1.this.metadata[0].name
    labels    = local.labels
  }

  spec {
    min_available = 2
    selector {
      match_labels = { "app.kubernetes.io/name" = var.name }
    }
  }
}

# ------------------------------ ingress (ALB) -------------------------------
resource "kubernetes_ingress_v1" "this" {
  metadata {
    name      = var.name
    namespace = kubernetes_namespace_v1.this.metadata[0].name
    labels    = local.labels

    annotations = {
      "alb.ingress.kubernetes.io/scheme"                = var.internal_alb ? "internal" : "internet-facing"
      "alb.ingress.kubernetes.io/target-type"           = "ip"
      "alb.ingress.kubernetes.io/certificate-arn"       = var.certificate_arn
      "alb.ingress.kubernetes.io/ssl-policy"            = "ELBSecurityPolicy-TLS13-1-2-2021-06"
      "alb.ingress.kubernetes.io/listen-ports"          = jsonencode([{ HTTP = 80 }, { HTTPS = 443 }])
      "alb.ingress.kubernetes.io/ssl-redirect"          = "443"
      "alb.ingress.kubernetes.io/inbound-cidrs"         = join(",", var.ingress_cidrs)
      "alb.ingress.kubernetes.io/healthcheck-protocol"  = "HTTP"
      "alb.ingress.kubernetes.io/healthcheck-port"      = "9000"
      "alb.ingress.kubernetes.io/healthcheck-path"      = "/health/ready"
      "alb.ingress.kubernetes.io/success-codes"         = "200"
      "alb.ingress.kubernetes.io/target-group-attributes" = "stickiness.enabled=true,stickiness.type=lb_cookie,stickiness.lb_cookie.duration_seconds=3600,deregistration_delay.timeout_seconds=60"
      "alb.ingress.kubernetes.io/load-balancer-attributes" = "idle_timeout.timeout_seconds=120,routing.http.drop_invalid_header_fields.enabled=true"
      "alb.ingress.kubernetes.io/group.name"            = var.name
    }
  }

  spec {
    ingress_class_name = "alb"

    rule {
      host = var.hostname
      http {
        path {
          path      = "/"
          path_type = "Prefix"
          backend {
            service {
              name = kubernetes_service_v1.this.metadata[0].name
              port { number = 8080 }
            }
          }
        }
      }
    }
  }

  wait_for_load_balancer = true
}

# ------------------------------ optional HPA --------------------------------
resource "kubernetes_horizontal_pod_autoscaler_v2" "this" {
  count = var.enable_hpa ? 1 : 0

  metadata {
    name      = var.name
    namespace = kubernetes_namespace_v1.this.metadata[0].name
    labels    = local.labels
  }

  spec {
    min_replicas = var.replicas
    max_replicas = var.hpa_max_replicas

    scale_target_ref {
      api_version = "apps/v1"
      kind        = "StatefulSet"
      name        = kubernetes_stateful_set_v1.this.metadata[0].name
    }

    metric {
      type = "Resource"
      resource {
        name = "cpu"
        target {
          type                = "Utilization"
          average_utilization = 60
        }
      }
    }

    behavior {
      scale_down {
        stabilization_window_seconds = 600 # avoid cache-rebalance thrash
        policy {
          type           = "Pods"
          value          = 1
          period_seconds = 300
        }
      }
      scale_up {
        stabilization_window_seconds = 60
        policy {
          type           = "Pods"
          value          = 2
          period_seconds = 60
        }
      }
    }
  }
}
