variable "namespace" {
  type    = string
  default = "keycloak"
}

variable "name" {
  type    = string
  default = "keycloak"
}

variable "keycloak_image" {
  type    = string
  default = "quay.io/keycloak/keycloak:26.4.0"
}

variable "replicas" {
  description = "Keycloak scales horizontally; 3 is the usual production floor."
  type        = number
  default     = 3
}

variable "hostname" {
  description = "Public hostname, e.g. sso.example.com."
  type        = string
}

variable "admin_hostname" {
  type    = string
  default = ""
}

variable "certificate_arn" {
  description = "ACM cert ARN attached to the ALB created by the ingress."
  type        = string
}

variable "internal_alb" {
  type    = bool
  default = false
}

variable "ingress_cidrs" {
  type    = list(string)
  default = ["0.0.0.0/0"]
}

variable "db_jdbc_url" { type = string }

variable "db_secret_arn" {
  description = "Secrets Manager secret with the DB credentials JSON."
  type        = string
}

variable "admin_secret_arn" {
  description = "Secrets Manager secret with the Keycloak bootstrap admin credentials."
  type        = string
}

variable "resources" {
  description = "Requests/limits. Keycloak is JVM based - set requests generously."
  type = object({
    requests_cpu    = string
    requests_memory = string
    limits_cpu      = string
    limits_memory   = string
  })
  default = {
    requests_cpu    = "1"
    requests_memory = "2Gi"
    limits_cpu      = "2"
    limits_memory   = "3Gi"
  }
}

variable "enable_hpa" {
  description = "Requires metrics-server. Scale-out triggers Infinispan rebalancing, so keep it conservative."
  type        = bool
  default     = false
}

variable "hpa_max_replicas" {
  type    = number
  default = 8
}

variable "labels" {
  type    = map(string)
  default = {}
}
