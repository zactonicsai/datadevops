output "namespace" { value = kubernetes_namespace_v1.this.metadata[0].name }
output "service_name" { value = kubernetes_service_v1.this.metadata[0].name }

output "alb_hostname" {
  description = "DNS name of the ALB created by the AWS Load Balancer Controller. Point your Route 53 alias at this."
  value       = try(kubernetes_ingress_v1.this.status[0].load_balancer[0].ingress[0].hostname, null)
}
