###############################################################################
# Realm configuration as code.
#
# Run this AFTER the infrastructure stack: the provider talks to the live
# Keycloak admin API, so the service must already be reachable.
# Keep it in a separate state file so an app-team change to a client can never
# accidentally destroy a database.
###############################################################################

resource "keycloak_realm" "this" {
  realm        = var.realm_name
  display_name = var.display_name != "" ? var.display_name : var.realm_name
  enabled      = true

  login_theme   = var.login_theme
  account_theme = "keycloak.v3"

  # --- login behaviour ---
  registration_allowed         = false
  registration_email_as_username = false
  reset_password_allowed       = true
  remember_me                  = true
  verify_email                 = true
  login_with_email_allowed     = true
  duplicate_emails_allowed     = false
  ssl_required                 = "external" # HTTPS required for anything non-local

  # --- token / session lifetimes ---
  sso_session_idle_timeout = var.sso_session_idle_timeout
  sso_session_max_lifespan = var.sso_session_max_lifespan
  access_token_lifespan    = var.access_token_lifespan
  refresh_token_max_reuse  = 0 # refresh token rotation

  password_policy = var.password_policy

  security_defenses {
    headers {
      x_frame_options                     = "DENY"
      content_security_policy             = "frame-src 'self'; frame-ancestors 'self'; object-src 'none';"
      content_security_policy_report_only = ""
      x_content_type_options              = "nosniff"
      x_robots_tag                        = "none"
      x_xss_protection                    = "1; mode=block"
      strict_transport_security           = "max-age=31536000; includeSubDomains"
    }

    brute_force_detection {
      permanent_lockout                = false
      max_login_failures               = var.brute_force.max_login_failures
      wait_increment_seconds           = var.brute_force.wait_increment_seconds
      quick_login_check_milli_seconds  = 1000
      minimum_quick_login_wait_seconds = 60
      max_failure_wait_seconds         = var.brute_force.max_failure_wait_seconds
      failure_reset_time_seconds       = var.brute_force.failure_reset_time_seconds
    }
  }

  dynamic "smtp_server" {
    for_each = var.smtp == null ? [] : [var.smtp]
    content {
      host              = smtp_server.value.host
      port              = smtp_server.value.port
      from              = smtp_server.value.from
      from_display_name = smtp_server.value.from_display_name
      ssl               = smtp_server.value.ssl
      starttls          = smtp_server.value.starttls

      auth {
        username = smtp_server.value.username
        password = smtp_server.value.password
      }
    }
  }
}

# --- audit -------------------------------------------------------------------
resource "keycloak_realm_events" "this" {
  realm_id = keycloak_realm.this.id

  events_enabled    = true
  events_expiration = "2592000s" # 30 days

  admin_events_enabled         = true
  admin_events_details_enabled = true

  enabled_event_types = [
    "LOGIN", "LOGIN_ERROR", "LOGOUT", "LOGOUT_ERROR",
    "CODE_TO_TOKEN", "CODE_TO_TOKEN_ERROR",
    "REFRESH_TOKEN", "REFRESH_TOKEN_ERROR",
    "UPDATE_PASSWORD", "UPDATE_PASSWORD_ERROR",
    "REGISTER", "REGISTER_ERROR",
    "IMPERSONATE", "PERMISSION_TOKEN",
  ]

  events_listeners = ["jboss-logging"]
}

# --- roles -------------------------------------------------------------------
resource "keycloak_role" "realm" {
  for_each    = var.realm_roles
  realm_id    = keycloak_realm.this.id
  name        = each.key
  description = each.value
}

# --- groups ------------------------------------------------------------------
resource "keycloak_group" "this" {
  for_each = var.groups
  realm_id = keycloak_realm.this.id
  name     = each.key
}

resource "keycloak_group_roles" "this" {
  for_each = var.groups
  realm_id = keycloak_realm.this.id
  group_id = keycloak_group.this[each.key].id
  role_ids = [for r in each.value : keycloak_role.realm[r].id]
}

# --- clients -----------------------------------------------------------------
resource "keycloak_openid_client" "this" {
  for_each = var.clients

  realm_id    = keycloak_realm.this.id
  client_id   = each.key
  name        = each.value.name
  description = each.value.description
  enabled     = true

  access_type = each.value.access_type
  root_url    = each.value.root_url != "" ? each.value.root_url : null

  valid_redirect_uris             = each.value.valid_redirect_uris
  valid_post_logout_redirect_uris = each.value.valid_post_logout_redirect_uris
  web_origins                     = each.value.web_origins

  standard_flow_enabled        = each.value.standard_flow_enabled
  implicit_flow_enabled        = false # deprecated and insecure - never enable
  direct_access_grants_enabled = each.value.direct_access_grants_enabled
  service_accounts_enabled     = each.value.service_accounts_enabled

  # PKCE is mandatory for public clients and good hygiene for confidential ones.
  pkce_code_challenge_method = each.value.pkce_code_challenge_method

  login_theme                  = var.login_theme
  backchannel_logout_session_required = true
}

resource "keycloak_openid_client_default_scopes" "this" {
  for_each = var.clients

  realm_id       = keycloak_realm.this.id
  client_id      = keycloak_openid_client.this[each.key].id
  default_scopes = each.value.default_scopes
}

resource "keycloak_openid_client_optional_scopes" "this" {
  for_each = var.clients

  realm_id        = keycloak_realm.this.id
  client_id       = keycloak_openid_client.this[each.key].id
  optional_scopes = each.value.optional_scopes
}

locals {
  client_roles = merge([
    for client_id, cfg in var.clients : {
      for role in cfg.client_roles : "${client_id}:${role}" => {
        client_id = client_id
        role      = role
      }
    }
  ]...)
}

resource "keycloak_role" "client" {
  for_each = local.client_roles

  realm_id  = keycloak_realm.this.id
  client_id = keycloak_openid_client.this[each.value.client_id].id
  name      = each.value.role
}
