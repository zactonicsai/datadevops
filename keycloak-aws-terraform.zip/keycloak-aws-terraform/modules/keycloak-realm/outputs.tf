output "realm_id" { value = keycloak_realm.this.id }

output "client_ids" {
  value = { for k, v in keycloak_openid_client.this : k => v.id }
}

output "client_secrets" {
  description = "Confidential client secrets. Push these into Secrets Manager, do not print them in CI logs."
  value       = { for k, v in keycloak_openid_client.this : k => v.client_secret }
  sensitive   = true
}

output "issuer_url" {
  value = keycloak_realm.this.realm
}
