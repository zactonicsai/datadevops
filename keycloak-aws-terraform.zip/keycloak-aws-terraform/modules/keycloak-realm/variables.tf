variable "realm_name" {
  description = "Realm id, e.g. corp. Never put applications in the 'master' realm."
  type        = string
}

variable "display_name" {
  type    = string
  default = ""
}

variable "login_theme" {
  type    = string
  default = "keycloak"
}

variable "sso_session_idle_timeout" {
  type    = string
  default = "30m"
}

variable "sso_session_max_lifespan" {
  type    = string
  default = "10h"
}

variable "access_token_lifespan" {
  type    = string
  default = "5m"
}

variable "password_policy" {
  description = "Keycloak password policy string."
  type        = string
  default     = "length(12) and upperCase(1) and lowerCase(1) and digits(1) and specialChars(1) and notUsername and passwordHistory(5) and forceExpiredPasswordChange(365) and hashAlgorithm(argon2)"
}

variable "smtp" {
  description = "SMTP settings (e.g. Amazon SES). Password comes from a TF_VAR / CI variable."
  type = object({
    host              = string
    port              = string
    from              = string
    from_display_name = string
    ssl               = bool
    starttls          = bool
    username          = string
    password          = string
  })
  default   = null
  sensitive = true
}

variable "clients" {
  description = <<-EOT
    Map of OIDC clients.
      access_type: "CONFIDENTIAL" (server-side app), "PUBLIC" (SPA/mobile, PKCE), "BEARER-ONLY" (API)
  EOT
  type = map(object({
    name                         = string
    description                  = optional(string, "")
    access_type                  = optional(string, "CONFIDENTIAL")
    valid_redirect_uris          = optional(list(string), [])
    valid_post_logout_redirect_uris = optional(list(string), [])
    web_origins                  = optional(list(string), [])
    root_url                     = optional(string, "")
    standard_flow_enabled        = optional(bool, true)
    direct_access_grants_enabled = optional(bool, false)
    service_accounts_enabled     = optional(bool, false)
    pkce_code_challenge_method   = optional(string, "S256")
    default_scopes               = optional(list(string), ["profile", "email", "roles", "web-origins", "acr", "basic"])
    optional_scopes              = optional(list(string), ["address", "phone", "offline_access"])
    client_roles                 = optional(list(string), [])
  }))
  default = {}
}

variable "realm_roles" {
  description = "Realm-level roles: role name -> description."
  type        = map(string)
  default     = {}
}

variable "groups" {
  description = "Group name -> list of realm roles granted to that group."
  type        = map(list(string))
  default     = {}
}

variable "brute_force" {
  type = object({
    enabled                    = bool
    max_login_failures         = number
    wait_increment_seconds     = number
    max_failure_wait_seconds   = number
    failure_reset_time_seconds = number
  })
  default = {
    enabled                    = true
    max_login_failures         = 10
    wait_increment_seconds     = 60
    max_failure_wait_seconds   = 900
    failure_reset_time_seconds = 43200
  }
}
