output "alb_dns_name" { value = aws_lb.this.dns_name }
output "alb_zone_id" { value = aws_lb.this.zone_id }
output "alb_arn" { value = aws_lb.this.arn }
output "target_group_arn" { value = aws_lb_target_group.this.arn }
output "node_security_group_id" { value = aws_security_group.node.id }
output "autoscaling_group_name" { value = aws_autoscaling_group.this.name }
output "log_group_name" { value = aws_cloudwatch_log_group.keycloak.name }
