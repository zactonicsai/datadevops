variable "name" {
  description = "Name prefix, e.g. keycloak-prod."
  type        = string
}

variable "vpc_id" { type = string }

variable "public_subnet_ids" {
  description = "Subnets for the ALB (public for internet-facing, private for internal)."
  type        = list(string)
}

variable "private_subnet_ids" {
  description = "Subnets for the Keycloak EC2 instances. Always private."
  type        = list(string)
}

variable "internal_alb" {
  description = "true = internal ALB (private hostname only)."
  type        = bool
  default     = false
}

variable "certificate_arn" {
  description = "ACM certificate ARN for the Keycloak hostname."
  type        = string
}

variable "hostname" {
  description = "Public hostname, e.g. sso.example.com. Keycloak MUST know this (KC_HOSTNAME)."
  type        = string
}

variable "admin_hostname" {
  description = "Optional separate hostname for /admin, e.g. sso-admin.internal.example.com."
  type        = string
  default     = ""
}

variable "ingress_cidrs" {
  description = "CIDRs allowed to hit the ALB on 443. Lock the admin path down separately."
  type        = list(string)
  default     = ["0.0.0.0/0"]
}

variable "keycloak_image" {
  description = "Container image. Pin an exact tag; do not use 'latest'."
  type        = string
  default     = "quay.io/keycloak/keycloak:26.4.0"
}

variable "instance_type" {
  type    = string
  default = "m7i-flex.large"
}

variable "min_size" {
  type    = number
  default = 2
}

variable "max_size" {
  type    = number
  default = 6
}

variable "desired_capacity" {
  type    = number
  default = 2
}

variable "cpu_target_value" {
  description = "Target-tracking CPU % for the ASG scaling policy."
  type        = number
  default = 55
}

variable "db_jdbc_url" { type = string }
variable "db_secret_arn" {
  description = "Secrets Manager secret with {username,password} for the DB."
  type        = string
}
variable "db_kms_key_arn" { type = string }

variable "admin_secret_arn" {
  description = "Secrets Manager secret with {username,password} for the Keycloak bootstrap admin."
  type        = string
}

variable "log_retention_days" {
  type    = number
  default = 90
}

variable "enable_deletion_protection" {
  type    = bool
  default = true
}

variable "access_logs_bucket" {
  description = "Optional S3 bucket for ALB access logs."
  type        = string
  default     = ""
}

variable "tags" {
  type    = map(string)
  default = {}
}
