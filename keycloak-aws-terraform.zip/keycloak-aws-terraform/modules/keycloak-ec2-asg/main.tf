###############################################################################
# Keycloak on EC2 Auto Scaling behind an Application Load Balancer
#
# Design notes:
#  - TLS terminates on the ALB (ACM cert). Keycloak listens on plain HTTP 8080
#    inside the VPC and trusts X-Forwarded-* headers (KC_PROXY_HEADERS).
#  - Management port 9000 serves /health/ready and /metrics -> used for the
#    ALB health check and never exposed publicly.
#  - Cluster discovery uses JDBC_PING (Keycloak >= 26.2), so nodes find each
#    other through the shared database. No multicast, no extra infrastructure.
#  - Sticky sessions are ON so a user keeps hitting the node holding their
#    session owner entry. Keycloak still works without it, just slower.
###############################################################################

data "aws_region" "current" {}
data "aws_caller_identity" "current" {}

data "aws_ssm_parameter" "al2023" {
  name = "/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64"
}

# ------------------------------ security groups -----------------------------
resource "aws_security_group" "alb" {
  name        = "${var.name}-alb"
  description = "Keycloak ALB"
  vpc_id      = var.vpc_id
  tags        = merge(var.tags, { Name = "${var.name}-alb" })
}

resource "aws_vpc_security_group_ingress_rule" "alb_https" {
  for_each          = toset(var.ingress_cidrs)
  security_group_id = aws_security_group.alb.id
  cidr_ipv4         = each.value
  from_port         = 443
  to_port           = 443
  ip_protocol       = "tcp"
  description       = "HTTPS"
}

resource "aws_vpc_security_group_ingress_rule" "alb_http_redirect" {
  for_each          = toset(var.ingress_cidrs)
  security_group_id = aws_security_group.alb.id
  cidr_ipv4         = each.value
  from_port         = 80
  to_port           = 80
  ip_protocol       = "tcp"
  description       = "HTTP -> redirected to HTTPS"
}

resource "aws_vpc_security_group_egress_rule" "alb_to_nodes" {
  security_group_id            = aws_security_group.alb.id
  referenced_security_group_id = aws_security_group.node.id
  from_port                    = 8080
  to_port                      = 9000
  ip_protocol                  = "tcp"
  description                  = "App + management ports"
}

resource "aws_security_group" "node" {
  name        = "${var.name}-node"
  description = "Keycloak EC2 nodes"
  vpc_id      = var.vpc_id
  tags        = merge(var.tags, { Name = "${var.name}-node" })
}

resource "aws_vpc_security_group_ingress_rule" "node_http" {
  security_group_id            = aws_security_group.node.id
  referenced_security_group_id = aws_security_group.alb.id
  from_port                    = 8080
  to_port                      = 8080
  ip_protocol                  = "tcp"
  description                  = "HTTP from ALB"
}

resource "aws_vpc_security_group_ingress_rule" "node_mgmt" {
  security_group_id            = aws_security_group.node.id
  referenced_security_group_id = aws_security_group.alb.id
  from_port                    = 9000
  to_port                      = 9000
  ip_protocol                  = "tcp"
  description                  = "Health checks from ALB"
}

# Infinispan / JGroups traffic between Keycloak nodes.
resource "aws_vpc_security_group_ingress_rule" "node_jgroups_tcp" {
  security_group_id            = aws_security_group.node.id
  referenced_security_group_id = aws_security_group.node.id
  from_port                    = 7800
  to_port                      = 7801
  ip_protocol                  = "tcp"
  description                  = "JGroups cluster traffic"
}

resource "aws_vpc_security_group_egress_rule" "node_all" {
  security_group_id = aws_security_group.node.id
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"
  description       = "Outbound (DB, Secrets Manager, image registry)"
}

# ------------------------------ IAM -----------------------------------------
resource "aws_iam_role" "node" {
  name = "${var.name}-node"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ec2.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
  tags = var.tags
}

# SSM Session Manager instead of SSH keys and bastion hosts.
resource "aws_iam_role_policy_attachment" "ssm" {
  role       = aws_iam_role.node.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
}

resource "aws_iam_role_policy_attachment" "cwagent" {
  role       = aws_iam_role.node.name
  policy_arn = "arn:aws:iam::aws:policy/CloudWatchAgentServerPolicy"
}

resource "aws_iam_role_policy" "secrets" {
  name = "${var.name}-secrets"
  role = aws_iam_role.node.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = ["secretsmanager:GetSecretValue"]
        Resource = [var.db_secret_arn, var.admin_secret_arn]
      },
      {
        Effect   = "Allow"
        Action   = ["kms:Decrypt"]
        Resource = [var.db_kms_key_arn]
      }
    ]
  })
}

resource "aws_iam_instance_profile" "node" {
  name = "${var.name}-node"
  role = aws_iam_role.node.name
  tags = var.tags
}

# ------------------------------ logging -------------------------------------
resource "aws_cloudwatch_log_group" "keycloak" {
  name              = "/keycloak/${var.name}"
  retention_in_days = var.log_retention_days
  tags              = var.tags
}

# ------------------------------ launch template -----------------------------
locals {
  user_data = templatefile("${path.module}/templates/user_data.sh.tftpl", {
    region            = data.aws_region.current.name
    keycloak_image    = var.keycloak_image
    hostname          = var.hostname
    admin_hostname    = var.admin_hostname
    db_jdbc_url       = var.db_jdbc_url
    db_secret_arn     = var.db_secret_arn
    admin_secret_arn  = var.admin_secret_arn
    log_group         = aws_cloudwatch_log_group.keycloak.name
    cluster_name      = var.name
  })
}

resource "aws_launch_template" "this" {
  name_prefix   = "${var.name}-"
  image_id      = data.aws_ssm_parameter.al2023.value
  instance_type = var.instance_type
  user_data     = base64encode(local.user_data)

  iam_instance_profile { arn = aws_iam_instance_profile.node.arn }

  vpc_security_group_ids = [aws_security_group.node.id]

  # IMDSv2 only - blocks the classic SSRF credential-theft path.
  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = "required"
    http_put_response_hop_limit = 2 # container needs 2 hops
    instance_metadata_tags      = "enabled"
  }

  block_device_mappings {
    device_name = "/dev/xvda"
    ebs {
      volume_size           = 30
      volume_type           = "gp3"
      encrypted             = true
      delete_on_termination = true
    }
  }

  monitoring { enabled = true }

  tag_specifications {
    resource_type = "instance"
    tags          = merge(var.tags, { Name = "${var.name}-node" })
  }

  lifecycle { create_before_destroy = true }
  tags = var.tags
}

# ------------------------------ load balancer -------------------------------
resource "aws_lb" "this" {
  name               = substr(var.name, 0, 32)
  load_balancer_type = "application"
  internal           = var.internal_alb
  subnets            = var.public_subnet_ids
  security_groups    = [aws_security_group.alb.id]

  enable_deletion_protection = var.enable_deletion_protection
  drop_invalid_header_fields = true
  idle_timeout               = 120

  dynamic "access_logs" {
    for_each = var.access_logs_bucket == "" ? [] : [1]
    content {
      bucket  = var.access_logs_bucket
      prefix  = var.name
      enabled = true
    }
  }

  tags = var.tags
}

resource "aws_lb_target_group" "this" {
  name        = substr("${var.name}-tg", 0, 32)
  port        = 8080
  protocol    = "HTTP"
  vpc_id      = var.vpc_id
  target_type = "instance"

  # Give Keycloak time to boot and join the cluster before draining old nodes.
  deregistration_delay = 60
  slow_start           = 60

  health_check {
    enabled             = true
    path                = "/health/ready"
    port                = "9000" # management port, not the traffic port
    protocol            = "HTTP"
    matcher             = "200"
    interval            = 15
    timeout             = 5
    healthy_threshold   = 2
    unhealthy_threshold = 3
  }

  stickiness {
    type            = "lb_cookie"
    cookie_duration = 3600
    enabled         = true
  }

  lifecycle { create_before_destroy = true }
  tags = var.tags
}

resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.this.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"
  certificate_arn   = var.certificate_arn

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.this.arn
  }

  tags = var.tags
}

resource "aws_lb_listener" "http_redirect" {
  load_balancer_arn = aws_lb.this.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type = "redirect"
    redirect {
      port        = "443"
      protocol    = "HTTPS"
      status_code = "HTTP_301"
    }
  }

  tags = var.tags
}

# Block the admin console at the edge unless the request comes from a
# trusted CIDR. Cheap, effective, and independent of Keycloak config.
resource "aws_lb_listener_rule" "block_admin" {
  count        = length(var.ingress_cidrs) == 1 && var.ingress_cidrs[0] == "0.0.0.0/0" ? 1 : 0
  listener_arn = aws_lb_listener.https.arn
  priority     = 10

  action {
    type = "fixed-response"
    fixed_response {
      content_type = "text/plain"
      message_body = "Not found"
      status_code  = "404"
    }
  }

  condition {
    path_pattern { values = ["/admin", "/admin/*"] }
  }

  tags = var.tags
}

# ------------------------------ auto scaling group --------------------------
resource "aws_autoscaling_group" "this" {
  name                      = var.name
  vpc_zone_identifier       = var.private_subnet_ids
  min_size                  = var.min_size
  max_size                  = var.max_size
  desired_capacity          = var.desired_capacity
  health_check_type         = "ELB" # replace nodes that fail /health/ready
  health_check_grace_period = 300
  target_group_arns         = [aws_lb_target_group.this.arn]
  capacity_rebalance        = true

  launch_template {
    id      = aws_launch_template.this.id
    version = aws_launch_template.this.latest_version
  }

  # Zero-downtime rollout when the launch template changes (new image, new env).
  instance_refresh {
    strategy = "Rolling"
    preferences {
      min_healthy_percentage = 100
      instance_warmup        = 300
      auto_rollback          = true
    }
    triggers = ["launch_template"]
  }

  dynamic "tag" {
    for_each = merge(var.tags, { Name = "${var.name}-node" })
    content {
      key                 = tag.key
      value               = tag.value
      propagate_at_launch = true
    }
  }

  timeouts { delete = "20m" }

  lifecycle {
    create_before_destroy = true
    ignore_changes        = [desired_capacity] # let scaling policies own this
  }
}

resource "aws_autoscaling_policy" "cpu" {
  name                   = "${var.name}-cpu-target"
  autoscaling_group_name = aws_autoscaling_group.this.name
  policy_type            = "TargetTrackingScaling"

  target_tracking_configuration {
    predefined_metric_specification {
      predefined_metric_type = "ASGAverageCPUUtilization"
    }
    target_value     = var.cpu_target_value
    disable_scale_in = false
  }
}

# Scale-in on Keycloak is disruptive (cache rebalancing), so give the node
# time to hand off its sessions before the instance is terminated.
resource "aws_autoscaling_lifecycle_hook" "drain" {
  name                   = "${var.name}-drain"
  autoscaling_group_name = aws_autoscaling_group.this.name
  lifecycle_transition   = "autoscaling:EC2_INSTANCE_TERMINATING"
  heartbeat_timeout      = 180
  default_result         = "CONTINUE"
}

# ------------------------------ alarms --------------------------------------
resource "aws_cloudwatch_metric_alarm" "unhealthy_hosts" {
  alarm_name          = "${var.name}-unhealthy-hosts"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "UnHealthyHostCount"
  namespace           = "AWS/ApplicationELB"
  period              = 60
  statistic           = "Maximum"
  threshold           = 0
  treat_missing_data  = "notBreaching"

  dimensions = {
    LoadBalancer = aws_lb.this.arn_suffix
    TargetGroup  = aws_lb_target_group.this.arn_suffix
  }

  tags = var.tags
}

resource "aws_cloudwatch_metric_alarm" "target_5xx" {
  alarm_name          = "${var.name}-target-5xx"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "HTTPCode_Target_5XX_Count"
  namespace           = "AWS/ApplicationELB"
  period              = 300
  statistic           = "Sum"
  threshold           = 10
  treat_missing_data  = "notBreaching"

  dimensions = { LoadBalancer = aws_lb.this.arn_suffix }
  tags       = var.tags
}
