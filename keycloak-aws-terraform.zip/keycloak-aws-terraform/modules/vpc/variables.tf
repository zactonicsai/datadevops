variable "name" {
  description = "Name prefix for all VPC resources."
  type        = string
}

variable "cidr_block" {
  description = "CIDR block for the VPC."
  type        = string
  default     = "10.40.0.0/16"
}

variable "azs" {
  description = "Availability zones to spread subnets across. Use at least 2 (3 for production)."
  type        = list(string)
}

variable "public_subnet_cidrs" {
  description = "CIDR per AZ for public (ALB / NAT) subnets."
  type        = list(string)
}

variable "private_subnet_cidrs" {
  description = "CIDR per AZ for private (app) subnets."
  type        = list(string)
}

variable "database_subnet_cidrs" {
  description = "CIDR per AZ for isolated database subnets."
  type        = list(string)
}

variable "single_nat_gateway" {
  description = "true = one NAT gateway (cheap, dev). false = one per AZ (HA, prod)."
  type        = bool
  default     = false
}

variable "eks_cluster_name" {
  description = "If set, subnets get the kubernetes.io/cluster tags needed by the AWS Load Balancer Controller."
  type        = string
  default     = ""
}

variable "tags" {
  description = "Tags applied to every resource."
  type        = map(string)
  default     = {}
}
