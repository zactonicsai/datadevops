variable "cluster_name" { type = string }

variable "kubernetes_version" {
  description = "EKS control plane version."
  type        = string
  default     = "1.33"
}

variable "vpc_id" { type = string }

variable "private_subnet_ids" {
  description = "Subnets for the control plane ENIs and worker nodes."
  type        = list(string)
}

variable "public_subnet_ids" {
  description = "Subnets where the AWS Load Balancer Controller will place internet-facing ALBs."
  type        = list(string)
  default     = []
}

variable "endpoint_public_access" {
  description = "Expose the Kubernetes API publicly. Prefer false + VPN/SSM in production."
  type        = bool
  default     = true
}

variable "public_access_cidrs" {
  type    = list(string)
  default = ["0.0.0.0/0"]
}

variable "node_instance_types" {
  type    = list(string)
  default = ["m7i-flex.large"]
}

variable "node_capacity_type" {
  description = "ON_DEMAND or SPOT. Keycloak is stateful-ish; prefer ON_DEMAND."
  type        = string
  default     = "ON_DEMAND"
}

variable "node_min_size" {
  type    = number
  default = 2
}

variable "node_max_size" {
  type    = number
  default = 6
}

variable "node_desired_size" {
  type    = number
  default = 3
}

variable "admin_principal_arns" {
  description = "IAM principals (your CI role, your SSO role) granted cluster-admin via EKS Access Entries."
  type        = list(string)
  default     = []
}

variable "log_retention_days" {
  type    = number
  default = 90
}

variable "tags" {
  type    = map(string)
  default = {}
}
