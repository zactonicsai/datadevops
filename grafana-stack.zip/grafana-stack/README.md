# Grafana Monitoring Stack — Simple Demo

A tiny, self-contained monitoring setup you can run with one command. It starts
**Grafana** (the dashboards), **Prometheus** (the database that collects the
numbers), **node-exporter** (machine health), and **two example app servers**
that are being monitored.

---

## 1. Step-by-step setup

**What you need:** Docker Desktop (or Docker Engine + Compose v2). Nothing else.

**Step 1 — start everything**

```bash
cd grafana-stack
docker compose up -d --build
```

The first run takes a minute or two because it downloads images and builds the
example apps.

**Step 2 — check the containers are running**

```bash
docker compose ps
```

You should see five services: `grafana`, `prometheus`, `node-exporter`,
`app-checkout`, `app-catalog`.

**Step 3 — open Grafana**

Go to **http://localhost:3000** and log in with:

- username: `admin`
- password: `admin`

**Step 4 — open the dashboard**

In the left menu click **Dashboards → Apps Overview**. Within about 30 seconds
you'll see live graphs: request rate, error rate, 95th-percentile latency,
in-flight requests, and host CPU/memory.

You don't have to click anything to create traffic — each example app quietly
calls itself in the background so the graphs always have data.

**Step 5 — poke the apps yourself (optional)**

```bash
curl localhost:8081/api/items    # checkout app
curl localhost:8082/api/slow     # catalog app
curl localhost:8081/metrics      # see the raw numbers Prometheus reads
```

**Step 6 — stop it**

```bash
docker compose down          # stop
docker compose down -v       # stop and delete stored metrics/dashboard state
```

---

## 2. What each piece does

| Service | Port | Job |
|---|---|---|
| `grafana` | 3000 | Draws the dashboards. Reads data from Prometheus. |
| `prometheus` | 9090 | Every 15s it visits each app's `/metrics` page, saves the numbers, and answers queries. |
| `node-exporter` | (internal) | Turns the host machine's CPU/RAM/disk stats into metrics. |
| `app-checkout` | 8081 | Example app. Slower (~120ms) and fails ~5% of requests. |
| `app-catalog` | 8082 | Example app. Faster (~45ms) and fails ~1% of requests. |

### The important idea: pull, not push

Prometheus **pulls**. Your app doesn't send anything anywhere — it just publishes
a plain-text page at `/metrics`, and Prometheus comes and reads it on a schedule.
That's why the app code is so small, and why `prometheus/prometheus.yml` is the
file that decides what gets monitored.

### File layout

```
grafana-stack/
├── docker-compose.yml                  # the whole stack
├── prometheus/prometheus.yml           # what to scrape, how often
├── grafana/
│   ├── provisioning/datasources/       # auto-connects Grafana to Prometheus
│   ├── provisioning/dashboards/        # tells Grafana where dashboards live
│   └── dashboards/apps-overview.json   # the dashboard itself, as code
└── apps/webapp/                        # the example app (Flask + prometheus_client)
    ├── app.py
    ├── Dockerfile
    └── requirements.txt
```

Grafana is **provisioned**, meaning the datasource and dashboard are defined in
files instead of clicked together by hand. Delete the containers, bring them
back, and everything is still there.

### The four metrics the app exposes

- `http_requests_total` — a **counter** (only ever goes up). Rate of change gives req/s.
- `http_request_duration_seconds` — a **histogram** (buckets of response times), used for p95.
- `http_requests_in_progress` — a **gauge** (goes up and down).
- Everything is labelled with `app="checkout"` / `app="catalog"` so you can split graphs by service.

Example query used on the dashboard:

```promql
sum by (app) (rate(http_requests_total[1m]))
```

Read it right-to-left: take the counter, work out how fast it's rising over the
last minute, then add up the results per app.

---

## 3. Adding your own app

1. Expose a `/metrics` endpoint in your app (every language has a Prometheus client library).
2. Add the service to `docker-compose.yml`.
3. Add its `host:port` to the `apps` job in `prometheus/prometheus.yml`.
4. `docker compose up -d` and check **http://localhost:9090/targets** — your app should show as `UP`.

---

## 4. Best practices worth copying

- **Pin image versions** (`grafana:12.1.0`, not `:latest`) so a redeploy can't silently change behaviour.
- **Keep dashboards in Git** as provisioned JSON, not hand-clicked in the UI.
- **Use labels, not metric names**, for dimensions — `http_requests_total{app="checkout"}` beats `checkout_http_requests_total`.
- **Counters end in `_total`, durations in `_seconds`** — that's the convention tooling expects.
- **Never label by user ID, email, or full URL.** Each unique label value creates a new time series; high-cardinality labels are the #1 way to blow up Prometheus.
- **Change the admin password** before this goes anywhere but your laptop. `admin/admin` is fine for a demo, dangerous anywhere else.
- **Set retention deliberately** (here it's 7 days) so disk usage stays predictable.

## 5. Options and trade-offs

**Prometheus vs. hosted (Grafana Cloud, Datadog)**
Self-hosted is free, private, and simple to run at small scale, but you own the
storage, upgrades, and long-term retention. Hosted costs money per metric but
removes all that operational work.

**Pull (Prometheus) vs. push (StatsD, OTLP)**
Pull gives you a free health check — a target that can't be scraped is obviously
down — and needs no config in the app. Push works better for short-lived jobs
and serverless functions, where nothing is around long enough to be scraped.
(Prometheus covers those with a Pushgateway.)

**Adding Loki for logs**
This stack does metrics only. Adding Loki + Alloy gives you logs beside your
graphs, which makes debugging much faster — at the cost of another two services
and noticeably more disk. Good next step once metrics feel comfortable.

**Alerting**
Grafana can alert on any of these panels (Alerting → Alert rules). Start with
one or two rules that page on real user pain — error rate and latency — rather
than alerting on CPU, which usually just creates noise.
