"""A tiny example web service that exposes Prometheus metrics on /metrics.

Two copies of this app run in the compose stack (checkout + catalog) with
different latency/error settings, and each one generates a little synthetic
traffic against itself so the dashboards are never empty.
"""

import os
import random
import threading
import time

from flask import Flask, Response, jsonify
from prometheus_client import (
    CONTENT_TYPE_LATEST,
    Counter,
    Gauge,
    Histogram,
    generate_latest,
)

APP_NAME = os.getenv("APP_NAME", "demo-app")
ERROR_RATE = float(os.getenv("ERROR_RATE", "0.02"))
BASE_LATENCY_MS = float(os.getenv("BASE_LATENCY_MS", "50"))
SELF_TRAFFIC = os.getenv("SELF_TRAFFIC", "true").lower() == "true"

app = Flask(__name__)

REQUESTS = Counter(
    "http_requests_total",
    "Total HTTP requests.",
    ["app", "method", "path", "status"],
)
LATENCY = Histogram(
    "http_request_duration_seconds",
    "HTTP request latency in seconds.",
    ["app", "path"],
    buckets=(0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0),
)
IN_PROGRESS = Gauge(
    "http_requests_in_progress",
    "Requests currently being handled.",
    ["app"],
)


def simulate_work(path):
    """Sleep for a realistic-looking amount of time, then maybe fail."""
    latency = random.gauss(BASE_LATENCY_MS, BASE_LATENCY_MS / 3) / 1000
    latency = max(latency, 0.001)
    if random.random() < 0.05:  # occasional slow request -> interesting p95
        latency *= 5
    time.sleep(latency)
    return random.random() < ERROR_RATE


@app.before_request
def _start_timer():
    IN_PROGRESS.labels(app=APP_NAME).inc()


@app.teardown_request
def _end_timer(exc=None):
    IN_PROGRESS.labels(app=APP_NAME).dec()


def handle(path):
    start = time.perf_counter()
    failed = simulate_work(path)
    LATENCY.labels(app=APP_NAME, path=path).observe(time.perf_counter() - start)
    status = 500 if failed else 200
    REQUESTS.labels(app=APP_NAME, method="GET", path=path, status=str(status)).inc()
    if failed:
        return jsonify(app=APP_NAME, path=path, error="something broke"), 500
    return jsonify(app=APP_NAME, path=path, ok=True), 200


@app.get("/")
def index():
    return handle("/")


@app.get("/api/items")
def items():
    return handle("/api/items")


@app.get("/api/slow")
def slow():
    return handle("/api/slow")


@app.get("/healthz")
def healthz():
    return jsonify(status="ok", app=APP_NAME)


@app.get("/metrics")
def metrics():
    return Response(generate_latest(), mimetype=CONTENT_TYPE_LATEST)


def traffic_generator():
    """Hit our own endpoints so the graphs have something to show."""
    import urllib.error
    import urllib.request

    paths = ["/", "/api/items", "/api/slow"]
    time.sleep(3)
    while True:
        try:
            urllib.request.urlopen(
                "http://127.0.0.1:8080" + random.choice(paths), timeout=5
            )
        except urllib.error.HTTPError:
            pass  # 500s are expected, that's the point
        except Exception:
            pass
        time.sleep(random.uniform(0.2, 1.0))


if SELF_TRAFFIC:
    threading.Thread(target=traffic_generator, daemon=True).start()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, threaded=True)
