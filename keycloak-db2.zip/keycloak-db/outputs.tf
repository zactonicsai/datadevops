output "db_instance_id" {
  description = "RDS instance identifier."
  value       = aws_db_instance.this.id
}

output "db_instance_arn" {
  description = "RDS instance ARN."
  value       = aws_db_instance.this.arn
}

output "db_address" {
  description = "Hostname of the database."
  value       = aws_db_instance.this.address
}

output "db_endpoint" {
  description = "host:port of the database."
  value       = aws_db_instance.this.endpoint
}

output "db_port" {
  description = "Port the database listens on."
  value       = aws_db_instance.this.port
}

output "db_name" {
  description = "Initial database name for Keycloak."
  value       = aws_db_instance.this.db_name
}

output "db_username" {
  description = "Master username."
  value       = var.master_username
}

output "db_security_group_id" {
  description = "Security group protecting the database."
  value       = aws_security_group.db.id
}

output "keycloak_security_group_id" {
  description = "Security group for the Keycloak compute layer. Attach this to the ECS service / EC2 instances / EKS pods in phase two; it already has DB egress and is already trusted by the database."
  value       = try(aws_security_group.keycloak[0].id, null)
}

output "keycloak_security_group_arn" {
  description = "ARN of the Keycloak application security group."
  value       = try(aws_security_group.keycloak[0].arn, null)
}

output "db_subnet_group_name" {
  description = "Name of the DB subnet group."
  value       = aws_db_subnet_group.this.name
}

output "db_parameter_group_name" {
  description = "Name of the Postgres parameter group."
  value       = aws_db_parameter_group.this.name
}

output "master_secret_arn" {
  description = "Secrets Manager ARN holding the master credentials JSON."
  value       = aws_secretsmanager_secret.master.arn
}

output "master_secret_name" {
  description = "Secrets Manager secret name."
  value       = aws_secretsmanager_secret.master.name
}

output "keycloak_jdbc_url" {
  description = "JDBC URL for KC_DB_URL. Credentials come from Secrets Manager, not from here."
  value       = "jdbc:postgresql://${aws_db_instance.this.endpoint}/${var.db_name}?sslmode=${var.force_ssl ? "verify-full" : "prefer"}"
}
