###############################################################################
# Keycloak database - PROD
# terraform apply -var-file=envs/prod.tfvars
###############################################################################

aws_region  = "eu-west-1"
project     = "keycloak"
environment = "prod"

# --- Networking (replace with real IDs) -------------------------------------
vpc_id     = "vpc-0bbbbbbbbbbbbbbbb"
subnet_ids = [
  "subnet-0prod111111111111",
  "subnet-0prod222222222222",
  "subnet-0prod333333333333",
]

# The Keycloak application SG is created by this module and is the only SG
# granted DB access. Attach it to the compute layer in phase two.
create_keycloak_security_group = true
keycloak_allow_all_egress      = true

allowed_security_group_ids = []
allowed_cidr_blocks        = [] # keep empty in prod; use SSM Session Manager for admin access

# --- Engine ------------------------------------------------------------------
engine_version             = "16.4"
parameter_group_family     = "postgres16"
auto_minor_version_upgrade = false # pin and upgrade deliberately

# --- Compute & storage -------------------------------------------------------
instance_class        = "db.m6g.large"
allocated_storage     = 100
max_allocated_storage = 500
storage_type          = "gp3"
storage_encrypted     = true
# Customer-managed KMS key is strongly recommended in prod:
# kms_key_id = "arn:aws:kms:eu-west-1:111122223333:key/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"

# --- Availability & lifecycle ------------------------------------------------
multi_az                = true
backup_retention_period = 30
backup_window           = "01:00-02:00"
maintenance_window      = "sun:03:00-sun:04:00"
copy_tags_to_snapshot   = true

deletion_protection = true
skip_final_snapshot = false
apply_immediately   = false # batch changes into the maintenance window

secret_recovery_window_in_days = 30

# --- Observability -----------------------------------------------------------
enabled_cloudwatch_logs_exports       = ["postgresql", "upgrade"]
monitoring_interval                   = 30
performance_insights_enabled          = true
performance_insights_retention_period = 731

# --- Postgres tuning ---------------------------------------------------------
force_ssl                  = true
log_min_duration_statement = "1000"

# Size above (Keycloak replicas x KC_DB_POOL_MAX_SIZE) plus headroom for
# admin sessions and the standby. db.m6g.large default is ~340.
max_connections = "500"

tags = {
  Owner       = "platform-team"
  CostCenter  = "engineering"
  Compliance  = "internal"
  DataClass   = "confidential"
}
