###############################################################################
# variables.tf - everything you can configure. Only the first four are required.
###############################################################################

# --- Required: existing resources you already own ----------------------------

variable "aws_region" {
  description = "Region to deploy into. Must match the VPC and subnet below."
  type        = string
}

variable "vpc_id" {
  description = "ID of an EXISTING VPC."
  type        = string
}

variable "subnet_id" {
  description = "ID of an EXISTING subnet. Use a private one and reach Grafana over SSM port-forwarding."
  type        = string
}

variable "ingress_cidr_blocks" {
  description = "CIDRs allowed to reach the Grafana port. Your VPC CIDR, not 0.0.0.0/0."
  type        = list(string)
}

# --- Optional ----------------------------------------------------------------

variable "name_prefix" {
  description = "Prefix for every resource name."
  type        = string
  default     = "grafana"
}

variable "instance_type" {
  description = "EC2 size. t4g.small (2 vCPU / 2 GiB, Graviton) is plenty for Grafana alone."
  type        = string
  default     = "t4g.small"
}

variable "architecture" {
  description = "CPU architecture for the auto-selected AMI: arm64 or x86_64. Must match instance_type."
  type        = string
  default     = "arm64"
}

variable "grafana_version" {
  description = "Grafana OSS version from the official RPM repo. Pin it; 'latest' is not reproducible."
  type        = string
  default     = "11.6.0"
}

variable "grafana_port" {
  description = "Port Grafana listens on."
  type        = number
  default     = 3000
}

variable "root_volume_size_gb" {
  description = "Root disk size. Grafana's SQLite database and plugins live here."
  type        = number
  default     = 20
}

variable "admin_password_ssm_parameter" {
  description = <<-EOT
    Name of an EXISTING SSM SecureString holding the initial admin password,
    e.g. /grafana/admin-password. Fetched at boot by the instance, so it never
    enters Terraform state. Leave "" to keep the admin/admin default (demo only).
  EOT
  type        = string
  default     = ""
}

variable "security_group_ids" {
  description = "EXISTING security group IDs. Leave [] and the module creates one from ingress_cidr_blocks."
  type        = list(string)
  default     = []
}

variable "iam_instance_profile_name" {
  description = "EXISTING instance profile. Leave \"\" and the module creates one with SSM access only."
  type        = string
  default     = ""
}

variable "create_instance" {
  description = "Also launch one instance from the template. false = build the template only."
  type        = bool
  default     = true
}

variable "tags" {
  description = "Tags applied to every resource."
  type        = map(string)
  default = {
    Project   = "grafana"
    ManagedBy = "terraform"
  }
}
