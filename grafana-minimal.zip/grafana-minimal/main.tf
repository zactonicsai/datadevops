###############################################################################
# main.tf - the whole module. Grafana OSS on one EC2 instance.
###############################################################################

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.60" }
  }
}

provider "aws" {
  region = var.aws_region
  # Stamped on every resource automatically.
  default_tags { tags = var.tags }
}


# =============================================================================
# LOOK UP EXISTING RESOURCES
# `data` blocks read; they never create or destroy anything.
# =============================================================================

data "aws_partition" "current" {}

# Confirms the VPC exists and gives us its CIDR as a fallback ingress range.
data "aws_vpc" "selected" {
  id = var.vpc_id
}

# Newest Amazon Linux 2023 image. The owners filter is essential - without it
# anyone could publish an AMI with a matching name.
data "aws_ami" "al2023" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-2023.*-kernel-6.1-${var.architecture}"]
  }
}


# =============================================================================
# DECISIONS
# Pattern: you named an existing resource -> use it. You didn't -> build one.
# =============================================================================

locals {
  name = var.name_prefix

  create_sg  = length(var.security_group_ids) == 0
  create_iam = var.iam_instance_profile_name == ""

  # one() safely unwraps a count-based list of 0 or 1 elements.
  sg_ids       = local.create_sg ? compact(aws_security_group.this[*].id) : var.security_group_ids
  profile_name = local.create_iam ? one(aws_iam_instance_profile.this[*].name) : var.iam_instance_profile_name
}


# =============================================================================
# SECURITY GROUP (only when you didn't supply one)
# =============================================================================

resource "aws_security_group" "this" {
  count = local.create_sg ? 1 : 0

  # name_prefix lets Terraform build the replacement before deleting the old.
  name_prefix = "${local.name}-sg-"
  description = "Grafana web UI"
  vpc_id      = var.vpc_id
  tags        = merge(var.tags, { Name = "${local.name}-sg" })

  lifecycle { create_before_destroy = true }
}

resource "aws_vpc_security_group_ingress_rule" "grafana" {
  # One rule per allowed CIDR. toset() gives each a stable address in state.
  for_each = local.create_sg ? toset(var.ingress_cidr_blocks) : toset([])

  security_group_id = aws_security_group.this[0].id
  description       = "Grafana UI"
  cidr_ipv4         = each.value
  ip_protocol       = "tcp"
  from_port         = var.grafana_port
  to_port           = var.grafana_port
}

# Outbound is needed at boot to reach rpm.grafana.com, plus SSM and SSM.
resource "aws_vpc_security_group_egress_rule" "all" {
  count = local.create_sg ? 1 : 0

  security_group_id = aws_security_group.this[0].id
  description       = "All outbound"
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1" # every protocol, every port
}


# =============================================================================
# IAM (only when you didn't supply a profile)
# Grants exactly two things: Session Manager access, and read of one SSM
# parameter. No S3, no CloudWatch, nothing else.
# =============================================================================

data "aws_iam_policy_document" "assume" {
  count = local.create_iam ? 1 : 0

  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "this" {
  count = local.create_iam ? 1 : 0

  name               = "${local.name}-role"
  assume_role_policy = data.aws_iam_policy_document.assume[0].json
  tags               = merge(var.tags, { Name = "${local.name}-role" })
}

# Lets you `aws ssm start-session` onto the box with no SSH key and no port 22.
resource "aws_iam_role_policy_attachment" "ssm" {
  count = local.create_iam ? 1 : 0

  role       = aws_iam_role.this[0].name
  policy_arn = "arn:${data.aws_partition.current.partition}:iam::aws:policy/AmazonSSMManagedInstanceCore"
}

# Read the admin password at boot. Scoped to that one parameter.
data "aws_iam_policy_document" "ssm_param" {
  count = local.create_iam && var.admin_password_ssm_parameter != "" ? 1 : 0

  statement {
    actions = ["ssm:GetParameter"]
    resources = [
      "arn:${data.aws_partition.current.partition}:ssm:${var.aws_region}:*:parameter/${trimprefix(var.admin_password_ssm_parameter, "/")}"
    ]
  }
  # Decrypting a SecureString needs KMS on whichever key encrypted it.
  # ViaService scopes this safely to SSM without naming the rotating key id.
  statement {
    actions   = ["kms:Decrypt"]
    resources = ["*"]
    condition {
      test     = "StringEquals"
      variable = "kms:ViaService"
      values   = ["ssm.${var.aws_region}.amazonaws.com"]
    }
  }
}

resource "aws_iam_role_policy" "ssm_param" {
  count = local.create_iam && var.admin_password_ssm_parameter != "" ? 1 : 0

  name   = "${local.name}-read-admin-password"
  role   = aws_iam_role.this[0].id
  policy = data.aws_iam_policy_document.ssm_param[0].json
}

# An instance profile is the wrapper that lets an EC2 instance wear a role.
resource "aws_iam_instance_profile" "this" {
  count = local.create_iam ? 1 : 0

  name = "${local.name}-profile"
  role = aws_iam_role.this[0].name
  tags = merge(var.tags, { Name = "${local.name}-profile" })

  lifecycle { create_before_destroy = true }
}


# =============================================================================
# LAUNCH TEMPLATE - the deliverable
# A saved recipe for an instance. Versioned: every change adds a version
# rather than overwriting, so rollback is one API call.
# =============================================================================

resource "aws_launch_template" "this" {
  name_prefix   = "${local.name}-lt-"
  description   = "Grafana OSS ${var.grafana_version}"
  image_id      = data.aws_ami.al2023.id
  instance_type = var.instance_type

  iam_instance_profile {
    name = local.profile_name
  }

  network_interfaces {
    device_index                = 0
    subnet_id                   = var.subnet_id
    security_groups             = local.sg_ids
    associate_public_ip_address = false # reach it via SSM, not the internet
    delete_on_termination       = true
  }

  # /dev/xvda is the root device on Amazon Linux 2023 (Ubuntu uses /dev/sda1).
  block_device_mappings {
    device_name = "/dev/xvda"
    ebs {
      volume_size           = var.root_volume_size_gb
      volume_type           = "gp3"
      encrypted             = "true" # string, not bool - the API models it that way
      delete_on_termination = "true"
    }
  }

  # IMDSv2 only. IMDSv1 answers any GET, which turns an SSRF bug into stolen
  # credentials. hop_limit 1 keeps the token from leaving the instance.
  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = "required"
    http_put_response_hop_limit = 1
  }

  # base64gzip: cloud-init auto-detects the gzip header and decompresses.
  # Keeps us well under the 16 KB user-data limit.
  user_data = base64gzip(templatefile("${path.module}/templates/user_data.sh.tftpl", {
    grafana_version = var.grafana_version
    grafana_port    = var.grafana_port
    ssm_param       = var.admin_password_ssm_parameter
    region          = var.aws_region
  }))

  # Tags on a launch template do NOT flow to what it launches - you must
  # declare them per resource type.
  tag_specifications {
    resource_type = "instance"
    tags          = merge(var.tags, { Name = "${local.name}-server" })
  }
  tag_specifications {
    resource_type = "volume"
    tags          = merge(var.tags, { Name = "${local.name}-volume" })
  }

  tags = merge(var.tags, { Name = "${local.name}-lt" })

  lifecycle { create_before_destroy = true }
}


# =============================================================================
# INSTANCE (optional)
# Set create_instance = false if you only want the template.
# =============================================================================

resource "aws_instance" "this" {
  count = var.create_instance ? 1 : 0

  launch_template {
    id      = aws_launch_template.this.id
    version = "$Latest"
  }

  # Everything else - AMI, type, subnet, SG, disk, user_data - comes from the
  # template above, so there is nothing to repeat here.
}
