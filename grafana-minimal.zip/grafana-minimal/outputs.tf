###############################################################################
# outputs.tf
###############################################################################

output "launch_template_id" {
  description = "Pass this to an ASG, a node group, or `aws ec2 run-instances --launch-template`."
  value       = aws_launch_template.this.id
}

output "launch_template_latest_version" {
  description = "Version number just created. Roll back by pointing at an earlier one."
  value       = aws_launch_template.this.latest_version
}

output "instance_id" {
  description = "Instance ID, or empty when create_instance = false."
  value       = var.create_instance ? one(aws_instance.this[*].id) : ""
}

output "private_ip" {
  description = "Private IP of the instance."
  value       = var.create_instance ? one(aws_instance.this[*].private_ip) : ""
}

output "open_grafana" {
  description = "Copy-paste command to tunnel to Grafana, then browse to http://localhost:3000"
  value = var.create_instance ? join(" ", [
    "aws ssm start-session --target ${one(aws_instance.this[*].id)}",
    "--region ${var.aws_region}",
    "--document-name AWS-StartPortForwardingSession",
    "--parameters '{\"portNumber\":[\"${var.grafana_port}\"],\"localPortNumber\":[\"3000\"]}'",
  ]) : "create_instance is false"
}
