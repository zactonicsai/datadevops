# Grafana on EC2 — minimal

One EC2 instance running Grafana OSS. No Mimir, no Loki, no Tempo, no S3.
Grafana stores its dashboards and users in a local SQLite file on the root volume.

## Files

```
main.tf                        provider, lookups, SG, IAM, launch template, instance
variables.tf                   every input; only four are required
outputs.tf                     IDs and a ready-to-run tunnel command
terraform.tfvars.example       copy to terraform.tfvars and fill in
templates/user_data.sh.tftpl   boot script: installs and starts Grafana
```

## Deploy

```bash
# 1. Set an admin password (optional but recommended)
aws ssm put-parameter --name /grafana/admin-password --type SecureString \
  --value "$(openssl rand -base64 24)" --region us-east-1

# 2. Fill in your VPC, subnet and CIDR
cp terraform.tfvars.example terraform.tfvars

# 3. Go
terraform init
terraform plan
terraform apply
```

## Open it

The instance has no public IP. Tunnel in:

```bash
terraform output -raw open_grafana   # prints the command
```

Run it, then browse to **http://localhost:3000** and log in as `admin`.

## What it creates

| Resource | Skipped if you supply |
|---|---|
| Launch template | — |
| EC2 instance | `create_instance = false` |
| Security group (Grafana port only) | `security_group_ids` |
| IAM role + profile (SSM access, read one parameter) | `iam_instance_profile_name` |

Everything else — VPC, subnet, KMS — must already exist.

## Choices made

- **Amazon Linux 2023**, newest AMI looked up at plan time.
- **Graviton (`t4g.small`)** by default: cheaper per vCPU. For x86 set both `architecture = "x86_64"` and an x86 `instance_type`.
- **IMDSv2 required**, hop limit 1.
- **Root volume encrypted**, 20 GiB.
- **No public IP**; access via SSM Session Manager.
- **Password from SSM at boot**, so it stays out of Terraform state.

## Limits of "minimal"

SQLite on a single instance means no HA and no automatic backup — if the
instance is replaced, your dashboards are gone. When that matters, move
Grafana's database to RDS Postgres (`GF_DATABASE_*` env vars) and put the
instance in an ASG behind an internal ALB.

Component version was current as of early 2026; check
https://github.com/grafana/grafana/releases before deploying.
