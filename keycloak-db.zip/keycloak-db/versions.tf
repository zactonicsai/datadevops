terraform {
  required_version = ">= 1.6.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.60"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }

  # Phase one: configure your backend here (or via -backend-config).
  # backend "s3" {
  #   bucket         = "my-tfstate"
  #   key            = "keycloak/db/terraform.tfstate"
  #   region         = "eu-west-1"
  #   dynamodb_table = "my-tfstate-lock"
  #   encrypt        = true
  # }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      ManagedBy = "terraform"
      Component = "keycloak-db"
    }
  }
}
