###############################################################################
# General
###############################################################################

variable "aws_region" {
  description = "AWS region to deploy the Keycloak database into."
  type        = string
}

variable "project" {
  description = "Short project/system name, used as a resource name prefix."
  type        = string
  default     = "keycloak"

  validation {
    condition     = can(regex("^[a-z0-9-]{2,20}$", var.project))
    error_message = "project must be 2-20 chars, lowercase alphanumeric and hyphens only."
  }
}

variable "environment" {
  description = "Deployment environment (dev, stage, prod, ...)."
  type        = string

  validation {
    condition     = can(regex("^[a-z0-9-]{2,12}$", var.environment))
    error_message = "environment must be 2-12 chars, lowercase alphanumeric and hyphens only."
  }
}

variable "tags" {
  description = "Additional tags applied to every resource in this module."
  type        = map(string)
  default     = {}
}

###############################################################################
# Networking (pre-existing VPC is expected)
###############################################################################

variable "vpc_id" {
  description = "ID of the VPC the database is placed in."
  type        = string
}

variable "subnet_ids" {
  description = "Private subnet IDs for the DB subnet group. Provide at least two, in different AZs."
  type        = list(string)

  validation {
    condition     = length(var.subnet_ids) >= 2
    error_message = "At least two subnet IDs in distinct availability zones are required."
  }
}

variable "allowed_security_group_ids" {
  description = "Security group IDs allowed to reach the database on the Postgres port (e.g. the Keycloak task/pod/instance SG)."
  type        = list(string)
  default     = []
}

variable "allowed_cidr_blocks" {
  description = "CIDR blocks allowed to reach the database. Prefer security group references; use CIDRs only for admin/bastion access."
  type        = list(string)
  default     = []
}

variable "publicly_accessible" {
  description = "Whether the instance gets a public IP. Should remain false."
  type        = bool
  default     = false
}

###############################################################################
# Engine
###############################################################################

variable "engine_version" {
  description = "PostgreSQL engine version. Keycloak 24+ is validated against PostgreSQL 15/16."
  type        = string
  default     = "16.4"
}

variable "parameter_group_family" {
  description = "RDS parameter group family, must match engine_version major (e.g. postgres16)."
  type        = string
  default     = "postgres16"
}

variable "auto_minor_version_upgrade" {
  description = "Allow AWS to apply minor engine upgrades during the maintenance window."
  type        = bool
  default     = true
}

variable "ca_cert_identifier" {
  description = "RDS CA certificate bundle identifier used for TLS."
  type        = string
  default     = "rds-ca-rsa2048-g1"
}

###############################################################################
# Database / credentials
###############################################################################

variable "db_name" {
  description = "Name of the initial database Keycloak connects to."
  type        = string
  default     = "keycloak"
}

variable "master_username" {
  description = "Master username. Keycloak uses this account unless you provision a lower-privilege role later."
  type        = string
  default     = "keycloak"

  validation {
    condition     = !contains(["admin", "postgres", "rdsadmin"], lower(var.master_username))
    error_message = "master_username cannot be a reserved RDS/Postgres name."
  }
}

variable "port" {
  description = "Port the database listens on."
  type        = number
  default     = 5432
}

variable "secret_name_override" {
  description = "Explicit Secrets Manager secret name. Defaults to <project>/<environment>/db/master."
  type        = string
  default     = null
}

variable "secret_recovery_window_in_days" {
  description = "Days AWS retains a deleted secret before permanent removal. 0 forces immediate deletion (handy in dev)."
  type        = number
  default     = 7
}

###############################################################################
# Compute & storage
###############################################################################

variable "instance_class" {
  description = "RDS instance class."
  type        = string
  default     = "db.t4g.micro"
}

variable "allocated_storage" {
  description = "Initial storage in GiB."
  type        = number
  default     = 20
}

variable "max_allocated_storage" {
  description = "Upper bound for storage autoscaling in GiB. Set to 0 to disable autoscaling."
  type        = number
  default     = 100
}

variable "storage_type" {
  description = "Storage type (gp3 recommended)."
  type        = string
  default     = "gp3"
}

variable "storage_iops" {
  description = "Provisioned IOPS. Only valid for gp3 volumes at or above 400 GiB, or io1/io2. Leave null otherwise."
  type        = number
  default     = null
}

variable "storage_throughput" {
  description = "Provisioned throughput in MiB/s. Only valid for gp3 volumes at or above 400 GiB. Leave null otherwise."
  type        = number
  default     = null
}

variable "storage_encrypted" {
  description = "Encrypt storage at rest."
  type        = bool
  default     = true
}

variable "kms_key_id" {
  description = "KMS key ARN for storage encryption. Null uses the AWS-managed aws/rds key."
  type        = string
  default     = null
}

###############################################################################
# Availability, backup & lifecycle
###############################################################################

variable "multi_az" {
  description = "Deploy a synchronous standby in a second AZ."
  type        = bool
  default     = false
}

variable "backup_retention_period" {
  description = "Automated backup retention in days (0 disables backups)."
  type        = number
  default     = 7
}

variable "backup_window" {
  description = "Daily backup window in UTC, format hh:mm-hh:mm."
  type        = string
  default     = "02:00-03:00"
}

variable "maintenance_window" {
  description = "Weekly maintenance window in UTC, format ddd:hh:mm-ddd:hh:mm."
  type        = string
  default     = "sun:03:30-sun:04:30"
}

variable "copy_tags_to_snapshot" {
  description = "Copy instance tags onto snapshots."
  type        = bool
  default     = true
}

variable "deletion_protection" {
  description = "Block accidental deletion of the instance."
  type        = bool
  default     = true
}

variable "skip_final_snapshot" {
  description = "Skip the final snapshot on destroy. Never true in production."
  type        = bool
  default     = false
}

variable "apply_immediately" {
  description = "Apply modifications immediately instead of waiting for the maintenance window."
  type        = bool
  default     = false
}

###############################################################################
# Observability
###############################################################################

variable "enabled_cloudwatch_logs_exports" {
  description = "Log types shipped to CloudWatch Logs."
  type        = list(string)
  default     = ["postgresql", "upgrade"]
}

variable "monitoring_interval" {
  description = "Enhanced Monitoring granularity in seconds. 0 disables it; valid values are 0, 1, 5, 10, 15, 30, 60."
  type        = number
  default     = 0

  validation {
    condition     = contains([0, 1, 5, 10, 15, 30, 60], var.monitoring_interval)
    error_message = "monitoring_interval must be one of 0, 1, 5, 10, 15, 30, 60."
  }
}

variable "performance_insights_enabled" {
  description = "Enable Performance Insights."
  type        = bool
  default     = false
}

variable "performance_insights_retention_period" {
  description = "Performance Insights retention in days (7 for the free tier, or 731/multiples of 31)."
  type        = number
  default     = 7
}

###############################################################################
# Postgres tuning (Keycloak-oriented)
###############################################################################

variable "force_ssl" {
  description = "Require TLS for all client connections (rds.force_ssl). Keycloak must then use sslmode=require or stronger."
  type        = bool
  default     = true
}

variable "max_connections" {
  description = "Override for max_connections. Null keeps the RDS default formula. Size this above Keycloak's total JDBC pool across all replicas."
  type        = string
  default     = null
}

variable "log_min_duration_statement" {
  description = "Log statements slower than this many milliseconds. -1 disables."
  type        = string
  default     = "1000"
}

variable "extra_db_parameters" {
  description = "Additional Postgres parameters to merge into the parameter group."
  type = list(object({
    name         = string
    value        = string
    apply_method = optional(string, "immediate")
  }))
  default = []
}
