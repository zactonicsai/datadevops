###############################################################################
# Keycloak database - DEV
# terraform apply -var-file=envs/dev.tfvars
###############################################################################

aws_region  = "eu-west-1"
project     = "keycloak"
environment = "dev"

# --- Networking (replace with real IDs) -------------------------------------
vpc_id     = "vpc-0aaaaaaaaaaaaaaaa"
subnet_ids = [
  "subnet-0dev1111111111111",
  "subnet-0dev2222222222222",
]

# SG of the Keycloak container/instance. Add a bastion SG here too if needed.
allowed_security_group_ids = [
  "sg-0keycloakdev00000000",
]
allowed_cidr_blocks = []

# --- Engine ------------------------------------------------------------------
engine_version         = "16.4"
parameter_group_family = "postgres16"

# --- Compute & storage -------------------------------------------------------
instance_class        = "db.t4g.micro"
allocated_storage     = 20
max_allocated_storage = 100
storage_type          = "gp3"

# --- Availability & lifecycle ------------------------------------------------
multi_az                = false
backup_retention_period = 1
backup_window           = "02:00-03:00"
maintenance_window      = "sun:03:30-sun:04:30"

deletion_protection = false
skip_final_snapshot = true
apply_immediately   = true

secret_recovery_window_in_days = 0 # allow immediate re-create of the secret

# --- Observability -----------------------------------------------------------
enabled_cloudwatch_logs_exports = ["postgresql", "upgrade"]
monitoring_interval             = 0
performance_insights_enabled    = false

# --- Postgres tuning ---------------------------------------------------------
force_ssl                  = true
log_min_duration_statement = "500"
# Leave max_connections on the RDS default for t4g.micro.

tags = {
  Owner      = "platform-team"
  CostCenter = "engineering"
}
