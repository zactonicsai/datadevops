locals {
  name = "${var.project}-${var.environment}"

  tags = merge(
    {
      Name        = "${local.name}-db"
      Project     = var.project
      Environment = var.environment
    },
    var.tags
  )

  secret_name = coalesce(var.secret_name_override, "${var.project}/${var.environment}/db/master")

  base_parameters = concat(
    [
      {
        name         = "rds.force_ssl"
        value        = var.force_ssl ? "1" : "0"
        apply_method = "pending-reboot"
      },
      {
        name         = "log_min_duration_statement"
        value        = var.log_min_duration_statement
        apply_method = "immediate"
      },
      {
        name         = "log_connections"
        value        = "1"
        apply_method = "immediate"
      },
      {
        name         = "log_disconnections"
        value        = "1"
        apply_method = "immediate"
      },
      {
        name         = "log_lock_waits"
        value        = "1"
        apply_method = "immediate"
      },
      {
        # Keycloak holds row locks briefly during realm/session writes.
        # Fail fast rather than pile up connections behind a stuck lock.
        name         = "lock_timeout"
        value        = "10000"
        apply_method = "immediate"
      },
      {
        name         = "idle_in_transaction_session_timeout"
        value        = "60000"
        apply_method = "immediate"
      },
      {
        name         = "shared_preload_libraries"
        value        = "pg_stat_statements"
        apply_method = "pending-reboot"
      },
    ],
    var.max_connections == null ? [] : [
      {
        name         = "max_connections"
        value        = var.max_connections
        apply_method = "pending-reboot"
      }
    ],
    var.extra_db_parameters
  )
}

###############################################################################
# Credentials
###############################################################################

resource "random_password" "master" {
  length  = 32
  special = true
  # RDS forbids '/', '@', '"' and spaces in the master password.
  override_special = "!#$%^&*()-_=+[]{}<>:?"
}

resource "aws_secretsmanager_secret" "master" {
  name                    = local.secret_name
  description             = "Master credentials for the ${local.name} Keycloak PostgreSQL database."
  kms_key_id              = var.kms_key_id
  recovery_window_in_days = var.secret_recovery_window_in_days

  tags = local.tags
}

resource "aws_secretsmanager_secret_version" "master" {
  secret_id = aws_secretsmanager_secret.master.id

  secret_string = jsonencode({
    engine   = "postgres"
    host     = aws_db_instance.this.address
    port     = aws_db_instance.this.port
    dbname   = var.db_name
    username = var.master_username
    password = random_password.master.result
    jdbcUrl  = "jdbc:postgresql://${aws_db_instance.this.endpoint}/${var.db_name}?sslmode=${var.force_ssl ? "verify-full" : "prefer"}"
  })
}

###############################################################################
# Networking
###############################################################################

resource "aws_db_subnet_group" "this" {
  name        = "${local.name}-db"
  description = "Subnet group for the ${local.name} Keycloak database."
  subnet_ids  = var.subnet_ids

  tags = local.tags
}

resource "aws_security_group" "db" {
  name        = "${local.name}-db"
  description = "Ingress to the ${local.name} Keycloak PostgreSQL instance."
  vpc_id      = var.vpc_id

  tags = local.tags

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_vpc_security_group_ingress_rule" "from_security_groups" {
  for_each = toset(var.allowed_security_group_ids)

  security_group_id            = aws_security_group.db.id
  description                  = "PostgreSQL from ${each.value}"
  referenced_security_group_id = each.value
  from_port                    = var.port
  to_port                      = var.port
  ip_protocol                  = "tcp"

  tags = local.tags
}

resource "aws_vpc_security_group_ingress_rule" "from_cidrs" {
  for_each = toset(var.allowed_cidr_blocks)

  security_group_id = aws_security_group.db.id
  description       = "PostgreSQL from ${each.value}"
  cidr_ipv4         = each.value
  from_port         = var.port
  to_port           = var.port
  ip_protocol       = "tcp"

  tags = local.tags
}

###############################################################################
# Parameter group
###############################################################################

resource "aws_db_parameter_group" "this" {
  name        = "${local.name}-pg"
  family      = var.parameter_group_family
  description = "Postgres parameters tuned for Keycloak (${local.name})."

  dynamic "parameter" {
    for_each = local.base_parameters
    content {
      name         = parameter.value.name
      value        = parameter.value.value
      apply_method = try(parameter.value.apply_method, "immediate")
    }
  }

  tags = local.tags

  lifecycle {
    create_before_destroy = true
  }
}

###############################################################################
# Enhanced monitoring role (only when monitoring_interval > 0)
###############################################################################

data "aws_iam_policy_document" "monitoring_assume" {
  count = var.monitoring_interval > 0 ? 1 : 0

  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["monitoring.rds.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "monitoring" {
  count = var.monitoring_interval > 0 ? 1 : 0

  name               = "${local.name}-rds-monitoring"
  assume_role_policy = data.aws_iam_policy_document.monitoring_assume[0].json

  tags = local.tags
}

resource "aws_iam_role_policy_attachment" "monitoring" {
  count = var.monitoring_interval > 0 ? 1 : 0

  role       = aws_iam_role.monitoring[0].name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonRDSEnhancedMonitoringRole"
}

###############################################################################
# Instance
###############################################################################

resource "aws_db_instance" "this" {
  identifier = "${local.name}-db"

  engine                     = "postgres"
  engine_version             = var.engine_version
  auto_minor_version_upgrade = var.auto_minor_version_upgrade
  ca_cert_identifier         = var.ca_cert_identifier
  instance_class             = var.instance_class

  db_name  = var.db_name
  username = var.master_username
  password = random_password.master.result
  port     = var.port

  allocated_storage     = var.allocated_storage
  max_allocated_storage = var.max_allocated_storage > 0 ? var.max_allocated_storage : null
  storage_type          = var.storage_type
  iops                  = var.storage_iops
  storage_throughput    = var.storage_throughput
  storage_encrypted     = var.storage_encrypted
  kms_key_id            = var.kms_key_id

  db_subnet_group_name   = aws_db_subnet_group.this.name
  vpc_security_group_ids = [aws_security_group.db.id]
  publicly_accessible    = var.publicly_accessible
  multi_az               = var.multi_az

  parameter_group_name = aws_db_parameter_group.this.name

  backup_retention_period = var.backup_retention_period
  backup_window           = var.backup_window
  maintenance_window      = var.maintenance_window
  copy_tags_to_snapshot   = var.copy_tags_to_snapshot

  deletion_protection       = var.deletion_protection
  skip_final_snapshot       = var.skip_final_snapshot
  final_snapshot_identifier = var.skip_final_snapshot ? null : "${local.name}-db-final-${formatdate("YYYYMMDDhhmmss", timestamp())}"
  apply_immediately         = var.apply_immediately

  enabled_cloudwatch_logs_exports = var.enabled_cloudwatch_logs_exports

  monitoring_interval = var.monitoring_interval
  monitoring_role_arn = var.monitoring_interval > 0 ? aws_iam_role.monitoring[0].arn : null

  performance_insights_enabled          = var.performance_insights_enabled
  performance_insights_retention_period = var.performance_insights_enabled ? var.performance_insights_retention_period : null
  performance_insights_kms_key_id       = var.performance_insights_enabled ? var.kms_key_id : null

  tags = local.tags

  lifecycle {
    ignore_changes = [
      # timestamp() would otherwise force a diff on every plan
      final_snapshot_identifier,
    ]
  }
}
