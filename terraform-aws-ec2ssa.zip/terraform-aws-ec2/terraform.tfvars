region             = "us-east-1"
name               = "demo-web"
ami_id             = "ami-0abcdef1234567890"   # replace with a valid AMI for your region
instance_type      = "t3.micro"
key_name           = "my-keypair"              # or remove / set null
security_group_ids = ["sg-0123456789abcdef0"]
subnet_id          = "subnet-0123456789abcdef0"

tags = {
  Environment = "dev"
  Project     = "demo"
}
