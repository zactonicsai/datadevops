resource "aws_instance" "this" {
  subnet_id = var.subnet_id

  launch_template {
    id      = var.launch_template_id
    version = var.launch_template_version
  }

  tags = merge(var.tags, { Name = var.name })
}
