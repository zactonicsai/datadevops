output "id" {
  description = "Launch template ID"
  value       = aws_launch_template.this.id
}

output "latest_version" {
  description = "Latest launch template version"
  value       = aws_launch_template.this.latest_version
}
