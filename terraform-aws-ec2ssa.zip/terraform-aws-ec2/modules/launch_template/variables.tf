variable "name" {
  description = "Name prefix for the launch template"
  type        = string
}

variable "ami_id" {
  description = "AMI ID for the instance"
  type        = string
}

variable "instance_type" {
  description = "EC2 instance type"
  type        = string
}

variable "key_name" {
  description = "EC2 key pair name (null for none)"
  type        = string
  default     = null
}

variable "security_group_ids" {
  description = "List of security group IDs"
  type        = list(string)
}

variable "user_data" {
  description = "Plain-text user data script (module base64-encodes it)"
  type        = string
  default     = ""
}

variable "tags" {
  description = "Tags applied to the instance"
  type        = map(string)
  default     = {}
}
