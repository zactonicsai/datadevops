#!/bin/bash
set -euxo pipefail
dnf update -y || yum update -y
dnf install -y httpd || yum install -y httpd
systemctl enable --now httpd
echo "<h1>Hello from $(hostname -f)</h1>" > /var/www/html/index.html
