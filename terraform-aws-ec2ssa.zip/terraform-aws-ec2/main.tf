module "launch_template" {
  source = "./modules/launch_template"

  name               = var.name
  ami_id             = var.ami_id
  instance_type      = var.instance_type
  key_name           = var.key_name
  security_group_ids = var.security_group_ids
  user_data          = file("${path.module}/user_data.sh")
  tags               = var.tags
}

module "ec2" {
  source = "./modules/ec2"

  name                    = var.name
  subnet_id               = var.subnet_id
  launch_template_id      = module.launch_template.id
  launch_template_version = module.launch_template.latest_version
  tags                    = var.tags
}
