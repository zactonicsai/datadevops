# terraform-aws-ec2 (Launch Template + EC2)

Minimal reusable modules: a Launch Template module and an EC2 module that consumes it.
All required values come from `terraform.tfvars`; user data is read from `user_data.sh`.

```
.
├── main.tf               # wires the two modules together
├── variables.tf
├── outputs.tf
├── versions.tf
├── terraform.tfvars      # <- fill in your values
├── user_data.sh          # <- bootstrap script
└── modules/
    ├── launch_template/
    └── ec2/
```

## Usage

```bash
terraform init
terraform plan
terraform apply
```

## Required tfvars

| Variable             | Description                        |
|----------------------|------------------------------------|
| `region`             | AWS region                         |
| `name`               | Name prefix / Name tag             |
| `ami_id`             | AMI ID                             |
| `instance_type`      | e.g. `t3.micro`                    |
| `security_group_ids` | List of SG IDs                     |
| `subnet_id`          | Subnet to launch in                |

Optional: `key_name`, `tags`.

## Notes
- The launch template module base64-encodes `user_data` for you; pass plain text.
- The EC2 module pins to `latest_version` of the template so instance changes flow through the template.
- Add `associate_public_ip_address`, `iam_instance_profile`, or block device mappings to the launch template module as needed.
