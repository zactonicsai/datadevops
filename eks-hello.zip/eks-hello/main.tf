# main.tf
# Builds the AWS side: an IAM role for the nodes, then the node group itself.

# ---------------------------------------------------------------------------
# LOCALS: computed values reused below. Keeps things DRY.
# ---------------------------------------------------------------------------
locals {
  # merge() combines maps. Baseline tags + whatever the tfvars adds.
  common_tags = merge(
    {
      Environment = var.env
      ManagedBy   = "terraform"
      Cluster     = var.cluster_name
    },
    var.tags
  )

  # e.g. "prod-hello-ng" - keeps names unique per environment.
  ng_name = "${var.env}-${var.node_group_name}"
}

# ---------------------------------------------------------------------------
# 1. TRUST POLICY
# An IAM role needs to say WHO is allowed to wear it. Here: EC2 instances.
# aws_iam_policy_document generates JSON for us instead of hand-writing it.
# ---------------------------------------------------------------------------
data "aws_iam_policy_document" "node_assume_role" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"] # "assume role" = temporarily become this role

    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"] # EC2 is the thing assuming it
    }
  }
}

# ---------------------------------------------------------------------------
# 2. THE ROLE ITSELF
# Every worker node boots up wearing this role. It is how nodes get permission
# to join the cluster and pull images.
# ---------------------------------------------------------------------------
resource "aws_iam_role" "node" {
  name               = "${local.ng_name}-node-role"
  assume_role_policy = data.aws_iam_policy_document.node_assume_role.json
  tags               = local.common_tags
}

# ---------------------------------------------------------------------------
# 3. ATTACH THE THREE REQUIRED AWS-MANAGED POLICIES
# for_each loops over the set, creating one attachment per policy.
# All three are mandatory - a node group will fail to become Active without them.
# ---------------------------------------------------------------------------
resource "aws_iam_role_policy_attachment" "node" {
  for_each = toset([
    # Lets the node register itself with the EKS control plane.
    "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy",
    # Lets the VPC CNI plugin hand out pod IP addresses.
    "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy",
    # Lets the node pull container images from ECR (your private registry).
    "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly",
  ])

  role       = aws_iam_role.node.name
  policy_arn = each.value # each.value = the current ARN in the loop
}

# ---------------------------------------------------------------------------
# 4. THE MANAGED NODE GROUP
# This is the actual ask: add worker capacity to an existing cluster.
# "Managed" means AWS handles the Auto Scaling Group, AMI updates and draining.
# ---------------------------------------------------------------------------
resource "aws_eks_node_group" "this" {
  # Which cluster to attach to. Read from the data source, so a typo in the
  # cluster name fails fast at plan time.
  cluster_name = data.aws_eks_cluster.this.name

  node_group_name = local.ng_name
  node_role_arn   = aws_iam_role.node.arn # the role from step 2
  subnet_ids      = var.subnet_ids        # where the EC2 instances live

  # --- Size ---------------------------------------------------------------
  scaling_config {
    desired_size = var.node_desired_size # start here
    min_size     = var.node_min_size     # never shrink below
    max_size     = var.node_max_size     # never grow above
  }

  # --- Machine shape ------------------------------------------------------
  instance_types = var.instance_types
  capacity_type  = var.capacity_type
  ami_type       = var.ami_type
  disk_size      = var.disk_size

  # NOTE: we deliberately do NOT set `version`. Omitting it means the node
  # group matches the cluster's Kubernetes version automatically. Fewer
  # version-mismatch surprises.

  # --- Safer rolling updates ---------------------------------------------
  update_config {
    # Replace at most 1 node at a time during upgrades. Use a number like 33
    # with max_unavailable_percentage instead if you want faster prod rollouts.
    max_unavailable = 1
  }

  # Labels land on the Kubernetes Node object. Pods can then target them
  # with nodeSelector, e.g. {workload = "web"}.
  labels = var.node_labels

  tags = merge(local.common_tags, { Name = local.ng_name })

  # --- Ordering -----------------------------------------------------------
  # Terraform builds in parallel by default. Without this, the node group can
  # be created before the IAM policies attach, and the nodes fail to join.
  depends_on = [aws_iam_role_policy_attachment.node]

  lifecycle {
    # After the HPA/Cluster Autoscaler changes node counts, we do not want
    # `terraform apply` to yank it back to desired_size. Ignore drift here.
    ignore_changes = [scaling_config[0].desired_size]
  }
}
