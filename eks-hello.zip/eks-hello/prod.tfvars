# prod.tfvars
# PROD = reliable, redundant, observable. Optimise for uptime, not cost.
# Run with:  terraform apply -var-file=prod.tfvars

# ---- Core (you MUST edit these three) --------------------------------------
region       = "us-east-1"
cluster_name = "my-prod-eks"  # <-- your existing cluster name
env          = "prod"

subnet_ids = [                # <-- PRIVATE subnets, 3 availability zones
  "subnet-0aaa1111prod",
  "subnet-0bbb2222prod",
  "subnet-0ccc3333prod",
]

# ---- Node group ------------------------------------------------------------
node_group_name   = "hello-ng"
instance_types    = ["m6i.large"]
capacity_type     = "ON_DEMAND"               # no surprise reclaims
ami_type          = "AL2023_x86_64_STANDARD"
disk_size         = 50
node_desired_size = 3                          # one per AZ
node_min_size     = 3                          # survive an AZ outage
node_max_size     = 10

node_labels = {
  workload = "web"
  tier     = "prod"
}

# ---- App -------------------------------------------------------------------
app_name       = "hello-web"
namespace      = "default"
image          = "nginxdemos/hello:0.4" # pin by digest for real prod workloads
container_port = 80

replicas         = 3
hpa_min_replicas = 3   # never fewer than 3 - survives losing a node
hpa_max_replicas = 20
hpa_cpu_target   = 60  # lower target = scale sooner = more headroom

cpu_request    = "200m"
memory_request = "128Mi"
cpu_limit      = "1000m"
memory_limit   = "256Mi"

# Public NLB so real users can reach it. Set service_internal = true if this
# should only be reachable from inside the VPC.
service_type     = "LoadBalancer"
service_internal = false

tags = {
  Owner      = "platform-team"
  CostCenter = "eng-prod"
  Compliance = "pci"
}
