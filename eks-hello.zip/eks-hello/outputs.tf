# outputs.tf
# Outputs are values Terraform prints after apply. Use them to grab the
# things you need next (URLs, names) without digging through the console.

output "node_group_name" {
  description = "Name of the node group that was created."
  value       = aws_eks_node_group.this.node_group_name
}

output "node_group_status" {
  description = "Should read ACTIVE once the nodes have joined the cluster."
  value       = aws_eks_node_group.this.status
}

output "node_role_arn" {
  description = "IAM role the worker nodes assume."
  value       = aws_iam_role.node.arn
}

output "app_url" {
  description = "Where to reach the hello page."
  # A ternary: condition ? value_if_true : value_if_false
  value = var.service_type == "LoadBalancer" ? (
    # try() returns the fallback if the value is not populated yet.
    try("http://${kubernetes_service.hello.status[0].load_balancer[0].ingress[0].hostname}", "load balancer still provisioning - re-run terraform output in ~3 min")
  ) : "ClusterIP only. Run: kubectl port-forward svc/${var.app_name} 8080:80 -n ${var.namespace}  then open http://localhost:8080"
}

output "handy_commands" {
  description = "Copy-paste commands for checking on things."
  value = {
    watch_pods  = "kubectl get pods -n ${var.namespace} -l app=${var.app_name} -w"
    watch_hpa   = "kubectl get hpa ${var.app_name} -n ${var.namespace} -w"
    watch_nodes = "kubectl get nodes -l eks.amazonaws.com/nodegroup=${aws_eks_node_group.this.node_group_name}"
  }
}
