# dev.tfvars
# DEV = cheap, small, disposable. Optimise for cost and fast feedback.
# Run with:  terraform apply -var-file=dev.tfvars

# ---- Core (you MUST edit these three) --------------------------------------
region       = "us-east-1"
cluster_name = "my-dev-eks"   # <-- your existing cluster name
env          = "dev"

subnet_ids = [                # <-- your subnet IDs, 2+ availability zones
  "subnet-0aaa1111dev",
  "subnet-0bbb2222dev",
]

# ---- Node group ------------------------------------------------------------
node_group_name   = "hello-ng"
instance_types    = ["t3.small", "t3a.small"] # 2 types = better Spot availability
capacity_type     = "SPOT"                    # ~70% cheaper, fine for dev
ami_type          = "AL2023_x86_64_STANDARD"
disk_size         = 20
node_desired_size = 1
node_min_size     = 1
node_max_size     = 2 # tight ceiling so a runaway loop cannot cost much

node_labels = {
  workload = "web"
  tier     = "dev"
}

# ---- App -------------------------------------------------------------------
app_name       = "hello-web"
namespace      = "default"
image          = "nginxdemos/hello:0.4"
container_port = 80

replicas         = 1
hpa_min_replicas = 1
hpa_max_replicas = 4
hpa_cpu_target   = 70

cpu_request    = "50m"
memory_request = "32Mi"
cpu_limit      = "200m"
memory_limit   = "64Mi"

# ClusterIP = no load balancer bill. Test with kubectl port-forward.
service_type     = "ClusterIP"
service_internal = false

tags = {
  Owner       = "platform-team"
  CostCenter  = "eng-sandbox"
  AutoShutdown = "true"
}
