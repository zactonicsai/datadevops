# k8s.tf
# Builds the Kubernetes side: the pods, the network entry point, and autoscaling.

locals {
  # Labels are how Kubernetes objects find each other. The Service uses these
  # to know which pods to send traffic to. Keep them identical everywhere.
  app_labels = {
    app = var.app_name
    env = var.env
  }
}

# ---------------------------------------------------------------------------
# DEPLOYMENT = "run N copies of this container and keep them alive"
# ---------------------------------------------------------------------------
resource "kubernetes_deployment" "hello" {
  metadata {
    name      = var.app_name
    namespace = var.namespace
    labels    = local.app_labels
  }

  spec {
    replicas = var.replicas # starting pod count

    # Which pods does this Deployment own? The ones matching these labels.
    selector {
      match_labels = local.app_labels
    }

    # --- The pod template: the blueprint every pod is stamped from ---------
    template {
      metadata {
        labels = local.app_labels # MUST match the selector above
      }

      spec {
        container {
          name  = "web"
          image = var.image # <-- your Docker image

          port {
            container_port = var.container_port
          }

          # --- Resources ---------------------------------------------------
          # requests = guaranteed reservation, used by the scheduler to pick
          #            a node. The HPA measures usage AGAINST the CPU request,
          #            so without a request, CPU autoscaling silently does nothing.
          # limits   = hard ceiling. Over the memory limit = pod killed (OOMKilled).
          resources {
            requests = {
              cpu    = var.cpu_request
              memory = var.memory_request
            }
            limits = {
              cpu    = var.cpu_limit
              memory = var.memory_limit
            }
          }

          # --- Health checks -----------------------------------------------
          # readiness: "can this pod take traffic YET?" Not ready = removed
          # from the Service. This is what makes deploys zero-downtime.
          readiness_probe {
            http_get {
              path = "/"
              port = var.container_port
            }
            initial_delay_seconds = 3
            period_seconds        = 5
          }

          # liveness: "is this pod stuck?" Failing = Kubernetes restarts it.
          liveness_probe {
            http_get {
              path = "/"
              port = var.container_port
            }
            initial_delay_seconds = 10
            period_seconds        = 10
          }
        }
      }
    }
  }

  # Do not try to schedule pods before there are nodes to run them on.
  depends_on = [aws_eks_node_group.this]

  lifecycle {
    # The HPA owns replica count at runtime. Stop Terraform fighting it.
    ignore_changes = [spec[0].replicas]
  }
}

# ---------------------------------------------------------------------------
# SERVICE = a stable address in front of pods that come and go
# ---------------------------------------------------------------------------
resource "kubernetes_service" "hello" {
  metadata {
    name      = var.app_name
    namespace = var.namespace
    labels    = local.app_labels

    # Annotations only matter when service_type = LoadBalancer.
    annotations = var.service_type == "LoadBalancer" ? {
      # "nlb" = Network Load Balancer: fast and cheap for plain TCP.
      "service.beta.kubernetes.io/aws-load-balancer-type"   = "nlb"
      # "internal" keeps it inside the VPC; "internet-facing" is public.
      "service.beta.kubernetes.io/aws-load-balancer-scheme" = var.service_internal ? "internal" : "internet-facing"
    } : {}
  }

  spec {
    # Send traffic to any pod carrying these labels.
    selector = local.app_labels

    port {
      port        = 80                  # the port callers hit
      target_port = var.container_port  # the port inside the container
      protocol    = "TCP"
    }

    type = var.service_type
  }
}

# ---------------------------------------------------------------------------
# HPA = Horizontal Pod Autoscaler: adds/removes PODS based on load
# (The node group's min/max above adds/removes MACHINES. Two different layers.)
# REQUIRES metrics-server installed in the cluster - see the tutorial.
# ---------------------------------------------------------------------------
resource "kubernetes_horizontal_pod_autoscaler_v2" "hello" {
  metadata {
    name      = var.app_name
    namespace = var.namespace
  }

  spec {
    # What am I scaling? Point at the Deployment above.
    scale_target_ref {
      api_version = "apps/v1"
      kind        = "Deployment"
      name        = kubernetes_deployment.hello.metadata[0].name
    }

    min_replicas = var.hpa_min_replicas
    max_replicas = var.hpa_max_replicas

    # The rule: keep average CPU across pods near the target percentage.
    metric {
      type = "Resource"
      resource {
        name = "cpu"
        target {
          type                = "Utilization"
          average_utilization = var.hpa_cpu_target # % of the cpu REQUEST
        }
      }
    }

    # --- Anti-flapping behaviour -------------------------------------------
    behavior {
      scale_up {
        # React fast to traffic spikes.
        stabilization_window_seconds = 30
        policy {
          type           = "Percent"
          value          = 100 # allowed to double the pod count...
          period_seconds = 30  # ...at most once every 30s
        }
      }
      scale_down {
        # Shrink slowly. 5 minutes of calm before removing pods, so a brief
        # dip in traffic does not cause a scale-down/scale-up loop.
        stabilization_window_seconds = 300
        policy {
          type           = "Percent"
          value          = 50
          period_seconds = 60
        }
      }
    }
  }
}
