# versions.tf
# This file tells Terraform which version of itself, and which "plugins"
# (called providers) it needs. Think of providers as translators: one speaks
# AWS, one speaks Kubernetes.

terraform {
  # Refuse to run on very old Terraform. 1.5 introduced features we rely on.
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws" # where to download the plugin from
      version = "~> 6.0"        # allow 6.x, block 7.x (breaking changes)
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.30"
    }
  }
}

# ---- AWS provider -----------------------------------------------------------
provider "aws" {
  region = var.region # which AWS region to talk to, e.g. us-east-1
}

# ---- Look up the cluster you ALREADY have -----------------------------------
# "data" = read-only. Terraform will NOT create or change these.
# It just fetches facts about the existing cluster so we can reuse them.
data "aws_eks_cluster" "this" {
  name = var.cluster_name
}

# Grabs a short-lived login token for the cluster. Used as a fallback.
data "aws_eks_cluster_auth" "this" {
  name = var.cluster_name
}

# ---- Kubernetes provider ----------------------------------------------------
# This is how Terraform logs into your cluster to create Deployments/Services.
provider "kubernetes" {
  # The cluster's API server URL (https://XXXX.eks.amazonaws.com)
  host = data.aws_eks_cluster.this.endpoint

  # The cluster's CA certificate, so we know we're talking to the real cluster.
  # It comes base64-encoded, so we decode it.
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.this.certificate_authority[0].data)

  # BEST PRACTICE: generate a fresh token at apply time by shelling out to the
  # AWS CLI. Tokens expire in ~15 min, so baking one into state is fragile.
  exec {
    api_version = "client.authentication.k8s.io/v1beta1"
    command     = "aws"
    args        = ["eks", "get-token", "--cluster-name", var.cluster_name, "--region", var.region]
  }
}
