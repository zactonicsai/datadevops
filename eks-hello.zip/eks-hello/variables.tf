# variables.tf
# Variables are the "knobs" of your Terraform. You set them per environment
# in dev.tfvars / prod.tfvars so the SAME code produces different results.

# ============================================================================
# CORE / SHARED
# ============================================================================

variable "region" {
  description = "AWS region the EKS cluster lives in."
  type        = string # a plain text value
}

variable "cluster_name" {
  description = "Name of the EXISTING EKS cluster. We do not create it."
  type        = string
}

variable "env" {
  description = "Environment short name. Used in resource names and tags."
  type        = string

  # Validation blocks stop bad input BEFORE anything is built.
  validation {
    condition     = contains(["dev", "prod"], var.env)
    error_message = "env must be either 'dev' or 'prod'."
  }
}

variable "subnet_ids" {
  description = <<-EOT
    Subnets the worker nodes will launch into.
    Use PRIVATE subnets in prod. Must be subnets the cluster already knows about.
  EOT
  type        = list(string) # a list of text values
}

# ============================================================================
# NODE GROUP (the EC2 machines that run your pods)
# ============================================================================

variable "node_group_name" {
  description = "Name for the new managed node group."
  type        = string
  default     = "hello-ng"
}

variable "instance_types" {
  description = <<-EOT
    EC2 sizes for the nodes. Listing MORE than one type helps Spot instances
    find capacity. For On-Demand, one type is fine.
  EOT
  type        = list(string)
  default     = ["t3.medium"]
}

variable "capacity_type" {
  description = "ON_DEMAND (reliable, pricier) or SPOT (cheap, can be reclaimed)."
  type        = string
  default     = "ON_DEMAND"

  validation {
    condition     = contains(["ON_DEMAND", "SPOT"], var.capacity_type)
    error_message = "capacity_type must be ON_DEMAND or SPOT."
  }
}

variable "ami_type" {
  description = <<-EOT
    OS image family for nodes.
    AL2023_x86_64_STANDARD  = Amazon Linux 2023, Intel/AMD (current default)
    AL2023_ARM_64_STANDARD  = Graviton/ARM, ~20% cheaper if your image is ARM
    (The old AL2_x86_64 family is end-of-life - do not use it.)
  EOT
  type        = string
  default     = "AL2023_x86_64_STANDARD"
}

variable "disk_size" {
  description = "Root EBS volume size per node, in GB."
  type        = number # a numeric value
  default     = 20
}

variable "node_desired_size" {
  description = "How many nodes to start with."
  type        = number
  default     = 2
}

variable "node_min_size" {
  description = "Floor. Autoscaling will never go below this."
  type        = number
  default     = 1
}

variable "node_max_size" {
  description = "Ceiling. Autoscaling will never go above this. Cost guardrail."
  type        = number
  default     = 3
}

variable "node_labels" {
  description = "Kubernetes labels stamped on every node in this group."
  type        = map(string) # key = value pairs
  default     = {}
}

# ============================================================================
# THE HELLO WORLD APP
# ============================================================================

variable "app_name" {
  description = "Name used for the Deployment, Service and HPA."
  type        = string
  default     = "hello-web"
}

variable "namespace" {
  description = "Kubernetes namespace to deploy into."
  type        = string
  default     = "default"
}

variable "image" {
  description = <<-EOT
    Docker image to run. Default is a public Docker Hub image that serves a
    simple HTML hello page showing which pod answered you - perfect for
    watching scaling happen.
    BEST PRACTICE: pin a real tag or a digest, never ':latest' in prod.
  EOT
  type        = string
  default     = "nginxdemos/hello:0.4"
}

variable "container_port" {
  description = "Port the container listens on. nginxdemos/hello uses 80."
  type        = number
  default     = 80
}

variable "replicas" {
  description = "Starting number of pods (HPA takes over after this)."
  type        = number
  default     = 2
}

variable "hpa_min_replicas" {
  description = "Fewest pods the autoscaler will keep running."
  type        = number
  default     = 2
}

variable "hpa_max_replicas" {
  description = "Most pods the autoscaler is allowed to create."
  type        = number
  default     = 10
}

variable "hpa_cpu_target" {
  description = "Target average CPU %. Above this -> add pods. Below -> remove."
  type        = number
  default     = 70
}

variable "cpu_request" {
  description = "CPU reserved per pod. REQUIRED for CPU-based autoscaling to work."
  type        = string
  default     = "100m" # 100 millicores = 0.1 of one CPU core
}

variable "memory_request" {
  description = "Memory reserved per pod."
  type        = string
  default     = "64Mi"
}

variable "cpu_limit" {
  description = "Hard CPU ceiling per pod."
  type        = string
  default     = "500m"
}

variable "memory_limit" {
  description = "Hard memory ceiling per pod. Exceed it and the pod is killed."
  type        = string
  default     = "128Mi"
}

variable "service_type" {
  description = <<-EOT
    How to expose the app.
    ClusterIP    = internal only (safest, use kubectl port-forward to test)
    LoadBalancer = creates a public AWS load balancer (costs money)
  EOT
  type        = string
  default     = "ClusterIP"
}

variable "service_internal" {
  description = "If LoadBalancer, true makes it internal (VPC-only) instead of public."
  type        = bool # true or false
  default     = false
}

variable "tags" {
  description = "Extra AWS tags applied to everything. Great for cost tracking."
  type        = map(string)
  default     = {}
}
