# ---------------------------------------------------------------------------
# Three tiers, three groups, referenced by group ID rather than CIDR.
#
# Every rule is a standalone aws_vpc_security_group_*_rule resource. Inline
# ingress/egress blocks on aws_security_group are mutually exclusive with
# these, force a whole-group replace on any edit, and produce useless plan
# diffs ("ingress.# 3 -> 4"). Standalone rules diff one rule at a time.
# ---------------------------------------------------------------------------

locals {
  # name_prefix (not name) lets AWS append a random suffix, which is what
  # makes create_before_destroy possible without a name collision.
  common_tags = var.tags
}

# --- Load balancer ---------------------------------------------------------

resource "aws_security_group" "alb" {
  name_prefix = "${var.name_prefix}-alb-"
  description = "Public entrypoint for Keycloak"
  vpc_id      = var.vpc_id

  tags = merge(local.common_tags, { Name = "${var.name_prefix}-alb", Tier = "edge" })

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_vpc_security_group_ingress_rule" "alb_https_ipv4" {
  for_each = toset(var.ingress.https_cidrs)

  security_group_id = aws_security_group.alb.id
  description       = "HTTPS from ${each.value}"
  cidr_ipv4         = each.value
  from_port         = 443
  to_port           = 443
  ip_protocol       = "tcp"
  tags              = local.common_tags
}

resource "aws_vpc_security_group_ingress_rule" "alb_https_ipv6" {
  for_each = toset(var.ingress.https_ipv6_cidrs)

  security_group_id = aws_security_group.alb.id
  description       = "HTTPS from ${each.value}"
  cidr_ipv6         = each.value
  from_port         = 443
  to_port           = 443
  ip_protocol       = "tcp"
  tags              = local.common_tags
}

resource "aws_vpc_security_group_ingress_rule" "alb_https_prefix_list" {
  for_each = toset(var.ingress.prefix_list_ids)

  security_group_id = aws_security_group.alb.id
  description       = "HTTPS from prefix list ${each.value}"
  prefix_list_id    = each.value
  from_port         = 443
  to_port           = 443
  ip_protocol       = "tcp"
  tags              = local.common_tags
}

resource "aws_vpc_security_group_ingress_rule" "alb_http_redirect" {
  for_each = var.ingress.allow_http_redirect ? toset(var.ingress.https_cidrs) : toset([])

  security_group_id = aws_security_group.alb.id
  description       = "HTTP from ${each.value} (301 redirect only)"
  cidr_ipv4         = each.value
  from_port         = 80
  to_port           = 80
  ip_protocol       = "tcp"
  tags              = local.common_tags
}

# Egress is scoped to the app group, not 0.0.0.0/0. A compromised ALB
# should not be a general-purpose outbound proxy.
resource "aws_vpc_security_group_egress_rule" "alb_to_app_http" {
  security_group_id            = aws_security_group.alb.id
  description                  = "Forward to Keycloak HTTP listener"
  referenced_security_group_id = aws_security_group.app.id
  from_port                    = var.ports.http
  to_port                      = var.ports.http
  ip_protocol                  = "tcp"
  tags                         = local.common_tags
}

resource "aws_vpc_security_group_egress_rule" "alb_to_app_health" {
  security_group_id            = aws_security_group.alb.id
  description                  = "Health checks against management port"
  referenced_security_group_id = aws_security_group.app.id
  from_port                    = var.ports.management
  to_port                      = var.ports.management
  ip_protocol                  = "tcp"
  tags                         = local.common_tags
}

# --- Keycloak instances ----------------------------------------------------

resource "aws_security_group" "app" {
  name_prefix = "${var.name_prefix}-app-"
  description = "Keycloak ASG instances"
  vpc_id      = var.vpc_id

  tags = merge(local.common_tags, { Name = "${var.name_prefix}-app", Tier = "app" })

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_vpc_security_group_ingress_rule" "app_from_alb_http" {
  security_group_id            = aws_security_group.app.id
  description                  = "HTTP from load balancer"
  referenced_security_group_id = aws_security_group.alb.id
  from_port                    = var.ports.http
  to_port                      = var.ports.http
  ip_protocol                  = "tcp"
  tags                         = local.common_tags
}

resource "aws_vpc_security_group_ingress_rule" "app_from_alb_health" {
  security_group_id            = aws_security_group.app.id
  description                  = "Health check from load balancer"
  referenced_security_group_id = aws_security_group.alb.id
  from_port                    = var.ports.management
  to_port                      = var.ports.management
  ip_protocol                  = "tcp"
  tags                         = local.common_tags
}

# Self-referencing rule: Infinispan cluster members talk to each other.
# This is the pair of rules that makes inline blocks blow up with a cycle;
# standalone rules resolve cleanly because the SG exists before its rules.
resource "aws_vpc_security_group_ingress_rule" "app_jgroups_tcp" {
  security_group_id            = aws_security_group.app.id
  description                  = "JGroups cluster transport"
  referenced_security_group_id = aws_security_group.app.id
  from_port                    = var.ports.jgroups
  to_port                      = var.ports.jgroups + 1 # +1 = FD_SOCK2
  ip_protocol                  = "tcp"
  tags                         = local.common_tags
}

resource "aws_vpc_security_group_egress_rule" "app_jgroups_tcp" {
  security_group_id            = aws_security_group.app.id
  description                  = "JGroups cluster transport"
  referenced_security_group_id = aws_security_group.app.id
  from_port                    = var.ports.jgroups
  to_port                      = var.ports.jgroups + 1
  ip_protocol                  = "tcp"
  tags                         = local.common_tags
}

resource "aws_vpc_security_group_egress_rule" "app_to_db" {
  security_group_id            = aws_security_group.app.id
  description                  = "PostgreSQL"
  referenced_security_group_id = aws_security_group.db.id
  from_port                    = var.ports.postgres
  to_port                      = var.ports.postgres
  ip_protocol                  = "tcp"
  tags                         = local.common_tags
}

# Needed for: yum/dnf, the Keycloak tarball, SSM, Secrets Manager.
# Replace with VPC endpoints in a locked-down account.
resource "aws_vpc_security_group_egress_rule" "app_https_out" {
  security_group_id = aws_security_group.app.id
  description       = "HTTPS egress for packages, SSM, Secrets Manager"
  cidr_ipv4         = "0.0.0.0/0"
  from_port         = 443
  to_port           = 443
  ip_protocol       = "tcp"
  tags              = local.common_tags
}

# --- Database --------------------------------------------------------------

resource "aws_security_group" "db" {
  name_prefix = "${var.name_prefix}-db-"
  description = "RDS PostgreSQL for Keycloak"
  vpc_id      = var.vpc_id

  tags = merge(local.common_tags, { Name = "${var.name_prefix}-db", Tier = "data" })

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_vpc_security_group_ingress_rule" "db_from_app" {
  security_group_id            = aws_security_group.db.id
  description                  = "PostgreSQL from Keycloak instances"
  referenced_security_group_id = aws_security_group.app.id
  from_port                    = var.ports.postgres
  to_port                      = var.ports.postgres
  ip_protocol                  = "tcp"
  tags                         = local.common_tags
}

# No egress rules on the DB group at all. Terraform removes the AWS default
# allow-all egress the moment you manage the group, which is the behaviour
# you want here.
