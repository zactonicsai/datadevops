variable "name_prefix" {
  description = "Prefix applied to every security group name, e.g. \"keycloak-dev\"."
  type        = string

  validation {
    condition     = can(regex("^[a-z0-9][a-z0-9-]{1,30}$", var.name_prefix))
    error_message = "name_prefix must be lowercase alphanumeric/hyphens, 2-31 chars."
  }
}

variable "vpc_id" {
  description = "ID of the EXISTING VPC. Passed in by the caller - this module never discovers it."
  type        = string
}

variable "ingress" {
  description = <<-EOT
    Who is allowed to reach the load balancer.
    Single object instead of five scalar variables: one thing to thread
    through the call site, and `optional()` keeps the common case empty.
  EOT
  type = object({
    https_cidrs        = optional(list(string), [])
    https_ipv6_cidrs   = optional(list(string), [])
    prefix_list_ids    = optional(list(string), [])
    allow_http_redirect = optional(bool, true)
  })
  default = {}

  validation {
    condition = length(var.ingress.https_cidrs) > 0 || length(var.ingress.prefix_list_ids) > 0 || length(var.ingress.https_ipv6_cidrs) > 0
    error_message = "Specify at least one of https_cidrs, https_ipv6_cidrs or prefix_list_ids."
  }
}

variable "ports" {
  description = "Ports Keycloak listens on. Defaults match Keycloak 26.x."
  type = object({
    http       = optional(number, 8080)
    management = optional(number, 9000) # /health/ready, /metrics
    jgroups    = optional(number, 7800) # Infinispan cluster transport
    postgres   = optional(number, 5432)
  })
  default = {}
}

variable "tags" {
  description = "Resource-specific tags only. Org-wide tags belong in provider default_tags."
  type        = map(string)
  default     = {}
}
