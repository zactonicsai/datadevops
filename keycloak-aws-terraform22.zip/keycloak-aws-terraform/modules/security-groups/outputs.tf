# Export IDs, not whole resource objects. Exporting the object leaks every
# attribute into the caller's graph and makes the module impossible to
# reimplement later without breaking someone.

output "alb_security_group_id" {
  description = "Attach to the load balancer."
  value       = aws_security_group.alb.id
}

output "app_security_group_id" {
  description = "Attach to the Keycloak launch template."
  value       = aws_security_group.app.id
}

output "db_security_group_id" {
  description = "Attach to the RDS instance."
  value       = aws_security_group.db.id
}
