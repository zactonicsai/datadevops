terraform {
  required_version = ">= 1.6"

  # Modules declare which providers they need, but NEVER configure them.
  # A provider block inside a module makes the module impossible to
  # for_each, and pins the caller's provider aliasing forever.
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.60"
    }
  }
}
