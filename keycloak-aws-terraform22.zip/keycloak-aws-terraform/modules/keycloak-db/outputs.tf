output "endpoint" {
  description = "host:port"
  value       = aws_db_instance.this.endpoint
}

output "address" {
  description = "Hostname only - what KC_DB_URL_HOST wants."
  value       = aws_db_instance.this.address
}

output "port" {
  value = aws_db_instance.this.port
}

output "database_name" {
  value = aws_db_instance.this.db_name
}

output "username" {
  value = aws_db_instance.this.username
}

output "master_user_secret_arn" {
  description = <<-EOT
    ARN of the RDS-managed Secrets Manager secret holding the master
    credentials. The app module turns this into an IAM read grant; the
    secret VALUE never passes through Terraform.
  EOT
  value       = aws_db_instance.this.master_user_secret[0].secret_arn
}

output "instance_id" {
  value = aws_db_instance.this.id
}
