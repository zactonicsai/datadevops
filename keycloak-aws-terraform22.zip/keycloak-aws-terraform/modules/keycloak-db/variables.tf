variable "name" {
  description = "Identifier for the instance and its child resources."
  type        = string
}

variable "subnet_ids" {
  description = <<-EOT
    EXISTING private subnet IDs for the DB subnet group.
    Passed in explicitly. A `data "aws_subnets"` with tag filters inside a
    module couples it invisibly to one org's naming convention and silently
    picks up new subnets someone adds later.
  EOT
  type        = list(string)

  validation {
    condition     = length(var.subnet_ids) >= 2
    error_message = "RDS requires subnets in at least two availability zones."
  }
}

variable "security_group_ids" {
  description = "Security groups to attach. Created by the security-groups module."
  type        = list(string)
}

variable "engine" {
  description = "Engine and sizing. One object beats eight scalars threaded through the call site."
  type = object({
    version               = optional(string, "16.4")
    instance_class        = optional(string, "db.t4g.small")
    allocated_storage     = optional(number, 20)
    max_allocated_storage = optional(number, 100) # storage autoscaling ceiling
    storage_type          = optional(string, "gp3")
    multi_az              = optional(bool, false)
    kms_key_id            = optional(string) # null => AWS-managed key
  })
  default = {}
}

variable "database" {
  description = "Logical database and master user Keycloak will connect as."
  type = object({
    name     = optional(string, "keycloak")
    username = optional(string, "kcadmin")
    port     = optional(number, 5432)
  })
  default = {}

  validation {
    condition     = can(regex("^[a-zA-Z][a-zA-Z0-9_]{0,62}$", var.database.name))
    error_message = "PostgreSQL database name must start with a letter; letters, digits, underscores only."
  }
}

variable "backup" {
  description = "Retention and maintenance windows."
  type = object({
    retention_period        = optional(number, 7)
    window                  = optional(string, "03:00-04:00")
    maintenance_window      = optional(string, "sun:04:30-sun:05:30")
    deletion_protection     = optional(bool, true)
    skip_final_snapshot     = optional(bool, false)
    performance_insights    = optional(bool, false)
    monitoring_interval     = optional(number, 0)
    apply_immediately       = optional(bool, false)
  })
  default = {}

  validation {
    condition     = var.backup.retention_period >= 1
    error_message = "Keycloak's realm data is not reconstructible; retention must be at least 1 day."
  }
}

variable "parameters" {
  description = "Extra postgres parameters, merged over the module's defaults."
  type        = map(string)
  default     = {}
}

variable "tags" {
  type    = map(string)
  default = {}
}
