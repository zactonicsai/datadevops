# ---------------------------------------------------------------------------
# Module boundary: everything here is created, changed and destroyed on the
# same schedule as the database itself. The subnet group and parameter group
# have no independent life, so they live with the instance rather than in a
# "aws_db_subnet_group wrapper module" that would be pure indirection.
# ---------------------------------------------------------------------------

locals {
  # Family is derived, not asked for. Every input you can compute is one
  # fewer thing the caller can get wrong.
  major_version    = split(".", var.engine.version)[0]
  parameter_family = "postgres${local.major_version}"

  default_parameters = {
    # Keycloak is chatty on connection setup; log the slow ones.
    "log_min_duration_statement" = "1000"
    "log_connections"            = "0"
  }

  parameters = merge(local.default_parameters, var.parameters)
}

resource "aws_db_subnet_group" "this" {
  name_prefix = "${var.name}-"
  description = "Keycloak database subnets"
  subnet_ids  = var.subnet_ids

  tags = merge(var.tags, { Name = "${var.name}-subnets" })

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_db_parameter_group" "this" {
  name_prefix = "${var.name}-"
  description = "Keycloak PostgreSQL parameters"
  family      = local.parameter_family

  dynamic "parameter" {
    for_each = local.parameters
    content {
      name  = parameter.key
      value = parameter.value
      # pending-reboot is the safe default: applying a static parameter
      # "immediately" errors out, and the resulting half-applied group is
      # the classic "parameter changed but nothing happened" bug. Override
      # per-parameter via var.parameters if you need live application.
      apply_method = "pending-reboot"
    }
  }

  tags = merge(var.tags, { Name = "${var.name}-params" })

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_db_instance" "this" {
  identifier_prefix = "${var.name}-"

  engine         = "postgres"
  engine_version = var.engine.version
  instance_class = var.engine.instance_class

  allocated_storage     = var.engine.allocated_storage
  max_allocated_storage = var.engine.max_allocated_storage
  storage_type          = var.engine.storage_type
  storage_encrypted     = true
  kms_key_id            = var.engine.kms_key_id

  db_name  = var.database.name
  username = var.database.username
  port     = var.database.port

  # No random_password, no password in tfvars, no password in state.
  # RDS generates the credential, stores it in Secrets Manager and rotates
  # it. The app reads it at boot via IAM. This is the single highest-value
  # practice in the whole project.
  manage_master_user_password   = true
  master_user_secret_kms_key_id = var.engine.kms_key_id

  multi_az               = var.engine.multi_az
  db_subnet_group_name   = aws_db_subnet_group.this.name
  vpc_security_group_ids = var.security_group_ids
  parameter_group_name   = aws_db_parameter_group.this.name
  publicly_accessible    = false

  backup_retention_period = var.backup.retention_period
  backup_window           = var.backup.window
  maintenance_window      = var.backup.maintenance_window
  copy_tags_to_snapshot   = true

  auto_minor_version_upgrade = true
  deletion_protection        = var.backup.deletion_protection
  apply_immediately          = var.backup.apply_immediately

  skip_final_snapshot       = var.backup.skip_final_snapshot
  final_snapshot_identifier = var.backup.skip_final_snapshot ? null : "${var.name}-final-${formatdate("YYYYMMDDhhmmss", timestamp())}"

  performance_insights_enabled = var.backup.performance_insights
  monitoring_interval          = var.backup.monitoring_interval
  monitoring_role_arn          = var.backup.monitoring_interval > 0 ? aws_iam_role.monitoring[0].arn : null

  enabled_cloudwatch_logs_exports = ["postgresql", "upgrade"]

  tags = merge(var.tags, { Name = var.name })

  lifecycle {
    # timestamp() in final_snapshot_identifier would otherwise force a diff
    # on every single plan.
    ignore_changes = [final_snapshot_identifier]

    precondition {
      condition     = !(var.backup.skip_final_snapshot && var.backup.deletion_protection)
      error_message = "skip_final_snapshot with deletion_protection is contradictory; pick one."
    }
  }
}

# count is used here for a genuinely optional sub-resource with no caller-
# facing references, which is the case where `[0]` indexing stays contained.
# It is NOT a substitute for feature-flagging the module itself.
resource "aws_iam_role" "monitoring" {
  count = var.backup.monitoring_interval > 0 ? 1 : 0

  name_prefix = "${var.name}-rds-mon-"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "monitoring.rds.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = var.tags
}

resource "aws_iam_role_policy_attachment" "monitoring" {
  count = var.backup.monitoring_interval > 0 ? 1 : 0

  role       = aws_iam_role.monitoring[0].name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonRDSEnhancedMonitoringRole"
}
