output "target_group_arn" {
  description = "Wire this into the ALB listener at the call site."
  value       = aws_lb_target_group.this.arn
}

output "autoscaling_group_name" {
  value = aws_autoscaling_group.this.name
}

output "launch_template_id" {
  value = aws_launch_template.this.id
}

output "instance_role_arn" {
  description = "Exposed so callers can attach their own policies."
  value       = aws_iam_role.instance.arn
}

output "instance_role_name" {
  value = aws_iam_role.instance.name
}

output "log_group_name" {
  value = aws_cloudwatch_log_group.this.name
}
