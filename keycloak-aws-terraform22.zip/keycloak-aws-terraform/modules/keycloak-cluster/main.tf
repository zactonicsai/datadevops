# ---------------------------------------------------------------------------
# One module = one lifecycle. The launch template, ASG, target group, log
# group and instance role are all replaced together when you ship a new
# Keycloak version, so they belong together. Splitting them into five
# single-resource modules would add five sets of variables and outputs and
# buy nothing.
#
# The module is deliberately SINGULAR. If you need three Keycloak clusters,
# for_each this module at the call site. A for_each inside the module would
# make every internal resource address depend on caller data, so adding a
# cluster to the middle of a map churns unrelated instances.
# ---------------------------------------------------------------------------

locals {
  user_data = base64encode(templatefile("${path.module}/templates/user-data.sh.tftpl", {
    keycloak_version = var.keycloak.version
    hostname         = var.keycloak.hostname
    java_opts        = var.keycloak.java_opts
    log_level        = var.keycloak.log_level
    http_port        = var.keycloak.http_port
    management_port  = var.keycloak.management_port
    db_host          = var.database.host
    db_port          = var.database.port
    db_name          = var.database.name
    db_username      = var.database.username
    db_secret_arn    = var.database.master_secret_arn
    log_group        = aws_cloudwatch_log_group.this.name
    cluster_name     = var.name
  }))
}

resource "aws_cloudwatch_log_group" "this" {
  name              = "/aws/ec2/${var.name}"
  retention_in_days = var.log_retention_days
  tags              = var.tags
}

# --- Target group ----------------------------------------------------------
# Lives with the ASG, not with the load balancer: it is replaced whenever the
# app is, while the ALB and its certificate outlive many app generations.

resource "aws_lb_target_group" "this" {
  name_prefix = substr(var.name, 0, 6) # AWS caps name_prefix at 6 chars
  port        = var.keycloak.http_port
  protocol    = "HTTP"
  vpc_id      = var.vpc_id
  target_type = "instance"

  deregistration_delay = var.target_group.deregistration_delay

  health_check {
    enabled = true
    # Keycloak 25+ serves /health on the MANAGEMENT port, not the HTTP port.
    # Health-checking / instead returns 302 to /admin and hides real failures.
    path                = "/health/ready"
    port                = tostring(var.keycloak.management_port)
    protocol            = "HTTP"
    matcher             = "200"
    healthy_threshold   = var.target_group.healthy_threshold
    unhealthy_threshold = var.target_group.unhealthy_threshold
    interval            = var.target_group.interval
    timeout             = var.target_group.timeout
  }

  stickiness {
    enabled         = var.target_group.stickiness_enabled
    type            = "lb_cookie"
    cookie_duration = var.target_group.stickiness_duration
  }

  tags = merge(var.tags, { Name = var.name })

  lifecycle {
    # A target group cannot be deleted while a listener references it, so it
    # must be created before the old one is destroyed.
    create_before_destroy = true
  }
}

# --- Launch template -------------------------------------------------------

resource "aws_launch_template" "this" {
  name_prefix   = "${var.name}-"
  image_id      = var.ami_id
  instance_type = var.capacity.instance_type
  user_data     = local.user_data

  iam_instance_profile {
    arn = aws_iam_instance_profile.this.arn
  }

  vpc_security_group_ids = var.security_group_ids

  block_device_mappings {
    device_name = "/dev/xvda"
    ebs {
      volume_size           = var.capacity.root_volume_gb
      volume_type           = "gp3"
      encrypted             = true
      delete_on_termination = true
    }
  }

  metadata_options {
    http_endpoint = "enabled"
    http_tokens   = "required" # IMDSv2 only
    # 2 hops so containers on the host can still reach IMDS if you add them.
    http_put_response_hop_limit = 2
  }

  monitoring {
    enabled = true
  }

  # Tags on the template do NOT propagate to instances; these blocks do.
  tag_specifications {
    resource_type = "instance"
    tags          = merge(var.tags, { Name = var.name })
  }

  tag_specifications {
    resource_type = "volume"
    tags          = merge(var.tags, { Name = "${var.name}-root" })
  }

  tags = var.tags

  lifecycle {
    create_before_destroy = true
  }
}

# --- Auto Scaling group ----------------------------------------------------

resource "aws_autoscaling_group" "this" {
  name_prefix = "${var.name}-"

  min_size         = var.capacity.min
  max_size         = var.capacity.max
  desired_capacity = var.capacity.desired

  vpc_zone_identifier = var.subnet_ids
  target_group_arns   = [aws_lb_target_group.this.arn]

  # ELB health, not just EC2: an instance whose Keycloak process is wedged
  # still passes the EC2 check forever.
  health_check_type         = "ELB"
  health_check_grace_period = var.capacity.health_check_grace
  wait_for_capacity_timeout = "10m"
  capacity_rebalance        = var.capacity.spot_percentage > 0

  mixed_instances_policy {
    instances_distribution {
      on_demand_base_capacity                  = var.capacity.on_demand_base
      on_demand_percentage_above_base_capacity = 100 - var.capacity.spot_percentage
      spot_allocation_strategy                 = "price-capacity-optimized"
    }

    launch_template {
      launch_template_specification {
        launch_template_id = aws_launch_template.this.id
        version            = aws_launch_template.this.latest_version
      }
    }
  }

  # Rolling replace on template change, rather than "new instances only when
  # something happens to scale out".
  instance_refresh {
    strategy = "Rolling"
    preferences {
      min_healthy_percentage = var.capacity.min_healthy_percentage
      instance_warmup        = tostring(var.capacity.health_check_grace)
    }
    triggers = ["launch_template", "tag"]
  }

  dynamic "tag" {
    for_each = merge(var.tags, { Name = var.name })
    content {
      key                 = tag.key
      value               = tag.value
      propagate_at_launch = true
    }
  }

  lifecycle {
    create_before_destroy = true

    precondition {
      condition     = length(var.subnet_ids) >= 2
      error_message = "Spread the ASG across at least two AZs."
    }
  }
}

resource "aws_autoscaling_policy" "cpu" {
  name                   = "${var.name}-cpu-target"
  autoscaling_group_name = aws_autoscaling_group.this.name
  policy_type            = "TargetTrackingScaling"

  target_tracking_configuration {
    predefined_metric_specification {
      predefined_metric_type = "ASGAverageCPUUtilization"
    }
    target_value = 60
  }
}
