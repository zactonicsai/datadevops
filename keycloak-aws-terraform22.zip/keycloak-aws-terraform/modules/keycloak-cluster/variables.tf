variable "name" {
  description = "Cluster name. Used as a prefix for every child resource."
  type        = string
}

variable "vpc_id" {
  description = "EXISTING VPC ID - required for the target group."
  type        = string
}

variable "subnet_ids" {
  description = "EXISTING private subnet IDs the ASG launches into."
  type        = list(string)
}

variable "security_group_ids" {
  description = "Security groups for the instances."
  type        = list(string)
}

variable "capacity" {
  description = "ASG sizing and rollout behaviour."
  type = object({
    min                   = optional(number, 2)
    max                   = optional(number, 4)
    desired               = optional(number, 2)
    instance_type         = optional(string, "t3.medium")
    root_volume_gb        = optional(number, 20)
    health_check_grace    = optional(number, 300)
    min_healthy_percentage = optional(number, 100)
    on_demand_base        = optional(number, 0)
    spot_percentage       = optional(number, 0) # 0 = all on-demand
  })
  default = {}

  validation {
    condition     = var.capacity.min >= 2
    error_message = "Keycloak's Infinispan caches need at least two nodes to survive a rolling replace."
  }

  validation {
    condition     = var.capacity.desired >= var.capacity.min && var.capacity.desired <= var.capacity.max
    error_message = "desired must sit between min and max."
  }
}

variable "keycloak" {
  description = "Keycloak runtime configuration."
  type = object({
    version         = optional(string, "26.0.7")
    hostname        = string # public FQDN users hit, e.g. auth.example.com
    java_opts       = optional(string, "-Xms512m -Xmx1024m")
    log_level       = optional(string, "INFO")
    http_port       = optional(number, 8080)
    management_port = optional(number, 9000)
  })

  validation {
    condition     = can(regex("^[0-9]+\\.[0-9]+(\\.[0-9]+)?$", var.keycloak.version))
    error_message = "keycloak.version must look like 26.0.7 or 26.1."
  }
}

variable "database" {
  description = "Connection details produced by the keycloak-db module."
  type = object({
    host              = string
    port              = optional(number, 5432)
    name              = string
    username          = string
    master_secret_arn = string
  })
}

variable "target_group" {
  description = "Health check tuning for the ALB target group."
  type = object({
    deregistration_delay = optional(number, 60)
    healthy_threshold    = optional(number, 2)
    unhealthy_threshold  = optional(number, 3)
    interval             = optional(number, 15)
    timeout              = optional(number, 5)
    stickiness_enabled   = optional(bool, true)
    stickiness_duration  = optional(number, 3600)
  })
  default = {}
}

variable "ami_id" {
  description = <<-EOT
    AMI to launch. Resolved by the CALLER (see envs/dev/main.tf), not by a
    data source in here - so that a new Amazon Linux release cannot silently
    replace your whole fleet on an unrelated `terraform apply`.
  EOT
  type        = string
}

variable "extra_iam_policy_arns" {
  description = "Additional managed policies for the instance role."
  type        = list(string)
  default     = []
}

variable "log_retention_days" {
  type    = number
  default = 30
}

variable "tags" {
  type    = map(string)
  default = {}
}
