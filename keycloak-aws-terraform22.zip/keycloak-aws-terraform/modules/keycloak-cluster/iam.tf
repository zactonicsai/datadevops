# Least-privilege instance role. The only interesting grant is read access
# to exactly one secret ARN - not "secretsmanager:*".

data "aws_iam_policy_document" "assume" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "instance" {
  name_prefix        = "${var.name}-inst-"
  assume_role_policy = data.aws_iam_policy_document.assume.json
  tags               = var.tags
}

# SSM Session Manager instead of SSH: no bastion, no key pairs, no port 22
# rule in the security group.
resource "aws_iam_role_policy_attachment" "ssm" {
  role       = aws_iam_role.instance.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
}

resource "aws_iam_role_policy_attachment" "cloudwatch_agent" {
  role       = aws_iam_role.instance.name
  policy_arn = "arn:aws:iam::aws:policy/CloudWatchAgentServerPolicy"
}

resource "aws_iam_role_policy_attachment" "extra" {
  for_each = toset(var.extra_iam_policy_arns)

  role       = aws_iam_role.instance.name
  policy_arn = each.value
}

data "aws_iam_policy_document" "secrets" {
  statement {
    sid       = "ReadDatabaseCredential"
    effect    = "Allow"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [var.database.master_secret_arn]
  }
}

resource "aws_iam_role_policy" "secrets" {
  name_prefix = "${var.name}-secrets-"
  role        = aws_iam_role.instance.id
  policy      = data.aws_iam_policy_document.secrets.json
}

resource "aws_iam_instance_profile" "this" {
  name_prefix = "${var.name}-"
  role        = aws_iam_role.instance.name

  lifecycle {
    create_before_destroy = true
  }
}
