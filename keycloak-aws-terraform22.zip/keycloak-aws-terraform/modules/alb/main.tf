resource "aws_lb" "this" {
  name_prefix        = substr(var.name, 0, 6)
  load_balancer_type = "application"
  internal           = var.options.internal
  subnets            = var.subnet_ids
  security_groups    = var.security_group_ids

  idle_timeout               = var.options.idle_timeout
  enable_deletion_protection = var.options.enable_deletion_protection
  drop_invalid_header_fields = var.options.drop_invalid_header_fields

  # dynamic block instead of a `count`-flagged second resource: the optional
  # feature stays inside the one resource that owns it.
  dynamic "access_logs" {
    for_each = var.access_logs.bucket == null ? [] : [var.access_logs]
    content {
      bucket  = access_logs.value.bucket
      prefix  = access_logs.value.prefix
      enabled = true
    }
  }

  tags = merge(var.tags, { Name = var.name })

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.this.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = var.options.ssl_policy
  certificate_arn   = var.certificate_arn

  default_action {
    type             = "forward"
    target_group_arn = var.default_target_group_arn
  }

  tags = var.tags
}

resource "aws_lb_listener_certificate" "extra" {
  for_each = toset(var.options.additional_certificate_arns)

  listener_arn    = aws_lb_listener.https.arn
  certificate_arn = each.value
}

resource "aws_lb_listener" "http_redirect" {
  count = var.options.http_redirect ? 1 : 0

  load_balancer_arn = aws_lb.this.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type = "redirect"
    redirect {
      port        = "443"
      protocol    = "HTTPS"
      status_code = "HTTP_301"
    }
  }

  tags = var.tags
}
