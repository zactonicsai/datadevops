output "arn" {
  value = aws_lb.this.arn
}

output "dns_name" {
  value = aws_lb.this.dns_name
}

output "zone_id" {
  description = "For the Route 53 alias record."
  value       = aws_lb.this.zone_id
}

output "https_listener_arn" {
  description = "Attach aws_lb_listener_rule to this for path-based routing."
  value       = aws_lb_listener.https.arn
}
