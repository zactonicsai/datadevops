variable "name" {
  type = string
}

variable "subnet_ids" {
  description = "EXISTING public subnet IDs (or private, for an internal ALB)."
  type        = list(string)
}

variable "security_group_ids" {
  type = list(string)
}

variable "certificate_arn" {
  description = "ACM certificate for the HTTPS listener."
  type        = string
}

variable "default_target_group_arn" {
  description = <<-EOT
    Where the HTTPS listener forwards by default. Supplied by the caller,
    which is what keeps this module independent of the app it fronts - the
    ALB outlives many app generations.
  EOT
  type        = string
}

variable "options" {
  type = object({
    internal                   = optional(bool, false)
    idle_timeout               = optional(number, 300)
    enable_deletion_protection = optional(bool, true)
    drop_invalid_header_fields = optional(bool, true)
    ssl_policy                 = optional(string, "ELBSecurityPolicy-TLS13-1-2-2021-06")
    http_redirect              = optional(bool, true)
    additional_certificate_arns = optional(list(string), [])
  })
  default = {}
}

variable "access_logs" {
  description = "Set bucket to enable. null bucket => logging off."
  type = object({
    bucket = optional(string)
    prefix = optional(string, "alb")
  })
  default = {}
}

variable "tags" {
  type    = map(string)
  default = {}
}
