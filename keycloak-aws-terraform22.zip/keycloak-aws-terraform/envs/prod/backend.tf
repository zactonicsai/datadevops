terraform {
  backend "s3" {
    key          = "keycloak/prod/terraform.tfstate"
    encrypt      = true
    use_lockfile = true
  }
}
