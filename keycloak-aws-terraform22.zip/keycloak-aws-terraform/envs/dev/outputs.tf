output "alb_dns_name" {
  description = "Point your CNAME/alias here."
  value       = module.alb.dns_name
}

output "keycloak_url" {
  value = "https://${var.hostname}"
}

output "database_endpoint" {
  value = module.database.endpoint
}

output "database_secret_arn" {
  description = "Read the master password with: aws secretsmanager get-secret-value --secret-id <arn>"
  value       = module.database.master_user_secret_arn
}

output "autoscaling_group_name" {
  value = module.keycloak.autoscaling_group_name
}

output "log_group_name" {
  value = module.keycloak.log_group_name
}
