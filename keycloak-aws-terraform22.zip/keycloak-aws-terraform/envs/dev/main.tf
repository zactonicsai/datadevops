# ---------------------------------------------------------------------------
# Root module. This is where ALL the environment discovery happens: data
# sources, AMI resolution, subnet validation. Modules stay pure functions of
# their inputs, so they can be unit-tested and reused in an account whose
# tagging conventions are nothing like yours.
# ---------------------------------------------------------------------------

locals {
  name = "keycloak-${var.environment}"
}

# --- lookups (root only) ---------------------------------------------------

data "aws_ami" "al2023" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-2023.*-kernel-6.1-x86_64"]
  }
}

# Fail fast at plan time if someone pastes in a subnet from the wrong VPC,
# instead of getting an opaque InvalidParameterValue from the ASG API.
data "aws_subnet" "private" {
  for_each = toset(var.private_subnet_ids)
  id       = each.value

  lifecycle {
    postcondition {
      condition     = self.vpc_id == var.vpc_id
      error_message = "Subnet ${self.id} belongs to ${self.vpc_id}, not ${var.vpc_id}."
    }
  }
}

# --- security groups -------------------------------------------------------

module "security_groups" {
  source = "../../modules/security-groups"

  name_prefix = local.name
  vpc_id      = var.vpc_id

  ingress = {
    https_cidrs = var.allowed_cidrs
  }
}

# --- database --------------------------------------------------------------

module "database" {
  source = "../../modules/keycloak-db"

  name               = local.name
  subnet_ids         = var.database_subnet_ids
  security_group_ids = [module.security_groups.db_security_group_id]

  engine = {
    version        = "16.4"
    instance_class = var.db_instance_class
    multi_az       = var.db_multi_az
  }

  database = {
    name     = "keycloak"
    username = "kcadmin"
  }

  backup = {
    retention_period    = var.environment == "prod" ? 30 : 7
    deletion_protection = var.deletion_protection
    skip_final_snapshot = !var.deletion_protection
    performance_insights = var.environment == "prod"
    monitoring_interval  = var.environment == "prod" ? 60 : 0
  }
}

# --- application -----------------------------------------------------------

module "keycloak" {
  source = "../../modules/keycloak-cluster"

  name               = local.name
  vpc_id             = var.vpc_id
  subnet_ids         = var.private_subnet_ids
  security_group_ids = [module.security_groups.app_security_group_id]
  ami_id             = data.aws_ami.al2023.id

  capacity = {
    min           = var.asg_min
    max           = var.asg_max
    desired       = var.asg_min
    instance_type = var.instance_type
  }

  keycloak = {
    version   = var.keycloak_version
    hostname  = var.hostname
    java_opts = "-Xms1024m -Xmx2048m"
  }

  # Outputs -> inputs. The dependency between these two modules is explicit
  # and visible in the graph; neither module knows the other exists.
  database = {
    host              = module.database.address
    port              = module.database.port
    name              = module.database.database_name
    username          = module.database.username
    master_secret_arn = module.database.master_user_secret_arn
  }
}

# --- load balancer ---------------------------------------------------------

module "alb" {
  source = "../../modules/alb"

  name               = local.name
  subnet_ids         = var.public_subnet_ids
  security_group_ids = [module.security_groups.alb_security_group_id]
  certificate_arn    = var.certificate_arn

  default_target_group_arn = module.keycloak.target_group_arn

  options = {
    enable_deletion_protection = var.deletion_protection
  }
}

# --- optional DNS ----------------------------------------------------------
# Uncomment if this account owns the zone.
#
# data "aws_route53_zone" "this" {
#   name         = "example.com"
#   private_zone = false
# }
#
# resource "aws_route53_record" "keycloak" {
#   zone_id = data.aws_route53_zone.this.zone_id
#   name    = var.hostname
#   type    = "A"
#
#   alias {
#     name                   = module.alb.dns_name
#     zone_id                = module.alb.zone_id
#     evaluate_target_health = true
#   }
# }

# ---------------------------------------------------------------------------
# Multiplicity belongs to the CALLER. Two Keycloak clusters look like this,
# with no change to the module at all:
#
#   module "keycloak" {
#     source   = "../../modules/keycloak-cluster"
#     for_each = var.clusters
#     name     = "keycloak-${each.key}"
#     ...
#   }
# ---------------------------------------------------------------------------
