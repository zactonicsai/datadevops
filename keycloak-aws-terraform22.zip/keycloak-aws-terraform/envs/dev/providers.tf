# The ONLY provider block in the entire project. Modules declare what they
# need in required_providers and inherit the configuration from here.
provider "aws" {
  region = var.region

  # Org-wide tags applied to every taggable resource by the provider itself.
  # This is why no module has a "add these six tags to everything" variable:
  # module-level `tags` is reserved for genuinely resource-specific values.
  default_tags {
    tags = {
      Application = "keycloak"
      Environment = var.environment
      ManagedBy   = "terraform"
      Repository  = "platform/keycloak-aws-terraform"
    }
  }
}
