variable "region" {
  type    = string
  default = "eu-west-1"
}

variable "environment" {
  type = string

  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "environment must be one of dev, staging, prod."
  }
}

# --- existing network (nothing here is created by this project) ------------

variable "vpc_id" {
  description = "EXISTING VPC."
  type        = string
}

variable "public_subnet_ids" {
  description = "EXISTING public subnets for the ALB."
  type        = list(string)
}

variable "private_subnet_ids" {
  description = "EXISTING private subnets for the Keycloak ASG."
  type        = list(string)
}

variable "database_subnet_ids" {
  description = "EXISTING subnets for the RDS subnet group. May equal private_subnet_ids."
  type        = list(string)
}

# --- exposure --------------------------------------------------------------

variable "hostname" {
  description = "Public FQDN, e.g. auth.dev.example.com."
  type        = string
}

variable "certificate_arn" {
  description = "ACM certificate covering hostname."
  type        = string
}

variable "allowed_cidrs" {
  description = "Who may reach the ALB. Narrow this in non-public environments."
  type        = list(string)
  default     = ["0.0.0.0/0"]
}

# --- sizing knobs surfaced to tfvars --------------------------------------

variable "keycloak_version" {
  type    = string
  default = "26.0.7"
}

variable "instance_type" {
  type    = string
  default = "t3.medium"
}

variable "asg_min" {
  type    = number
  default = 2
}

variable "asg_max" {
  type    = number
  default = 4
}

variable "db_instance_class" {
  type    = string
  default = "db.t4g.small"
}

variable "db_multi_az" {
  type    = bool
  default = false
}

variable "deletion_protection" {
  type    = bool
  default = false
}
