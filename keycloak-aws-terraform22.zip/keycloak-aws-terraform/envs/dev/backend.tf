# One state file per environment. Partial config so the bucket name is not
# hardcoded per env:
#   terraform init -backend-config=../backend.hcl -backend-config="key=keycloak/dev.tfstate"
terraform {
  backend "s3" {
    key          = "keycloak/dev/terraform.tfstate"
    encrypt      = true
    use_lockfile = true # native S3 locking; no DynamoDB table needed (TF >= 1.10)
  }
}
