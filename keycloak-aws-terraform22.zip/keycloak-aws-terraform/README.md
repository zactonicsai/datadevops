# Keycloak on AWS — Terraform module design reference

A working, opinionated example: Keycloak on an Auto Scaling group behind an
ALB target group, backed by RDS PostgreSQL, using **existing** VPC subnets and
purpose-built security groups.

The point of the repo is the *shape* of the modules, not the Keycloak install.

---

## Layout

```
.
├── modules/
│   ├── security-groups/     ALB + app + DB groups, standalone rule resources
│   ├── keycloak-db/         RDS Postgres, subnet group, parameter group
│   ├── keycloak-cluster/    launch template, ASG, target group, IAM, logs
│   └── alb/                 load balancer + listeners
└── envs/
    ├── dev/                 root module: providers, data lookups, wiring
    └── prod/                same root, different .tfvars
```

## Quick start

```bash
cp envs/dev/terraform.tfvars.example envs/dev/terraform.tfvars
$EDITOR envs/dev/terraform.tfvars     # your vpc_id, subnet_ids, cert ARN, hostname

terraform -chdir=envs/dev init -backend-config=../backend.hcl
terraform -chdir=envs/dev plan
terraform -chdir=envs/dev apply
```

Then point DNS for `hostname` at the `alb_dns_name` output, and read the
bootstrap admin credential out of Secrets Manager.

---

## The design rules this repo demonstrates

### 1. Draw module boundaries by lifecycle, not by resource type

`keycloak-cluster` owns the launch template, ASG, target group, IAM role and
log group because all five are replaced together when you ship a new Keycloak
version. A module that wraps a single `aws_lb_target_group` would be pure
indirection — a hundred lines of variables and outputs to save you twelve.

The target group is the interesting case. It could plausibly live in the `alb`
module. It doesn't, because it churns with the *app*, while the load balancer
and its certificate outlive many app generations. The listener wiring happens
at the root: `module.keycloak.target_group_arn` → `module.alb`.

### 2. Modules never configure providers

Every module has `required_providers` and **no** `provider` block. A provider
block inside a module makes it impossible to `for_each`, and permanently pins
the caller's aliasing. `envs/*/providers.tf` is the only provider config in the
project.

### 3. Modules never discover their own environment

No `data "aws_vpc"` with tag filters, no `data "aws_subnets"` inside any
module. Those couple a module invisibly to one org's naming convention and
silently pick up subnets somebody adds later. All lookups — including the AMI —
live in `envs/dev/main.tf`, and IDs are passed in.

The AMI case matters: resolving `most_recent = true` inside the cluster module
means an unrelated `apply` six weeks later replaces your entire fleet.

### 4. Object variables with `optional()`, not scalar sprawl

```hcl
variable "capacity" {
  type = object({
    min           = optional(number, 2)
    max           = optional(number, 4)
    instance_type = optional(string, "t3.medium")
    ...
  })
  default = {}
}
```

One thing to thread through the call site instead of eight. Keep nesting to two
levels — past that, every new input touches four files. Note that
`engine.version` drives `parameter_family` in `keycloak-db`: anything you can
derive is one fewer thing the caller can get wrong.

### 5. Multiplicity belongs to the caller

Every module here is singular. Three clusters means `for_each` on the module
call, not a `for_each` inside it — internal resource addresses that depend on
caller data turn small map edits into destroy/create churn on unrelated
instances.

### 6. `count` is not a feature-flag system

`count = var.create_x ? 1 : 0` leaks `[0]` into every downstream reference. It
appears twice in this repo, both times for a self-contained optional
sub-resource nothing else references (the RDS monitoring role, the HTTP
redirect listener). Optional *behaviour* inside a resource uses `dynamic`
blocks instead — see `access_logs` in the ALB module.

### 7. Standalone security group rules, always

`aws_vpc_security_group_ingress_rule` / `_egress_rule`, never inline
`ingress {}` blocks. Inline blocks force a whole-group replace on any edit,
produce useless diffs, and deadlock on the mutual references you need here:
ALB ↔ app ↔ DB, plus the self-referencing JGroups rule for Infinispan
clustering. Standalone rules resolve cleanly and diff one rule at a time.

Groups reference each other **by group ID**, never by CIDR. The DB group has no
egress rules at all.

### 8. Tags: `default_tags` for org-wide, module `tags` for specific

The provider applies `Application`/`Environment`/`ManagedBy`/`Repository` to
everything. No module carries a "add these six tags to every resource"
variable. Module-level `tags` is reserved for genuinely resource-specific
values, merged with a `Name`.

### 9. Secrets never pass through Terraform

`manage_master_user_password = true` — RDS generates the credential, stores it
in Secrets Manager and can rotate it. The cluster module receives only the
secret *ARN* and turns it into an IAM grant scoped to that one ARN. Instances
fetch the value at boot. No `random_password`, no password in tfvars, no
password in state.

### 10. Validate at plan time

- `validation` blocks on inputs (`asg_min >= 2`, DB name regex, at least two
  subnets, contradictory backup settings).
- `precondition` on resources for cross-input invariants.
- `postcondition` on the root's `data "aws_subnet"` lookup, so a subnet pasted
  in from the wrong VPC fails during plan rather than as an opaque API error
  fifteen minutes into an apply.

### 11. Export IDs, not objects

Outputs are `alb_security_group_id`, not the whole `aws_security_group`. Export
the object and every attribute joins the caller's graph, and you can never
reimplement the module without breaking someone.

### 12. Environment reuse: same root, different `.tfvars`

That's the baseline, and `envs/prod` is exactly that. Reach for Terragrunt or
Terraform Stacks only once the root config *itself* starts getting copy-pasted
with real structural differences — not before.

---

## Keycloak-specific details worth knowing

| Thing | Why |
|---|---|
| Health check on port **9000**, path `/health/ready` | Keycloak 25+ serves health on the management port. Checking `/` on 8080 returns a 302 and hides real failures. |
| `KC_CACHE_STACK=jdbc-ping` | Infinispan peer discovery over the database. No multicast, no static peer list, no EC2 describe permissions — nodes joining and leaving an ASG just work. |
| Port 7800–7801 self-referencing SG rule | JGroups transport + FD_SOCK2 between cluster members. |
| `KC_PROXY_HEADERS=xforwarded` + `KC_HOSTNAME=https://…` | Without both, Keycloak issues redirects and token issuer URLs pointing at the instance's private IP. |
| ALB stickiness on | Not required with a working Infinispan cluster, but it keeps auth flows on one node and makes failures much easier to reason about. |
| `kc.sh build` at bootstrap, `start --optimized` at runtime | Skips a ~30s augmentation step on every restart. |
| `health_check_type = "ELB"` | An instance whose Keycloak process is wedged passes the EC2 check forever. |
| `instance_refresh` | Rolling replace when the launch template changes, rather than "new instances eventually, whenever something scales out". |

---

## Known trade-offs / what's deliberately missing

- **No VPC, NAT or route tables.** By design — this consumes existing network.
- **Bootstrap admin user** isn't created here. Set `KC_BOOTSTRAP_ADMIN_USERNAME`
  / `KC_BOOTSTRAP_ADMIN_PASSWORD` from a second secret for a first-run node, or
  run `kc.sh bootstrap-admin` via SSM once.
- **Egress is `0.0.0.0/0` on 443** for dnf, the Keycloak tarball, SSM and
  Secrets Manager. In a locked-down account, replace with VPC endpoints plus a
  private package mirror.
- **Downloading the tarball at boot** is fine for a reference; bake an AMI with
  Packer for anything real, and pass its ID via `ami_id`.
- **No WAF, no Shield, no rate limiting** on the ALB.
