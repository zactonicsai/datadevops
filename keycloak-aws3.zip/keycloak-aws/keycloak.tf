###############################################################################
# Keycloak 26.7.2 on ECS Fargate, fronted by an ALB, backed by the RDS module.
# Everything Keycloak-specific lives here; security settings are in security.tf.
###############################################################################

locals {
  keycloak_image = "${var.keycloak_image_repository}:${var.keycloak_version}"
  keycloak_url   = "https://${var.keycloak_hostname}"
}

resource "aws_cloudwatch_log_group" "keycloak" {
  name              = "/ecs/${local.name}"
  retention_in_days = var.log_retention_days
  kms_key_id        = null # set to aws_kms_key.main.arn after granting logs.amazonaws.com key access

  tags = local.tags
}

resource "aws_ecs_cluster" "this" {
  name = local.name

  setting {
    name  = "containerInsights"
    value = "enhanced"
  }

  tags = local.tags
}

resource "aws_ecs_cluster_capacity_providers" "this" {
  cluster_name       = aws_ecs_cluster.this.name
  capacity_providers = ["FARGATE"]

  default_capacity_provider_strategy {
    capacity_provider = "FARGATE"
    weight            = 1
  }
}

resource "aws_ecs_task_definition" "keycloak" {
  family                   = local.name
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = var.keycloak_cpu
  memory                   = var.keycloak_memory
  execution_role_arn       = aws_iam_role.ecs_execution.arn
  task_role_arn            = aws_iam_role.ecs_task.arn

  runtime_platform {
    operating_system_family = "LINUX"
    cpu_architecture        = "X86_64"
  }

  container_definitions = jsonencode([
    {
      name      = "keycloak"
      image     = local.keycloak_image
      essential = true

      # `start` re-augments the server on boot. For production, build an
      # optimized image (kc.sh build) and use ["start", "--optimized"].
      command = ["start"]

      portMappings = [
        { name = "http", containerPort = 8080, protocol = "tcp" },
        { name = "management", containerPort = 9000, protocol = "tcp" },
        { name = "jgroups", containerPort = 7800, protocol = "tcp" },
      ]

      environment = [
        # Database -> RDS PostgreSQL 18 (module output)
        { name = "KC_DB", value = "postgres" },
        { name = "KC_DB_URL", value = module.rds.jdbc_url },
        { name = "KC_DB_USERNAME", value = module.rds.master_username },
        { name = "KC_DB_POOL_MAX_SIZE", value = "20" },

        # HTTP / proxy: TLS is terminated at the ALB
        { name = "KC_HTTP_ENABLED", value = "true" },
        { name = "KC_HTTP_PORT", value = "8080" },
        { name = "KC_HTTP_MANAGEMENT_PORT", value = "9000" },
        { name = "KC_PROXY_HEADERS", value = "xforwarded" },
        { name = "KC_HOSTNAME", value = local.keycloak_url },
        { name = "KC_HOSTNAME_STRICT", value = "true" },

        # Health + metrics endpoints on the management port
        { name = "KC_HEALTH_ENABLED", value = "true" },
        { name = "KC_METRICS_ENABLED", value = "true" },

        # Clustering: jdbc-ping discovers peers through the same Postgres DB,
        # so no extra service discovery is needed on Fargate.
        { name = "KC_CACHE", value = "ispn" },
        { name = "KC_CACHE_STACK", value = "jdbc-ping" },

        { name = "KC_LOG_LEVEL", value = var.keycloak_log_level },
        { name = "KC_LOG_CONSOLE_OUTPUT", value = "json" },
      ]

      secrets = [
        {
          name      = "KC_DB_PASSWORD"
          valueFrom = "${module.rds.master_user_secret_arn}:password::"
        },
        {
          name      = "KC_BOOTSTRAP_ADMIN_USERNAME"
          valueFrom = "${aws_secretsmanager_secret.keycloak_admin.arn}:username::"
        },
        {
          name      = "KC_BOOTSTRAP_ADMIN_PASSWORD"
          valueFrom = "${aws_secretsmanager_secret.keycloak_admin.arn}:password::"
        },
      ]

      logConfiguration = {
        logDriver = "awslogs"
        options = {
          "awslogs-group"         = aws_cloudwatch_log_group.keycloak.name
          "awslogs-region"        = data.aws_region.current.region
          "awslogs-stream-prefix" = "keycloak"
        }
      }

      ulimits = [
        { name = "nofile", softLimit = 65536, hardLimit = 65536 }
      ]
    }
  ])

  tags = local.tags
}

resource "aws_ecs_service" "keycloak" {
  name            = local.name
  cluster         = aws_ecs_cluster.this.id
  task_definition = aws_ecs_task_definition.keycloak.arn
  desired_count   = var.keycloak_desired_count
  launch_type     = "FARGATE"

  enable_execute_command             = true
  health_check_grace_period_seconds  = 300
  deployment_minimum_healthy_percent = 100
  deployment_maximum_percent         = 200
  propagate_tags                     = "SERVICE"

  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }

  network_configuration {
    subnets          = var.private_subnet_ids
    security_groups  = [aws_security_group.keycloak.id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.keycloak.arn
    container_name   = "keycloak"
    container_port   = 8080
  }

  depends_on = [aws_lb_listener.https]

  tags = local.tags
}

# --- Load balancer --------------------------------------------------------------

resource "aws_lb" "keycloak" {
  name                       = "${local.name}-alb"
  load_balancer_type         = "application"
  internal                   = var.alb_internal
  subnets                    = var.alb_internal ? var.private_subnet_ids : var.public_subnet_ids
  security_groups            = [aws_security_group.alb.id]
  drop_invalid_header_fields = true
  enable_deletion_protection = var.environment == "prod"
  idle_timeout               = 120

  tags = local.tags
}

resource "aws_lb_target_group" "keycloak" {
  name                 = "${local.name}-tg"
  vpc_id               = data.aws_vpc.this.id
  port                 = 8080
  protocol             = "HTTP"
  target_type          = "ip"
  deregistration_delay = 30

  health_check {
    enabled             = true
    path                = "/health/ready"
    port                = "9000"
    protocol            = "HTTP"
    matcher             = "200"
    interval            = 30
    timeout             = 5
    healthy_threshold   = 2
    unhealthy_threshold = 3
  }

  lifecycle {
    create_before_destroy = true
  }

  tags = local.tags
}

resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.keycloak.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = var.alb_ssl_policy
  certificate_arn   = var.certificate_arn

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.keycloak.arn
  }

  tags = local.tags
}

resource "aws_lb_listener" "http_redirect" {
  load_balancer_arn = aws_lb.keycloak.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type = "redirect"
    redirect {
      port        = "443"
      protocol    = "HTTPS"
      status_code = "HTTP_301"
    }
  }

  tags = local.tags
}
