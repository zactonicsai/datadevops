###############################################################################
# Root module - shared locals and module wiring
###############################################################################

data "aws_caller_identity" "current" {}

data "aws_region" "current" {}

locals {
  name = "${var.project_name}-${var.environment}"

  tags = merge(
    {
      Project     = var.project_name
      Environment = var.environment
      ManagedBy   = "terraform"
      Component   = "keycloak"
    },
    var.tags
  )
}

###############################################################################
# RDS PostgreSQL 18 - the only module in this stack
# Security groups, KMS key and the monitoring role come from security.tf.
###############################################################################

module "rds" {
  source = "./modules/rds"

  name               = "${local.name}-pg"
  subnet_ids         = var.private_subnet_ids
  security_group_ids = [aws_security_group.rds.id]

  engine_version         = var.db_engine_version
  parameter_group_family = "postgres18"

  instance_class        = var.db_instance_class
  allocated_storage     = var.db_allocated_storage
  max_allocated_storage = var.db_max_allocated_storage

  db_name         = var.db_name
  master_username = var.db_master_username

  kms_key_arn         = aws_kms_key.main.arn
  monitoring_role_arn = aws_iam_role.rds_monitoring.arn

  multi_az                = var.db_multi_az
  backup_retention_period = var.db_backup_retention_period
  deletion_protection     = var.db_deletion_protection
  skip_final_snapshot     = var.db_skip_final_snapshot

  tags = local.tags
}
