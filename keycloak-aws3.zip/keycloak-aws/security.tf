###############################################################################
# Security settings - KMS, security groups, IAM roles and secrets.
# Kept out of the RDS module on purpose: the module stays RDS-only and every
# security decision for the stack lives in this single file.
###############################################################################

# --- KMS ----------------------------------------------------------------------

resource "aws_kms_key" "main" {
  description             = "${local.name} - RDS storage, Performance Insights, secrets"
  enable_key_rotation     = true
  rotation_period_in_days = 365
  deletion_window_in_days = 30

  tags = merge(local.tags, { Name = "${local.name}-kms" })
}

resource "aws_kms_alias" "main" {
  name          = "alias/${local.name}"
  target_key_id = aws_kms_key.main.key_id
}

# --- Security groups -----------------------------------------------------------

resource "aws_security_group" "alb" {
  name        = "${local.name}-alb"
  description = "Ingress to the Keycloak load balancer"
  vpc_id      = data.aws_vpc.this.id

  tags = merge(local.tags, { Name = "${local.name}-alb" })

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_security_group" "keycloak" {
  name        = "${local.name}-tasks"
  description = "Keycloak Fargate tasks"
  vpc_id      = data.aws_vpc.this.id

  tags = merge(local.tags, { Name = "${local.name}-tasks" })

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_security_group" "rds" {
  name        = "${local.name}-rds"
  description = "PostgreSQL 18 instance - reachable only from Keycloak tasks"
  vpc_id      = data.aws_vpc.this.id

  tags = merge(local.tags, { Name = "${local.name}-rds" })

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_security_group" "vpc_endpoints" {
  count = var.create_vpc_endpoints ? 1 : 0

  name        = "${local.name}-vpce"
  description = "Interface VPC endpoints"
  vpc_id      = data.aws_vpc.this.id

  tags = merge(local.tags, { Name = "${local.name}-vpce" })
}

# ALB: HTTPS in from the allowed CIDRs, HTTP only for the redirect
resource "aws_vpc_security_group_ingress_rule" "alb_https" {
  for_each = toset(var.alb_ingress_cidrs)

  security_group_id = aws_security_group.alb.id
  description       = "HTTPS from ${each.value}"
  cidr_ipv4         = each.value
  ip_protocol       = "tcp"
  from_port         = 443
  to_port           = 443
}

resource "aws_vpc_security_group_ingress_rule" "alb_http_redirect" {
  for_each = toset(var.alb_ingress_cidrs)

  security_group_id = aws_security_group.alb.id
  description       = "HTTP from ${each.value} (redirected to 443)"
  cidr_ipv4         = each.value
  ip_protocol       = "tcp"
  from_port         = 80
  to_port           = 80
}

resource "aws_vpc_security_group_egress_rule" "alb_to_tasks" {
  security_group_id            = aws_security_group.alb.id
  description                  = "ALB to Keycloak HTTP port"
  referenced_security_group_id = aws_security_group.keycloak.id
  ip_protocol                  = "tcp"
  from_port                    = 8080
  to_port                      = 8080
}

resource "aws_vpc_security_group_egress_rule" "alb_to_tasks_health" {
  security_group_id            = aws_security_group.alb.id
  description                  = "ALB to Keycloak management port (health checks)"
  referenced_security_group_id = aws_security_group.keycloak.id
  ip_protocol                  = "tcp"
  from_port                    = 9000
  to_port                      = 9000
}

# Keycloak tasks: only the ALB may talk to them
resource "aws_vpc_security_group_ingress_rule" "tasks_from_alb" {
  security_group_id            = aws_security_group.keycloak.id
  description                  = "Keycloak HTTP from ALB"
  referenced_security_group_id = aws_security_group.alb.id
  ip_protocol                  = "tcp"
  from_port                    = 8080
  to_port                      = 8080
}

resource "aws_vpc_security_group_ingress_rule" "tasks_health_from_alb" {
  security_group_id            = aws_security_group.keycloak.id
  description                  = "Keycloak management/health from ALB"
  referenced_security_group_id = aws_security_group.alb.id
  ip_protocol                  = "tcp"
  from_port                    = 9000
  to_port                      = 9000
}

# Infinispan clustering between tasks (jdbc-ping discovery, TCP transport)
resource "aws_vpc_security_group_ingress_rule" "tasks_cluster" {
  security_group_id            = aws_security_group.keycloak.id
  description                  = "Infinispan JGroups between Keycloak tasks"
  referenced_security_group_id = aws_security_group.keycloak.id
  ip_protocol                  = "tcp"
  from_port                    = 7800
  to_port                      = 7800
}

resource "aws_vpc_security_group_egress_rule" "tasks_all" {
  security_group_id = aws_security_group.keycloak.id
  description       = "Outbound (image pull, Secrets Manager, RDS)"
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"
}

# RDS: PostgreSQL from Keycloak tasks only
resource "aws_vpc_security_group_ingress_rule" "rds_from_tasks" {
  security_group_id            = aws_security_group.rds.id
  description                  = "PostgreSQL from Keycloak tasks"
  referenced_security_group_id = aws_security_group.keycloak.id
  ip_protocol                  = "tcp"
  from_port                    = 5432
  to_port                      = 5432
}

# VPC endpoints: HTTPS from inside the VPC
resource "aws_vpc_security_group_ingress_rule" "vpce_https" {
  count = var.create_vpc_endpoints ? 1 : 0

  security_group_id = aws_security_group.vpc_endpoints[0].id
  description       = "HTTPS from the VPC"
  cidr_ipv4         = data.aws_vpc.this.cidr_block
  ip_protocol       = "tcp"
  from_port         = 443
  to_port           = 443
}

# --- IAM: RDS enhanced monitoring ---------------------------------------------

data "aws_iam_policy_document" "rds_monitoring_assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["monitoring.rds.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "rds_monitoring" {
  name               = "${local.name}-rds-monitoring"
  assume_role_policy = data.aws_iam_policy_document.rds_monitoring_assume.json
  tags               = local.tags
}

resource "aws_iam_role_policy_attachment" "rds_monitoring" {
  role       = aws_iam_role.rds_monitoring.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonRDSEnhancedMonitoringRole"
}

# --- IAM: ECS roles -------------------------------------------------------------

data "aws_iam_policy_document" "ecs_assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["ecs-tasks.amazonaws.com"]
    }
    condition {
      test     = "StringEquals"
      variable = "aws:SourceAccount"
      values   = [data.aws_caller_identity.current.account_id]
    }
  }
}

resource "aws_iam_role" "ecs_execution" {
  name               = "${local.name}-ecs-execution"
  assume_role_policy = data.aws_iam_policy_document.ecs_assume.json
  tags               = local.tags
}

resource "aws_iam_role_policy_attachment" "ecs_execution_managed" {
  role       = aws_iam_role.ecs_execution.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

data "aws_iam_policy_document" "ecs_execution_secrets" {
  statement {
    sid     = "ReadKeycloakSecrets"
    actions = ["secretsmanager:GetSecretValue"]
    resources = [
      module.rds.master_user_secret_arn,
      aws_secretsmanager_secret.keycloak_admin.arn,
    ]
  }

  statement {
    sid       = "DecryptSecrets"
    actions   = ["kms:Decrypt"]
    resources = [aws_kms_key.main.arn]
  }
}

resource "aws_iam_role_policy" "ecs_execution_secrets" {
  name   = "${local.name}-secrets-read"
  role   = aws_iam_role.ecs_execution.id
  policy = data.aws_iam_policy_document.ecs_execution_secrets.json
}

resource "aws_iam_role" "ecs_task" {
  name               = "${local.name}-ecs-task"
  assume_role_policy = data.aws_iam_policy_document.ecs_assume.json
  tags               = local.tags
}

data "aws_iam_policy_document" "ecs_task" {
  statement {
    sid = "ECSExec"
    actions = [
      "ssmmessages:CreateControlChannel",
      "ssmmessages:CreateDataChannel",
      "ssmmessages:OpenControlChannel",
      "ssmmessages:OpenDataChannel",
    ]
    resources = ["*"]
  }
}

resource "aws_iam_role_policy" "ecs_task" {
  name   = "${local.name}-task"
  role   = aws_iam_role.ecs_task.id
  policy = data.aws_iam_policy_document.ecs_task.json
}

# --- Secrets: Keycloak bootstrap admin -----------------------------------------

resource "random_password" "keycloak_admin" {
  length           = 32
  special          = true
  override_special = "!#$%&*()-_=+[]{}<>:?"
}

resource "aws_secretsmanager_secret" "keycloak_admin" {
  name        = "${local.name}/bootstrap-admin"
  description = "Keycloak temporary bootstrap admin credentials"
  kms_key_id  = aws_kms_key.main.arn

  tags = local.tags
}

resource "aws_secretsmanager_secret_version" "keycloak_admin" {
  secret_id = aws_secretsmanager_secret.keycloak_admin.id
  secret_string = jsonencode({
    username = var.keycloak_admin_username
    password = random_password.keycloak_admin.result
  })
}
