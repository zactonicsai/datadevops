# Keycloak 26.7.2 on AWS with RDS PostgreSQL 18

Terraform stack that runs Keycloak on ECS Fargate behind an ALB, backed by an
Amazon RDS for PostgreSQL 18 instance created by a dedicated local module.

## Layout

```
.
├── main.tf                 # locals, shared data sources, module "rds" call
├── network.tf              # non-Keycloak: VPC lookup + optional VPC endpoints
├── security.tf             # ALL security settings: KMS, SGs, IAM, secrets
├── keycloak.tf             # Keycloak: ECS cluster, task def, service, ALB
├── variables.tf
├── outputs.tf
├── versions.tf             # terraform + provider requirements, backend stub
├── terraform.tfvars.example
└── modules/
    └── rds/                # RDS-only module (no SGs, no IAM, no KMS)
        ├── main.tf         # subnet group, parameter group, db instance
        ├── variables.tf
        ├── outputs.tf
        └── versions.tf
```

The RDS module deliberately creates **only** database resources. Security
groups, the KMS key and the enhanced-monitoring role are built in `security.tf`
and injected into the module, so security review touches one file.

## Notes

- **PostgreSQL 18**: `engine_version = "18"` pins the major version; RDS selects
  the latest supported 18.x minor at creation and `auto_minor_version_upgrade`
  keeps it current. Pin a full version (e.g. `18.3`) if you need determinism.
- **Credentials**: `manage_master_user_password = true` means the DB password is
  generated and held by Secrets Manager — it never enters Terraform state. ECS
  injects it as `KC_DB_PASSWORD` via the `secrets` block.
- **TLS to the DB**: `rds.force_ssl = 1` in the parameter group, and the JDBC URL
  produced by the module appends `sslmode=require`.
- **Clustering**: `KC_CACHE_STACK=jdbc-ping` lets tasks discover each other
  through Postgres, so `keycloak_desired_count > 1` works without extra service
  discovery. Port 7800 is open task-to-task.
- **Bootstrap admin**: `KC_BOOTSTRAP_ADMIN_*` creates a temporary admin on first
  start. Create a permanent admin, then remove those secrets from the task
  definition.
- **Production image**: `command = ["start"]` re-augments on every boot. Build an
  optimized image (`kc.sh build`) in ECR and switch to `["start","--optimized"]`.

## Usage

```bash
cp terraform.tfvars.example terraform.tfvars   # fill in VPC, subnets, cert, hostname
terraform init
terraform plan
terraform apply
```

Then point `keycloak_hostname` at the `alb_dns_name` output.
