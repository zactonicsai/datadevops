###############################################################################
# Root outputs
###############################################################################

output "keycloak_url" {
  description = "Public Keycloak URL (point keycloak_hostname at the ALB)."
  value       = local.keycloak_url
}

output "keycloak_version" {
  description = "Deployed Keycloak version."
  value       = var.keycloak_version
}

output "alb_dns_name" {
  description = "ALB DNS name - create a CNAME/ALIAS from keycloak_hostname to this."
  value       = aws_lb.keycloak.dns_name
}

output "alb_zone_id" {
  description = "ALB hosted zone ID (for Route 53 alias records)."
  value       = aws_lb.keycloak.zone_id
}

output "ecs_cluster_name" {
  description = "ECS cluster running Keycloak."
  value       = aws_ecs_cluster.this.name
}

output "rds_endpoint" {
  description = "RDS PostgreSQL 18 endpoint."
  value       = module.rds.endpoint
}

output "rds_engine_version" {
  description = "Running PostgreSQL version."
  value       = module.rds.engine_version_actual
}

output "rds_master_user_secret_arn" {
  description = "Secrets Manager secret holding the RDS master credentials."
  value       = module.rds.master_user_secret_arn
}

output "keycloak_admin_secret_arn" {
  description = "Secrets Manager secret holding the bootstrap admin credentials."
  value       = aws_secretsmanager_secret.keycloak_admin.arn
}
