###############################################################################
# Root input variables (non-Keycloak infrastructure + Keycloak app settings)
###############################################################################

# --- General -----------------------------------------------------------------

variable "aws_region" {
  description = "AWS region to deploy into."
  type        = string
  default     = "eu-west-1"
}

variable "project_name" {
  description = "Short name used as a prefix for every resource."
  type        = string
  default     = "keycloak"
}

variable "environment" {
  description = "Environment name (dev, stage, prod)."
  type        = string
  default     = "dev"
}

variable "tags" {
  description = "Extra tags merged into the default tags."
  type        = map(string)
  default     = {}
}

# --- Networking (existing VPC) ------------------------------------------------

variable "vpc_id" {
  description = "ID of the existing VPC."
  type        = string
}

variable "private_subnet_ids" {
  description = "Private subnets for the ECS tasks and the RDS instance (>= 2 AZs)."
  type        = list(string)
}

variable "public_subnet_ids" {
  description = "Public subnets for the internet-facing ALB (>= 2 AZs)."
  type        = list(string)
}

variable "create_vpc_endpoints" {
  description = "Create interface/gateway endpoints so Fargate tasks in private subnets work without a NAT gateway."
  type        = bool
  default     = false
}

variable "route_table_ids" {
  description = "Route table IDs for the S3 gateway endpoint (only used when create_vpc_endpoints = true)."
  type        = list(string)
  default     = []
}

# --- Database (passed into modules/rds) ---------------------------------------

variable "db_engine_version" {
  description = "PostgreSQL version. \"18\" pins the major version and tracks the latest 18.x minor."
  type        = string
  default     = "18"
}

variable "db_instance_class" {
  description = "RDS instance class."
  type        = string
  default     = "db.t4g.medium"
}

variable "db_allocated_storage" {
  description = "Initial DB storage in GiB."
  type        = number
  default     = 50
}

variable "db_max_allocated_storage" {
  description = "Storage autoscaling ceiling in GiB."
  type        = number
  default     = 200
}

variable "db_name" {
  description = "Database name used by Keycloak."
  type        = string
  default     = "keycloak"
}

variable "db_master_username" {
  description = "RDS master username."
  type        = string
  default     = "kcadmin"
}

variable "db_multi_az" {
  description = "Run RDS Multi-AZ."
  type        = bool
  default     = true
}

variable "db_backup_retention_period" {
  description = "Automated backup retention in days."
  type        = number
  default     = 14
}

variable "db_deletion_protection" {
  description = "Enable RDS deletion protection."
  type        = bool
  default     = true
}

variable "db_skip_final_snapshot" {
  description = "Skip the final snapshot on destroy."
  type        = bool
  default     = false
}

# --- Keycloak ------------------------------------------------------------------

variable "keycloak_version" {
  description = "Keycloak container image tag. 26.7.2 is the current release."
  type        = string
  default     = "26.7.2"
}

variable "keycloak_image_repository" {
  description = "Container image repository for Keycloak."
  type        = string
  default     = "quay.io/keycloak/keycloak"
}

variable "keycloak_hostname" {
  description = "Public DNS name Keycloak is served on, e.g. sso.example.com."
  type        = string
}

variable "keycloak_admin_username" {
  description = "Bootstrap (temporary) admin username created on first start."
  type        = string
  default     = "admin"
}

variable "keycloak_desired_count" {
  description = "Number of Keycloak tasks. >1 uses the jdbc-ping cache stack for clustering."
  type        = number
  default     = 2
}

variable "keycloak_cpu" {
  description = "Fargate task CPU units."
  type        = number
  default     = 1024
}

variable "keycloak_memory" {
  description = "Fargate task memory in MiB."
  type        = number
  default     = 2048
}

variable "keycloak_log_level" {
  description = "Keycloak root log level."
  type        = string
  default     = "INFO"
}

variable "log_retention_days" {
  description = "CloudWatch Logs retention for the Keycloak log group."
  type        = number
  default     = 30
}

# --- Edge security -------------------------------------------------------------

variable "certificate_arn" {
  description = "ACM certificate ARN for the HTTPS listener (must cover keycloak_hostname)."
  type        = string
}

variable "alb_ingress_cidrs" {
  description = "CIDR blocks allowed to reach the ALB on 443. Restrict this in production."
  type        = list(string)
  default     = ["0.0.0.0/0"]
}

variable "alb_ssl_policy" {
  description = "ALB TLS security policy."
  type        = string
  default     = "ELBSecurityPolicy-TLS13-1-2-2021-06"
}

variable "alb_internal" {
  description = "Make the ALB internal instead of internet-facing."
  type        = bool
  default     = false
}
