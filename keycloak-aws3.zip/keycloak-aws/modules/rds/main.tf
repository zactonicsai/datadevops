###############################################################################
# modules/rds - PostgreSQL 18 instance for Keycloak
#
# Scope: DB subnet group, parameter group and the DB instance itself.
# Everything else (SGs, KMS, IAM) is injected by the root module.
###############################################################################

locals {
  final_snapshot_identifier = var.skip_final_snapshot ? null : "${var.name}-final-${formatdate("YYYYMMDDhhmmss", timestamp())}"
}

resource "aws_db_subnet_group" "this" {
  name        = "${var.name}-subnet-group"
  description = "Private subnets for ${var.name}"
  subnet_ids  = var.subnet_ids

  tags = merge(var.tags, { Name = "${var.name}-subnet-group" })
}

resource "aws_db_parameter_group" "this" {
  name        = "${var.name}-${replace(var.parameter_group_family, ".", "-")}"
  family      = var.parameter_group_family
  description = "PostgreSQL 18 parameters for ${var.name}"

  dynamic "parameter" {
    for_each = var.parameters
    content {
      name         = parameter.value.name
      value        = parameter.value.value
      apply_method = parameter.value.apply_method
    }
  }

  lifecycle {
    create_before_destroy = true
  }

  tags = merge(var.tags, { Name = "${var.name}-parameters" })
}

resource "aws_db_instance" "this" {
  identifier = var.name

  # Engine: PostgreSQL 18. Pinning to the major version lets RDS pick the
  # latest supported 18.x minor at create time and keeps in-place minor
  # upgrades non-destructive.
  engine                      = "postgres"
  engine_version              = var.engine_version
  auto_minor_version_upgrade  = var.auto_minor_version_upgrade
  allow_major_version_upgrade = false
  parameter_group_name        = aws_db_parameter_group.this.name
  ca_cert_identifier          = var.ca_cert_identifier

  # Sizing / storage
  instance_class        = var.instance_class
  storage_type          = var.storage_type
  allocated_storage     = var.allocated_storage
  max_allocated_storage = var.max_allocated_storage > 0 ? var.max_allocated_storage : null

  # Database
  db_name  = var.db_name
  username = var.master_username
  port     = var.port

  # Credentials are generated, stored and rotatable via Secrets Manager -
  # no password ever passes through Terraform state.
  manage_master_user_password   = true
  master_user_secret_kms_key_id = var.kms_key_arn

  # Placement / access
  db_subnet_group_name   = aws_db_subnet_group.this.name
  vpc_security_group_ids = var.security_group_ids
  publicly_accessible    = false
  multi_az               = var.multi_az

  # Encryption & auth
  storage_encrypted                   = true
  kms_key_id                          = var.kms_key_arn
  iam_database_authentication_enabled = var.iam_database_authentication_enabled

  # Backups & snapshots
  backup_retention_period   = var.backup_retention_period
  backup_window             = var.backup_window
  maintenance_window        = var.maintenance_window
  copy_tags_to_snapshot     = true
  skip_final_snapshot       = var.skip_final_snapshot
  final_snapshot_identifier = local.final_snapshot_identifier
  delete_automated_backups  = false
  deletion_protection       = var.deletion_protection

  # Observability
  performance_insights_enabled          = var.performance_insights_enabled
  performance_insights_kms_key_id       = var.performance_insights_enabled ? var.kms_key_arn : null
  performance_insights_retention_period = var.performance_insights_enabled ? var.performance_insights_retention_period : null
  monitoring_interval                   = var.monitoring_role_arn == null ? 0 : var.monitoring_interval
  monitoring_role_arn                   = var.monitoring_role_arn
  enabled_cloudwatch_logs_exports       = var.enabled_cloudwatch_logs_exports

  apply_immediately = var.apply_immediately

  lifecycle {
    ignore_changes = [final_snapshot_identifier]
  }

  tags = merge(var.tags, { Name = var.name })
}
