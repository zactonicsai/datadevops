###############################################################################
# modules/rds - input variables
# This module provisions the RDS PostgreSQL instance ONLY.
# Networking, security groups, KMS keys and IAM roles are created by the caller
# and passed in, so that security settings stay in the root security.tf file.
###############################################################################

variable "name" {
  description = "Name / identifier prefix for the RDS instance and its companion resources."
  type        = string
}

variable "subnet_ids" {
  description = "Private subnet IDs (at least two, in different AZs) for the DB subnet group."
  type        = list(string)

  validation {
    condition     = length(var.subnet_ids) >= 2
    error_message = "RDS requires at least two subnets in two different Availability Zones."
  }
}

variable "security_group_ids" {
  description = "Security group IDs to attach to the DB instance (created in the root module's security.tf)."
  type        = list(string)
}

# --- Engine ------------------------------------------------------------------

variable "engine_version" {
  description = "PostgreSQL engine version. Use the major version (\"18\") to always land on the latest supported 18.x minor."
  type        = string
  default     = "18"

  validation {
    condition     = startswith(var.engine_version, "18")
    error_message = "This module is pinned to PostgreSQL major version 18."
  }
}

variable "parameter_group_family" {
  description = "DB parameter group family."
  type        = string
  default     = "postgres18"
}

variable "parameters" {
  description = "DB parameter group parameters. Defaults enforce TLS-only connections."
  type = list(object({
    name         = string
    value        = string
    apply_method = optional(string, "immediate")
  }))
  default = [
    {
      name         = "rds.force_ssl"
      value        = "1"
      apply_method = "pending-reboot"
    },
    {
      name  = "log_min_duration_statement"
      value = "1000"
    },
    {
      name  = "log_connections"
      value = "1"
    },
    {
      name  = "log_disconnections"
      value = "1"
    }
  ]
}

# --- Sizing / storage --------------------------------------------------------

variable "instance_class" {
  description = "RDS instance class."
  type        = string
  default     = "db.t4g.medium"
}

variable "allocated_storage" {
  description = "Initial storage in GiB."
  type        = number
  default     = 50
}

variable "max_allocated_storage" {
  description = "Upper bound for storage autoscaling in GiB. Set to 0 to disable autoscaling."
  type        = number
  default     = 200
}

variable "storage_type" {
  description = "Storage type (gp3 recommended)."
  type        = string
  default     = "gp3"
}

# --- Database ----------------------------------------------------------------

variable "db_name" {
  description = "Name of the initial database created on the instance (used by Keycloak)."
  type        = string
  default     = "keycloak"
}

variable "master_username" {
  description = "Master username. The password is generated and rotated by AWS Secrets Manager."
  type        = string
  default     = "kcadmin"
}

variable "port" {
  description = "Database port."
  type        = number
  default     = 5432
}

# --- Security / encryption (values supplied by the root security.tf) ---------

variable "kms_key_arn" {
  description = "KMS key ARN used for storage, Performance Insights and the managed master-user secret."
  type        = string
}

variable "monitoring_role_arn" {
  description = "IAM role ARN for RDS Enhanced Monitoring. Null disables enhanced monitoring."
  type        = string
  default     = null
}

variable "iam_database_authentication_enabled" {
  description = "Enable IAM database authentication."
  type        = bool
  default     = true
}

variable "deletion_protection" {
  description = "Protect the instance from accidental deletion."
  type        = bool
  default     = true
}

# --- Availability / maintenance ---------------------------------------------

variable "multi_az" {
  description = "Deploy a standby in a second AZ."
  type        = bool
  default     = true
}

variable "backup_retention_period" {
  description = "Automated backup retention in days."
  type        = number
  default     = 14
}

variable "backup_window" {
  description = "Daily backup window (UTC)."
  type        = string
  default     = "02:00-03:00"
}

variable "maintenance_window" {
  description = "Weekly maintenance window (UTC)."
  type        = string
  default     = "sun:03:30-sun:04:30"
}

variable "auto_minor_version_upgrade" {
  description = "Automatically apply 18.x minor version upgrades during the maintenance window."
  type        = bool
  default     = true
}

variable "performance_insights_enabled" {
  description = "Enable Performance Insights."
  type        = bool
  default     = true
}

variable "performance_insights_retention_period" {
  description = "Performance Insights retention in days (7 = free tier)."
  type        = number
  default     = 7
}

variable "monitoring_interval" {
  description = "Enhanced Monitoring granularity in seconds (0 disables it)."
  type        = number
  default     = 60
}

variable "enabled_cloudwatch_logs_exports" {
  description = "Log types exported to CloudWatch Logs."
  type        = list(string)
  default     = ["postgresql", "upgrade"]
}

variable "skip_final_snapshot" {
  description = "Skip the final snapshot on destroy (leave false outside of sandboxes)."
  type        = bool
  default     = false
}

variable "apply_immediately" {
  description = "Apply modifications immediately instead of during the maintenance window."
  type        = bool
  default     = false
}

variable "ca_cert_identifier" {
  description = "RDS CA certificate identifier. Null keeps the AWS default."
  type        = string
  default     = null
}

variable "tags" {
  description = "Tags applied to all resources in this module."
  type        = map(string)
  default     = {}
}
