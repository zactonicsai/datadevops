# Terraform RDS Module

A small, reusable RDS module that provisions:

- An RDS instance (PostgreSQL by default, also MySQL / MariaDB / SQL Server / Oracle)
- A DB subnet group
- A dedicated security group, locked to the security groups or CIDRs you name
- A generated master password (unless you supply one)
- A Secrets Manager secret containing the credentials **and a ready-to-use JDBC URL**
- An IAM policy other resources can attach to read that secret

## Layout

```
.
├── modules/rds/              # the reusable module
│   ├── main.tf               # locals, password, subnet group, db instance
│   ├── security_group.tf     # SG + ingress/egress rules
│   ├── secrets.tf            # Secrets Manager secret + read policy
│   ├── variables.tf
│   ├── outputs.tf
│   └── versions.tf
└── examples/simple-postgres/ # runnable example
```

## Quick start

```hcl
module "orders_db" {
  source = "./modules/rds"

  name        = "orders"
  environment = "dev"

  vpc_id     = var.vpc_id
  subnet_ids = var.private_subnet_ids

  allowed_security_group_ids = [aws_security_group.app.id]

  engine        = "postgres"
  database_name = "orders"
  username      = "orders_admin"
}
```

Then:

```bash
cd examples/simple-postgres
terraform init
terraform plan
terraform apply
```

## What lands in Secrets Manager

The secret name defaults to `<environment>/<name>/rds` (e.g. `dev/orders/rds`).
The payload is JSON:

```json
{
  "engine": "postgres",
  "host": "orders-dev.abc123.us-east-1.rds.amazonaws.com",
  "port": "5432",
  "dbname": "orders",
  "username": "orders_admin",
  "password": "...",
  "jdbc_url": "jdbc:postgresql://orders-dev.abc123.us-east-1.rds.amazonaws.com:5432/orders",
  "uri": "postgresql://orders_admin:...@orders-dev...:5432/orders",
  "dbInstanceIdentifier": "orders-dev"
}
```

The key names match the shape AWS uses for RDS-managed secrets, so the console
and the standard rotation Lambdas can read it.

JDBC URLs are built per engine:

| Engine    | Format                                                    |
|-----------|-----------------------------------------------------------|
| postgres  | `jdbc:postgresql://host:5432/db`                          |
| mysql     | `jdbc:mysql://host:3306/db`                               |
| mariadb   | `jdbc:mariadb://host:3306/db`                             |
| sqlserver | `jdbc:sqlserver://host:1433;databaseName=db`              |
| oracle    | `jdbc:oracle:thin:@host:1521:db`                          |

## Consuming the secret

**Give a role read access:**

```hcl
resource "aws_iam_role_policy_attachment" "app" {
  role       = aws_iam_role.app_task.name
  policy_arn = module.orders_db.secret_read_policy_arn
}
```

**Inject into an ECS task definition:**

```hcl
secrets = [
  { name = "SPRING_DATASOURCE_URL",      valueFrom = "${module.orders_db.secret_arn}:jdbc_url::" },
  { name = "SPRING_DATASOURCE_USERNAME", valueFrom = "${module.orders_db.secret_arn}:username::" },
  { name = "SPRING_DATASOURCE_PASSWORD", valueFrom = "${module.orders_db.secret_arn}:password::" },
]
```

**Read it from the CLI:**

```bash
aws secretsmanager get-secret-value \
  --secret-id dev/orders/rds \
  --query SecretString --output text | jq -r .jdbc_url
```

## Key inputs

| Name | Description | Default |
|------|-------------|---------|
| `name` | Base name for all resources | required |
| `environment` | dev / stage / prod | `dev` |
| `vpc_id` | VPC for the security group | required |
| `subnet_ids` | Subnets for the DB subnet group (2+ AZs) | required |
| `database_name` | Initial database | required |
| `allowed_security_group_ids` | SGs allowed to connect | `[]` |
| `allowed_cidr_blocks` | CIDRs allowed to connect | `[]` |
| `engine` / `engine_version` | Engine selection | `postgres` / latest |
| `instance_class` | Instance size | `db.t3.micro` |
| `password` | Master password | generated |
| `secret_name` | Secret name override | `<env>/<name>/rds` |
| `deletion_protection` | Block deletion | `true` |
| `skip_final_snapshot` | Skip snapshot on destroy | `false` |

See `modules/rds/variables.tf` for the full list.

## Notes

- The password appears in Terraform state. Use an encrypted S3 backend with
  restricted access.
- The module writes the secret once. If you enable AWS rotation later, add
  `ignore_changes = [secret_string]` to the secret version, or Terraform will
  overwrite the rotated value on the next apply.
- For production, set `multi_az = true`, `deletion_protection = true`,
  `skip_final_snapshot = false`, and pass a customer-managed `kms_key_id`.
