locals {
  name_prefix = "${var.name}-${var.environment}"

  # Default ports per engine family.
  default_ports = {
    postgres  = 5432
    mysql     = 3306
    mariadb   = 3306
    sqlserver = 1433
    oracle    = 1521
  }

  engine_family = (
    startswith(var.engine, "sqlserver") ? "sqlserver" :
    startswith(var.engine, "oracle") ? "oracle" :
    var.engine
  )

  port = coalesce(var.port, lookup(local.default_ports, local.engine_family, 5432))

  # JDBC sub-protocol per engine family.
  jdbc_subprotocols = {
    postgres  = "postgresql"
    mysql     = "mysql"
    mariadb   = "mariadb"
    sqlserver = "sqlserver"
    oracle    = "oracle:thin"
  }

  jdbc_subprotocol = lookup(local.jdbc_subprotocols, local.engine_family, "postgresql")

  address = aws_db_instance.this.address

  # SQL Server and Oracle do not use the /<database> path form.
  jdbc_url = (
    local.engine_family == "sqlserver"
    ? "jdbc:sqlserver://${local.address}:${local.port};databaseName=${var.database_name}"
    : local.engine_family == "oracle"
    ? "jdbc:oracle:thin:@${local.address}:${local.port}:${var.database_name}"
    : "jdbc:${local.jdbc_subprotocol}://${local.address}:${local.port}/${var.database_name}"
  )

  master_password = var.password != null ? var.password : random_password.this[0].result

  tags = merge(
    {
      Name        = local.name_prefix
      Environment = var.environment
      ManagedBy   = "terraform"
      Module      = "rds"
    },
    var.tags
  )
}

###############################################################################
# Password
###############################################################################
resource "random_password" "this" {
  count = var.password == null ? 1 : 0

  length  = var.password_length
  special = true
  # RDS rejects slash, at-sign, double-quote and space in master passwords.
  override_special = "!#$%&*()-_=+[]{}<>:?"
}

###############################################################################
# Subnet group
###############################################################################
resource "aws_db_subnet_group" "this" {
  name       = "${local.name_prefix}-subnets"
  subnet_ids = var.subnet_ids

  tags = merge(local.tags, { Name = "${local.name_prefix}-subnets" })
}

###############################################################################
# Instance
###############################################################################
resource "aws_db_instance" "this" {
  identifier = local.name_prefix

  engine         = var.engine
  engine_version = var.engine_version
  instance_class = var.instance_class

  db_name  = var.database_name
  username = var.username
  password = local.master_password
  port     = local.port

  allocated_storage     = var.allocated_storage
  max_allocated_storage = var.max_allocated_storage > 0 ? var.max_allocated_storage : null
  storage_type          = var.storage_type
  storage_encrypted     = var.storage_encrypted
  kms_key_id            = var.kms_key_id

  db_subnet_group_name   = aws_db_subnet_group.this.name
  vpc_security_group_ids = [aws_security_group.this.id]
  publicly_accessible    = var.publicly_accessible
  multi_az               = var.multi_az
  parameter_group_name   = var.parameter_group_name

  backup_retention_period = var.backup_retention_period
  backup_window           = var.backup_window
  maintenance_window      = var.maintenance_window

  deletion_protection       = var.deletion_protection
  skip_final_snapshot       = var.skip_final_snapshot
  final_snapshot_identifier = var.skip_final_snapshot ? null : "${local.name_prefix}-final-${formatdate("YYYYMMDDhhmmss", timestamp())}"

  apply_immediately            = var.apply_immediately
  auto_minor_version_upgrade   = var.auto_minor_version_upgrade
  performance_insights_enabled = var.performance_insights_enabled

  monitoring_interval = var.monitoring_interval
  monitoring_role_arn = var.monitoring_interval > 0 ? var.monitoring_role_arn : null

  enabled_cloudwatch_logs_exports = var.enabled_cloudwatch_logs_exports

  copy_tags_to_snapshot = true

  tags = local.tags

  lifecycle {
    # The snapshot name is timestamp-based; ignore it so it never forces a diff.
    ignore_changes = [final_snapshot_identifier]
  }
}
