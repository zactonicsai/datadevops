# modules/rds

Reusable RDS instance + security group + Secrets Manager credentials.

See the repository root `README.md` for usage, the secret payload shape,
and the JDBC URL formats per engine.

Inputs and outputs are documented inline in `variables.tf` and `outputs.tf`.
