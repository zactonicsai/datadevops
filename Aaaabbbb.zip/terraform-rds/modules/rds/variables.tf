###############################################################################
# Naming / tagging
###############################################################################
variable "name" {
  description = "Base name used for all resources (e.g. \"orders-api\")."
  type        = string
}

variable "environment" {
  description = "Environment name (dev, stage, prod). Used in names and tags."
  type        = string
  default     = "dev"
}

variable "tags" {
  description = "Extra tags applied to every resource."
  type        = map(string)
  default     = {}
}

###############################################################################
# Networking
###############################################################################
variable "vpc_id" {
  description = "VPC in which the security group is created."
  type        = string
}

variable "subnet_ids" {
  description = "Subnet IDs for the DB subnet group (at least two AZs)."
  type        = list(string)
}

variable "allowed_cidr_blocks" {
  description = "CIDR blocks allowed to reach the database port."
  type        = list(string)
  default     = []
}

variable "allowed_security_group_ids" {
  description = "Security group IDs allowed to reach the database port (preferred over CIDRs)."
  type        = list(string)
  default     = []
}

variable "publicly_accessible" {
  description = "Whether the instance gets a public IP. Keep false unless you really need it."
  type        = bool
  default     = false
}

###############################################################################
# Engine
###############################################################################
variable "engine" {
  description = "Database engine: postgres, mysql, mariadb, sqlserver-ex, oracle-se2, etc."
  type        = string
  default     = "postgres"
}

variable "engine_version" {
  description = "Engine version. Leave null to let AWS pick the default for the major version."
  type        = string
  default     = null
}

variable "port" {
  description = "Database port. Leave null to use the engine default (5432 / 3306 / 1433 / 1521)."
  type        = number
  default     = null
}

variable "instance_class" {
  description = "Instance class."
  type        = string
  default     = "db.t3.micro"
}

variable "parameter_group_name" {
  description = "Optional existing DB parameter group."
  type        = string
  default     = null
}

###############################################################################
# Storage
###############################################################################
variable "allocated_storage" {
  description = "Allocated storage in GiB."
  type        = number
  default     = 20
}

variable "max_allocated_storage" {
  description = "Upper limit for storage autoscaling. Set to 0 to disable."
  type        = number
  default     = 100
}

variable "storage_type" {
  description = "Storage type (gp3, gp2, io1)."
  type        = string
  default     = "gp3"
}

variable "storage_encrypted" {
  description = "Encrypt storage at rest."
  type        = bool
  default     = true
}

variable "kms_key_id" {
  description = "KMS key ARN for storage encryption. Null uses the AWS managed key."
  type        = string
  default     = null
}

###############################################################################
# Credentials
###############################################################################
variable "database_name" {
  description = "Initial database name created on the instance."
  type        = string
}

variable "username" {
  description = "Master username."
  type        = string
  default     = "dbadmin"
}

variable "password" {
  description = "Master password. Leave null to generate a strong random one."
  type        = string
  default     = null
  sensitive   = true
}

variable "password_length" {
  description = "Length of the generated password."
  type        = number
  default     = 32
}

###############################################################################
# Secrets Manager
###############################################################################
variable "secret_name" {
  description = "Secrets Manager secret name. Null builds \"<environment>/<name>/rds\"."
  type        = string
  default     = null
}

variable "secret_kms_key_id" {
  description = "KMS key for the secret. Null uses the AWS managed key."
  type        = string
  default     = null
}

variable "secret_recovery_window_in_days" {
  description = "Days before a deleted secret is purged. 0 forces immediate deletion (handy in dev)."
  type        = number
  default     = 7
}

variable "extra_secret_values" {
  description = "Extra key/value pairs merged into the secret JSON payload."
  type        = map(string)
  default     = {}
}

###############################################################################
# Backup / maintenance / lifecycle
###############################################################################
variable "multi_az" {
  description = "Deploy a standby in a second AZ."
  type        = bool
  default     = false
}

variable "backup_retention_period" {
  description = "Days to retain automated backups."
  type        = number
  default     = 7
}

variable "backup_window" {
  description = "Daily backup window, UTC (hh24:mi-hh24:mi)."
  type        = string
  default     = "03:00-04:00"
}

variable "maintenance_window" {
  description = "Weekly maintenance window, UTC (ddd:hh24:mi-ddd:hh24:mi)."
  type        = string
  default     = "sun:04:00-sun:05:00"
}

variable "deletion_protection" {
  description = "Block accidental deletion of the instance."
  type        = bool
  default     = true
}

variable "skip_final_snapshot" {
  description = "Skip the final snapshot on destroy. True is convenient for dev only."
  type        = bool
  default     = false
}

variable "apply_immediately" {
  description = "Apply changes immediately instead of during the maintenance window."
  type        = bool
  default     = false
}

variable "performance_insights_enabled" {
  description = "Enable Performance Insights."
  type        = bool
  default     = false
}

variable "monitoring_interval" {
  description = "Enhanced monitoring interval in seconds (0 disables)."
  type        = number
  default     = 0
}

variable "monitoring_role_arn" {
  description = "IAM role ARN for enhanced monitoring. Required if monitoring_interval > 0."
  type        = string
  default     = null
}

variable "enabled_cloudwatch_logs_exports" {
  description = "Log types exported to CloudWatch Logs (e.g. [\"postgresql\", \"upgrade\"])."
  type        = list(string)
  default     = []
}

variable "auto_minor_version_upgrade" {
  description = "Allow automatic minor version upgrades."
  type        = bool
  default     = true
}
