output "db_instance_id" {
  description = "RDS instance identifier."
  value       = aws_db_instance.this.identifier
}

output "db_instance_arn" {
  description = "RDS instance ARN."
  value       = aws_db_instance.this.arn
}

output "db_instance_address" {
  description = "Hostname of the instance."
  value       = aws_db_instance.this.address
}

output "db_instance_endpoint" {
  description = "host:port endpoint."
  value       = aws_db_instance.this.endpoint
}

output "db_instance_port" {
  description = "Port the instance listens on."
  value       = local.port
}

output "database_name" {
  description = "Initial database name."
  value       = var.database_name
}

output "jdbc_url" {
  description = "JDBC connection URL (no credentials)."
  value       = local.jdbc_url
}

output "security_group_id" {
  description = "Security group attached to the instance."
  value       = aws_security_group.this.id
}

output "subnet_group_name" {
  description = "DB subnet group name."
  value       = aws_db_subnet_group.this.name
}

output "secret_arn" {
  description = "ARN of the Secrets Manager secret holding credentials and the JDBC URL."
  value       = aws_secretsmanager_secret.this.arn
}

output "secret_name" {
  description = "Name of the Secrets Manager secret."
  value       = aws_secretsmanager_secret.this.name
}

output "secret_read_policy_arn" {
  description = "Attach this IAM policy to any role that needs to read the secret."
  value       = aws_iam_policy.secret_read.arn
}

output "master_password" {
  description = "Master password. Prefer reading it from Secrets Manager."
  value       = local.master_password
  sensitive   = true
}
