locals {
  secret_name = coalesce(var.secret_name, "${var.environment}/${var.name}/rds")

  secret_payload = merge(
    {
      engine   = var.engine
      host     = local.address
      port     = tostring(local.port)
      dbname   = var.database_name
      username = var.username
      password = local.master_password

      # Ready-to-use connection strings for consumers.
      jdbc_url = local.jdbc_url
      uri      = "${local.jdbc_subprotocol}://${var.username}:${urlencode(local.master_password)}@${local.address}:${local.port}/${var.database_name}"

      # Matches the shape of an RDS-managed rotation secret, so the AWS
      # JDBC/rotation Lambdas and the Secrets Manager console understand it.
      dbInstanceIdentifier = aws_db_instance.this.identifier
    },
    var.extra_secret_values
  )
}

resource "aws_secretsmanager_secret" "this" {
  name        = local.secret_name
  description = "Credentials and JDBC URL for the ${local.name_prefix} RDS instance"
  kms_key_id  = var.secret_kms_key_id

  recovery_window_in_days = var.secret_recovery_window_in_days

  tags = merge(local.tags, { Name = local.secret_name })
}

resource "aws_secretsmanager_secret_version" "this" {
  secret_id     = aws_secretsmanager_secret.this.id
  secret_string = jsonencode(local.secret_payload)
}

###############################################################################
# Read-only policy other resources (ECS tasks, Lambdas, EC2 roles) can attach
# to fetch these credentials.
###############################################################################
data "aws_iam_policy_document" "secret_read" {
  statement {
    sid    = "ReadDatabaseSecret"
    effect = "Allow"

    actions = [
      "secretsmanager:GetSecretValue",
      "secretsmanager:DescribeSecret",
    ]

    resources = [aws_secretsmanager_secret.this.arn]
  }

  dynamic "statement" {
    for_each = var.secret_kms_key_id != null ? [1] : []

    content {
      sid       = "DecryptSecret"
      effect    = "Allow"
      actions   = ["kms:Decrypt"]
      resources = [var.secret_kms_key_id]
    }
  }
}

resource "aws_iam_policy" "secret_read" {
  name        = "${local.name_prefix}-rds-secret-read"
  description = "Read the ${local.name_prefix} database secret"
  policy      = data.aws_iam_policy_document.secret_read.json

  tags = local.tags
}
