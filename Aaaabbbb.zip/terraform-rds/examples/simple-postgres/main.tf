terraform {
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
  }
}

provider "aws" {
  region = var.region
}

###############################################################################
# Look up an existing VPC and its private subnets.
# Swap these data sources for your own VPC module outputs if you have them.
###############################################################################
data "aws_vpc" "selected" {
  default = var.vpc_id == null ? true : null
  id      = var.vpc_id
}

data "aws_subnets" "private" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.selected.id]
  }
}

###############################################################################
# The application security group. Only instances in this SG can reach the DB.
###############################################################################
resource "aws_security_group" "app" {
  name        = "orders-api-app-sg"
  description = "Application tier for the orders API"
  vpc_id      = data.aws_vpc.selected.id
}

###############################################################################
# The RDS module
###############################################################################
module "orders_db" {
  source = "../../modules/rds"

  name        = "orders"
  environment = "dev"

  vpc_id     = data.aws_vpc.selected.id
  subnet_ids = data.aws_subnets.private.ids

  # Grant access to the app tier only.
  allowed_security_group_ids = [aws_security_group.app.id]
  # allowed_cidr_blocks      = ["10.0.0.0/16"]  # alternative, less precise

  engine         = "postgres"
  engine_version = "16.3"
  instance_class = "db.t4g.micro"

  database_name = "orders"
  username      = "orders_admin"
  # password intentionally omitted -> a strong one is generated and stored
  # in Secrets Manager.

  allocated_storage     = 20
  max_allocated_storage = 100

  backup_retention_period = 7
  multi_az                = false

  # Dev-friendly settings. Flip both for anything real.
  deletion_protection            = false
  skip_final_snapshot            = true
  secret_recovery_window_in_days = 0

  enabled_cloudwatch_logs_exports = ["postgresql", "upgrade"]

  extra_secret_values = {
    app = "orders-api"
  }

  tags = {
    Owner = "platform-team"
    Cost  = "orders"
  }
}

###############################################################################
# Example consumer: an ECS task role that can read the secret at runtime.
###############################################################################
data "aws_iam_policy_document" "ecs_assume" {
  statement {
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["ecs-tasks.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "app_task" {
  name               = "orders-api-task-role"
  assume_role_policy = data.aws_iam_policy_document.ecs_assume.json
}

resource "aws_iam_role_policy_attachment" "app_reads_secret" {
  role       = aws_iam_role.app_task.name
  policy_arn = module.orders_db.secret_read_policy_arn
}
