output "endpoint" {
  value = module.orders_db.db_instance_endpoint
}

output "jdbc_url" {
  description = "Use this in Spring Boot / Hibernate config."
  value       = module.orders_db.jdbc_url
}

output "secret_arn" {
  description = "Fetch credentials with: aws secretsmanager get-secret-value --secret-id <this>"
  value       = module.orders_db.secret_arn
}

output "security_group_id" {
  value = module.orders_db.security_group_id
}
