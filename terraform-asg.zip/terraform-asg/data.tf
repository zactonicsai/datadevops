data "aws_vpc" "default" {
  count   = var.vpc_id == "" ? 1 : 0
  default = true
}

data "aws_subnets" "selected" {
  count = length(var.subnet_ids) == 0 ? 1 : 0

  filter {
    name   = "vpc-id"
    values = [local.vpc_id]
  }
}

data "aws_ami" "al2023" {
  count       = var.ami_id == "" ? 1 : 0
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-2023.*-kernel-6.1-x86_64"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

locals {
  name = "${var.project}-${var.environment}"

  vpc_id = var.vpc_id != "" ? var.vpc_id : data.aws_vpc.default[0].id

  subnet_ids = length(var.subnet_ids) > 0 ? var.subnet_ids : data.aws_subnets.selected[0].ids

  ami_id = var.ami_id != "" ? var.ami_id : data.aws_ami.al2023[0].id

  user_data = base64encode(templatefile("${path.module}/user_data.sh.tftpl", {
    project     = var.project
    environment = var.environment
    app_port    = var.app_port
    region      = var.aws_region
  }))
}
