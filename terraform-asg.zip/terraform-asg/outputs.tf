output "asg_name" {
  description = "Name of the Auto Scaling Group."
  value       = aws_autoscaling_group.this.name
}

output "asg_arn" {
  description = "ARN of the Auto Scaling Group."
  value       = aws_autoscaling_group.this.arn
}

output "launch_template_id" {
  description = "Launch template ID."
  value       = aws_launch_template.this.id
}

output "launch_template_latest_version" {
  description = "Latest version of the launch template."
  value       = aws_launch_template.this.latest_version
}

output "security_group_id" {
  description = "Security group attached to the instances."
  value       = aws_security_group.this.id
}

output "iam_role_name" {
  description = "IAM role assumed by the instances."
  value       = aws_iam_role.this.name
}

output "ami_id" {
  description = "AMI used by the launch template."
  value       = local.ami_id
}

output "vpc_id" {
  description = "VPC the ASG is deployed into."
  value       = local.vpc_id
}

output "subnet_ids" {
  description = "Subnets the ASG spans."
  value       = local.subnet_ids
}

output "capacity" {
  description = "Configured min / desired / max capacity."
  value = {
    min     = var.min_size
    desired = var.desired_capacity
    max     = var.max_size
  }
}
