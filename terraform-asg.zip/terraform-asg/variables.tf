variable "project" {
  description = "Project name, used as a prefix for resource names."
  type        = string
  default     = "webapp"
}

variable "environment" {
  description = "Deployment environment."
  type        = string

  validation {
    condition     = contains(["dev", "stage", "prod"], var.environment)
    error_message = "environment must be one of: dev, stage, prod."
  }
}

variable "aws_region" {
  description = "AWS region to deploy into."
  type        = string
  default     = "us-east-1"
}

variable "vpc_id" {
  description = "VPC to deploy into. Leave empty to use the account's default VPC."
  type        = string
  default     = ""
}

variable "subnet_ids" {
  description = "Subnets for the ASG. Leave empty to use all subnets in the chosen VPC."
  type        = list(string)
  default     = []
}

variable "instance_type" {
  description = "EC2 instance type."
  type        = string
  default     = "t3.micro"
}

variable "ami_id" {
  description = "AMI to launch. Leave empty to use the latest Amazon Linux 2023."
  type        = string
  default     = ""
}

variable "key_name" {
  description = "Optional EC2 key pair name. SSM Session Manager is enabled, so this is usually unnecessary."
  type        = string
  default     = null
}

variable "min_size" {
  description = "Minimum number of instances."
  type        = number
  default     = 1
}

variable "desired_capacity" {
  description = "Desired number of instances."
  type        = number
  default     = 1
}

variable "max_size" {
  description = "Maximum number of instances."
  type        = number
  default     = 2
}

variable "root_volume_size" {
  description = "Root EBS volume size in GB."
  type        = number
  default     = 20
}

variable "ingress_cidrs" {
  description = "CIDR blocks allowed to reach the instances on the app port."
  type        = list(string)
  default     = ["0.0.0.0/0"]
}

variable "app_port" {
  description = "Port the application listens on."
  type        = number
  default     = 80
}

variable "enable_cpu_scaling" {
  description = "Attach a target-tracking policy on average CPU utilization."
  type        = bool
  default     = true
}

variable "cpu_target" {
  description = "Target average CPU utilization percentage for scaling."
  type        = number
  default     = 60
}

variable "enable_detailed_monitoring" {
  description = "Enable EC2 detailed (1-minute) CloudWatch monitoring."
  type        = bool
  default     = false
}

variable "extra_tags" {
  description = "Additional tags applied to all resources."
  type        = map(string)
  default     = {}
}
