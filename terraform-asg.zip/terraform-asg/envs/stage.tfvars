project     = "webapp"
environment = "stage"
aws_region  = "us-east-1"

# Replace with your staging VPC and private subnets.
vpc_id     = ""
subnet_ids = []

instance_type    = "t3.small"
root_volume_size = 30

min_size         = 1
desired_capacity = 1
max_size         = 2

app_port      = 80
ingress_cidrs = ["10.0.0.0/8"]

enable_cpu_scaling         = true
cpu_target                 = 65
enable_detailed_monitoring = true

extra_tags = {
  Owner      = "platform-team"
  CostCenter = "engineering"
}
