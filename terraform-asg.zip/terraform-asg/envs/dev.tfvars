project     = "webapp"
environment = "dev"
aws_region  = "us-east-1"

# Leave vpc_id / subnet_ids empty to use the default VPC.
vpc_id     = ""
subnet_ids = []

instance_type    = "t3.micro"
root_volume_size = 20

min_size         = 1
desired_capacity = 1
max_size         = 2

app_port      = 80
ingress_cidrs = ["0.0.0.0/0"]

enable_cpu_scaling         = true
cpu_target                 = 70
enable_detailed_monitoring = false

extra_tags = {
  Owner      = "platform-team"
  CostCenter = "engineering"
}
