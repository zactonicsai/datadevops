project     = "webapp"
environment = "prod"
aws_region  = "us-east-1"

# Replace with your production VPC and private subnets across multiple AZs.
vpc_id     = ""
subnet_ids = []

instance_type    = "t3.medium"
root_volume_size = 50

min_size         = 1
desired_capacity = 1
max_size         = 2

app_port      = 80
ingress_cidrs = ["10.0.0.0/8"]

enable_cpu_scaling         = true
cpu_target                 = 55
enable_detailed_monitoring = true

extra_tags = {
  Owner      = "platform-team"
  CostCenter = "engineering"
  Compliance = "pci"
}
