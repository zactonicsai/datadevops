# AWS Auto Scaled EC2 (Terraform)

Auto Scaling Group of EC2 instances behind a launch template, with a bootstrap user data script and per-environment variable files.

Capacity defaults to **min 1 / desired 1 / max 2** in every environment.

## Layout

```
.
├── versions.tf          # Terraform + AWS provider constraints, default tags
├── variables.tf         # Input variables
├── data.tf              # VPC / subnet / AMI lookups, locals
├── security.tf          # Security group, IAM role, instance profile
├── main.tf              # Launch template, ASG, CPU target-tracking policy
├── outputs.tf           # Outputs
├── user_data.sh.tftpl   # Bootstrap script (rendered with templatefile)
└── envs/
    ├── dev.tfvars
    ├── stage.tfvars
    └── prod.tfvars
```

## Usage

Init once, then plan and apply per environment.

```bash
terraform init

# dev
terraform plan  -var-file=envs/dev.tfvars
terraform apply -var-file=envs/dev.tfvars

# stage
terraform apply -var-file=envs/stage.tfvars

# prod
terraform apply -var-file=envs/prod.tfvars
```

### Keeping environments isolated

A single state file can only hold one environment at a time. Pick one:

**Workspaces**

```bash
terraform workspace new dev
terraform workspace select dev
terraform apply -var-file=envs/dev.tfvars
```

**Separate backends** (recommended for prod) — uncomment the `backend "s3"` block in `versions.tf` and pass a per-environment key:

```bash
terraform init -reconfigure -backend-config="key=asg/dev/terraform.tfstate"
```

## What gets created

| Resource | Notes |
|---|---|
| Launch template | Amazon Linux 2023, gp3 encrypted root, IMDSv2 required |
| Auto Scaling Group | Rolling instance refresh on template change |
| Scaling policy | Target tracking on average CPU (toggle with `enable_cpu_scaling`) |
| Security group | Inbound on `app_port`, all outbound |
| IAM role + profile | `AmazonSSMManagedInstanceCore`, `CloudWatchAgentServerPolicy` |

## User data

`user_data.sh.tftpl` is rendered with `project`, `environment`, `app_port`, and `region`, then base64-encoded into the launch template. It updates packages, installs and configures nginx on the app port, writes an index page showing the environment and instance ID, exposes `/health`, and starts the SSM agent.

Output is logged to `/var/log/user-data.log` on each instance.

Editing the script changes the launch template, which triggers a rolling instance refresh on the next apply.

## Notes

- Instances are reachable via **SSM Session Manager** — no SSH key or bastion needed. Set `key_name` if you still want one.
- `desired_capacity` is in `ignore_changes` so that scaling activity isn't reverted by Terraform. Remove that line if you want Terraform to enforce it.
- `dev.tfvars` opens the app port to `0.0.0.0/0`. Stage and prod are restricted to `10.0.0.0/8` — adjust to your VPC CIDRs.
- The default VPC is used when `vpc_id` and `subnet_ids` are empty. Set both explicitly for stage and prod.
- No load balancer is included. To add one, create an `aws_lb_target_group` and set `target_group_arns` plus `health_check_type = "ELB"` on the ASG.
