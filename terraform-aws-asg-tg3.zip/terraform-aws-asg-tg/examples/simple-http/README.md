# Example: simple HTTP hello world

The smallest useful call of the module. Two nginx instances in an ASG behind an
ALB, serving a page that names the instance and AZ that answered — refresh a few
times and you can watch the load balancer rotate between them.

## What it creates

- Security groups for the ALB and the web instances
- A launch template running nginx from user data
- The ASG + target group, via the parent module
- An internet-facing ALB with an HTTP listener

## What it expects to already exist

- A VPC with public subnets (ALB) and subnets with outbound internet for the instances
- An IAM role and instance profile — not created here
- Optionally, policy ARNs to attach (defaults to `AmazonSSMManagedInstanceCore`)

## Usage

```hcl
module "hello" {
  source = "./examples/simple-http"

  vpc_id              = "vpc-0abc123"
  public_subnet_ids   = ["subnet-0pub1", "subnet-0pub2"]
  instance_subnet_ids = ["subnet-0app1", "subnet-0app2"]

  instance_role_name    = "web-instance-role"
  instance_profile_name = "web-instance-profile"

  greeting = "Hello from us-east-1"
}
```

Or run it directly:

```bash
terraform init
terraform apply \
  -var vpc_id=vpc-0abc123 \
  -var 'public_subnet_ids=["subnet-0pub1","subnet-0pub2"]' \
  -var 'instance_subnet_ids=["subnet-0app1","subnet-0app2"]' \
  -var instance_role_name=web-instance-role \
  -var instance_profile_name=web-instance-profile

curl "$(terraform output -raw url)"
```

## Notes

- The listener is plain HTTP so the example needs no ACM certificate. Add one and
  switch to port 443 before putting anything real behind it.
- Health checks hit `/healthz`, a static file nginx serves, so a failure means
  the instance is genuinely unreachable rather than the app being slow.
- Instances take no inbound traffic except from the ALB security group. Use SSM
  Session Manager to get a shell — there is no SSH rule and no key pair.
