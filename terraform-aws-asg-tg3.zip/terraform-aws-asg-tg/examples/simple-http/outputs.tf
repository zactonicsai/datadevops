output "url" {
  description = "Open this in a browser."
  value       = "http://${aws_lb.this.dns_name}"
}

output "alb_dns_name" {
  description = "ALB DNS name."
  value       = aws_lb.this.dns_name
}

output "autoscaling_group_name" {
  description = "Name of the ASG."
  value       = module.web_asg.autoscaling_group_name
}

output "target_group_arn" {
  description = "Target group ARN."
  value       = module.web_asg.target_group_arn
}
