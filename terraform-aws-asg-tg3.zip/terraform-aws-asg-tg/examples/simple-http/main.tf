###############################################################################
# Security groups
###############################################################################

resource "aws_security_group" "alb" {
  name_prefix = "${var.name_prefix}-alb-"
  description = "Public ingress to the hello ALB"
  vpc_id      = var.vpc_id

  tags = { Name = "${var.name_prefix}-alb" }

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_vpc_security_group_ingress_rule" "alb_http" {
  for_each = toset(var.allowed_cidrs)

  security_group_id = aws_security_group.alb.id
  description       = "HTTP from ${each.value}"
  cidr_ipv4         = each.value
  from_port         = 80
  to_port           = 80
  ip_protocol       = "tcp"
}

resource "aws_vpc_security_group_egress_rule" "alb_to_web" {
  security_group_id            = aws_security_group.alb.id
  description                  = "Forward to the web instances"
  referenced_security_group_id = aws_security_group.web.id
  from_port                    = 80
  to_port                      = 80
  ip_protocol                  = "tcp"
}

resource "aws_security_group" "web" {
  name_prefix = "${var.name_prefix}-web-"
  description = "Hello web instances"
  vpc_id      = var.vpc_id

  tags = { Name = "${var.name_prefix}-web" }

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_vpc_security_group_ingress_rule" "web_from_alb" {
  security_group_id            = aws_security_group.web.id
  description                  = "HTTP from the ALB only"
  referenced_security_group_id = aws_security_group.alb.id
  from_port                    = 80
  to_port                      = 80
  ip_protocol                  = "tcp"
}

resource "aws_vpc_security_group_egress_rule" "web_all" {
  security_group_id = aws_security_group.web.id
  description       = "Outbound for package installs and SSM"
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"
}

###############################################################################
# Launch template
###############################################################################

data "aws_ssm_parameter" "al2023" {
  name = "/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64"
}

locals {
  user_data = <<-BASH
    #!/bin/bash
    set -euxo pipefail

    dnf install -y nginx
    TOKEN=$(curl -sX PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 60")
    INSTANCE_ID=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/instance-id)
    AZ=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/placement/availability-zone)

    cat > /usr/share/nginx/html/index.html <<HTML
    <!doctype html>
    <html>
      <head><title>${var.greeting}</title></head>
      <body style="font-family: system-ui; padding: 3rem">
        <h1>${var.greeting}</h1>
        <p>Instance: $INSTANCE_ID</p>
        <p>Availability zone: $AZ</p>
      </body>
    </html>
    HTML

    # Lightweight endpoint for the target group health check.
    printf 'ok\n' > /usr/share/nginx/html/healthz

    systemctl enable --now nginx
  BASH
}

resource "aws_launch_template" "web" {
  name_prefix   = "${var.name_prefix}-src-"
  description   = "Hello world nginx host"
  image_id      = data.aws_ssm_parameter.al2023.value
  instance_type = var.instance_type
  user_data     = base64encode(local.user_data)

  block_device_mappings {
    device_name = "/dev/xvda"

    ebs {
      volume_size           = 10
      volume_type           = "gp3"
      encrypted             = true
      delete_on_termination = true
    }
  }

  metadata_options {
    http_endpoint = "enabled"
    http_tokens   = "required"
  }

  tags = { Name = "${var.name_prefix}-lt" }

  lifecycle {
    create_before_destroy = true
  }
}

###############################################################################
# ASG + target group
###############################################################################

module "web_asg" {
  source = "../../"

  name_prefix = var.name_prefix

  vpc_id             = var.vpc_id
  subnet_ids         = var.instance_subnet_ids
  security_group_ids = [aws_security_group.web.id]

  iam_role_name             = var.instance_role_name
  iam_instance_profile_name = var.instance_profile_name
  iam_policy_arns           = var.existing_policy_arns

  launch_template_id = aws_launch_template.web.id

  min_size         = var.min_size
  max_size         = var.max_size
  desired_capacity = var.min_size

  target_group_port     = 80
  target_group_protocol = "HTTP"

  health_check = {
    path     = "/healthz"
    interval = 15
    matcher  = "200"
  }

  tags = { Role = "web" }
}

###############################################################################
# Load balancer
###############################################################################

resource "aws_lb" "this" {
  name_prefix        = substr("${var.name_prefix}-", 0, 6)
  load_balancer_type = "application"
  internal           = false
  subnets            = var.public_subnet_ids
  security_groups    = [aws_security_group.alb.id]

  tags = { Name = "${var.name_prefix}-alb" }
}

resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.this.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = module.web_asg.target_group_arn
  }
}
