variable "region" {
  description = "AWS region."
  type        = string
  default     = "us-east-1"
}

variable "name_prefix" {
  description = "Prefix for all resource names."
  type        = string
  default     = "hello"
}

variable "vpc_id" {
  description = "Existing VPC ID."
  type        = string
}

variable "public_subnet_ids" {
  description = "Existing public subnets for the ALB."
  type        = list(string)
}

variable "instance_subnet_ids" {
  description = "Existing subnets for the web instances. Private subnets with a NAT route are fine."
  type        = list(string)
}

variable "allowed_cidrs" {
  description = "CIDRs allowed to reach the ALB."
  type        = list(string)
  default     = ["0.0.0.0/0"]
}

variable "instance_role_name" {
  description = "Existing IAM role name for the instances."
  type        = string
}

variable "instance_profile_name" {
  description = "Existing IAM instance profile that wraps instance_role_name."
  type        = string
}

variable "existing_policy_arns" {
  description = "Existing managed policy ARNs the module attaches to the role."
  type        = list(string)
  default     = ["arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"]
}

variable "instance_type" {
  description = "EC2 instance type."
  type        = string
  default     = "t3.micro"
}

variable "min_size" {
  description = "Minimum instance count."
  type        = number
  default     = 2
}

variable "max_size" {
  description = "Maximum instance count."
  type        = number
  default     = 4
}

variable "greeting" {
  description = "Text shown on the page."
  type        = string
  default     = "Hello from Terraform"
}

variable "tags" {
  description = "Tags applied to everything."
  type        = map(string)
  default = {
    Example   = "simple-http"
    ManagedBy = "terraform"
  }
}
