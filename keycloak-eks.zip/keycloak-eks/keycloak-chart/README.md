# Keycloak Helm chart for EKS — pinned to a dedicated node group

Deploys **Keycloak 26.7.0** (the current release, July 2026) onto a dedicated EKS managed node group, using the **official upstream image** `quay.io/keycloak/keycloak`.

---

## Why not the Bitnami chart?

The Bitnami chart is the one most search results point at, but as of 2026 it is a poor foundation for an identity system:

- Bitnami moved its free container catalogue to a **`bitnamilegacy` repository that receives no updates or security patches**. Charts that still reference the old repository break when an image is pulled on a fresh node.
- Maintained images now require a paid **Bitnami Secure Images** subscription.
- For the one service in your cluster that everything else depends on, running unpatched images is not a reasonable trade.

This chart pulls from `quay.io/keycloak/keycloak` — the image the Keycloak project itself publishes and patches. If you must stay on Bitnami as a short-term bridge, pin `image.repository: bitnamilegacy/keycloak`, mirror it into your own ECR, and treat it as temporary.

---

## Two modes

Set `mode` in values.yaml.

### `operator` (default, recommended)

The chart renders a `Keycloak` custom resource. The official Keycloak Operator turns it into a StatefulSet with correct probes, Infinispan cluster discovery, schema-migration handling, and zero-downtime patch updates.

Install the operator **first**:

```bash
kubectl create namespace keycloak

mkdir -p kc-operator && cd kc-operator
cat > kustomization.yaml <<'EOF'
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
namespace: keycloak
resources:
  - github.com/keycloak/keycloak-k8s-resources/kubernetes?ref=26.7.0
EOF
kubectl apply -k .
cd ..

kubectl -n keycloak rollout status deployment/keycloak-operator
```

**Pros:** correct by default; upgrade automation; realm import CR; fewer ways to get it subtly wrong.
**Cons:** needs CRDs (cluster-admin) and a running operator.

### `standalone`

The chart renders a plain StatefulSet + Services itself. No operator, no CRDs, no cluster-admin.

**Pros:** nothing else to install; every knob is visible in the templates.
**Cons:** you own cluster discovery, probes and upgrade safety.

---

## Install

```bash
# 1. Database credentials (or use External Secrets Operator — see below)
kubectl -n keycloak create secret generic keycloak-db-secret \
  --from-literal=username=kcadmin \
  --from-literal=password='<from AWS Secrets Manager>'

# 2. Check what will be created before creating it
helm lint ./keycloak-chart
helm template keycloak ./keycloak-chart -n keycloak -f my-values.yaml | less

# 3. Install
helm install keycloak ./keycloak-chart \
  -n keycloak --create-namespace \
  -f my-values.yaml \
  --wait --timeout 10m
```

Upgrade:

```bash
helm upgrade keycloak ./keycloak-chart -n keycloak -f my-values.yaml
```

Roll back:

```bash
helm history keycloak -n keycloak
helm rollback keycloak <revision> -n keycloak
```

> Helm rollback reverts Kubernetes objects. It does **not** revert database schema migrations, which Keycloak runs on start. Snapshot RDS before any minor-version upgrade — that snapshot is your real rollback plan.

---

## The part that pins Keycloak to your node group

Everything lives in the `nodeGroup:` block at the top of `values.yaml`:

```yaml
nodeGroup:
  enabled: true
  labelKey: workload         # matches --labels workload=keycloak
  labelValue: keycloak
  tolerateTaint: true
  taintKey: dedicated        # matches --taints key=dedicated,value=keycloak,effect=NO_SCHEDULE
  taintValue: keycloak
  taintEffect: NoSchedule    # Kubernetes spelling, not the CLI's NO_SCHEDULE
  spreadAcrossZones: true
```

From that the chart generates three things, and applies them in three places:

| Generated | What it does |
|---|---|
| `tolerations` | Gets past the node taint — "I am **allowed** here." |
| `affinity.nodeAffinity` | Matches the node label — "I **must** be here." |
| `topologySpreadConstraints` | One pod per AZ, so an AZ outage cannot take down logins. |

Applied to:

1. `spec.scheduling` — the Keycloak server pods
2. `spec.update.scheduling` — **the operator's upgrade Job**
3. the StatefulSet pod spec (standalone mode)

### Three details that trip people up

**You need tolerations *and* affinity.** A toleration alone lets pods drift onto other node groups. Affinity alone leaves them `Pending` with `untolerated taint`.

**There is no `nodeSelector` in the Keycloak CRD.** Verified against the 26.7.0 CRD: `spec.scheduling` accepts exactly `affinity`, `tolerations`, `topologySpreadConstraints`, `priorityClassName`. Tutorials that tell you to set `nodeSelector` are wrong — it is dropped. This chart emits `nodeAffinity` instead, which works in both modes.

**`spec.update.scheduling` matters.** When the image changes, the operator runs a temporary Job to decide whether a rolling update is safe. That Job is a separate pod. Without its own tolerations it cannot be scheduled onto tainted nodes, and the upgrade hangs silently on a `Pending` pod. This chart copies the rules automatically.

---

## Verify after installing

```bash
# pods are on the dedicated nodes?
kubectl -n keycloak get pods -o wide
kubectl get nodes -l workload=keycloak

# one pod per AZ?
for p in $(kubectl -n keycloak get pods -o name); do
  n=$(kubectl -n keycloak get $p -o jsonpath='{.spec.nodeName}')
  echo "$p -> $(kubectl get node $n -o jsonpath='{.metadata.labels.topology\.kubernetes\.io/zone}')"
done

# public URL correct end to end?
curl -s https://auth.example.com/realms/master/.well-known/openid-configuration | jq .issuer
```

The `issuer` must print exactly `https://auth.example.com/realms/master`. Anything else means `hostname` or `proxyHeaders` is wrong.

See `examples/rendered-operator-mode.yaml` for the exact objects the defaults produce.

---

## Values reference (the ones that matter)

| Key | Default | Notes |
|---|---|---|
| `mode` | `operator` | `operator` or `standalone` |
| `nodeGroup.labelKey` / `labelValue` | `workload` / `keycloak` | must match `--labels` on the node group |
| `nodeGroup.taintKey` / `taintValue` / `taintEffect` | `dedicated` / `keycloak` / `NoSchedule` | must match `--taints` |
| `replicas` | `3` | production minimum |
| `image.tag` | `26.7.0` | pin it; Keycloak has no LTS |
| `resources` | 1–2 CPU / 1750Mi | memory request == limit on purpose |
| `database.host` | *(placeholder)* | **must change** — point at RDS |
| `database.existingSecret` | `keycloak-db-secret` | create it before installing |
| `hostname` | `https://auth.example.com` | **must change** — exact public URL |
| `proxyHeaders` | `xforwarded` | correct for an AWS ALB |
| `networkPolicy.enabled` | `true` | required if you trust forwarded headers |
| `ingress.certificateArn` | *(placeholder)* | **must change** — your ACM cert |
| `podDisruptionBudget.minAvailable` | `2` | must be **lower** than `replicas` |
| `update.strategy` | `Auto` | operator mode only |

---

## Production hardening

- **Do not** use `database.create: true`. The password would land in your shell history, in `helm get values`, and in the Helm release Secret. Use the **External Secrets Operator** or the **Secrets Store CSI driver** to pull it from AWS Secrets Manager, and it will refresh on rotation without a manual pod restart.
- Enable **KMS envelope encryption** for Secrets on the cluster.
- Put **AWS WAF** on the ALB with a rate-based rule on `/realms/*/protocol/openid-connect/token`.
- Serve the admin console on a **separate internal hostname** (`adminHostname`) behind VPN.
- Never expose the management port (9000) publicly.
- Delete the bootstrap admin after creating your own, and enable **MFA**.
- Plan a **quarterly upgrade**: Keycloak has no LTS, so only the newest minor gets security fixes.

---

## Requirements

- Kubernetes / EKS 1.34+
- Helm 3.8+
- An external PostgreSQL database (RDS or Aurora)
- AWS Load Balancer Controller, if `ingress.enabled: true`
- Keycloak Operator 26.7.0, if `mode: operator`
- Prometheus Operator CRDs, if `serviceMonitor.enabled: true`
