{{/* ------------------------------------------------------------------ */}}
{{/* Names                                                               */}}
{{/* ------------------------------------------------------------------ */}}

{{- define "keycloak.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "keycloak.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "keycloak.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "keycloak.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "keycloak.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{/* Service that the Ingress points at.                                  */}}
{{/* The operator names its Service "<cr-name>-service".                  */}}
{{- define "keycloak.serviceName" -}}
{{- if eq .Values.mode "operator" -}}
{{- printf "%s-service" (include "keycloak.fullname" .) -}}
{{- else -}}
{{- include "keycloak.fullname" . -}}
{{- end -}}
{{- end -}}

{{/* Hostname without the scheme, for the Ingress rule.                   */}}
{{- define "keycloak.ingressHost" -}}
{{- if .Values.ingress.host -}}
{{- .Values.ingress.host -}}
{{- else -}}
{{- .Values.hostname | trimPrefix "https://" | trimPrefix "http://" | trimSuffix "/" -}}
{{- end -}}
{{- end -}}


{{/* ------------------------------------------------------------------ */}}
{{/* Labels                                                              */}}
{{/* ------------------------------------------------------------------ */}}

{{- define "keycloak.labels" -}}
helm.sh/chart: {{ include "keycloak.chart" . }}
app.kubernetes.io/name: {{ include "keycloak.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Values.image.tag | quote }}
app.kubernetes.io/component: server
app.kubernetes.io/part-of: keycloak
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "keycloak.selectorLabels" -}}
app.kubernetes.io/name: {{ include "keycloak.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/* Labels that actually land on the running pods.                       */}}
{{/* In operator mode the OPERATOR owns the pod labels, so we must match  */}}
{{/* its labels, not ours. These are the labels the Keycloak docs use.    */}}
{{- define "keycloak.podMatchLabels" -}}
{{- if .Values.podDisruptionBudget.selectorLabels -}}
{{- toYaml .Values.podDisruptionBudget.selectorLabels -}}
{{- else if eq .Values.mode "operator" -}}
app: keycloak
app.kubernetes.io/managed-by: keycloak-operator
app.kubernetes.io/component: server
{{- else -}}
{{ include "keycloak.selectorLabels" . }}
{{- end -}}
{{- end -}}


{{/* ------------------------------------------------------------------ */}}
{{/* SCHEDULING - this is what pins Keycloak to your node group          */}}
{{/* ------------------------------------------------------------------ */}}

{{/*
  ONE helper builds the whole scheduling block as a real object, then renders
  it with toYaml. It is reused in three places:
    1. the Keycloak CR's spec.scheduling        (the server pods)
    2. the Keycloak CR's spec.update.scheduling (the upgrade Job)
    3. the standalone StatefulSet's pod spec
  Every key it produces is valid in BOTH the Keycloak CRD scheduling stanza
  and a plain Kubernetes PodSpec, which is why one helper can serve all three.

  Note it emits nodeAffinity, never nodeSelector: the Keycloak CRD's
  scheduling stanza supports exactly affinity, tolerations,
  topologySpreadConstraints and priorityClassName. There is no
  nodeSelector field, so nodeSelector would be silently dropped.
*/}}
{{- define "keycloak.scheduling" -}}
{{- $s := dict -}}
{{- $ng := .Values.nodeGroup -}}
{{- $sel := dict "matchLabels" (fromYaml (include "keycloak.podMatchLabels" .)) -}}

{{/* --- tolerations: the "keycard" that gets past the node taint --- */}}
{{- $tol := list -}}
{{- if and $ng.enabled $ng.tolerateTaint -}}
{{- $tol = append $tol (dict "key" $ng.taintKey "operator" "Equal" "value" $ng.taintValue "effect" $ng.taintEffect) -}}
{{- end -}}
{{- range .Values.extraTolerations -}}
{{- $tol = append $tol . -}}
{{- end -}}
{{- if $tol -}}
{{- $s = set $s "tolerations" $tol -}}
{{- end -}}

{{/* --- affinity: the "contract" that keeps Keycloak ON those nodes --- */}}
{{- $aff := dict -}}
{{- if $ng.enabled -}}
{{- $term := dict "matchExpressions" (list (dict "key" $ng.labelKey "operator" "In" "values" (list $ng.labelValue))) -}}
{{- $aff = set $aff "nodeAffinity" (dict "requiredDuringSchedulingIgnoredDuringExecution" (dict "nodeSelectorTerms" (list $term))) -}}
{{- end -}}
{{- if .Values.extraAffinity -}}
{{- $aff = mergeOverwrite $aff (deepCopy .Values.extraAffinity) -}}
{{- end -}}
{{- if $aff -}}
{{- $s = set $s "affinity" $aff -}}
{{- end -}}

{{/* --- topology spread: one pod per AZ so an AZ outage is survivable --- */}}
{{- $tsc := list -}}
{{- if $ng.enabled -}}
{{- if $ng.spreadAcrossZones -}}
{{- $tsc = append $tsc (dict "maxSkew" (int $ng.maxSkew) "topologyKey" "topology.kubernetes.io/zone" "whenUnsatisfiable" $ng.whenUnsatisfiable "labelSelector" $sel) -}}
{{- end -}}
{{- if $ng.spreadAcrossNodes -}}
{{- $tsc = append $tsc (dict "maxSkew" (int $ng.maxSkew) "topologyKey" "kubernetes.io/hostname" "whenUnsatisfiable" "ScheduleAnyway" "labelSelector" $sel) -}}
{{- end -}}
{{- end -}}
{{- range .Values.extraTopologySpreadConstraints -}}
{{- $tsc = append $tsc . -}}
{{- end -}}
{{- if $tsc -}}
{{- $s = set $s "topologySpreadConstraints" $tsc -}}
{{- end -}}

{{- with .Values.priorityClassName -}}
{{- $s = set $s "priorityClassName" . -}}
{{- end -}}

{{- if $s -}}
{{- toYaml $s -}}
{{- end -}}
{{- end -}}


{{/* ------------------------------------------------------------------ */}}
{{/* Misc                                                                */}}
{{/* ------------------------------------------------------------------ */}}

{{- define "keycloak.image" -}}
{{- printf "%s/%s:%s" .Values.image.registry .Values.image.repository .Values.image.tag -}}
{{- end -}}

{{- define "keycloak.dbSecretName" -}}
{{- if .Values.database.create -}}
{{- printf "%s-db" (include "keycloak.fullname" .) -}}
{{- else -}}
{{- .Values.database.existingSecret -}}
{{- end -}}
{{- end -}}
