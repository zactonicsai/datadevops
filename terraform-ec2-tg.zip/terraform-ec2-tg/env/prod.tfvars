###############################################################################
# PROD
# AMI is pinned, termination protection is on, launch template version is
# pinned to a number so a template edit can never silently affect a new launch.
###############################################################################

project     = "myapp"
environment = "prod"
region      = "us-east-1"

allowed_account_ids = ["333333333333"] # prod account

# --- Existing network -------------------------------------------------------
vpc_id     = "vpc-0prd00000000000aa"
subnet_ids = [
  "subnet-0prd0000000000a1", # us-east-1a
  "subnet-0prd0000000000b2", # us-east-1b
  "subnet-0prd0000000000c3", # us-east-1c
]
instance_subnet_id          = "subnet-0prd0000000000a1"
security_group_ids          = ["sg-0prd00000000app1", "sg-0prd00000000obs1"]
associate_public_ip_address = false

# --- Existing IAM / SSH -----------------------------------------------------
iam_instance_profile_name = "myapp-prod-ec2-profile"
key_name                  = null # no SSH keys in prod - Session Manager only

# --- AMI --------------------------------------------------------------------
ami_id = "ami-0prod000000000001"

# --- Instance ---------------------------------------------------------------
instance_type              = "m6i.large"
root_volume_size           = 100
root_volume_type           = "gp3"
root_volume_iops           = 3000
root_volume_throughput     = 250
enable_detailed_monitoring = true
disable_api_termination    = true
launch_template_version    = "3" # pin explicitly; bump deliberately
ebs_kms_key_id             = "arn:aws:kms:us-east-1:333333333333:key/REPLACE-ME"

user_data = <<-EOT
  #!/bin/bash
  set -euo pipefail
  systemctl enable --now nginx amazon-cloudwatch-agent
EOT

# --- Target group -----------------------------------------------------------
target_group_port    = 80
deregistration_delay = 300
slow_start           = 60
stickiness_enabled   = true
stickiness_duration  = 86400

health_check = {
  path                = "/health"
  matcher             = "200"
  interval            = 10
  timeout             = 5
  healthy_threshold   = 3
  unhealthy_threshold = 2
}

tags = {
  CostCenter  = "engineering"
  Owner       = "platform-team"
  Backup      = "hourly"
  Compliance  = "pci"
  DataClass   = "confidential"
}
