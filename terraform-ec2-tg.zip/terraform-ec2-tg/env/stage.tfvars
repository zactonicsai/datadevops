###############################################################################
# STAGE
# Mirrors prod as closely as budget allows.
###############################################################################

project     = "myapp"
environment = "stage"
region      = "us-east-1"

allowed_account_ids = ["222222222222"] # stage account

# --- Existing network -------------------------------------------------------
vpc_id     = "vpc-0stg00000000000aa"
subnet_ids = [
  "subnet-0stg0000000000a1", # us-east-1a
  "subnet-0stg0000000000b2", # us-east-1b
]
instance_subnet_id          = "subnet-0stg0000000000a1"
security_group_ids          = ["sg-0stg00000000app1", "sg-0stg00000000obs1"]
associate_public_ip_address = false

# --- Existing IAM / SSH -----------------------------------------------------
iam_instance_profile_name = "myapp-stage-ec2-profile"
key_name                  = null

# --- AMI --------------------------------------------------------------------
# Stage pins the AMI that was validated in dev, so prod promotes a known image.
ami_id = "ami-0stage00000000001"

# --- Instance ---------------------------------------------------------------
instance_type              = "t3.medium"
cpu_credits                = "unlimited"
root_volume_size           = 50
root_volume_type           = "gp3"
root_volume_throughput     = 125
enable_detailed_monitoring = true
disable_api_termination    = false
launch_template_version    = "$Latest"
ebs_kms_key_id             = "arn:aws:kms:us-east-1:222222222222:key/REPLACE-ME"

user_data = <<-EOT
  #!/bin/bash
  set -euo pipefail
  dnf -y install nginx amazon-cloudwatch-agent
  echo "ok" > /usr/share/nginx/html/health
  systemctl enable --now nginx amazon-cloudwatch-agent
EOT

# --- Target group -----------------------------------------------------------
target_group_port    = 80
deregistration_delay = 30
slow_start           = 30
stickiness_enabled   = false

health_check = {
  path                = "/health"
  matcher             = "200"
  interval            = 15
  timeout             = 5
  healthy_threshold   = 2
  unhealthy_threshold = 3
}

tags = {
  CostCenter = "engineering"
  Owner      = "platform-team"
  Backup     = "daily"
}
