###############################################################################
# DEV
# Replace every REPLACE-ME value with real IDs from your existing account.
###############################################################################

project     = "myapp"
environment = "dev"
region      = "us-east-1"

allowed_account_ids = ["111111111111"] # dev account

# --- Existing network -------------------------------------------------------
vpc_id     = "vpc-0dev00000000000aa"
subnet_ids = [
  "subnet-0dev0000000000a1", # us-east-1a
  "subnet-0dev0000000000b2", # us-east-1b
]
instance_subnet_id          = "subnet-0dev0000000000a1"
security_group_ids          = ["sg-0dev00000000app1"]
associate_public_ip_address = false

# --- Existing IAM / SSH -----------------------------------------------------
iam_instance_profile_name = "myapp-dev-ec2-profile"
key_name                  = null # use SSM Session Manager

# --- AMI --------------------------------------------------------------------
# Dev tracks the latest Amazon Linux 2023 AMI.
ami_id = null

# --- Instance ---------------------------------------------------------------
instance_type              = "t3.micro"
cpu_credits                = "standard"
root_volume_size           = 20
root_volume_type           = "gp3"
enable_detailed_monitoring = false
disable_api_termination    = false
launch_template_version    = "$Latest"

user_data = <<-EOT
  #!/bin/bash
  set -euo pipefail
  dnf -y update
  dnf -y install nginx
  echo "ok" > /usr/share/nginx/html/health
  systemctl enable --now nginx
EOT

# --- Target group -----------------------------------------------------------
target_group_port    = 80
deregistration_delay = 10
stickiness_enabled   = false

health_check = {
  path                = "/health"
  matcher             = "200"
  interval            = 30
  timeout             = 5
  healthy_threshold   = 2
  unhealthy_threshold = 2
}

tags = {
  CostCenter = "engineering"
  Owner      = "platform-team"
  Backup     = "none"
}
