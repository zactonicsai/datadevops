locals {
  # ---------------------------------------------------------------------------
  # Naming
  # ---------------------------------------------------------------------------
  name = "${var.project}-${var.environment}"

  # Target group names are capped at 32 characters by the ELB API.
  target_group_name = substr("${local.name}-tg", 0, 32)

  common_tags = merge(
    {
      Project     = var.project
      Environment = var.environment
      ManagedBy   = "terraform"
    },
    var.tags
  )

  # ---------------------------------------------------------------------------
  # Existing resources resolved at plan time
  # ---------------------------------------------------------------------------
  instance_subnet_id = coalesce(var.instance_subnet_id, var.subnet_ids[0])

  vpc_id = coalesce(var.vpc_id, data.aws_subnet.selected.vpc_id)

  ami_id = coalesce(var.ami_id, try(nonsensitive(data.aws_ssm_parameter.ami[0].value), null))

  # ---------------------------------------------------------------------------
  # Conditionals
  # ---------------------------------------------------------------------------
  # credit_specification is only valid on burstable (T-family) instances.
  is_burstable = can(regex("^t[2-9][a-z]*\\.", var.instance_type))

  # protocol_version is only valid for HTTP/HTTPS target groups.
  is_http_target_group = contains(["HTTP", "HTTPS"], var.target_group_protocol)

  attachment_port = coalesce(var.target_group_attachment_port, var.target_group_port)
}
