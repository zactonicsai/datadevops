resource "aws_instance" "this" {
  # Everything else (AMI, instance type, SGs, IAM profile, disks, IMDS) comes
  # from the launch template. Only placement lives here.
  launch_template {
    id      = aws_launch_template.this.id
    version = var.launch_template_version
  }

  subnet_id                   = local.instance_subnet_id
  associate_public_ip_address = var.associate_public_ip_address

  user_data_replace_on_change = var.user_data_replace_on_change

  # Volume tags come from the launch template's tag_specifications block.
  # Do not also set volume_tags here - the two conflict.
  tags = merge(local.common_tags, { Name = local.name })

  lifecycle {
    precondition {
      condition     = contains(var.subnet_ids, local.instance_subnet_id)
      error_message = "instance_subnet_id must be one of the values listed in subnet_ids."
    }

    precondition {
      condition     = local.ami_id != null
      error_message = "No AMI resolved. Set ami_id, or make sure ami_ssm_parameter points at a valid public SSM parameter."
    }
  }
}
