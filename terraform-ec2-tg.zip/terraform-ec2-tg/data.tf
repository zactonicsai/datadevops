###############################################################################
# Everything here READS existing infrastructure. Nothing is created.
###############################################################################

data "aws_caller_identity" "current" {}

# The subnet the instance lands in. Also gives us the VPC ID for the target
# group when var.vpc_id is not supplied explicitly.
data "aws_subnet" "selected" {
  id = local.instance_subnet_id
}

# Fails the plan early with a clear error if the IAM instance profile does not
# exist, instead of failing mid-apply at RunInstances.
data "aws_iam_instance_profile" "this" {
  count = var.iam_instance_profile_name == null ? 0 : 1
  name  = var.iam_instance_profile_name
}

# Resolve the latest AMI only when an explicit ami_id was not pinned.
data "aws_ssm_parameter" "ami" {
  count = var.ami_id == null ? 1 : 0
  name  = var.ami_ssm_parameter
}
