# EC2 Launch Template + EC2 Instance + Target Group (Terraform)

*Terraform >= 1.9 · AWS provider ~> 6.60 (current: 6.60.0, August 2026)*

This stack creates exactly **three things**:

| Resource | Terraform type |
|---|---|
| Launch template | `aws_launch_template` |
| One EC2 instance built from it | `aws_instance` |
| Target group + registration | `aws_lb_target_group`, `aws_lb_target_group_attachment` |

Everything else — **VPC, subnets, security groups, IAM role/instance profile, KMS key, key pair, load balancer, listener** — is expected to exist already and is referenced by ID or name through variables.

---

## 1. File layout

```
.
├── versions.tf          # Terraform + provider pins, partial S3 backend
├── providers.tf         # region, account guard, default_tags
├── variables.tf         # every input, with validation
├── locals.tf            # naming, computed values
├── data.tf              # lookups of EXISTING resources (read-only)
├── launch_template.tf   # aws_launch_template
├── ec2.tf               # aws_instance
├── target_group.tf      # aws_lb_target_group + attachment
├── outputs.tf
├── env/
│   ├── dev.tfvars
│   ├── stage.tfvars
│   └── prod.tfvars
└── backend/
    ├── dev.hcl
    ├── stage.hcl
    └── prod.hcl
```

One root module, three sets of values. No workspaces, no duplicated `.tf` files per environment.

---

## 2. Step-by-step: deploy dev

### Step 1 — Collect your existing IDs

You cannot run this until you know what already exists. Grab them:

```bash
export AWS_PROFILE=dev
export AWS_REGION=us-east-1

# VPC
aws ec2 describe-vpcs \
  --query 'Vpcs[].{ID:VpcId,CIDR:CidrBlock,Name:Tags[?Key==`Name`]|[0].Value}' \
  --output table

# Subnets in that VPC
aws ec2 describe-subnets \
  --filters Name=vpc-id,Values=vpc-0dev00000000000aa \
  --query 'Subnets[].{ID:SubnetId,AZ:AvailabilityZone,CIDR:CidrBlock,Name:Tags[?Key==`Name`]|[0].Value}' \
  --output table

# Security groups
aws ec2 describe-security-groups \
  --filters Name=vpc-id,Values=vpc-0dev00000000000aa \
  --query 'SecurityGroups[].{ID:GroupId,Name:GroupName}' \
  --output table

# IAM instance profiles (note: the PROFILE name, not the role name)
aws iam list-instance-profiles \
  --query 'InstanceProfiles[].{Profile:InstanceProfileName,Role:Roles[0].RoleName}' \
  --output table

# Account ID, for allowed_account_ids
aws sts get-caller-identity --query Account --output text
```

> ⚠️ **The most common mistake here:** passing an IAM **role** name where an instance **profile** name is required. They are different objects, and they often share a name when created in the console but not when created by Terraform or CloudFormation. The `list-instance-profiles` command above shows both columns so you can pick the right one.

### Step 2 — Fill in `env/dev.tfvars`

Replace every placeholder ID. Minimum required inputs:

```hcl
project             = "myapp"
environment         = "dev"
region              = "us-east-1"
allowed_account_ids = ["111111111111"]

subnet_ids                = ["subnet-...", "subnet-..."]
security_group_ids        = ["sg-..."]
iam_instance_profile_name = "myapp-dev-ec2-profile"
```

### Step 3 — Point the backend at your state bucket

Edit `backend/dev.hcl`:

```hcl
bucket       = "myorg-tfstate-dev"
key          = "myapp/ec2/dev/terraform.tfstate"
region       = "us-east-1"
encrypt      = true
use_lockfile = true
```

`use_lockfile = true` is S3-native state locking (Terraform 1.11+). A DynamoDB lock table is no longer needed.

If you have no state bucket yet, delete the `backend "s3" {}` block from `versions.tf` to run with local state — fine for a first test, not for a team.

### Step 4 — Initialize

```bash
terraform init -backend-config=backend/dev.hcl
```

### Step 5 — Format and validate

```bash
terraform fmt -recursive -check
terraform validate
```

### Step 6 — Plan

```bash
terraform plan -var-file=env/dev.tfvars -out=dev.tfplan
```

Expect exactly 4 resources to add: launch template, instance, target group, attachment.

Read the plan. In particular check that `image_id` resolved to a real AMI and `vpc_id` on the target group matches the VPC your subnets live in.

### Step 7 — Apply

```bash
terraform apply dev.tfplan
```

Applying a saved plan file (rather than `apply -var-file=...`) guarantees you get exactly what you reviewed.

### Step 8 — Verify

```bash
terraform output

INSTANCE_ID=$(terraform output -raw instance_id)
TG_ARN=$(terraform output -raw target_group_arn)

# Instance is running?
aws ec2 describe-instances --instance-ids "$INSTANCE_ID" \
  --query 'Reservations[].Instances[].State.Name' --output text

# Is it passing the health check?
aws elbv2 describe-target-health --target-group-arn "$TG_ARN" \
  --query 'TargetHealthDescriptions[].{Target:Target.Id,State:TargetHealth.State,Reason:TargetHealth.Reason}' \
  --output table
```

A brand-new target sits in `initial` for a minute, then becomes `healthy`. If it goes to `unhealthy`, jump to [Troubleshooting](#8-troubleshooting).

### Step 9 — Connect the target group to your existing load balancer

This stack deliberately does **not** create a listener, because you said the ALB already exists. Wire it up with either:

**Option A — AWS CLI (one-off):**

```bash
aws elbv2 create-rule \
  --listener-arn arn:aws:elasticloadbalancing:...:listener/app/my-alb/... \
  --priority 100 \
  --conditions Field=path-pattern,Values='/api/*' \
  --actions Type=forward,TargetGroupArn="$TG_ARN"
```

**Option B — add it to this stack** (paste into a new `listener_rule.tf`):

```hcl
variable "listener_arn" {
  description = "ARN of an existing ALB listener. Null skips rule creation."
  type        = string
  default     = null
}

variable "listener_rule_priority" {
  type    = number
  default = 100
}

variable "listener_rule_path_patterns" {
  type    = list(string)
  default = ["/*"]
}

resource "aws_lb_listener_rule" "this" {
  count = var.listener_arn == null ? 0 : 1

  listener_arn = var.listener_arn
  priority     = var.listener_rule_priority

  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.this.arn
  }

  condition {
    path_pattern {
      values = var.listener_rule_path_patterns
    }
  }
}
```

### Step 10 — Promote to stage, then prod

```bash
terraform init -reconfigure -backend-config=backend/stage.hcl
terraform plan  -var-file=env/stage.tfvars -out=stage.tfplan
terraform apply stage.tfplan

terraform init -reconfigure -backend-config=backend/prod.hcl
terraform plan  -var-file=env/prod.tfvars -out=prod.tfplan
terraform apply prod.tfplan
```

> ⚠️ `-reconfigure` swaps backends without copying state between environments. Never use `-migrate-state` here — that would move dev's state into prod's bucket.

Because switching backends by hand is easy to get wrong, most teams script it:

```bash
#!/usr/bin/env bash
# tf.sh dev plan
set -euo pipefail
ENV="$1"; shift
[[ -f "env/${ENV}.tfvars" ]] || { echo "unknown env: $ENV"; exit 1; }
terraform init -reconfigure -backend-config="backend/${ENV}.hcl" -input=false
terraform "$@" -var-file="env/${ENV}.tfvars"
```

---

## 3. What each environment does differently

| Setting | dev | stage | prod | Why |
|---|---|---|---|---|
| `instance_type` | `t3.micro` | `t3.medium` | `m6i.large` | Cost in dev, prod-like in stage, no burst variability in prod |
| `cpu_credits` | `standard` | `unlimited` | n/a (not burstable) | Unlimited credits cost money when exhausted |
| `ami_id` | `null` (latest AL2023) | pinned | pinned | Dev tracks latest; stage validates a specific image; prod promotes the exact image stage proved |
| `launch_template_version` | `$Latest` | `$Latest` | `"3"` | Prod launches must never shift because someone edited the template |
| `root_volume_size` | 20 GiB | 50 GiB | 100 GiB | |
| `ebs_kms_key_id` | AWS-managed | CMK | CMK | Customer-managed keys give you key rotation and audit control |
| `enable_detailed_monitoring` | false | true | true | 1-minute metrics are billable |
| `disable_api_termination` | false | false | **true** | Stops an accidental console termination |
| `deregistration_delay` | 10s | 30s | 300s | Prod needs time to drain long-lived connections |
| `slow_start` | 0 | 30s | 60s | Lets a fresh instance warm caches/JIT before full traffic |
| `stickiness_enabled` | false | false | true | |
| Health check interval | 30s | 15s | 10s | Faster detection where it matters |

---

## 4. Design decisions worth knowing

### Why the launch template has no `network_interfaces` block

If you declare `network_interfaces { subnet_id = ... }` inside a launch template, the subnet becomes baked into the template and `aws_instance.subnet_id` conflicts with it. By putting only `vpc_security_group_ids` in the template and leaving `subnet_id` on the instance, the same template can launch into any AZ — which is exactly what you want if you later point an Auto Scaling group at it.

### `$Latest` vs `$Default` vs a pinned number

| Value | Behavior | Pros | Cons |
|---|---|---|---|
| `$Latest` | Newest version, whatever it is | Never think about version numbers | An unrelated template edit changes what the next launch gets |
| `$Default` | The version marked default | Explicit promotion step | Two things to track (latest + default pointer) |
| `"3"` | Exactly that version | Fully deterministic and auditable | You must bump it by hand |

This config sets `update_default_version = true`, so the Default pointer follows Latest. Prod pins a number anyway.

### Editing the launch template does not touch the running instance

This surprises people. A new launch template version affects the **next** launch. Terraform will show a new LT version in the plan and **no change** to `aws_instance`. To roll the existing instance onto the new template:

```bash
terraform apply -replace=aws_instance.this -var-file=env/dev.tfvars
```

That destroys and recreates the instance. If that's unacceptable, you want an Auto Scaling group with an instance refresh rather than a standalone instance — see [§7](#7-scaling-up-later).

### `create_before_destroy` on the target group

A target group cannot be deleted while a listener forwards to it. Without `create_before_destroy`, any change that forces replacement (renaming, changing port/protocol, changing `target_type`) deadlocks the apply.

### Preconditions instead of runtime failures

`ec2.tf` checks that `instance_subnet_id` is actually in `subnet_ids`, and that an AMI resolved. `variables.tf` regex-validates every ID format. These fail during `plan`, in seconds, instead of halfway through an `apply`.

### `allowed_account_ids`

The provider refuses to run if the credentials in your shell belong to a different account than the tfvars file expects. This is the cheapest possible protection against `AWS_PROFILE=prod terraform apply -var-file=env/dev.tfvars`.

---

## 5. Security defaults baked in

| Setting | Value | Why |
|---|---|---|
| `metadata_options.http_tokens` | `required` | IMDSv2 only. Blocks the SSRF-to-credential-theft attack class. |
| `http_put_response_hop_limit` | `1` | Containers on the host can't reach IMDS. Set to `2` only if they must. |
| `block_device_mappings.ebs.encrypted` | `true` | Encryption at rest, always |
| `key_name` | `null` | No SSH keys; use SSM Session Manager (`aws ssm start-session --target $INSTANCE_ID`) |
| `associate_public_ip_address` | `false` | Private subnets only |
| `ebs_optimized` | `true` | Free on all current-generation instance types |

For Session Manager to work, the existing instance profile needs the `AmazonSSMManagedInstanceCore` managed policy, and the subnet needs either a NAT gateway or VPC endpoints for `ssm`, `ssmmessages`, and `ec2messages`.

---

## 6. Day-two operations

**Rotate to a new AMI (dev):** nothing to do — `$Latest` picks it up on the next launch. Force it now:
```bash
terraform apply -replace=aws_instance.this -var-file=env/dev.tfvars
```

**Promote an AMI to prod:** copy the AMI ID that stage validated into `env/prod.tfvars`, bump `launch_template_version`, plan, apply, then replace the instance in a maintenance window.

**Drain before replacing:** with `deregistration_delay = 300`, the ALB stops sending new requests immediately and waits up to 5 minutes for in-flight ones. Terraform's destroy does not wait for that — deregister manually first if you need a clean drain:
```bash
aws elbv2 deregister-targets --target-group-arn "$TG_ARN" --targets Id="$INSTANCE_ID"
```

**Tear down:**
```bash
terraform destroy -var-file=env/dev.tfvars
```
Prod will refuse until you set `disable_api_termination = false` and apply that first. That is the feature working.

---

## 7. Scaling up later

One instance registered to a target group has no self-healing: if it dies, the target group has nothing to send traffic to. When you're ready, swap `aws_instance` for an Auto Scaling group — **the launch template and target group stay exactly as they are**:

```hcl
resource "aws_autoscaling_group" "this" {
  name                = "${local.name}-asg"
  vpc_zone_identifier = var.subnet_ids
  target_group_arns   = [aws_lb_target_group.this.arn]

  min_size         = 2
  max_size         = 6
  desired_capacity = 2

  health_check_type         = "ELB"
  health_check_grace_period = 120

  launch_template {
    id      = aws_launch_template.this.id
    version = var.launch_template_version
  }

  instance_refresh {
    strategy = "Rolling"
    preferences {
      min_healthy_percentage = 50
    }
  }
}
```

Then delete `ec2.tf` and `aws_lb_target_group_attachment` (the ASG handles registration itself). This is the main reason the launch template was written without a hard-coded subnet.

| | Single instance | Auto Scaling group |
|---|---|---|
| Pros | Simple; stable instance ID; cheapest | Self-healing; rolling AMI updates; multi-AZ; scales with load |
| Cons | No self-healing; single AZ; replacement = downtime | More moving parts; instance IDs are ephemeral |

---

## 8. Troubleshooting

**`InvalidParameterValue: Value (myapp-dev-ec2-role) for parameter iamInstanceProfile.name is invalid`**
You passed a role name. Pass the instance profile name.

**Target stuck `unhealthy`, reason `Target.Timeout`**
The instance security group must allow inbound traffic on `target_group_port` **from the load balancer's security group**. This is the number one cause. Check with:
```bash
aws ec2 describe-security-groups --group-ids sg-... \
  --query 'SecurityGroups[].IpPermissions'
```

**Target `unhealthy`, reason `Target.ResponseCodeMismatch`**
The app answered, but not with a code in `health_check.matcher`. Either fix the app or widen the matcher (`"200-299"`).

**`Error: creating ELBv2 Target Group: ValidationError: Target group name cannot be longer than 32 characters`**
`locals.tf` already truncates, but a very long `project` plus `environment` can still collide with another truncated name. Shorten `project`.

**Target group created in the wrong VPC**
Happens when `vpc_id` is set to one VPC but `subnet_ids` live in another. The target group uses `var.vpc_id` when supplied. Either fix the mismatch or set `vpc_id = null` to derive it from the subnet.

**Plan wants to replace the instance every run**
Usually `user_data_replace_on_change = true` combined with a user_data script containing something non-deterministic (a timestamp, a random value).

**`Error: The provider is configured with allowed account IDs...`**
Your shell credentials point at a different account than the tfvars file. This is intentional — check `AWS_PROFILE`.

---

## 9. Recommended pre-commit checks

```bash
terraform fmt -recursive
terraform validate
tflint --recursive
trivy config .            # or: checkov -d .
```

`trivy`/`checkov` will flag things like unencrypted volumes and IMDSv1 — both already handled here, which makes any new finding a real signal.
