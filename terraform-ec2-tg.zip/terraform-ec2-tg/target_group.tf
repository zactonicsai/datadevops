resource "aws_lb_target_group" "this" {
  name        = local.target_group_name
  vpc_id      = local.vpc_id
  target_type = "instance"

  port             = var.target_group_port
  protocol         = var.target_group_protocol
  protocol_version = local.is_http_target_group ? var.target_group_protocol_version : null

  deregistration_delay = var.deregistration_delay
  slow_start           = var.slow_start

  health_check {
    enabled             = var.health_check.enabled
    path                = local.is_http_target_group ? var.health_check.path : null
    port                = var.health_check.port
    protocol            = var.health_check.protocol
    matcher             = local.is_http_target_group ? var.health_check.matcher : null
    interval            = var.health_check.interval
    timeout             = var.health_check.timeout
    healthy_threshold   = var.health_check.healthy_threshold
    unhealthy_threshold = var.health_check.unhealthy_threshold
  }

  dynamic "stickiness" {
    for_each = local.is_http_target_group ? [1] : []
    content {
      enabled         = var.stickiness_enabled
      type            = "lb_cookie"
      cookie_duration = var.stickiness_duration
    }
  }

  tags = merge(local.common_tags, { Name = local.target_group_name })

  # A target group cannot be deleted while a listener still forwards to it,
  # so create the replacement first when a change forces replacement.
  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_lb_target_group_attachment" "this" {
  target_group_arn = aws_lb_target_group.this.arn
  target_id        = aws_instance.this.id
  port             = local.attachment_port
}
