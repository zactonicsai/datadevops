###############################################################################
# Core / naming
###############################################################################

variable "project" {
  description = "Short project or application name. Used as a name prefix."
  type        = string

  validation {
    condition     = can(regex("^[a-z0-9][a-z0-9-]{1,24}$", var.project))
    error_message = "project must be lowercase alphanumeric/hyphen, 2-25 chars."
  }
}

variable "environment" {
  description = "Deployment environment."
  type        = string

  validation {
    condition     = contains(["dev", "stage", "prod"], var.environment)
    error_message = "environment must be one of: dev, stage, prod."
  }
}

variable "region" {
  description = "AWS region to deploy into."
  type        = string
  default     = "us-east-1"
}

variable "allowed_account_ids" {
  description = "AWS account IDs this configuration is allowed to apply to. Prevents applying dev config to the prod account."
  type        = list(string)
  default     = []
}

variable "tags" {
  description = "Extra tags merged into every resource."
  type        = map(string)
  default     = {}
}

###############################################################################
# Existing network (NOT created by this configuration)
###############################################################################

variable "vpc_id" {
  description = "Existing VPC ID. If null, it is derived from the subnet the instance lands in."
  type        = string
  default     = null
}

variable "subnet_ids" {
  description = "Existing private subnet IDs available to this stack. The instance is placed in instance_subnet_id, or the first entry if that is null."
  type        = list(string)

  validation {
    condition     = length(var.subnet_ids) > 0
    error_message = "subnet_ids must contain at least one existing subnet ID."
  }

  validation {
    condition     = alltrue([for s in var.subnet_ids : can(regex("^subnet-[0-9a-f]{8,17}$", s))])
    error_message = "Each entry in subnet_ids must look like subnet-xxxxxxxx."
  }
}

variable "instance_subnet_id" {
  description = "Which existing subnet the EC2 instance is launched into. Defaults to the first entry of subnet_ids."
  type        = string
  default     = null
}

variable "security_group_ids" {
  description = "Existing security group IDs attached to the instance via the launch template."
  type        = list(string)

  validation {
    condition     = length(var.security_group_ids) > 0
    error_message = "security_group_ids must contain at least one existing security group ID."
  }

  validation {
    condition     = alltrue([for sg in var.security_group_ids : can(regex("^sg-[0-9a-f]{8,17}$", sg))])
    error_message = "Each entry in security_group_ids must look like sg-xxxxxxxx."
  }
}

variable "associate_public_ip_address" {
  description = "Attach a public IP. Keep false for private subnets."
  type        = bool
  default     = false
}

###############################################################################
# Existing IAM / SSH (NOT created by this configuration)
###############################################################################

variable "iam_instance_profile_name" {
  description = "Name of an EXISTING IAM instance profile (the profile, not the role). Set null to launch with no profile."
  type        = string
  default     = null
}

variable "key_name" {
  description = "Name of an EXISTING EC2 key pair. Leave null and use SSM Session Manager instead."
  type        = string
  default     = null
}

###############################################################################
# AMI
###############################################################################

variable "ami_id" {
  description = "Explicit AMI ID. If null, the AMI is resolved from ami_ssm_parameter. Pin this in prod."
  type        = string
  default     = null

  validation {
    condition     = var.ami_id == null || can(regex("^ami-[0-9a-f]{8,17}$", var.ami_id))
    error_message = "ami_id must be null or look like ami-xxxxxxxx."
  }
}

variable "ami_ssm_parameter" {
  description = "Public SSM parameter used to resolve the AMI when ami_id is null."
  type        = string
  default     = "/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64"
}

###############################################################################
# Instance / launch template
###############################################################################

variable "instance_type" {
  description = "EC2 instance type."
  type        = string
  default     = "t3.micro"
}

variable "launch_template_version" {
  description = "Which launch template version the instance uses: $Latest, $Default, or a number."
  type        = string
  default     = "$Latest"
}

variable "update_launch_template_default_version" {
  description = "Move the launch template's Default version pointer to each newly created version."
  type        = bool
  default     = true
}

variable "root_volume_size" {
  description = "Root EBS volume size in GiB."
  type        = number
  default     = 20

  validation {
    condition     = var.root_volume_size >= 8 && var.root_volume_size <= 16384
    error_message = "root_volume_size must be between 8 and 16384 GiB."
  }
}

variable "root_volume_type" {
  description = "Root EBS volume type."
  type        = string
  default     = "gp3"

  validation {
    condition     = contains(["gp2", "gp3", "io1", "io2"], var.root_volume_type)
    error_message = "root_volume_type must be gp2, gp3, io1 or io2."
  }
}

variable "root_volume_iops" {
  description = "Provisioned IOPS for the root volume. Only valid for gp3/io1/io2."
  type        = number
  default     = null
}

variable "root_volume_throughput" {
  description = "Throughput in MiB/s for the root volume. Only valid for gp3."
  type        = number
  default     = null
}

variable "ebs_kms_key_id" {
  description = "Existing KMS key ARN for EBS encryption. Null uses the AWS-managed aws/ebs key."
  type        = string
  default     = null
}

variable "enable_detailed_monitoring" {
  description = "Enable 1-minute CloudWatch metrics (billable)."
  type        = bool
  default     = false
}

variable "disable_api_termination" {
  description = "Enable EC2 termination protection."
  type        = bool
  default     = false
}

variable "cpu_credits" {
  description = "Burstable credit mode for T-family instances: standard or unlimited. Ignored for other families."
  type        = string
  default     = "standard"

  validation {
    condition     = contains(["standard", "unlimited"], var.cpu_credits)
    error_message = "cpu_credits must be standard or unlimited."
  }
}

variable "user_data" {
  description = "Raw user data script. Rendered base64 automatically. Null means no user data."
  type        = string
  default     = null
}

variable "user_data_replace_on_change" {
  description = "Replace the instance when user_data changes."
  type        = bool
  default     = false
}

variable "metadata_http_put_response_hop_limit" {
  description = "IMDS hop limit. Use 2 if containers on the host need IMDS."
  type        = number
  default     = 1
}

###############################################################################
# Target group
###############################################################################

variable "target_group_port" {
  description = "Port the target group forwards to on the instance."
  type        = number
  default     = 80
}

variable "target_group_protocol" {
  description = "Target group protocol."
  type        = string
  default     = "HTTP"

  validation {
    condition     = contains(["HTTP", "HTTPS", "TCP", "TLS", "UDP", "TCP_UDP", "GENEVE"], var.target_group_protocol)
    error_message = "Unsupported target_group_protocol."
  }
}

variable "target_group_protocol_version" {
  description = "HTTP1, HTTP2 or GRPC. Only applies to HTTP/HTTPS target groups."
  type        = string
  default     = "HTTP1"
}

variable "deregistration_delay" {
  description = "Seconds the load balancer waits before deregistering a target."
  type        = number
  default     = 30
}

variable "slow_start" {
  description = "Seconds to ramp traffic to a newly registered target. 0 disables; otherwise 30-900."
  type        = number
  default     = 0
}

variable "stickiness_enabled" {
  description = "Enable session stickiness on the target group."
  type        = bool
  default     = false
}

variable "stickiness_duration" {
  description = "Stickiness cookie duration in seconds."
  type        = number
  default     = 86400
}

variable "health_check" {
  description = "Target group health check settings."
  type = object({
    enabled             = optional(bool, true)
    path                = optional(string, "/health")
    port                = optional(string, "traffic-port")
    protocol            = optional(string, "HTTP")
    matcher             = optional(string, "200")
    interval            = optional(number, 30)
    timeout             = optional(number, 5)
    healthy_threshold   = optional(number, 2)
    unhealthy_threshold = optional(number, 2)
  })
  default = {}
}

variable "target_group_attachment_port" {
  description = "Override port for the instance registration. Null uses target_group_port."
  type        = number
  default     = null
}
