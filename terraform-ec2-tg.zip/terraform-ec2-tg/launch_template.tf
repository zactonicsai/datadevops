resource "aws_launch_template" "this" {
  name        = "${local.name}-lt"
  description = "Launch template for ${local.name}"

  image_id      = local.ami_id
  instance_type = var.instance_type
  key_name      = var.key_name

  # Existing security groups. Note: because we do NOT declare a
  # network_interfaces block here, the subnet stays a property of the instance,
  # which keeps this template reusable across AZs.
  vpc_security_group_ids = var.security_group_ids

  update_default_version = var.update_launch_template_default_version

  disable_api_termination = var.disable_api_termination
  ebs_optimized           = true

  user_data = var.user_data == null ? null : base64encode(var.user_data)

  dynamic "iam_instance_profile" {
    for_each = var.iam_instance_profile_name == null ? [] : [1]
    content {
      name = data.aws_iam_instance_profile.this[0].name
    }
  }

  block_device_mappings {
    device_name = "/dev/xvda"

    ebs {
      volume_size           = var.root_volume_size
      volume_type           = var.root_volume_type
      iops                  = var.root_volume_type == "gp2" ? null : var.root_volume_iops
      throughput            = var.root_volume_type == "gp3" ? var.root_volume_throughput : null
      encrypted             = true
      kms_key_id            = var.ebs_kms_key_id
      delete_on_termination = true
    }
  }

  # IMDSv2 required. This is the single most important EC2 hardening setting.
  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = "required"
    http_put_response_hop_limit = var.metadata_http_put_response_hop_limit
    instance_metadata_tags      = "enabled"
  }

  monitoring {
    enabled = var.enable_detailed_monitoring
  }

  dynamic "credit_specification" {
    for_each = local.is_burstable ? [1] : []
    content {
      cpu_credits = var.cpu_credits
    }
  }

  private_dns_name_options {
    hostname_type                     = "ip-name"
    enable_resource_name_dns_a_record = true
  }

  # Tags applied to resources CREATED BY the template at launch time.
  tag_specifications {
    resource_type = "instance"
    tags          = merge(local.common_tags, { Name = local.name })
  }

  tag_specifications {
    resource_type = "volume"
    tags          = merge(local.common_tags, { Name = "${local.name}-root" })
  }

  tag_specifications {
    resource_type = "network-interface"
    tags          = merge(local.common_tags, { Name = "${local.name}-eni" })
  }

  # Tags on the launch template object itself.
  tags = merge(local.common_tags, { Name = "${local.name}-lt" })

  lifecycle {
    create_before_destroy = true
  }
}
