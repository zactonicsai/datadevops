provider "aws" {
  region = var.region

  # Guard rail: refuse to run if credentials point at the wrong account.
  allowed_account_ids = var.allowed_account_ids

  default_tags {
    tags = local.common_tags
  }
}
