output "account_id" {
  description = "AWS account this stack was applied to."
  value       = data.aws_caller_identity.current.account_id
}

output "launch_template_id" {
  description = "Launch template ID."
  value       = aws_launch_template.this.id
}

output "launch_template_arn" {
  description = "Launch template ARN."
  value       = aws_launch_template.this.arn
}

output "launch_template_latest_version" {
  description = "Newest version number of the launch template."
  value       = aws_launch_template.this.latest_version
}

output "launch_template_default_version" {
  description = "Version the launch template treats as default."
  value       = aws_launch_template.this.default_version
}

output "instance_id" {
  description = "EC2 instance ID."
  value       = aws_instance.this.id
}

output "instance_arn" {
  description = "EC2 instance ARN."
  value       = aws_instance.this.arn
}

output "instance_private_ip" {
  description = "Private IP address of the instance."
  value       = aws_instance.this.private_ip
}

output "instance_public_ip" {
  description = "Public IP, if one was assigned."
  value       = aws_instance.this.public_ip
}

output "instance_az" {
  description = "Availability Zone of the instance."
  value       = aws_instance.this.availability_zone
}

output "resolved_ami_id" {
  description = "AMI actually used by the launch template."
  value       = local.ami_id
}

output "vpc_id" {
  description = "VPC the target group was created in."
  value       = local.vpc_id
}

output "target_group_arn" {
  description = "Target group ARN. Wire this into an existing listener or listener rule."
  value       = aws_lb_target_group.this.arn
}

output "target_group_arn_suffix" {
  description = "Target group ARN suffix, for CloudWatch metric dimensions."
  value       = aws_lb_target_group.this.arn_suffix
}

output "target_group_name" {
  description = "Target group name."
  value       = aws_lb_target_group.this.name
}
