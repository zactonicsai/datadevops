terraform {
  required_version = ">= 1.9.0, < 2.0.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.60"
    }
  }

  # Backend is intentionally left partial.
  # Supply the per-environment values with:
  #   terraform init -backend-config=backend/dev.hcl
  backend "s3" {}
}
