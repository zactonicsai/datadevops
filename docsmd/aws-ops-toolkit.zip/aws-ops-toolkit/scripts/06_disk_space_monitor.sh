#!/usr/bin/env bash
#
# 06_disk_space_monitor.sh
# WHAT IT DOES: runs ON an EC2 server (not from your laptop) and checks the
# three things that silently kill servers: disk full, memory full, CPU pegged.
# If something crosses a limit it can send you an alert through SNS and push
# the numbers into CloudWatch so you get graphs.
#
# WHY IT MATTERS: AWS does NOT watch disk space or memory for you by default.
# CloudWatch only sees CPU and network from outside the machine. A full disk
# is the #1 cause of "the app just stopped writing logs and then died".
#
# USAGE (on the server):
#   ./06_disk_space_monitor.sh
#   DISK_LIMIT=75 SNS_TOPIC_ARN=arn:aws:sns:us-east-1:1234:ops ./06_disk_space_monitor.sh
#   ./06_disk_space_monitor.sh --push-metrics    # also send numbers to CloudWatch
#
# CRON (check every 10 minutes, log the output):
#   */10 * * * * /opt/tools/06_disk_space_monitor.sh >> /var/log/diskmon.log 2>&1
#
set -uo pipefail   # note: no -e here, we want to finish ALL checks even if one fails

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/common.sh"

# ---- Settings you can change without editing the code ----
# "${VAR:-default}" means "use VAR if it exists, otherwise use the default".
DISK_LIMIT="${DISK_LIMIT:-80}"        # percent full
MEM_LIMIT="${MEM_LIMIT:-85}"          # percent used
LOAD_PER_CPU_LIMIT="${LOAD_PER_CPU_LIMIT:-2.0}"
SNS_TOPIC_ARN="${SNS_TOPIC_ARN:-}"    # empty = don't send alerts
PUSH_METRICS=false
[ "${1:-}" = "--push-metrics" ] && PUSH_METRICS=true

PROBLEMS=()   # an array: an empty list we will add problem messages to

# Who am I? IMDSv2 is the current, secure way to ask "what instance am I?"
get_instance_id() {
  local token
  token=$(curl -sf -X PUT "http://169.254.169.254/latest/api/token" \
          -H "X-aws-ec2-metadata-token-ttl-seconds: 60" 2>/dev/null) || { echo "unknown"; return; }
  curl -sf -H "X-aws-ec2-metadata-token: $token" \
    "http://169.254.169.254/latest/meta-data/instance-id" 2>/dev/null || echo "unknown"
}
INSTANCE_ID=$(get_instance_id)
HOSTNAME_NOW=$(hostname)

header "Health check on ${HOSTNAME_NOW} (${INSTANCE_ID}) at $(date)"

# ---------- CHECK 1: DISK ----------
# df -hP lists every filesystem. We skip fake ones like tmpfs and /proc.
header "Disk usage (limit ${DISK_LIMIT}%)"
while read -r filesystem size used avail percent mount; do
  pct="${percent%\%}"                      # strip the "%" sign off "83%"
  case "$mount" in /dev*|/sys*|/proc*|/run*) continue ;; esac
  if [ "$pct" -ge "$DISK_LIMIT" ]; then
    err "$mount is ${pct}% full (${used} used of ${size}, only ${avail} left)"
    PROBLEMS+=("DISK: $mount at ${pct}% (${avail} free)")
  else
    ok "$mount is ${pct}% full (${avail} free)"
  fi
done < <(df -hP -x tmpfs -x devtmpfs -x squashfs 2>/dev/null | tail -n +2)

# Inodes: a disk can be "empty" but still refuse new files because it ran out
# of file *slots*. Millions of tiny session or cache files cause this.
header "Inode usage (file-slot usage)"
while read -r filesystem inodes iused ifree ipercent mount; do
  pct="${ipercent%\%}"
  case "$mount" in /dev*|/sys*|/proc*|/run*) continue ;; esac
  [[ "$pct" =~ ^[0-9]+$ ]] || continue
  if [ "$pct" -ge "$DISK_LIMIT" ]; then
    err "$mount has used ${pct}% of its inodes"
    PROBLEMS+=("INODES: $mount at ${pct}%")
  else
    ok "$mount inodes ${pct}%"
  fi
done < <(df -iP -x tmpfs -x devtmpfs -x squashfs 2>/dev/null | tail -n +2)

# ---------- CHECK 2: MEMORY ----------
header "Memory usage (limit ${MEM_LIMIT}%)"
MEM_TOTAL=$(awk '/MemTotal/{print $2}' /proc/meminfo)
MEM_AVAIL=$(awk '/MemAvailable/{print $2}' /proc/meminfo)
MEM_USED_PCT=$(( (MEM_TOTAL - MEM_AVAIL) * 100 / MEM_TOTAL ))
if [ "$MEM_USED_PCT" -ge "$MEM_LIMIT" ]; then
  err "Memory ${MEM_USED_PCT}% used"
  PROBLEMS+=("MEMORY: ${MEM_USED_PCT}% used")
  log "Top 5 memory hogs:"
  ps -eo pid,comm,%mem --sort=-%mem | head -6
else
  ok "Memory ${MEM_USED_PCT}% used"
fi

# ---------- CHECK 3: CPU LOAD ----------
# "Load average" = how many jobs were waiting. Compare it to your CPU count.
# 4 CPUs with a load of 4.0 means "completely busy but keeping up".
header "CPU load"
CPUS=$(nproc)
LOAD1=$(awk '{print $1}' /proc/loadavg)
LOAD_PER_CPU=$(awk -v l="$LOAD1" -v c="$CPUS" 'BEGIN{printf "%.2f", l/c}')
if awk -v a="$LOAD_PER_CPU" -v b="$LOAD_PER_CPU_LIMIT" 'BEGIN{exit !(a>b)}'; then
  err "Load ${LOAD1} across ${CPUS} CPUs = ${LOAD_PER_CPU} per CPU"
  PROBLEMS+=("CPU: load ${LOAD_PER_CPU} per CPU")
else
  ok "Load ${LOAD1} across ${CPUS} CPUs = ${LOAD_PER_CPU} per CPU"
fi

# ---------- PUSH NUMBERS TO CLOUDWATCH ----------
if [ "$PUSH_METRICS" = true ] && command -v aws >/dev/null 2>&1; then
  header "Sending metrics to CloudWatch namespace 'CustomOps'"
  ROOT_DISK_PCT=$(df -hP / | tail -1 | awk '{print $5}' | tr -d '%')
  aws cloudwatch put-metric-data --namespace CustomOps \
    --dimensions InstanceId="$INSTANCE_ID" \
    --metric-name DiskUsedPercent --unit Percent --value "$ROOT_DISK_PCT" \
    && ok "sent DiskUsedPercent=$ROOT_DISK_PCT"
  aws cloudwatch put-metric-data --namespace CustomOps \
    --dimensions InstanceId="$INSTANCE_ID" \
    --metric-name MemoryUsedPercent --unit Percent --value "$MEM_USED_PCT" \
    && ok "sent MemoryUsedPercent=$MEM_USED_PCT"
fi

# ---------- ALERT ----------
if [ ${#PROBLEMS[@]} -eq 0 ]; then
  ok "All checks passed."
  exit 0
fi

header "${#PROBLEMS[@]} problem(s) found"
printf '  - %s\n' "${PROBLEMS[@]}"

if [ -n "$SNS_TOPIC_ARN" ] && command -v aws >/dev/null 2>&1; then
  MESSAGE="Host: ${HOSTNAME_NOW} (${INSTANCE_ID})
Time: $(date -u)
Problems:
$(printf '  - %s\n' "${PROBLEMS[@]}")"
  aws sns publish --topic-arn "$SNS_TOPIC_ARN" \
    --subject "ALERT: ${HOSTNAME_NOW} health check failed" \
    --message "$MESSAGE" >/dev/null && ok "Alert sent to SNS" || err "Could not send SNS alert"
fi

exit 1
