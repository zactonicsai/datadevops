#!/usr/bin/env bash
# common.sh - shared helpers for every bash script in this toolkit.
# You never run this file directly. Other scripts "source" it, which means
# "copy these functions into yourself before you start".

# ---- Colors (only if we are printing to a real terminal) ----
if [ -t 1 ]; then
  RED=$'\033[0;31m'; GREEN=$'\033[0;32m'; YELLOW=$'\033[0;33m'
  BLUE=$'\033[0;34m'; BOLD=$'\033[1m'; RESET=$'\033[0m'
else
  RED=""; GREEN=""; YELLOW=""; BLUE=""; BOLD=""; RESET=""
fi

log()    { printf '%s[ .. ]%s %s\n' "$BLUE"   "$RESET" "$*"; }
ok()     { printf '%s[ OK ]%s %s\n' "$GREEN"  "$RESET" "$*"; }
warn()   { printf '%s[WARN]%s %s\n' "$YELLOW" "$RESET" "$*"; }
err()    { printf '%s[FAIL]%s %s\n' "$RED"    "$RESET" "$*" >&2; }
header() { printf '\n%s=== %s ===%s\n' "$BOLD" "$*" "$RESET"; }

# die "message" -> print an error and stop the whole script.
die() { err "$*"; exit 1; }

# need_cmd aws -> stop early with a friendly message if a tool is missing.
need_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "Missing required command: '$1'. Please install it first."
}

# whoami_aws -> prints which AWS account and user/role we are about to touch.
# ALWAYS call this before doing anything. It is the cloud version of
# "check you are in the right room before you start rearranging furniture".
whoami_aws() {
  need_cmd aws
  local caller
  caller=$(aws sts get-caller-identity --output json 2>/dev/null) \
    || die "AWS credentials are missing or expired. Try: aws configure"
  local account arn
  account=$(echo "$caller" | grep -o '"Account": *"[^"]*"' | cut -d'"' -f4)
  arn=$(echo "$caller" | grep -o '"Arn": *"[^"]*"' | cut -d'"' -f4)
  log "Account : ${BOLD}${account}${RESET}"
  log "Identity: ${arn}"
  log "Region  : ${AWS_REGION:-${AWS_DEFAULT_REGION:-$(aws configure get region 2>/dev/null || echo 'not set')}}"
}

# confirm "Delete 5 volumes?" -> asks yes/no. Returns success only on "yes".
# Any script that CHANGES something must call this first.
confirm() {
  local reply
  printf '%s%s [type yes to continue]:%s ' "$YELLOW" "$1" "$RESET"
  read -r reply
  [ "$reply" = "yes" ]
}
