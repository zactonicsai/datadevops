#!/usr/bin/env python3
"""
08_iam_key_audit.py
===================
WHAT IT DOES
    Reviews every human user and every access key in the account and reports:
      - access keys that are old (never rotated)
      - access keys that have NEVER been used
      - keys not used in a long time (still valid, still dangerous)
      - users with no multi-factor authentication (MFA)
      - passwords that have never been changed
      - the root account being used (it should be locked in a drawer)

WHY IT MATTERS
    An AWS access key is a username and password rolled into one long string.
    If it leaks into a GitHub repo, a Slack message, or a laptop backup, whoever
    finds it becomes you. Bots scan public GitHub for these keys every second.
    Old keys are the worst kind, because nobody remembers where they were used,
    so nobody dares delete them, so they live forever.

SAFETY
    Read-only.

USAGE
    python3 08_iam_key_audit.py
    python3 08_iam_key_audit.py --max-key-age 60 --max-idle-days 45
"""

import argparse
import csv
import datetime as dt
import io
import sys
import time

import boto3
from botocore.exceptions import ClientError

NEVER = ("N/A", "not_supported", "no_information", "")


def parse_time(value):
    """The credential report uses ISO dates and some placeholder words."""
    if not value or value in NEVER:
        return None
    try:
        return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def days_since(when):
    if when is None:
        return None
    return (dt.datetime.now(dt.timezone.utc) - when).days


def get_credential_report(iam):
    """
    IAM can build a CSV summary of every user's credentials. It has to be
    generated first, which takes a few seconds, so we ask and then wait.
    """
    for _ in range(10):
        try:
            report = iam.get_credential_report()
            return report["Content"].decode("utf-8")
        except ClientError as exc:
            code = exc.response["Error"]["Code"]
            if code in ("ReportNotPresent", "ReportInProgress", "ReportExpired"):
                iam.generate_credential_report()
                time.sleep(3)
            else:
                raise
    raise RuntimeError("Credential report never became ready")


def main():
    parser = argparse.ArgumentParser(description="Audit IAM users and access keys")
    parser.add_argument("--max-key-age", type=int, default=90,
                        help="Flag keys older than this many days (default 90)")
    parser.add_argument("--max-idle-days", type=int, default=90,
                        help="Flag keys unused for this many days (default 90)")
    parser.add_argument("--profile")
    args = parser.parse_args()

    session = boto3.Session(profile_name=args.profile) if args.profile else boto3.Session()
    iam = session.client("iam")

    identity = session.client("sts").get_caller_identity()
    print(f"Account: {identity['Account']}")
    print("Generating IAM credential report (this takes a few seconds) ...\n")

    raw = get_credential_report(iam)
    rows = list(csv.DictReader(io.StringIO(raw)))

    findings = []
    user_count = 0

    for row in rows:
        user = row["user"]

        # ---- The root account gets special treatment ----
        if user == "<root_account>":
            if row.get("mfa_active") != "true":
                findings.append(("CRITICAL", "root account",
                                 "Root account has NO multi-factor authentication",
                                 "Turn on MFA for root today. This is the master key to everything."))
            last_used = parse_time(row.get("password_last_used"))
            if last_used and days_since(last_used) < 30:
                findings.append(("HIGH", "root account",
                                 f"Root was logged into {days_since(last_used)} days ago",
                                 "Root should be used only for a handful of tasks. "
                                 "Create IAM users or use IAM Identity Center for daily work."))
            for n in ("1", "2"):
                if row.get(f"access_key_{n}_active") == "true":
                    findings.append(("CRITICAL", "root account",
                                     f"Root has an ACTIVE access key #{n}",
                                     "Delete root access keys. There is almost no valid reason to have one."))
            continue

        user_count += 1

        # ---- Console password + MFA ----
        if row.get("password_enabled") == "true":
            if row.get("mfa_active") != "true":
                findings.append(("HIGH", user,
                                 "Can log into the console but has NO MFA",
                                 "Require MFA for every human user"))
            pw_changed = parse_time(row.get("password_last_changed"))
            if pw_changed and days_since(pw_changed) > 365:
                findings.append(("MEDIUM", user,
                                 f"Password unchanged for {days_since(pw_changed)} days",
                                 "Rotate the password"))
            pw_used = parse_time(row.get("password_last_used"))
            if pw_used is None:
                findings.append(("MEDIUM", user,
                                 "Has a console password that has NEVER been used",
                                 "Remove the password - unused credentials are pure risk"))
            elif days_since(pw_used) > 180:
                findings.append(("MEDIUM", user,
                                 f"Has not logged in for {days_since(pw_used)} days",
                                 "Probably a former employee. Disable or delete the user."))

        # ---- Access keys ----
        for n in ("1", "2"):
            if row.get(f"access_key_{n}_active") != "true":
                continue
            created = parse_time(row.get(f"access_key_{n}_last_rotated"))
            used = parse_time(row.get(f"access_key_{n}_last_used_date"))
            age = days_since(created)

            if age is not None and age > args.max_key_age:
                findings.append(("HIGH", user,
                                 f"Access key #{n} is {age} days old (limit {args.max_key_age})",
                                 "Rotate it: create a new key, update the app, verify it works, "
                                 "then delete the old key. Never delete first."))
            if used is None:
                findings.append(("HIGH", user,
                                 f"Access key #{n} has NEVER been used",
                                 "Delete it. An unused key is all risk and no benefit."))
            else:
                idle = days_since(used)
                if idle > args.max_idle_days:
                    service = row.get(f"access_key_{n}_last_used_service", "?")
                    findings.append(("MEDIUM", user,
                                     f"Access key #{n} unused for {idle} days (last service: {service})",
                                     "Probably safe to delete after checking with the owner"))

        if row.get("access_key_1_active") == "true" and row.get("access_key_2_active") == "true":
            findings.append(("LOW", user,
                             "Has two active access keys",
                             "Two keys are normal DURING a rotation. If a rotation is not "
                             "in progress, delete the old one."))

    # ---- Report ----
    print("=" * 78)
    print("IAM CREDENTIAL AUDIT")
    print("=" * 78)
    print(f"Users checked: {user_count}\n")

    if not findings:
        print("No problems found. Excellent credential hygiene.")
        return 0

    order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    findings.sort(key=lambda f: order.get(f[0], 9))

    current = None
    for severity, user, issue, fix in findings:
        if severity != current:
            print(f"\n----- {severity} -----")
            current = severity
        print(f"\n  {user}")
        print(f"    Problem: {issue}")
        print(f"    Fix    : {fix}")

    counts = {}
    for f in findings:
        counts[f[0]] = counts.get(f[0], 0) + 1
    print("\n" + "-" * 78)
    print("TOTALS: " + ", ".join(f"{k}={v}" for k, v in
                                 sorted(counts.items(), key=lambda kv: order.get(kv[0], 9))))
    print("\nGolden rule: prefer IAM ROLES over long-lived access keys.")
    print("A role hands out a temporary key that expires by itself in a few hours.")
    print("A leaked temporary key is nearly worthless. A leaked permanent key is a breach.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
