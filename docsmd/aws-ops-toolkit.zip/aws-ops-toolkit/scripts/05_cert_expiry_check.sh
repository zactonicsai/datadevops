#!/usr/bin/env bash
#
# 05_cert_expiry_check.sh
# WHAT IT DOES: finds certificates that are about to expire.
#   Part A - certificates stored in AWS Certificate Manager (ACM)
#   Part B - the live certificate a website is actually serving right now
#
# WHY IT MATTERS: an expired certificate makes every browser show a big red
# "NOT SECURE" warning. It is one of the most common and most embarrassing
# outages, and it is 100% preventable with a calendar reminder like this.
#
# SAFETY: read-only.
#
# USAGE:
#   ./05_cert_expiry_check.sh                          # ACM certs, warn under 30 days
#   ./05_cert_expiry_check.sh 45                       # warn under 45 days
#   ./05_cert_expiry_check.sh 30 www.example.com api.example.com
#
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/common.sh"

DAYS_WARNING="${1:-30}"
shift || true
HOSTNAMES=("$@")

need_cmd aws
need_cmd date

EXIT_CODE=0

header "Part A: certificates inside AWS Certificate Manager"
whoami_aws

# We ask ACM for every certificate ARN, then look at each one in detail.
CERT_ARNS=$(aws acm list-certificates --query 'CertificateSummaryList[].CertificateArn' --output text 2>/dev/null || echo "")

if [ -z "$CERT_ARNS" ]; then
  log "No ACM certificates found in this region."
else
  NOW_EPOCH=$(date +%s)   # "epoch" = seconds since 1 Jan 1970. Easy to subtract.
  for arn in $CERT_ARNS; do
    detail=$(aws acm describe-certificate --certificate-arn "$arn" --output json)
    domain=$(echo "$detail" | python3 -c 'import sys,json; print(json.load(sys.stdin)["Certificate"]["DomainName"])')
    status=$(echo "$detail" | python3 -c 'import sys,json; print(json.load(sys.stdin)["Certificate"]["Status"])')
    not_after=$(echo "$detail" | python3 -c 'import sys,json; c=json.load(sys.stdin)["Certificate"]; print(c.get("NotAfter",""))')

    if [ -z "$not_after" ]; then
      warn "$domain - status $status - no expiry date yet (not issued)"
      continue
    fi

    exp_epoch=$(date -d "$not_after" +%s 2>/dev/null || date -jf "%Y-%m-%dT%H:%M:%S" "${not_after%%+*}" +%s)
    days_left=$(( (exp_epoch - NOW_EPOCH) / 86400 ))   # 86400 seconds in a day

    if   [ "$days_left" -lt 0 ]; then
      err  "$domain - EXPIRED ${days_left#-} days ago"; EXIT_CODE=2
    elif [ "$days_left" -le "$DAYS_WARNING" ]; then
      warn "$domain - expires in $days_left days"; [ "$EXIT_CODE" -lt 1 ] && EXIT_CODE=1
    else
      ok   "$domain - expires in $days_left days"
    fi
  done
fi

if [ ${#HOSTNAMES[@]} -gt 0 ]; then
  header "Part B: live certificates served by real websites"
  need_cmd openssl
  NOW_EPOCH=$(date +%s)
  for host in "${HOSTNAMES[@]}"; do
    # openssl s_client opens a secure connection and shows the certificate.
    # </dev/null means "don't type anything, just connect and hang up".
    raw=$(echo | openssl s_client -servername "$host" -connect "${host}:443" 2>/dev/null \
          | openssl x509 -noout -enddate 2>/dev/null || true)
    if [ -z "$raw" ]; then
      err "$host - could not reach it or no certificate returned"; EXIT_CODE=2; continue
    fi
    end_date="${raw#notAfter=}"
    exp_epoch=$(date -d "$end_date" +%s)
    days_left=$(( (exp_epoch - NOW_EPOCH) / 86400 ))
    if   [ "$days_left" -lt 0 ]; then err  "$host - EXPIRED"; EXIT_CODE=2
    elif [ "$days_left" -le "$DAYS_WARNING" ]; then warn "$host - expires in $days_left days"; [ "$EXIT_CODE" -lt 1 ] && EXIT_CODE=1
    else ok "$host - expires in $days_left days"; fi
  done
fi

# Exit codes let other tools react: 0 = all good, 1 = warning, 2 = broken.
exit "$EXIT_CODE"
