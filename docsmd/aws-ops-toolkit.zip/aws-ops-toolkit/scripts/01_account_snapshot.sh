#!/usr/bin/env bash
#
# 01_account_snapshot.sh
# WHAT IT DOES: prints a one-page "what do we own right now?" report.
# SAFETY: 100% read-only. It only asks questions, it never changes anything.
#
# USAGE:
#   ./01_account_snapshot.sh                 # uses your default region
#   ./01_account_snapshot.sh us-west-2       # checks one specific region
#
set -euo pipefail
# set -e  = stop the moment a command fails (don't keep going with bad data)
# set -u  = stop if I use a variable I never defined (catches typos)
# set -o pipefail = if any command in a pipe fails, the whole pipe fails

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/common.sh"

REGION="${1:-${AWS_REGION:-${AWS_DEFAULT_REGION:-us-east-1}}}"
export AWS_DEFAULT_REGION="$REGION"

need_cmd aws
whoami_aws

header "EC2 instances in $REGION"
aws ec2 describe-instances \
  --query 'Reservations[].Instances[].{
      Name:Tags[?Key==`Name`]|[0].Value,
      Id:InstanceId,
      Type:InstanceType,
      State:State.Name,
      PrivateIP:PrivateIpAddress,
      PublicIP:PublicIpAddress,
      AZ:Placement.AvailabilityZone
    }' \
  --output table || warn "Could not list EC2 instances (permission or region issue)."

header "Instance count by state"
# We ask AWS for just the state words, then sort them and count duplicates.
aws ec2 describe-instances \
  --query 'Reservations[].Instances[].State.Name' --output text \
  | tr '\t' '\n' | sort | uniq -c | sort -rn || true

header "EBS volumes not attached to anything (you still pay for these)"
aws ec2 describe-volumes --filters Name=status,Values=available \
  --query 'Volumes[].{Id:VolumeId,SizeGB:Size,Type:VolumeType,Created:CreateTime}' \
  --output table || true

header "Elastic IPs not attached to anything (AWS charges for idle ones)"
aws ec2 describe-addresses \
  --query 'Addresses[?AssociationId==`null`].{IP:PublicIp,AllocId:AllocationId}' \
  --output table || true

header "RDS databases"
aws rds describe-db-instances \
  --query 'DBInstances[].{Name:DBInstanceIdentifier,Engine:Engine,Class:DBInstanceClass,
           Status:DBInstanceStatus,MultiAZ:MultiAZ,Public:PubliclyAccessible}' \
  --output table 2>/dev/null || warn "No RDS access or no databases."

header "Load balancers"
aws elbv2 describe-load-balancers \
  --query 'LoadBalancers[].{Name:LoadBalancerName,Type:Type,Scheme:Scheme,State:State.Code}' \
  --output table 2>/dev/null || warn "No load balancers found."

header "Auto Scaling groups"
aws autoscaling describe-auto-scaling-groups \
  --query 'AutoScalingGroups[].{Name:AutoScalingGroupName,Min:MinSize,Max:MaxSize,
           Desired:DesiredCapacity,Running:length(Instances)}' \
  --output table 2>/dev/null || warn "No Auto Scaling groups found."

header "S3 buckets (buckets are global, not per-region)"
aws s3api list-buckets --query 'Buckets[].{Name:Name,Created:CreationDate}' --output table || true

ok "Snapshot complete for region $REGION"
