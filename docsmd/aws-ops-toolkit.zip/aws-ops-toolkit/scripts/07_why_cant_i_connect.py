#!/usr/bin/env python3
"""
07_why_cant_i_connect.py
========================
WHAT IT DOES
    You cannot reach a server. This script checks every single gate between
    the internet and that server, in order, and tells you which gate is shut.

THINK OF IT LIKE A SCHOOL BUILDING
    To reach a classroom (your app) a visitor must pass:
      1. Is the school even open?          -> is the instance running?
      2. Does the building have an address? -> does it have a public IP?
      3. Is there a road to the front door? -> route table has an internet gateway?
      4. The hallway guard                  -> Network ACL (checks in AND out)
      5. The classroom door lock            -> Security group
      6. Is the teacher listening?          -> is the app actually bound to the port?
    Most "the network is broken!" tickets are really gate 4 or gate 5.

SAFETY
    100% read-only.

USAGE
    python3 07_why_cant_i_connect.py i-0abc123def456
    python3 07_why_cant_i_connect.py i-0abc123def456 --port 443 --from 203.0.113.10
    python3 07_why_cant_i_connect.py i-0abc123def456 --port 22 --from 10.0.5.20
"""

import argparse
import ipaddress
import sys

import boto3
from botocore.exceptions import ClientError

PASS, FAIL, WARN, INFO = "PASS", "FAIL", "WARN", "INFO"


def mark(status):
    symbols = {PASS: "  [PASS] ", FAIL: "  [FAIL] ", WARN: "  [WARN] ", INFO: "  [ -- ] "}
    if not sys.stdout.isatty():
        return symbols[status]
    colors = {PASS: "\033[0;32m", FAIL: "\033[1;31m", WARN: "\033[0;33m", INFO: "\033[0;34m"}
    return f"{colors[status]}{symbols[status]}\033[0m"


def say(status, message, fix=None):
    print(f"{mark(status)}{message}")
    if fix:
        print(f"           -> {fix}")


def ip_in_cidr(ip, cidr):
    """Is this single IP address inside this address range?"""
    try:
        return ipaddress.ip_address(ip) in ipaddress.ip_network(cidr, strict=False)
    except ValueError:
        return False


def rule_matches_port(rule, port):
    proto = rule.get("IpProtocol")
    if proto == "-1":
        return True
    start, end = rule.get("FromPort"), rule.get("ToPort")
    if start is None:
        return True
    return start <= port <= end


def check_security_group_inbound(ec2, group_ids, source_ip, port, problems):
    """Security groups are STATEFUL: if traffic is allowed in, the reply is
    automatically allowed back out. So we only need to check inbound."""
    groups = ec2.describe_security_groups(GroupIds=list(group_ids))["SecurityGroups"]
    allowed_by = []

    for sg in groups:
        for rule in sg.get("IpPermissions", []):
            if not rule_matches_port(rule, port):
                continue
            for rng in rule.get("IpRanges", []):
                cidr = rng.get("CidrIp", "")
                if ip_in_cidr(source_ip, cidr):
                    allowed_by.append(f"{sg['GroupId']} ({sg.get('GroupName')}) allows {cidr}")
            for ref in rule.get("UserIdGroupPairs", []):
                allowed_by.append(
                    f"{sg['GroupId']} allows traffic from security group {ref.get('GroupId')} "
                    f"(only helps if your source is inside that group)")

    if allowed_by:
        say(PASS, f"Security group allows port {port} from {source_ip}")
        for line in allowed_by:
            print(f"           {line}")
    else:
        say(FAIL, f"NO security group rule allows port {port} from {source_ip}",
            f"Add an inbound rule: port {port}, source {source_ip}/32")
        problems.append("Security group blocks the traffic")
        print("           Current inbound rules:")
        for sg in groups:
            for rule in sg.get("IpPermissions", []):
                ports = ("ALL" if rule.get("IpProtocol") == "-1"
                         else f"{rule.get('FromPort')}-{rule.get('ToPort')}")
                sources = [r.get("CidrIp") for r in rule.get("IpRanges", [])]
                sources += [f"sg:{r.get('GroupId')}" for r in rule.get("UserIdGroupPairs", [])]
                print(f"             {sg['GroupId']}: ports {ports} from {sources or 'none'}")


def check_nacl(ec2, subnet_id, source_ip, port, problems):
    """
    Network ACLs are STATELESS. That is the trap that catches everyone.
    Stateless means the reply traffic is NOT automatically allowed back.
    You must allow the request coming in AND the answer going out on
    "ephemeral ports" (1024-65535), the temporary ports clients use.
    Rules are numbered and the LOWEST matching number wins - then it stops.
    """
    acls = ec2.describe_network_acls(
        Filters=[{"Name": "association.subnet-id", "Values": [subnet_id]}])["NetworkAcls"]
    if not acls:
        say(WARN, "Could not find a Network ACL for this subnet")
        return

    acl = acls[0]
    say(INFO, f"Network ACL: {acl['NetworkAclId']} (rules are checked lowest number first)")

    def evaluate(egress, test_port, label):
        entries = sorted((e for e in acl["Entries"] if e.get("Egress") == egress),
                         key=lambda e: e["RuleNumber"])
        for entry in entries:
            cidr = entry.get("CidrBlock", "")
            if not cidr or not ip_in_cidr(source_ip, cidr):
                continue
            proto = entry.get("Protocol")
            if proto not in ("-1", "6"):     # -1 = all, 6 = TCP
                continue
            rng = entry.get("PortRange")
            if proto != "-1" and rng and not (rng["From"] <= test_port <= rng["To"]):
                continue
            action = entry["RuleAction"]
            rule_no = entry["RuleNumber"]
            if action == "allow":
                say(PASS, f"NACL {label}: rule #{rule_no} allows {cidr} port {test_port}")
            else:
                say(FAIL, f"NACL {label}: rule #{rule_no} DENIES {cidr} port {test_port}",
                    f"Add an allow rule with a number LOWER than {rule_no}")
                problems.append(f"Network ACL denies {label}")
            return
        say(FAIL, f"NACL {label}: no rule matches, so the default DENY applies",
            "Network ACLs deny anything not explicitly allowed")
        problems.append(f"Network ACL has no allow rule for {label}")

    evaluate(False, port, "inbound request")
    # The reply leaves from a high random port. This is the step people forget.
    evaluate(True, 50000, "outbound reply (ephemeral port ~1024-65535)")


def check_routing(ec2, subnet_id, source_ip, problems):
    tables = ec2.describe_route_tables(
        Filters=[{"Name": "association.subnet-id", "Values": [subnet_id]}])["RouteTables"]
    if not tables:
        # No explicit link means the subnet quietly uses the VPC's main table.
        subnet = ec2.describe_subnets(SubnetIds=[subnet_id])["Subnets"][0]
        tables = ec2.describe_route_tables(
            Filters=[{"Name": "vpc-id", "Values": [subnet["VpcId"]]},
                     {"Name": "association.main", "Values": ["true"]}])["RouteTables"]
        say(INFO, "Subnet is not explicitly linked to a route table, so it uses the main one")

    if not tables:
        say(FAIL, "No route table found at all")
        problems.append("No route table")
        return None

    table = tables[0]
    say(INFO, f"Route table: {table['RouteTableId']}")

    has_igw = has_nat = False
    for route in table["Routes"]:
        dest = route.get("DestinationCidrBlock", route.get("DestinationPrefixListId", "?"))
        target = (route.get("GatewayId") or route.get("NatGatewayId")
                  or route.get("TransitGatewayId") or route.get("VpcPeeringConnectionId") or "local")
        print(f"           {dest:<20} -> {target}")
        if str(target).startswith("igw-"):
            has_igw = True
        if str(target).startswith("nat-"):
            has_nat = True

    source_is_private = ipaddress.ip_address(source_ip).is_private
    if source_is_private:
        say(PASS, "Source is a private address, so no internet gateway is needed")
    elif has_igw:
        say(PASS, "Subnet is PUBLIC (it has a route to an internet gateway)")
    else:
        say(FAIL, "Subnet is PRIVATE - no internet gateway route",
            "Traffic from the public internet cannot reach this subnet. Use a "
            "load balancer, a bastion host, VPN, or Session Manager instead")
        problems.append("Subnet has no internet gateway route")

    if has_nat and not has_igw:
        say(INFO, "There is a NAT gateway: this subnet can call OUT to the internet, "
                  "but the internet cannot start a connection IN")
    return table


def main():
    parser = argparse.ArgumentParser(description="Trace why you cannot reach an EC2 instance")
    parser.add_argument("instance_id", help="Instance ID, e.g. i-0abc123")
    parser.add_argument("--port", type=int, default=22, help="Port you are trying to reach")
    parser.add_argument("--from", dest="source_ip", default="0.0.0.0",
                        help="The IP address you are connecting FROM")
    parser.add_argument("--region")
    parser.add_argument("--profile")
    args = parser.parse_args()

    session = boto3.Session(profile_name=args.profile) if args.profile else boto3.Session()
    ec2 = session.client("ec2", region_name=args.region)

    source_ip = args.source_ip
    if source_ip == "0.0.0.0":
        print("No --from given, assuming a random internet address 203.0.113.99")
        source_ip = "203.0.113.99"

    print("=" * 78)
    print(f"CONNECTIVITY CHECK: {args.instance_id}  port {args.port}  from {source_ip}")
    print("=" * 78)

    problems = []

    # ---- Gate 1: does the instance exist and is it awake? ----
    print("\nGate 1: The instance itself")
    try:
        result = ec2.describe_instances(InstanceIds=[args.instance_id])
        instance = result["Reservations"][0]["Instances"][0]
    except (ClientError, IndexError) as exc:
        say(FAIL, f"Could not find instance {args.instance_id}: {exc}")
        return 2

    state = instance["State"]["Name"]
    if state == "running":
        say(PASS, f"Instance is {state}")
    else:
        say(FAIL, f"Instance is {state}, not running", "Start the instance first")
        problems.append(f"Instance is {state}")

    # Status checks tell you if the OS is healthy, not just the hardware.
    try:
        checks = ec2.describe_instance_status(InstanceIds=[args.instance_id])["InstanceStatuses"]
        if checks:
            sys_ok = checks[0]["SystemStatus"]["Status"]
            inst_ok = checks[0]["InstanceStatus"]["Status"]
            say(PASS if sys_ok == "ok" else FAIL, f"AWS hardware check: {sys_ok}")
            say(PASS if inst_ok == "ok" else FAIL, f"Operating system check: {inst_ok}",
                None if inst_ok == "ok" else "The OS may have failed to boot")
            if inst_ok != "ok":
                problems.append("Instance OS status check failing")
    except ClientError:
        pass

    # ---- Gate 2: does it have an address you can reach? ----
    print("\nGate 2: Addresses")
    private_ip = instance.get("PrivateIpAddress")
    public_ip = instance.get("PublicIpAddress")
    say(INFO, f"Private IP: {private_ip}")
    source_is_private = ipaddress.ip_address(source_ip).is_private
    if public_ip:
        say(PASS, f"Public IP: {public_ip}")
    elif source_is_private:
        say(PASS, "No public IP, but you are connecting from inside the network - that is fine")
    else:
        say(FAIL, "Instance has NO public IP address",
            "Attach an Elastic IP, or connect through a bastion/VPN/Session Manager")
        problems.append("No public IP")

    subnet_id = instance["SubnetId"]
    say(INFO, f"Subnet: {subnet_id}   VPC: {instance['VpcId']}")

    # ---- Gate 3: routing ----
    print("\nGate 3: Routing (is there a road to this subnet?)")
    check_routing(ec2, subnet_id, source_ip, problems)

    # ---- Gate 4: network ACL ----
    print("\nGate 4: Network ACL (the hallway guard - stateless, checks both directions)")
    check_nacl(ec2, subnet_id, source_ip, args.port, problems)

    # ---- Gate 5: security group ----
    print("\nGate 5: Security group (the door lock - stateful, inbound only)")
    group_ids = [g["GroupId"] for g in instance.get("SecurityGroups", [])]
    if group_ids:
        check_security_group_inbound(ec2, group_ids, source_ip, args.port, problems)
    else:
        say(FAIL, "Instance has no security groups attached")
        problems.append("No security groups")

    # ---- Gate 6: things only the OS knows ----
    print("\nGate 6: Inside the machine (this script cannot see these - check by hand)")
    say(INFO, "Is the application actually running and listening on the port?",
        f"On the server run:  sudo ss -tlnp | grep :{args.port}")
    say(INFO, "Is the operating system firewall blocking it?",
        "Run:  sudo iptables -L -n   or   sudo ufw status   or   sudo firewall-cmd --list-all")
    say(INFO, "Is the app bound to 127.0.0.1 instead of 0.0.0.0?",
        "Binding to 127.0.0.1 means 'only I can talk to me'. Bind to 0.0.0.0 to accept "
        "connections from other machines.")

    # ---- Verdict ----
    print("\n" + "=" * 78)
    if problems:
        print(f"FOUND {len(problems)} BLOCKING PROBLEM(S):")
        for i, problem in enumerate(problems, 1):
            print(f"  {i}. {problem}")
        print("\nFix them from the top of the list down - the first gate matters most.")
        return 1

    print("AWS-side networking looks correct.")
    print("If it still does not work, the problem is inside the machine (Gate 6):")
    print("  the app is not running, not listening, or the OS firewall is blocking it.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
