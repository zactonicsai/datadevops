#!/usr/bin/env python3
"""
02_security_audit.py
====================
WHAT IT DOES
    Looks for the four mistakes that cause most cloud break-ins:
      1. Security groups that let the WHOLE INTERNET reach a private port
      2. S3 buckets that are readable by the public
      3. Databases (RDS) with a public address
      4. Disks (EBS) and snapshots stored without encryption

WHY IT MATTERS
    A security group is a door lock. "0.0.0.0/0" means "no lock at all -
    anybody on Earth may knock". That is fine for port 443 (a public website).
    It is a disaster for port 22 (server login) or 3306 (a MySQL database).
    Automated bots scan every AWS IP address constantly and find open ports
    in minutes, not months.

SAFETY
    Read-only. This script never changes, opens, closes, or deletes anything.

USAGE
    python3 02_security_audit.py
    python3 02_security_audit.py --region eu-west-1
    python3 02_security_audit.py --all-regions
    python3 02_security_audit.py --json > findings.json
"""

import argparse
import json
import sys

import boto3
from botocore.exceptions import ClientError

# Ports that should essentially never be open to the whole internet.
# Format: port number -> what it is used for.
DANGEROUS_PORTS = {
    20: "FTP data", 21: "FTP", 22: "SSH (Linux login)", 23: "Telnet (no encryption!)",
    25: "SMTP mail", 135: "Windows RPC", 139: "NetBIOS", 445: "Windows file sharing",
    1433: "Microsoft SQL Server", 1521: "Oracle DB", 3306: "MySQL / MariaDB",
    3389: "RDP (Windows remote desktop)", 5432: "PostgreSQL", 5601: "Kibana",
    5984: "CouchDB", 6379: "Redis", 8020: "Hadoop", 9200: "Elasticsearch",
    9300: "Elasticsearch cluster", 11211: "Memcached", 27017: "MongoDB",
}

# Ports where "open to the world" is normal and expected.
EXPECTED_PUBLIC_PORTS = {80, 443}

OPEN_TO_WORLD = ("0.0.0.0/0", "::/0")


def severity_label(text):
    """Adds color so problems jump off the screen."""
    colors = {"CRITICAL": "\033[1;31m", "HIGH": "\033[0;31m",
              "MEDIUM": "\033[0;33m", "LOW": "\033[0;34m", "OK": "\033[0;32m"}
    if not sys.stdout.isatty():
        return text
    return f"{colors.get(text, '')}{text}\033[0m"


def rule_covers_port(rule, port):
    """Does this one firewall rule include the given port number?"""
    protocol = rule.get("IpProtocol")
    if protocol == "-1":            # "-1" is AWS shorthand for ALL protocols
        return True
    start = rule.get("FromPort")
    end = rule.get("ToPort")
    if start is None or end is None:
        return False
    return start <= port <= end


def describe_port_range(rule):
    """Turns AWS's raw numbers into something a human can read."""
    if rule.get("IpProtocol") == "-1":
        return "ALL ports, ALL protocols"
    start, end = rule.get("FromPort"), rule.get("ToPort")
    proto = rule.get("IpProtocol", "?")
    if start == end:
        return f"{proto}/{start}"
    return f"{proto}/{start}-{end}"


def audit_security_groups(ec2, region, findings):
    """Check every firewall rule in the region."""
    # First find which security groups are actually attached to something.
    # An unused open group is still bad, but less urgent than a live one.
    in_use = set()
    for page in ec2.get_paginator("describe_network_interfaces").paginate():
        for nic in page["NetworkInterfaces"]:
            for group in nic.get("Groups", []):
                in_use.add(group["GroupId"])

    for page in ec2.get_paginator("describe_security_groups").paginate():
        for sg in page["SecurityGroups"]:
            sg_id, sg_name = sg["GroupId"], sg.get("GroupName", "")
            attached = sg_id in in_use

            for rule in sg.get("IpPermissions", []):
                # Collect every "from anywhere" source in this rule
                world_sources = [r["CidrIp"] for r in rule.get("IpRanges", [])
                                 if r.get("CidrIp") in OPEN_TO_WORLD]
                world_sources += [r["CidrIpv6"] for r in rule.get("Ipv6Ranges", [])
                                  if r.get("CidrIpv6") in OPEN_TO_WORLD]
                if not world_sources:
                    continue  # this rule only allows specific IPs - good

                port_text = describe_port_range(rule)

                if rule.get("IpProtocol") == "-1":
                    findings.append({
                        "severity": "CRITICAL", "region": region, "type": "SecurityGroup",
                        "resource": f"{sg_id} ({sg_name})", "attached": attached,
                        "issue": "Every port on every protocol is open to the entire internet",
                        "detail": port_text,
                        "fix": "Delete this rule and replace it with the specific ports you need",
                    })
                    continue

                hits = [f"{p} = {DANGEROUS_PORTS[p]}"
                        for p in DANGEROUS_PORTS if rule_covers_port(rule, p)]
                if hits:
                    findings.append({
                        "severity": "CRITICAL" if attached else "HIGH",
                        "region": region, "type": "SecurityGroup",
                        "resource": f"{sg_id} ({sg_name})", "attached": attached,
                        "issue": "Sensitive port open to the entire internet: " + "; ".join(hits),
                        "detail": port_text,
                        "fix": "Limit the source to your office IP or a VPN, or use "
                               "AWS Systems Manager Session Manager instead of open SSH",
                    })
                else:
                    start = rule.get("FromPort")
                    if start not in EXPECTED_PUBLIC_PORTS:
                        findings.append({
                            "severity": "LOW", "region": region, "type": "SecurityGroup",
                            "resource": f"{sg_id} ({sg_name})", "attached": attached,
                            "issue": "Port open to the internet (may be intentional)",
                            "detail": port_text, "fix": "Confirm this port is meant to be public",
                        })


def audit_s3(s3, findings):
    """S3 buckets are global, so we only check them once, not per region."""
    try:
        buckets = s3.list_buckets()["Buckets"]
    except ClientError as exc:
        print(f"  Could not list S3 buckets: {exc}")
        return

    for bucket in buckets:
        name = bucket["Name"]

        # The Public Access Block is the master safety switch. All four
        # settings should be True. Missing config = switch is OFF.
        try:
            block = s3.get_public_access_block(Bucket=name)["PublicAccessBlockConfiguration"]
            off = [k for k, v in block.items() if not v]
            if off:
                findings.append({
                    "severity": "HIGH", "region": "global", "type": "S3Bucket",
                    "resource": name, "attached": True,
                    "issue": "Public Access Block is partly disabled: " + ", ".join(off),
                    "detail": json.dumps(block),
                    "fix": "Turn all four Block Public Access settings ON unless this "
                           "bucket is deliberately a public website",
                })
        except ClientError as exc:
            if exc.response["Error"]["Code"] in ("NoSuchPublicAccessBlockConfiguration",):
                findings.append({
                    "severity": "HIGH", "region": "global", "type": "S3Bucket",
                    "resource": name, "attached": True,
                    "issue": "No Public Access Block configured at all",
                    "detail": "The master safety switch was never turned on",
                    "fix": "aws s3api put-public-access-block --bucket " + name +
                           " --public-access-block-configuration "
                           "BlockPublicAcls=true,IgnorePublicAcls=true,"
                           "BlockPublicPolicy=true,RestrictPublicBuckets=true",
                })

        # Is the bucket policy itself public?
        try:
            status = s3.get_bucket_policy_status(Bucket=name)["PolicyStatus"]
            if status.get("IsPublic"):
                findings.append({
                    "severity": "CRITICAL", "region": "global", "type": "S3Bucket",
                    "resource": name, "attached": True,
                    "issue": "Bucket policy makes this bucket PUBLIC",
                    "detail": "AWS itself reports IsPublic = true",
                    "fix": "Review the bucket policy and remove Principal '*' unless "
                           "this is a public website bucket",
                })
        except ClientError:
            pass  # no policy at all is normal and fine

        # Is default encryption on?
        try:
            s3.get_bucket_encryption(Bucket=name)
        except ClientError as exc:
            if exc.response["Error"]["Code"] == "ServerSideEncryptionConfigurationNotFoundError":
                findings.append({
                    "severity": "MEDIUM", "region": "global", "type": "S3Bucket",
                    "resource": name, "attached": True,
                    "issue": "No default encryption set",
                    "detail": "Files land on disk unencrypted",
                    "fix": "Enable default SSE-S3 or SSE-KMS encryption",
                })


def audit_rds(rds, region, findings):
    """Databases should almost never have a public address."""
    try:
        for page in rds.get_paginator("describe_db_instances").paginate():
            for db in page["DBInstances"]:
                if db.get("PubliclyAccessible"):
                    findings.append({
                        "severity": "CRITICAL", "region": region, "type": "RDS",
                        "resource": db["DBInstanceIdentifier"], "attached": True,
                        "issue": "Database has a public internet address",
                        "detail": db.get("Endpoint", {}).get("Address", "n/a"),
                        "fix": "Set PubliclyAccessible=false and reach the database "
                               "from inside the VPC or through a bastion/VPN",
                    })
                if not db.get("StorageEncrypted"):
                    findings.append({
                        "severity": "HIGH", "region": region, "type": "RDS",
                        "resource": db["DBInstanceIdentifier"], "attached": True,
                        "issue": "Database storage is not encrypted",
                        "detail": db.get("Engine", ""),
                        "fix": "Encryption cannot be added in place. Take a snapshot, "
                               "copy it with encryption on, restore from the copy",
                    })
                if db.get("BackupRetentionPeriod", 0) == 0:
                    findings.append({
                        "severity": "HIGH", "region": region, "type": "RDS",
                        "resource": db["DBInstanceIdentifier"], "attached": True,
                        "issue": "Automated backups are turned OFF",
                        "detail": "BackupRetentionPeriod = 0",
                        "fix": "Set backup retention to at least 7 days",
                    })
    except ClientError as exc:
        print(f"  Skipping RDS in {region}: {exc.response['Error']['Code']}")


def audit_ebs(ec2, region, findings):
    """Unencrypted disks are a compliance failure waiting to happen."""
    try:
        for page in ec2.get_paginator("describe_volumes").paginate():
            for vol in page["Volumes"]:
                if not vol.get("Encrypted"):
                    findings.append({
                        "severity": "MEDIUM", "region": region, "type": "EBSVolume",
                        "resource": vol["VolumeId"], "attached": bool(vol.get("Attachments")),
                        "issue": "Disk is not encrypted",
                        "detail": f"{vol['Size']} GB, {vol['VolumeType']}",
                        "fix": "Turn on 'EBS encryption by default' for the region so "
                               "all NEW disks are encrypted automatically",
                    })
    except ClientError as exc:
        print(f"  Skipping EBS in {region}: {exc.response['Error']['Code']}")


def get_regions(session):
    ec2 = session.client("ec2")
    return sorted(r["RegionName"] for r in ec2.describe_regions()["Regions"])


def main():
    parser = argparse.ArgumentParser(description="Read-only AWS security audit")
    parser.add_argument("--region", help="One region to check")
    parser.add_argument("--all-regions", action="store_true", help="Check every enabled region")
    parser.add_argument("--profile", help="Named AWS CLI profile to use")
    parser.add_argument("--json", action="store_true", help="Print raw JSON instead of a report")
    args = parser.parse_args()

    session = boto3.Session(profile_name=args.profile) if args.profile else boto3.Session()

    identity = session.client("sts").get_caller_identity()
    if not args.json:
        print(f"Account : {identity['Account']}")
        print(f"Identity: {identity['Arn']}")

    regions = get_regions(session) if args.all_regions else [args.region or session.region_name or "us-east-1"]

    findings = []
    for region in regions:
        if not args.json:
            print(f"\nScanning {region} ...")
        ec2 = session.client("ec2", region_name=region)
        audit_security_groups(ec2, region, findings)
        audit_ebs(ec2, region, findings)
        audit_rds(session.client("rds", region_name=region), region, findings)

    audit_s3(session.client("s3"), findings)

    if args.json:
        print(json.dumps(findings, indent=2, default=str))
        return 1 if findings else 0

    # ---- Human readable report, worst problems first ----
    order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    findings.sort(key=lambda f: order.get(f["severity"], 9))

    print("\n" + "=" * 78)
    print("SECURITY AUDIT RESULTS")
    print("=" * 78)

    if not findings:
        print(severity_label("OK") + "  No problems found. Nice work.")
        return 0

    for f in findings:
        live = "IN USE" if f["attached"] else "not attached"
        print(f"\n[{severity_label(f['severity'])}] {f['type']}: {f['resource']}  ({live}, {f['region']})")
        print(f"    Problem : {f['issue']}")
        print(f"    Details : {f['detail']}")
        print(f"    Fix     : {f['fix']}")

    counts = {}
    for f in findings:
        counts[f["severity"]] = counts.get(f["severity"], 0) + 1
    print("\n" + "-" * 78)
    print("TOTALS: " + ", ".join(f"{severity_label(k)}={v}" for k, v in
                                 sorted(counts.items(), key=lambda kv: order.get(kv[0], 9))))
    # Exit code 1 means "problems found" so a CI pipeline can fail the build.
    return 1


if __name__ == "__main__":
    sys.exit(main())
