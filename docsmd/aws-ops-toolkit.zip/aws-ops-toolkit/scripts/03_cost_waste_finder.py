#!/usr/bin/env python3
"""
03_cost_waste_finder.py
=======================
WHAT IT DOES
    Hunts for things you are paying for but not using, and adds up roughly
    how much money you would save by cleaning them up.

WHAT IT LOOKS FOR
    - EBS volumes with status "available" (a disk plugged into nothing)
    - Elastic IPs that are not attached to anything
    - Snapshots older than N days
    - EC2 instances that have been STOPPED for a long time (the disk still bills)
    - Old, unused AMIs
    - Load balancers with zero healthy targets

WHY IT MATTERS
    Cloud waste is quiet. Nothing breaks, no alarm fires, the bill just creeps
    up 3% a month forever. Deleting one forgotten 500 GB volume saves about
    $40 every single month, which is $480 a year, for one minute of work.

SAFETY
    Read-only by default. It PRINTS delete commands but does not run them.
    Use --generate-cleanup to write those commands to a file you can review.

USAGE
    python3 03_cost_waste_finder.py
    python3 03_cost_waste_finder.py --region us-west-2 --snapshot-age 120
    python3 03_cost_waste_finder.py --generate-cleanup cleanup.sh
"""

import argparse
import datetime as dt
import sys

import boto3
from botocore.exceptions import ClientError

# Rough US-East-1 on-demand prices, USD per month. Prices change, so treat
# these as "close enough to argue for cleanup", not as an invoice.
PRICE_PER_GB_MONTH = {"gp3": 0.08, "gp2": 0.10, "io1": 0.125, "io2": 0.125,
                      "st1": 0.045, "sc1": 0.015, "standard": 0.05}
SNAPSHOT_PRICE_PER_GB_MONTH = 0.05
IDLE_EIP_PRICE_PER_MONTH = 3.60      # ~$0.005/hour
IDLE_ALB_PRICE_PER_MONTH = 16.20     # ~$0.0225/hour base charge


def days_old(timestamp):
    """How many days ago was this created?"""
    now = dt.datetime.now(dt.timezone.utc)
    return (now - timestamp).days


def name_of(resource):
    """AWS stores names as a tag, not a real field. This digs it out."""
    for tag in resource.get("Tags", []) or []:
        if tag["Key"] == "Name":
            return tag["Value"]
    return "(no Name tag)"


def find_unattached_volumes(ec2, waste):
    for page in ec2.get_paginator("describe_volumes").paginate(
            Filters=[{"Name": "status", "Values": ["available"]}]):
        for vol in page["Volumes"]:
            gb = vol["Size"]
            price = PRICE_PER_GB_MONTH.get(vol["VolumeType"], 0.10) * gb
            waste.append({
                "kind": "Unattached EBS volume",
                "id": vol["VolumeId"],
                "name": name_of(vol),
                "detail": f"{gb} GB {vol['VolumeType']}, created {days_old(vol['CreateTime'])} days ago",
                "monthly": price,
                "cleanup": f"aws ec2 delete-volume --volume-id {vol['VolumeId']}",
                "caution": "Take a snapshot first if you are not 100% sure it is garbage",
            })


def find_idle_eips(ec2, waste):
    for addr in ec2.describe_addresses()["Addresses"]:
        if not addr.get("AssociationId"):
            waste.append({
                "kind": "Idle Elastic IP",
                "id": addr.get("AllocationId", addr["PublicIp"]),
                "name": addr["PublicIp"],
                "detail": "Reserved but pointing at nothing",
                "monthly": IDLE_EIP_PRICE_PER_MONTH,
                "cleanup": f"aws ec2 release-address --allocation-id {addr.get('AllocationId','')}",
                "caution": "Once released, you can never get that same IP address back",
            })


def find_old_snapshots(ec2, account_id, max_age, waste):
    paginator = ec2.get_paginator("describe_snapshots")
    for page in paginator.paginate(OwnerIds=[account_id]):
        for snap in page["Snapshots"]:
            age = days_old(snap["StartTime"])
            if age <= max_age:
                continue
            gb = snap["VolumeSize"]
            waste.append({
                "kind": f"Snapshot older than {max_age} days",
                "id": snap["SnapshotId"],
                "name": name_of(snap) or snap.get("Description", "")[:40],
                "detail": f"{gb} GB, {age} days old",
                "monthly": SNAPSHOT_PRICE_PER_GB_MONTH * gb,
                "cleanup": f"aws ec2 delete-snapshot --snapshot-id {snap['SnapshotId']}",
                "caution": "Check it is not the base image for an AMI you still use",
            })


def find_long_stopped_instances(ec2, max_age, waste):
    """A stopped instance is free for CPU but you still pay for its disks."""
    for page in ec2.get_paginator("describe_instances").paginate(
            Filters=[{"Name": "instance-state-name", "Values": ["stopped"]}]):
        for res in page["Reservations"]:
            for inst in res["Instances"]:
                # The reason string looks like: "User initiated (2024-01-15 09:22:33 GMT)"
                reason = inst.get("StateTransitionReason", "")
                disk_gb = 0
                vol_ids = [bd["Ebs"]["VolumeId"] for bd in inst.get("BlockDeviceMappings", [])
                           if "Ebs" in bd]
                if vol_ids:
                    try:
                        vols = ec2.describe_volumes(VolumeIds=vol_ids)["Volumes"]
                        disk_gb = sum(v["Size"] for v in vols)
                    except ClientError:
                        pass
                waste.append({
                    "kind": "Stopped EC2 instance still holding disks",
                    "id": inst["InstanceId"],
                    "name": name_of(inst),
                    "detail": f"{inst['InstanceType']}, {disk_gb} GB attached, stopped: {reason or 'unknown'}",
                    "monthly": disk_gb * 0.10,
                    "cleanup": f"aws ec2 terminate-instances --instance-ids {inst['InstanceId']}",
                    "caution": "TERMINATE IS PERMANENT. Snapshot the disks first.",
                })


def find_unused_amis(ec2, account_id, waste):
    """AMIs you own that no running instance is using."""
    try:
        images = ec2.describe_images(Owners=[account_id])["Images"]
    except ClientError:
        return
    in_use = set()
    for page in ec2.get_paginator("describe_instances").paginate():
        for res in page["Reservations"]:
            for inst in res["Instances"]:
                in_use.add(inst.get("ImageId"))

    for img in images:
        if img["ImageId"] in in_use:
            continue
        gb = sum(bd["Ebs"]["VolumeSize"] for bd in img.get("BlockDeviceMappings", [])
                 if "Ebs" in bd and "VolumeSize" in bd["Ebs"])
        waste.append({
            "kind": "Unused AMI (and its hidden snapshots)",
            "id": img["ImageId"],
            "name": img.get("Name", "")[:50],
            "detail": f"{gb} GB of backing snapshots, created {img.get('CreationDate','?')[:10]}",
            "monthly": SNAPSHOT_PRICE_PER_GB_MONTH * gb,
            "cleanup": f"aws ec2 deregister-image --image-id {img['ImageId']}",
            "caution": "Your Auto Scaling launch templates may still reference this AMI",
        })


def find_empty_load_balancers(session, region, waste):
    elb = session.client("elbv2", region_name=region)
    try:
        lbs = elb.describe_load_balancers()["LoadBalancers"]
    except ClientError:
        return
    for lb in lbs:
        arn = lb["LoadBalancerArn"]
        healthy = 0
        try:
            for tg in elb.describe_target_groups(LoadBalancerArn=arn)["TargetGroups"]:
                health = elb.describe_target_health(TargetGroupArn=tg["TargetGroupArn"])
                healthy += sum(1 for t in health["TargetHealthDescriptions"]
                               if t["TargetHealth"]["State"] == "healthy")
        except ClientError:
            continue
        if healthy == 0:
            waste.append({
                "kind": "Load balancer with zero healthy targets",
                "id": lb["LoadBalancerName"],
                "name": lb.get("DNSName", ""),
                "detail": f"{lb['Type']} load balancer serving nothing",
                "monthly": IDLE_ALB_PRICE_PER_MONTH,
                "cleanup": f"aws elbv2 delete-load-balancer --load-balancer-arn {arn}",
                "caution": "Targets may just be temporarily unhealthy - check twice",
            })


def main():
    parser = argparse.ArgumentParser(description="Find wasted AWS spend (read-only)")
    parser.add_argument("--region", help="Region to scan")
    parser.add_argument("--profile", help="AWS CLI profile")
    parser.add_argument("--snapshot-age", type=int, default=90,
                        help="Flag snapshots older than this many days (default 90)")
    parser.add_argument("--stopped-age", type=int, default=30,
                        help="Flag instances stopped longer than this (default 30)")
    parser.add_argument("--generate-cleanup", metavar="FILE",
                        help="Write the delete commands to a review-then-run script")
    args = parser.parse_args()

    session = boto3.Session(profile_name=args.profile) if args.profile else boto3.Session()
    region = args.region or session.region_name or "us-east-1"
    ec2 = session.client("ec2", region_name=region)
    account_id = session.client("sts").get_caller_identity()["Account"]

    print(f"Account {account_id}, region {region}")
    print("Scanning for waste ...\n")

    waste = []
    find_unattached_volumes(ec2, waste)
    find_idle_eips(ec2, waste)
    find_old_snapshots(ec2, account_id, args.snapshot_age, waste)
    find_long_stopped_instances(ec2, args.stopped_age, waste)
    find_unused_amis(ec2, account_id, waste)
    find_empty_load_balancers(session, region, waste)

    if not waste:
        print("No obvious waste found. Your account is tidy.")
        return 0

    # Most expensive first - fix the big stuff before the pennies.
    waste.sort(key=lambda w: w["monthly"], reverse=True)

    print("=" * 78)
    print(f"{'ESTIMATED WASTE':^78}")
    print("=" * 78)
    for item in waste:
        print(f"\n${item['monthly']:>8.2f}/month  {item['kind']}")
        print(f"              {item['id']}  {item['name']}")
        print(f"              {item['detail']}")
        print(f"      Caution: {item['caution']}")
        print(f"      Cleanup: {item['cleanup']}")

    total = sum(i["monthly"] for i in waste)
    print("\n" + "-" * 78)
    print(f"{len(waste)} items  |  about ${total:,.2f} per month  |  ${total * 12:,.2f} per year")
    print("-" * 78)
    print("Reminder: these are rough US-East-1 list prices, not your real bill.")

    if args.generate_cleanup:
        with open(args.generate_cleanup, "w", encoding="utf-8") as fh:
            fh.write("#!/usr/bin/env bash\n")
            fh.write("# GENERATED CLEANUP SCRIPT - READ EVERY LINE BEFORE RUNNING\n")
            fh.write("# Every command is commented out on purpose. Uncomment what you\n")
            fh.write("# have personally verified is safe to delete.\n")
            fh.write("set -euo pipefail\n\n")
            for item in waste:
                fh.write(f"# {item['kind']}: {item['id']} ({item['name']})\n")
                fh.write(f"#   saves ~${item['monthly']:.2f}/month\n")
                fh.write(f"#   CAUTION: {item['caution']}\n")
                fh.write(f"# {item['cleanup']}\n\n")
        print(f"\nWrote review-first cleanup script to: {args.generate_cleanup}")
        print("Every line is commented out. Nothing runs until a human uncomments it.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
