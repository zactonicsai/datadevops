#!/usr/bin/env python3
"""
04_tag_checker.py
=================
WHAT IT DOES
    Checks every resource in your account for the tags your team requires,
    and shows you who is missing what.

WHAT IS A TAG?
    A tag is a sticky label with a name and a value, like:
        Owner       = payments-team
        Environment = production
        CostCenter  = CC-4471
    AWS does not care what the labels say. YOU care, because tags are the only
    way to answer questions like "who owns this server?" and "how much did the
    marketing team spend last month?".

WHY IT MATTERS
    Untagged resources are orphans. When the bill jumps $2,000 nobody knows who
    to ask. When you want to shut down old test servers, nobody dares because
    nobody knows what they do. Tagging discipline is boring and it saves teams
    days of detective work every quarter.

SAFETY
    Read-only by default.
    With --apply-tag it CAN write tags, and it asks for confirmation first.

USAGE
    python3 04_tag_checker.py
    python3 04_tag_checker.py --required Owner Environment CostCenter
    python3 04_tag_checker.py --allowed-values Environment=dev,test,prod
    python3 04_tag_checker.py --csv untagged.csv
"""

import argparse
import csv
import sys
from collections import defaultdict

import boto3
from botocore.exceptions import ClientError

DEFAULT_REQUIRED = ["Owner", "Environment", "CostCenter", "Application"]


def short_arn(arn):
    """ARNs are long and ugly. Show the useful tail end."""
    parts = arn.split(":")
    if len(parts) >= 6:
        service = parts[2]
        tail = parts[5]
        return f"{service}: {tail}"
    return arn


def collect_resources(session, region):
    """
    The Resource Groups Tagging API is the magic door: one call returns
    EVERY taggable resource in the region instead of asking each service
    (EC2, RDS, S3, Lambda...) one at a time.
    """
    client = session.client("resourcegroupstaggingapi", region_name=region)
    resources = []
    try:
        paginator = client.get_paginator("get_resources")
        for page in paginator.paginate(ResourcesPerPage=100):
            for item in page["ResourceTagMappingList"]:
                tags = {t["Key"]: t["Value"] for t in item.get("Tags", [])}
                resources.append({"arn": item["ResourceARN"], "tags": tags})
    except ClientError as exc:
        print(f"Could not read resources in {region}: {exc}")
    return resources


def parse_allowed_values(raw_list):
    """Turns ['Environment=dev,test,prod'] into {'Environment': {'dev','test','prod'}}"""
    allowed = {}
    for entry in raw_list or []:
        if "=" not in entry:
            continue
        key, values = entry.split("=", 1)
        allowed[key.strip()] = {v.strip() for v in values.split(",") if v.strip()}
    return allowed


def main():
    parser = argparse.ArgumentParser(description="Find resources missing required tags")
    parser.add_argument("--region", help="Region to check")
    parser.add_argument("--profile", help="AWS CLI profile")
    parser.add_argument("--required", nargs="+", default=DEFAULT_REQUIRED,
                        help=f"Tag keys that must exist (default: {' '.join(DEFAULT_REQUIRED)})")
    parser.add_argument("--allowed-values", nargs="+", metavar="KEY=v1,v2",
                        help="Restrict a tag to a fixed list, e.g. Environment=dev,test,prod")
    parser.add_argument("--csv", metavar="FILE", help="Also save results as a spreadsheet")
    parser.add_argument("--apply-tag", metavar="KEY=VALUE",
                        help="WRITES a tag onto every non-compliant resource (asks first)")
    args = parser.parse_args()

    session = boto3.Session(profile_name=args.profile) if args.profile else boto3.Session()
    region = args.region or session.region_name or "us-east-1"
    allowed = parse_allowed_values(args.allowed_values)

    print(f"Region        : {region}")
    print(f"Required tags : {', '.join(args.required)}")
    if allowed:
        for k, v in allowed.items():
            print(f"  {k} must be one of: {', '.join(sorted(v))}")
    print("\nReading resources ...")

    resources = collect_resources(session, region)
    print(f"Found {len(resources)} taggable resources.\n")

    bad = []            # resources with a problem
    missing_counts = defaultdict(int)   # how often each tag is missing
    by_service = defaultdict(lambda: {"total": 0, "bad": 0})

    for res in resources:
        service = res["arn"].split(":")[2] if len(res["arn"].split(":")) > 2 else "unknown"
        by_service[service]["total"] += 1

        missing = [k for k in args.required if k not in res["tags"] or not res["tags"][k].strip()]
        wrong = []
        for key, valid in allowed.items():
            value = res["tags"].get(key)
            if value and value not in valid:
                wrong.append(f"{key}='{value}' is not allowed")

        if missing or wrong:
            by_service[service]["bad"] += 1
            for m in missing:
                missing_counts[m] += 1
            bad.append({"arn": res["arn"], "service": service,
                        "missing": missing, "wrong": wrong, "tags": res["tags"]})

    # ---------- Report ----------
    print("=" * 78)
    print("TAG COMPLIANCE REPORT")
    print("=" * 78)
    print(f"\nCompliant: {len(resources) - len(bad)} / {len(resources)} "
          f"({100 * (len(resources) - len(bad)) / max(len(resources), 1):.0f}%)\n")

    print("By service:")
    print(f"  {'SERVICE':<22}{'TOTAL':>8}{'PROBLEMS':>10}{'SCORE':>8}")
    for service, nums in sorted(by_service.items(), key=lambda kv: -kv[1]["bad"]):
        score = 100 * (nums["total"] - nums["bad"]) / nums["total"]
        print(f"  {service:<22}{nums['total']:>8}{nums['bad']:>10}{score:>7.0f}%")

    if missing_counts:
        print("\nMost commonly missing tag:")
        for key, count in sorted(missing_counts.items(), key=lambda kv: -kv[1]):
            print(f"  {key:<20} missing on {count} resources")

    if bad:
        print(f"\nFirst 25 problem resources (of {len(bad)}):")
        for item in bad[:25]:
            print(f"\n  {short_arn(item['arn'])}")
            if item["missing"]:
                print(f"    missing: {', '.join(item['missing'])}")
            if item["wrong"]:
                print(f"    invalid: {'; '.join(item['wrong'])}")
            if item["tags"]:
                have = ", ".join(f"{k}={v}" for k, v in list(item["tags"].items())[:4])
                print(f"    has    : {have}")
            else:
                print("    has    : no tags at all")

    # ---------- Optional CSV ----------
    if args.csv:
        with open(args.csv, "w", newline="", encoding="utf-8") as fh:
            writer = csv.writer(fh)
            writer.writerow(["ARN", "Service", "MissingTags", "InvalidValues", "ExistingTags"])
            for item in bad:
                writer.writerow([item["arn"], item["service"], "|".join(item["missing"]),
                                 "|".join(item["wrong"]),
                                 "|".join(f"{k}={v}" for k, v in item["tags"].items())])
        print(f"\nSaved spreadsheet: {args.csv}")

    # ---------- Optional write ----------
    if args.apply_tag and bad:
        if "=" not in args.apply_tag:
            print("--apply-tag needs the form KEY=VALUE")
            return 2
        key, value = args.apply_tag.split("=", 1)
        print(f"\nAbout to add {key}={value} to {len(bad)} resources.")
        answer = input("Type 'yes' to continue: ")
        if answer != "yes":
            print("Cancelled. Nothing was changed.")
            return 0
        client = session.client("resourcegroupstaggingapi", region_name=region)
        arns = [b["arn"] for b in bad]
        # The API accepts a maximum of 20 ARNs per call, so we send it in chunks.
        for i in range(0, len(arns), 20):
            chunk = arns[i:i + 20]
            result = client.tag_resources(ResourceARNList=chunk, Tags={key: value})
            failed = result.get("FailedResourcesMap", {})
            print(f"  tagged {len(chunk) - len(failed)} of {len(chunk)}")
            for arn, info in failed.items():
                print(f"    FAILED {short_arn(arn)}: {info.get('ErrorMessage')}")

    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
