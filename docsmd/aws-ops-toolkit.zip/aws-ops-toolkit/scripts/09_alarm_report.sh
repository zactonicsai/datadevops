#!/usr/bin/env bash
#
# 09_alarm_report.sh
# WHAT IT DOES: shows every CloudWatch alarm that is currently unhappy, plus
# the alarms that are "asleep" (INSUFFICIENT_DATA) which are often broken
# alarms nobody noticed, plus alarms that have no action attached at all.
#
# WHY IT MATTERS: an alarm that pages nobody is just a decoration. An alarm
# stuck in INSUFFICIENT_DATA is a smoke detector with a dead battery.
#
# SAFETY: read-only.
#
# USAGE:
#   ./09_alarm_report.sh
#   ./09_alarm_report.sh eu-west-1
#
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/common.sh"

REGION="${1:-${AWS_REGION:-${AWS_DEFAULT_REGION:-us-east-1}}}"
export AWS_DEFAULT_REGION="$REGION"
need_cmd aws
whoami_aws

header "Alarms currently RINGING (state = ALARM)"
aws cloudwatch describe-alarms --state-value ALARM \
  --query 'MetricAlarms[].{Alarm:AlarmName,Metric:MetricName,
           Since:StateUpdatedTimestamp,Reason:StateReason}' \
  --output table || true

header "Alarms with NO DATA (state = INSUFFICIENT_DATA)"
log "These usually mean the thing being watched was deleted, renamed, or never reported."
aws cloudwatch describe-alarms --state-value INSUFFICIENT_DATA \
  --query 'MetricAlarms[].{Alarm:AlarmName,Metric:MetricName,Since:StateUpdatedTimestamp}' \
  --output table || true

header "Alarms that notify NOBODY (empty AlarmActions)"
log "An alarm with no action cannot wake anyone up. Attach an SNS topic."
aws cloudwatch describe-alarms \
  --query 'MetricAlarms[?length(AlarmActions)==`0`].{Alarm:AlarmName,State:StateValue}' \
  --output table || true

header "Alarms that flipped state in the last 24 hours (flapping check)"
# An alarm that flaps on and off all day trains people to ignore alarms.
SINCE=$(date -u -d '24 hours ago' +%Y-%m-%dT%H:%M:%S 2>/dev/null \
        || date -u -v-24H +%Y-%m-%dT%H:%M:%S)
aws cloudwatch describe-alarms \
  --query "MetricAlarms[?StateUpdatedTimestamp>='${SINCE}'].{Alarm:AlarmName,
           State:StateValue,Changed:StateUpdatedTimestamp}" \
  --output table || true

header "Summary count by state"
aws cloudwatch describe-alarms --query 'MetricAlarms[].StateValue' --output text \
  | tr '\t' '\n' | sort | uniq -c | sort -rn || true

ok "Alarm report complete for $REGION"
