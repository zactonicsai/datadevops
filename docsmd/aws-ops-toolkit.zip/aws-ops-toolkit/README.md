# AWS Ops Toolkit — A Beginner-Friendly Guide for Cloud Teams

**What this is:** nine small scripts that watch over an AWS account, plus a full
explanation of what every one of them does and why it matters. Everything is
written in plain language. If you can read a recipe, you can read this.

**Golden rule of this toolkit:** *scripts that look are safe, scripts that touch
are dangerous.* Eight of these nine scripts only look. They read information and
print a report. They never delete, change, open, or close anything. The one
script that can write something asks you to type `yes` first.

---

# Table of Contents

1. [Part 0 — The 20 problems every cloud team faces](#part-0)
2. [Part 1 — Step by step: run your first script in 15 minutes](#part-1)
3. [Part 2 — The background ideas, explained simply](#part-2)
4. [Part 3 — Every script, what it does, and example output](#part-3)
5. [Part 4 — Best practices](#part-4)
6. [Part 5 — Your options, with pros and cons](#part-5)
7. [Part 6 — Where to go next](#part-6)

---

<a name="part-0"></a>
# Part 0 — The 20 Problems Every Cloud Team Faces

Before writing any script, you should know what you are fighting. Here is the
honest list. Almost every ticket a cloud team gets is one of these twenty things.

## Group A — Money problems

**1. The bill goes up and nobody knows why.**
Cloud costs grow quietly. Nobody gets an alert when a developer starts a big
server for a test and forgets it. By the time finance notices, three months have
gone by. *→ Script 03 finds the waste.*

**2. Zombie resources.**
A "zombie" is something you pay for that does nothing: a disk attached to a
deleted server, a reserved IP address pointing nowhere, a load balancer with no
servers behind it. They never break, so they never get noticed. *→ Script 03.*

**3. Nobody knows who owns what.**
You find a server named `test-server-2`. Whose is it? Can you delete it? Nobody
knows, so it lives forever. This is a tagging problem. *→ Script 04.*

**4. Oversized resources.**
Somebody picked a giant server "just to be safe" and it runs at 4% CPU forever.
You are paying ten times what you need.

**5. Storage that never gets cleaned up.**
Backups, snapshots, and log files pile up. A snapshot from 2019 costs the same
as one from yesterday. *→ Script 03.*

## Group B — Security problems

**6. A door left open to the whole internet.**
Someone opens port 22 or a database port to `0.0.0.0/0` ("everybody on Earth")
to fix something quickly, and forgets to close it. Bots find open ports in
minutes. *→ Script 02.*

**7. Public storage buckets.**
An S3 bucket accidentally set to public leaks customer data. This is the single
most common cause of "company leaks 5 million records" headlines. *→ Script 02.*

**8. Old access keys that never get rotated.**
An access key is a permanent password. Keys leak into code repos, chat messages,
and old laptops. A key from three years ago is still a working master key.
*→ Script 08.*

**9. Ex-employees who still have access.**
People leave, accounts stay. *→ Script 08.*

**10. No multi-factor authentication.**
A stolen password should not be enough to get in. *→ Script 08.*

**11. Unencrypted data.**
Disks, databases, and backups stored in plain text. Usually fine until an
auditor asks, and then it is an emergency. *→ Script 02.*

**12. Too many permissions.**
Everyone gets Administrator "because it's easier". Then one mistake or one
stolen laptop can destroy the whole account.

## Group C — Reliability problems

**13. The disk fills up.**
AWS does not watch disk space for you by default. The server keeps running,
the app quietly cannot write, and then everything falls over. *→ Script 06.*

**14. Certificates expire.**
Every browser shows a giant red warning. Fully preventable, still happens
constantly. *→ Script 05.*

**15. Alarms that nobody set up, or alarms that page nobody.**
An alarm with no notification attached is a decoration. An alarm stuck in
"no data" is a smoke detector with a dead battery. *→ Script 09.*

**16. Alert fatigue.**
The opposite problem. So many false alarms fire that people mute the channel and
then miss the real one. *→ Script 09 finds flapping alarms.*

**17. No tested backups.**
"We have backups" is a belief until someone restores one. Untested backups fail
about as often as they work.

## Group D — Network and change problems

**18. "I can't connect and I don't know why."**
The single most common ticket in any cloud team. There are six different gates
traffic must pass through, and any one can be the culprit. *→ Script 07.*

**19. Drift.**
Someone fixes something by hand in the console during an outage. Now the real
world does not match the code that is supposed to describe it. The next
deployment silently undoes the fix.

**20. No inventory.**
Simple question: "how many servers do we run?" Most teams cannot answer in under
an hour. *→ Script 01.*

---

<a name="part-1"></a>
# Part 1 — Step By Step: Run Your First Script in 15 Minutes

We will set up everything and run **Script 01, the account snapshot**. It is the
safest script in the box — it only reads. Follow these seven steps in order.

## Step 1 — Install the AWS CLI

The AWS CLI ("Command Line Interface") is a program that lets you type commands
to AWS instead of clicking buttons in a web page.

**Mac:**
```bash
brew install awscli
```

**Windows:** download and run the installer from the AWS website, then reopen
your terminal.

**Linux (Ubuntu/Debian):**
```bash
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o awscli.zip
unzip awscli.zip
sudo ./aws/install
```

Check it worked:
```bash
aws --version
```
You should see something like `aws-cli/2.x.x`. If you see "command not found",
close your terminal, open a new one, and try again.

## Step 2 — Install Python and boto3

Python is a programming language. `boto3` is the AWS toolbox for Python.

```bash
python3 --version          # should say 3.8 or higher
pip3 install boto3
```

## Step 3 — Create a read-only user for yourself

**Do not use the root account.** The root account is the master key to
everything. Lock it away and never use it for daily work.

In the AWS console:
1. Go to **IAM → Users → Create user**
2. Name it something like `yourname-readonly`
3. Attach the AWS-managed policy called **`ReadOnlyAccess`**
4. Finish creating the user, then go to **Security credentials → Create access key**
5. Choose "Command Line Interface", and copy the two values it shows you

> **Important:** the secret key is shown exactly once. Copy it now. If you lose
> it, you delete the key and make a new one. That is normal and fine.

Why read-only? Because a read-only key that leaks is embarrassing. An
administrator key that leaks is a catastrophe. Start with the least power you
need. This idea has a name: **least privilege.**

## Step 4 — Tell your computer about the key

```bash
aws configure
```

It asks four questions:

```
AWS Access Key ID     : AKIA................
AWS Secret Access Key : wJalr................................
Default region name   : us-east-1
Default output format : json
```

For the region, use the one where your resources actually live (`us-east-1`,
`eu-west-1`, `ap-south-1`, and so on).

## Step 5 — Check that it works

```bash
aws sts get-caller-identity
```

You should see something like:

```json
{
    "UserId": "AIDAEXAMPLE",
    "Account": "123456789012",
    "Arn": "arn:aws:iam::123456789012:user/yourname-readonly"
}
```

This command means **"AWS, who do you think I am?"** Always run it before you run
anything else. It is how you avoid the classic disaster of running a cleanup
script against production when you thought you were in the test account.

## Step 6 — Get the scripts ready

```bash
cd aws-ops-toolkit/scripts
chmod +x *.sh *.py
```

`chmod +x` means "mark this file as a program I am allowed to run".

## Step 7 — Run it

```bash
./01_account_snapshot.sh
```

You will see something like this:

```
[ .. ] Account : 123456789012
[ .. ] Identity: arn:aws:iam::123456789012:user/yourname-readonly
[ .. ] Region  : us-east-1

=== EC2 instances in us-east-1 ===
-----------------------------------------------------------------------
|                          DescribeInstances                          |
+------------+---------------+------------+----------+----------------+
|   Name     |      Id       |    Type    |  State   |   PrivateIP    |
+------------+---------------+------------+----------+----------------+
|  web-01    | i-0a1b2c3d4e  | t3.medium  | running  | 10.0.1.15      |
|  web-02    | i-0f9e8d7c6b  | t3.medium  | running  | 10.0.2.22      |
|  old-test  | i-05f4e3d2c1  | t3.large   | stopped  | 10.0.1.88      |
+------------+---------------+------------+----------+----------------+

=== Instance count by state ===
      2 running
      1 stopped

=== EBS volumes not attached to anything (you still pay for these) ===
+--------------------------+----------+--------+
|            Id            | SizeGB   | Type   |
+--------------------------+----------+--------+
|  vol-0123456789abcdef0   |   500    |  gp2   |
+--------------------------+----------+--------+
```

**Read that last table again.** That 500 GB disk is attached to nothing and costs
about **$50 every month** — $600 a year — to store nothing. You just found real
money in fifteen minutes.

### If something goes wrong

| Message | What it means | Fix |
|---|---|---|
| `Unable to locate credentials` | Your computer has no key | Run `aws configure` |
| `ExpiredToken` | Temporary credentials ran out | Log in again |
| `AccessDenied` | Your user lacks permission | Ask for `ReadOnlyAccess` |
| `command not found: aws` | CLI is not installed or not on your PATH | Redo Step 1 |
| Empty tables everywhere | Right account, wrong region | `./01_account_snapshot.sh eu-west-1` |

**You are done with setup.** Everything else in this guide builds on what you
just did.

---

<a name="part-2"></a>
# Part 2 — The Background Ideas, Explained Simply

## What is AWS, really?

AWS rents you computers. Instead of buying a server, putting it in a room, and
plugging it in, you type a command and one appears in about 30 seconds. When you
are done, you type another command and it disappears, and you stop paying.

That speed is wonderful and dangerous. Making things is easy, so people make a
lot of things. **Nothing reminds you to clean up.** That is the root cause of
about half the problems in Part 0.

## The key ideas, one at a time

### Region
A region is a physical place in the world where AWS has data centers:
`us-east-1` is Virginia, `eu-west-1` is Ireland, `ap-south-1` is Mumbai.

**The thing that confuses everyone:** most resources exist in exactly one region
and are invisible from the others. If you create a server in Ireland and then
look at your dashboard set to Virginia, you will see nothing and panic.

Think of regions as separate school buildings. A locker in Building A is not
visible from Building B, even though both belong to the same school.

A few things are **global** (they live everywhere at once): S3 bucket names,
IAM users, and Route 53 DNS.

### EC2 instance
A rented computer. "Instance" is just AWS's word for "one server".

### EBS volume
The hard disk that plugs into an EC2 instance. Here is the important part:
**the disk and the computer are separate things.** You can delete the computer
and the disk keeps existing, and keeps billing you. That is where zombie disks
come from.

### Security group
A firewall wrapped around one server. It is a list that says *"these specific
people may knock on these specific doors."*

Two things you must remember:

1. **It only lists what is ALLOWED.** There is no "deny" list. Anything not on
   the allow list is automatically blocked.
2. **It is stateful.** "Stateful" means it remembers. If you let a visitor in
   the front door, it automatically lets them back out. You never have to write
   a rule for the reply.

A rule looks like: *allow TCP port 443 from 0.0.0.0/0*.

### CIDR (the `/24` thing)
CIDR is how you write "a range of addresses" in short form.

| Written as | Means | Like saying |
|---|---|---|
| `10.0.5.20/32` | exactly one address | one specific house |
| `10.0.5.0/24` | 256 addresses | one street |
| `10.0.0.0/16` | 65,536 addresses | one whole neighborhood |
| `0.0.0.0/0` | every address that exists | **the entire planet** |

The number after the slash is how many bits are locked down. Bigger number =
smaller, more specific range. **`0.0.0.0/0` is the one to be scared of.**

### Network ACL (NACL)
A second firewall, but around a whole **subnet** (a group of servers) instead of
one server. It is different from a security group in three ways that trip
everybody up:

1. **It is stateless.** It does NOT remember. If you allow traffic in, you must
   *separately* allow the reply going out. Forgetting this causes connections
   that hang forever with no error message.
2. **It has deny rules,** not just allow rules.
3. **Rules are numbered, and the lowest matching number wins.** Once a rule
   matches, evaluation stops. A `DENY` at rule 50 beats an `ALLOW` at rule 100,
   every time.

> **Analogy:** the security group is the lock on your classroom door. The NACL is
> the guard in the hallway who checks people going *both* directions and follows
> a numbered rulebook from the top down.

### Route table
A list of directions: "to reach the internet, go through that gateway". If a
subnet has a route to an **internet gateway (igw-...)**, it is a *public* subnet.
If it does not, it is a *private* subnet and the internet cannot reach it, no
matter how open your security groups are.

A **NAT gateway** is a one-way door: servers inside can call out to the internet
(to download updates), but the internet cannot start a conversation with them.
That is exactly what you want for databases.

### IAM
"Identity and Access Management" — the system that decides who can do what.

- **User** = a person, with a permanent password or key
- **Role** = a temporary costume that a person or a server can put on
- **Policy** = the written list of what is allowed

**The single most important security idea in AWS:** prefer **roles** over
**users with access keys**. A role hands out a key that expires by itself in a
few hours. A leaked temporary key is nearly worthless. A leaked permanent key is
a breach.

### Tag
A sticky label with a name and value, like `Owner = payments-team`.
AWS does not care what it says. *You* care, because tags are the only way to ever
answer "who owns this?" and "what did the marketing team spend?".

### CloudWatch
AWS's own monitoring service. It collects numbers (metrics), keeps text (logs),
and rings bells (alarms) when a number crosses a line.

**The catch that bites everyone:** CloudWatch only sees your servers from the
*outside*. It knows CPU and network traffic. It does **not** know disk space or
memory, because those live inside the machine. You have to send those numbers
yourself — which is exactly what Script 06 does.

### AWS CLI vs boto3
Two ways to talk to AWS. Same conversation, different language.

- **AWS CLI** = you type commands in the terminal. Used by the `.sh` scripts.
- **boto3** = you write Python code. Used by the `.py` scripts.

Use the CLI for short, simple things. Use Python when you need to loop, compare,
do math, or make decisions.

### Exit codes
When a script finishes it hands back a number. `0` means "everything fine".
Anything else means "there was a problem". You never see it, but other programs
do — which is how you make a build pipeline fail automatically when the security
audit finds something.

```bash
python3 02_security_audit.py
echo $?        # prints the exit code of the last command
```

Our scripts use: **0** = clean, **1** = problems found, **2** = the script itself
broke.

### cron
A built-in alarm clock for Linux that runs a command on a schedule.

```
*/10 * * * *  /opt/tools/06_disk_space_monitor.sh
 │   │ │ │ │
 │   │ │ │ └── day of the week (0-6)
 │   │ │ └──── month (1-12)
 │   │ └────── day of the month (1-31)
 │   └──────── hour (0-23)
 └──────────── minute (0-59)      */10 means "every 10 minutes"
```

Edit your schedule with `crontab -e`. A few useful ones:

```
0 8 * * 1     # 8:00 AM every Monday
0 */6 * * *   # every 6 hours
30 2 * * *    # 2:30 AM every day
```

---

<a name="part-3"></a>
# Part 3 — Every Script Explained

| # | File | Language | Writes anything? | Answers the question |
|---|------|----------|------------------|----------------------|
| 01 | `01_account_snapshot.sh` | bash | No | What do we own? |
| 02 | `02_security_audit.py` | python | No | What is dangerously open? |
| 03 | `03_cost_waste_finder.py` | python | No | What are we paying for and not using? |
| 04 | `04_tag_checker.py` | python | Only with `--apply-tag` | Who owns what? |
| 05 | `05_cert_expiry_check.sh` | bash | No | What expires soon? |
| 06 | `06_disk_space_monitor.sh` | bash | Sends metrics/alerts | Is this server healthy? |
| 07 | `07_why_cant_i_connect.py` | python | No | Why can't I reach this server? |
| 08 | `08_iam_key_audit.py` | python | No | Who has keys they shouldn't? |
| 09 | `09_alarm_report.sh` | bash | No | Are our alarms actually working? |

---

## Script 01 — Account Snapshot

**Run it:**
```bash
./01_account_snapshot.sh                # your default region
./01_account_snapshot.sh eu-west-1      # a specific region
```

**What it lists:** EC2 instances, a count by state, unattached disks, idle IP
addresses, RDS databases, load balancers, Auto Scaling groups, and S3 buckets.

**When to use it:** on your first day at a new job, before a big change, after an
incident, or once a month just to stay honest.

### The one bit of bash worth learning here

```bash
set -euo pipefail
```

Four safety switches in one line:

- `set -e` — stop immediately if any command fails. Without this, a script that
  fails halfway keeps going and does the rest of its work using garbage data.
- `set -u` — stop if you use a variable that was never set. This catches typos.
  Without it, `rm -rf /$DIRR` (note the typo) becomes `rm -rf /`. People have
  genuinely destroyed servers this way.
- `set -o pipefail` — if any command in a chain of pipes fails, the whole chain
  counts as failed.

**Put this line at the top of every bash script you ever write.**

---

## Script 02 — Security Audit

**Run it:**
```bash
python3 02_security_audit.py
python3 02_security_audit.py --all-regions
python3 02_security_audit.py --json > findings.json
```

**Example output:**

```
[CRITICAL] SecurityGroup: sg-0a1b2c3d (web-servers)  (IN USE, us-east-1)
    Problem : Sensitive port open to the entire internet: 22 = SSH (Linux login)
    Details : tcp/22
    Fix     : Limit the source to your office IP or a VPN, or use AWS Systems
              Manager Session Manager instead of open SSH

[CRITICAL] S3Bucket: company-backups-2019  (IN USE, global)
    Problem : Bucket policy makes this bucket PUBLIC
    Details : AWS itself reports IsPublic = true
    Fix     : Review the bucket policy and remove Principal '*'

TOTALS: CRITICAL=2, HIGH=5, MEDIUM=11, LOW=3
```

**How to read severity:**

- **CRITICAL** — fix today. A stranger could be using this right now.
- **HIGH** — fix this week.
- **MEDIUM** — fix this sprint. Usually a compliance problem, not an active hole.
- **LOW** — probably intentional, just confirm someone meant to do it.

**The "attached" flag matters.** An open security group attached to nothing is
still bad practice, but nobody can walk through a door that leads nowhere. Fix
the `IN USE` ones first.

### Why port 22 open to the world is genuinely dangerous

Port 22 is SSH — the door you use to log into a Linux server. It requires a
password or a key, so surely it is fine?

No. Automated bots scan every AWS IP address around the clock. An open port 22
will receive **thousands of login attempts per day** within hours of being
opened. They try common usernames and leaked passwords, forever, for free. You
only have to be unlucky once.

The modern answer is not "use a stronger password". It is **do not have the door
at all**. Use **AWS Systems Manager Session Manager**, which gives you a terminal
through the AWS console with zero open ports, and logs every command.

---

## Script 03 — Cost Waste Finder

**Run it:**
```bash
python3 03_cost_waste_finder.py
python3 03_cost_waste_finder.py --snapshot-age 180
python3 03_cost_waste_finder.py --generate-cleanup cleanup.sh
```

**Example output:**

```
$   50.00/month  Unattached EBS volume
              vol-0123456789abcdef0  (no Name tag)
              500 GB gp2, created 412 days ago
      Caution: Take a snapshot first if you are not 100% sure it is garbage
      Cleanup: aws ec2 delete-volume --volume-id vol-0123456789abcdef0

$   16.20/month  Load balancer with zero healthy targets
              old-api-alb  old-api-alb-1234.us-east-1.elb.amazonaws.com
              application load balancer serving nothing

$    3.60/month  Idle Elastic IP
              eipalloc-0abc123  52.1.2.3
              Reserved but pointing at nothing
      Caution: Once released, you can never get that same IP address back

23 items  |  about $412.80 per month  |  $4,953.60 per year
```

### The `--generate-cleanup` flag, and why it is deliberately annoying

This flag writes a shell script with all the delete commands — **and every single
line is commented out.** You must open the file, read each line, decide, and
manually uncomment the ones you want.

That extra step is not laziness. It is the whole design. A script that
automatically deletes "unused" things will eventually delete something that was
not unused, at 3 AM, on a Saturday, in production.

**A real story shape you will meet:** a volume looks unattached because someone
detached it during a migration and plans to reattach it tomorrow. An automated
cleaner deletes it. There is no undo.

**Safe cleanup order, every time:**
1. Run the finder and read the report
2. Snapshot anything you are not 100% certain about
3. Ask the owner in a group channel — give them 48 hours to object
4. Delete a few, wait a week, make sure nothing broke
5. Then delete the rest

---

## Script 04 — Tag Checker

**Run it:**
```bash
python3 04_tag_checker.py
python3 04_tag_checker.py --required Owner Environment CostCenter
python3 04_tag_checker.py --allowed-values Environment=dev,test,prod
python3 04_tag_checker.py --csv untagged.csv
```

**Example output:**

```
Compliant: 142 / 213 (67%)

By service:
  SERVICE                  TOTAL  PROBLEMS   SCORE
  ec2                         89        41     54%
  s3                          34        18     47%
  lambda                      52         9     83%

Most commonly missing tag:
  CostCenter           missing on 58 resources
  Owner                missing on 31 resources
```

**A tag standard that actually works:**

| Tag | Example | Why |
|---|---|---|
| `Owner` | `payments-team` | Who to ask before deleting |
| `Environment` | `prod` | Prevents "oops, that was production" |
| `CostCenter` | `CC-4471` | Splits the bill by team |
| `Application` | `checkout-api` | Groups related resources |
| `ManagedBy` | `terraform` | Warns you not to edit it by hand |

Use a team as the `Owner`, not a person. People change jobs; teams last longer.

**Best practice:** do not chase tags forever by hand. Make them impossible to
skip. Put tags in your Terraform/CloudFormation code so new resources are born
tagged, and use an **AWS Organizations Tag Policy** or a **Service Control
Policy** to reject untagged creation outright. Then run this script only to catch
the leftovers from before the rule existed.

---

## Script 05 — Certificate Expiry Check

**Run it:**
```bash
./05_cert_expiry_check.sh                                # ACM certs, warn under 30 days
./05_cert_expiry_check.sh 45                             # warn under 45 days
./05_cert_expiry_check.sh 30 www.example.com api.example.com
```

**Example output:**

```
=== Part A: certificates inside AWS Certificate Manager ===
[ OK ] shop.example.com - expires in 245 days
[WARN] api.example.com - expires in 18 days
[FAIL] old.example.com - EXPIRED 7 days ago

=== Part B: live certificates served by real websites ===
[ OK ] www.example.com - expires in 61 days
```

### Why there are two parts

**Part A** checks what is stored in AWS Certificate Manager. **Part B** opens a
real connection to a real website and looks at the certificate it is actually
serving.

These can disagree, and when they do, Part B is the truth. You can have a shiny
renewed certificate sitting in ACM that nobody ever attached to the load
balancer. ACM says "all good". Visitors still see the red warning screen.

**Always check the live site, not just the storage cupboard.**

**Best practice:** certificates issued by ACM and attached to AWS services renew
themselves automatically — *as long as DNS validation still works*. The usual
failure is that someone deleted the validation record from DNS months ago, so
auto-renewal silently fails. This script catches that.

---

## Script 06 — Disk / Memory / CPU Monitor

**This one runs ON the server, not from your laptop.**

```bash
./06_disk_space_monitor.sh
DISK_LIMIT=75 ./06_disk_space_monitor.sh
SNS_TOPIC_ARN=arn:aws:sns:us-east-1:1234:ops-alerts ./06_disk_space_monitor.sh
./06_disk_space_monitor.sh --push-metrics
```

**Schedule it with cron:**
```bash
crontab -e
# then add:
*/10 * * * * /opt/tools/06_disk_space_monitor.sh >> /var/log/diskmon.log 2>&1
```

**Example output:**

```
=== Health check on web-01 (i-0a1b2c3d) at Mon Jul 27 14:22:01 UTC 2026 ===

=== Disk usage (limit 80%) ===
[ OK ] / is 42% full (28G free)
[FAIL] /var/log is 94% full (1.1G free)

=== Inode usage (file-slot usage) ===
[ OK ] / inodes 12%

=== Memory usage (limit 85%) ===
[FAIL] Memory 91% used
[ .. ] Top 5 memory hogs:
   PID COMMAND         %MEM
  1247 java            67.2
  1832 postgres         8.1

2 problem(s) found
  - DISK: /var/log at 94% (1.1G free)
  - MEMORY: 91% used
[ OK ] Alert sent to SNS
```

### Three things this teaches

**1. Inodes — the sneaky one.**
A filesystem has two separate limits: how many *bytes* it can hold, and how many
*files* it can hold. Run out of file slots and you get "No space left on device"
even though `df -h` proudly reports 60% free. Millions of tiny session files or
cache files cause this. It looks like a haunting until you know to check.

```bash
df -h    # checks space
df -i    # checks file slots  ← the one people forget
```

**2. Load average is not a percentage.**
`/proc/loadavg` gives you a number like `4.12`. That is *not* 4% and not 412%. It
is "on average, 4.12 jobs were waiting to run".

**Compare it to your CPU count.** On a 4-CPU machine:
- load 4.0 = completely busy but keeping up
- load 8.0 = twice as much work as you can handle, things are queuing
- load 1.0 = relaxed

On a 1-CPU machine, load 4.0 is a fire. Same number, opposite meaning. That is
why the script divides by `nproc`.

**3. IMDSv2 — how a server learns its own name.**
Every EC2 instance can ask a special internal address, `169.254.169.254`, "who am
I?". The old way (IMDSv1) just asked. The current, secure way (IMDSv2) requires
you to fetch a token first:

```bash
TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" \
        -H "X-aws-ec2-metadata-token-ttl-seconds: 60")
curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
     http://169.254.169.254/latest/meta-data/instance-id
```

The extra step blocks a real attack where a tricked web app could be made to
fetch that address and hand over the server's credentials. **Always use IMDSv2.**
AWS now enables it by default on new instances, and you should require it.

---

## Script 07 — Why Can't I Connect?

**The most useful script in this box.** Run it the moment someone says "the
network is broken".

```bash
python3 07_why_cant_i_connect.py i-0abc123def456
python3 07_why_cant_i_connect.py i-0abc123 --port 443 --from 203.0.113.10
python3 07_why_cant_i_connect.py i-0abc123 --port 22 --from 10.0.5.20
```

**Example output:**

```
CONNECTIVITY CHECK: i-0abc123def  port 22  from 203.0.113.10

Gate 1: The instance itself
  [PASS] Instance is running
  [PASS] AWS hardware check: ok
  [PASS] Operating system check: ok

Gate 2: Addresses
  [ -- ] Private IP: 10.0.1.15
  [PASS] Public IP: 54.1.2.3

Gate 3: Routing (is there a road to this subnet?)
  [ -- ] Route table: rtb-0abc123
           10.0.0.0/16          -> local
           0.0.0.0/0            -> igw-0def456
  [PASS] Subnet is PUBLIC (it has a route to an internet gateway)

Gate 4: Network ACL (the hallway guard - stateless, checks both directions)
  [ -- ] Network ACL: acl-0aaa111 (rules are checked lowest number first)
  [PASS] NACL inbound request: rule #100 allows 0.0.0.0/0 port 22
  [FAIL] NACL outbound reply (ephemeral port ~1024-65535): no rule matches,
         so the default DENY applies
           -> Network ACLs deny anything not explicitly allowed

Gate 5: Security group (the door lock - stateful, inbound only)
  [PASS] Security group allows port 22 from 203.0.113.10
           sg-0a1b2c3d (bastion-sg) allows 203.0.113.0/24

FOUND 1 BLOCKING PROBLEM(S):
  1. Network ACL has no allow rule for outbound reply (ephemeral port)
```

**That is the classic bug**, and it is nearly impossible to spot by eye. The
security group is perfect. The inbound NACL rule is perfect. The connection still
hangs forever with no error — because the *answer* cannot get back out.

### Ephemeral ports, the thing nobody explains

When your laptop connects to a server on port 22, your laptop does **not** use
port 22. It picks a random high port for itself, usually somewhere between 1024
and 65535. That is an **ephemeral port** ("ephemeral" = short-lived).

So the conversation is:
- **Request:** your laptop port `51234` → server port `22`
- **Reply:** server port `22` → your laptop port `51234`

A security group is *stateful*, so it handles the reply automatically. A NACL is
*stateless*, so **you must add an outbound rule allowing ports 1024–65535** or
every connection dies silently.

### The six gates, in order

| Gate | What it checks | Typical failure |
|---|---|---|
| 1 | Instance running and healthy | It is stopped |
| 2 | Has a reachable address | No public IP |
| 3 | Route table | Private subnet, no internet gateway |
| 4 | Network ACL | Missing the outbound ephemeral rule |
| 5 | Security group | Port simply not allowed |
| 6 | Inside the OS | App not running, or OS firewall on |

The script cannot see Gate 6 — nothing outside the machine can. If Gates 1–5 all
pass and it still fails, log in and run:

```bash
sudo ss -tlnp | grep :22      # is anything listening on that port?
sudo iptables -L -n           # is the OS firewall blocking it?
```

**One more Gate 6 trap:** if your app is bound to `127.0.0.1` instead of
`0.0.0.0`, it is saying "only I may talk to me". It will work perfectly when you
test it while logged into the server, and be completely unreachable from
anywhere else. This wastes hours. Check it early.

---

## Script 08 — IAM Key Audit

```bash
python3 08_iam_key_audit.py
python3 08_iam_key_audit.py --max-key-age 60 --max-idle-days 45
```

**Example output:**

```
----- CRITICAL -----

  root account
    Problem: Root account has NO multi-factor authentication
    Fix    : Turn on MFA for root today. This is the master key to everything.

----- HIGH -----

  deploy-bot
    Problem: Access key #1 is 847 days old (limit 90)
    Fix    : Rotate it: create a new key, update the app, verify it works,
             then delete the old key. Never delete first.

  jsmith
    Problem: Access key #2 has NEVER been used
    Fix    : Delete it. An unused key is all risk and no benefit.

TOTALS: CRITICAL=1, HIGH=6, MEDIUM=12, LOW=2
```

### How to rotate a key without breaking production

The order matters enormously. Do it exactly like this:

1. **Create** a second key for the same user (AWS allows two on purpose — this is
   precisely why)
2. **Deploy** the new key to wherever the app reads it from
3. **Wait and verify** — watch the "last used" date on the new key start moving
4. **Deactivate** the old key (do not delete yet — deactivate is instantly
   reversible)
5. **Wait 48 hours.** If something breaks, reactivate and investigate
6. **Delete** the old key

**The mistake everyone makes once:** deleting the old key first. There is always
one forgotten cron job or one legacy script still using it, and it fails at the
worst moment with a confusing error.

### The better answer: stop using keys

Long-lived access keys are a last resort, not a default.

- **For EC2, Lambda, ECS:** attach an **IAM role**. The service gets temporary
  credentials automatically and rotates them for you. Zero keys to manage.
- **For humans:** use **IAM Identity Center** (formerly AWS SSO). People log in
  with the company account, get a temporary session, and it expires by itself.
- **For GitHub Actions and other CI:** use **OIDC federation**. Your pipeline
  proves who it is and gets a temporary key. No secret stored anywhere.

**Only use a permanent access key when literally nothing else works.**

---

## Script 09 — Alarm Report

```bash
./09_alarm_report.sh
./09_alarm_report.sh eu-west-1
```

**What it shows, and why each section exists:**

**Alarms currently ringing.** The obvious one — what is broken now.

**Alarms with no data (INSUFFICIENT_DATA).** These usually mean the thing being
watched was deleted or renamed. The alarm is not "quiet", it is **blind**. This
is the smoke detector with a dead battery, and it will not save you.

**Alarms that notify nobody.** An alarm with no SNS action attached changes color
on a dashboard nobody is looking at. It is a decoration.

**Alarms that flipped in the last 24 hours.** An alarm that goes off and on all
day is *flapping*. Flapping alarms train your team to ignore alarms, which then
costs you a real outage six months later. Fix flapping by requiring several bad
readings in a row before firing, not just one.

### What to actually alarm on

**Do alarm on things that hurt users:**
- Website returning errors (5xx count)
- Response time getting slow (p99 latency)
- Queue backing up and not draining
- Disk over 85% (from Script 06)
- Health check failures

**Do not alarm on things that are merely interesting:**
- CPU at 80% — that might be a perfectly efficient server
- Any single spike in anything
- Things nobody will act on at 3 AM

**The test:** *"If this fires at 3 AM, is there something a human should do right
now?"* If the honest answer is no, it should be a dashboard or a daily report,
not an alarm.

---

<a name="part-4"></a>
# Part 4 — Best Practices

## Safety

1. **Read-only by default.** Any script that changes something should require an
   explicit flag *and* a typed confirmation.
2. **Always print the account and identity first.** Every script here starts by
   saying which account it is in. This is the cheapest possible protection
   against the "wrong account" disaster.
3. **Dry run first.** Show what *would* happen, then do it in a second run.
4. **Never delete on a schedule.** Automated *detection* is great. Automated
   *deletion* eventually eats something important.
5. **Snapshot before you delete.** A snapshot costs pennies. A restore from
   nothing costs your weekend.

## Credentials

6. **Never put a key in a script.** Not even temporarily, not even in a private
   repo. Use `aws configure`, environment variables, or a role.
7. **Use roles, not keys, wherever possible.**
8. **Least privilege.** A monitoring script needs `ReadOnlyAccess`, never
   `AdministratorAccess`.
9. **Use named profiles to keep accounts apart:**
   ```bash
   aws configure --profile prod
   aws configure --profile dev
   python3 02_security_audit.py --profile dev
   ```
   Typing `--profile dev` is a small speed bump that has saved a lot of careers.

## Writing scripts

10. **`set -euo pipefail` at the top of every bash script.** Non-negotiable.
11. **Meaningful exit codes** so other tools can react.
12. **Comment the *why*, not the *what*.** `i = i + 1` needs no comment.
    "AWS only accepts 20 ARNs per call, so we chunk" absolutely does.
13. **Make settings configurable** through flags or environment variables so
    people never have to edit your code to change a threshold.
14. **Handle the "not allowed" error gracefully.** Print a clear message and keep
    going instead of crashing with a stack trace.
15. **Paginate.** AWS returns results in pages of about 50–1000. If you ignore
    this, your script quietly reports on only the first page and you believe a
    lie. Every script here uses `get_paginator` for exactly this reason.

## Running them

16. **Start with a daily email, not an alarm.** Get a feel for the normal noise
    level before you let anything wake people up.
17. **Put security checks in your build pipeline.** Exit code 1 fails the build:
    ```yaml
    - run: python3 02_security_audit.py || exit 1
    ```
18. **Version-control the scripts.** They *are* infrastructure.
19. **Track the trend, not the snapshot.** "47 problems" means little. "47, down
    from 130 last quarter" means your team is winning.

---

<a name="part-5"></a>
# Part 5 — Your Options, With Pros and Cons

## Bash or Python?

| | Bash | Python |
|---|---|---|
| **Good for** | Short commands, gluing tools together, anything already running on the server | Logic, loops, math, comparing things, JSON |
| **Pros** | Already installed everywhere, very short for simple jobs, natural fit for cron | Readable, great error handling, boto3 is excellent, easy to test |
| **Cons** | Gets ugly fast past ~100 lines, error handling is awkward, quoting rules are genuinely hostile | Needs Python + boto3 installed, more lines for trivial jobs |
| **Use when** | "Run this command and show me the table" | "Look at all of these, compare them, and decide" |

**Practical rule:** if you find yourself writing an `if` inside a `for` inside a
`while` in bash, stop and switch to Python. You will save hours.

## Where should the script run?

| Option | Pros | Cons | Best for |
|---|---|---|---|
| **Your laptop, by hand** | Zero setup, easy to debug | Only runs when you remember, needs your personal keys | Investigating, one-off checks |
| **cron on an EC2 box** | Simple, familiar, full Linux | You must maintain that server, and if it dies your monitoring dies silently | On-instance checks like Script 06 |
| **AWS Lambda + EventBridge** | No server to maintain, cheap, uses a role instead of keys | 15-minute time limit, packaging boto3 takes setup, harder to debug | Scheduled account-wide audits |
| **CI/CD pipeline** | Blocks bad changes before they ship, results visible to everyone | Only runs on deploys, not continuously | Security and tag checks |
| **AWS Systems Manager Run Command** | Runs on many servers at once, no SSH needed, fully logged | AWS-only, needs the SSM agent | Fleet-wide checks |

**A sensible progression:** run by hand → cron → Lambda. Do not start with
Lambda. Get the script right first.

## Your own scripts, or an off-the-shelf tool?

| | These scripts | AWS Config / Security Hub | Third-party (Prowler, ScoutSuite, Steampipe) |
|---|---|---|---|
| **Cost** | Free | Charges per rule per resource — can be surprising | Mostly free and open source |
| **Setup** | Minutes | Hours, plus ongoing tuning | An hour |
| **Coverage** | The things you chose | Very broad, AWS-maintained | Hundreds of checks |
| **You understand it** | Completely | Not really | Partly |
| **Customizable** | Totally | Within AWS's framework | Yes, with effort |

**Honest recommendation:** use these scripts to *learn how AWS actually works* —
that understanding is the real prize, and it transfers to every tool you will
ever use. Then, once your account is big enough to matter, run **Prowler** or
**Security Hub** for breadth, and keep small custom scripts for the checks that
are unique to your company. Do not try to out-build AWS's rule library.

## Access keys or roles?

| | Long-lived access key | IAM role (temporary) |
|---|---|---|
| **Pros** | Works anywhere, simple to understand | Expires by itself, nothing to store, nothing to rotate, hugely safer |
| **Cons** | Permanent, leaks are catastrophic, someone must remember to rotate | Slightly more setup, only works with AWS-aware services |
| **Verdict** | Last resort only | **Default choice** |

## Clicking in the console, or infrastructure as code?

| | Console clicking | Terraform / CloudFormation / CDK |
|---|---|---|
| **Pros** | Fast, visual, great for learning and exploring | Repeatable, reviewable, undo-able, self-documenting |
| **Cons** | Nobody knows what you did or why, impossible to repeat exactly, causes drift | Learning curve, slower for tiny changes |
| **Use for** | Looking around, emergencies, learning | Anything that will exist tomorrow |

**The rule that keeps teams sane:** you may *look* in the console freely. Try not
to *change* things there. Every manual change becomes drift, and drift becomes a
mystery outage three months later when a deployment quietly undoes it.

---

<a name="part-6"></a>
# Part 6 — Where To Go Next

## Your first week

- **Day 1:** Run Script 01 in every region. Actually look at what you own.
- **Day 2:** Run Script 02. Fix every CRITICAL. Just those.
- **Day 3:** Run Script 08. Turn on root MFA. Delete never-used keys.
- **Day 4:** Run Script 03. Share the yearly figure with your manager — this is
  how you get time budgeted for cleanup work.
- **Day 5:** Put Script 06 on cron on your three most important servers.

## Your first month

- Agree a tag standard with your team and get it into your Terraform
- Add Script 02 to your build pipeline
- Schedule Scripts 02, 03, and 08 to email you weekly
- Write down the first three runbooks (what to do when X breaks)

## Good next steps for the scripts themselves

- **Send results to Slack** instead of the terminal (an incoming webhook is about
  five lines of Python)
- **Save results over time** to an S3 bucket or DynamoDB table so you can chart
  the trend
- **Handle multiple accounts** by assuming a role in each one and looping
- **Add a `--fix` mode** for the safest checks only — enabling S3 Block Public
  Access is safe to automate; deleting volumes is not

## Concepts worth learning next, in order

1. **VPC networking properly** — subnets, route tables, NAT, VPC endpoints. This
   is the single highest-value thing to actually understand deeply. It is where
   the confusing problems live.
2. **IAM policy documents** — how to read and write a policy by hand.
3. **Infrastructure as code** — Terraform is the most transferable choice.
4. **CloudWatch Logs Insights** — query your logs instead of grepping them.
5. **AWS Organizations and SCPs** — how to make bad things *impossible* rather
   than merely detectable. This is the endgame: detection is good, prevention is
   better.

## A closing thought

The scripts in this folder are worth something. Understanding *why* each check
exists is worth far more. Every one of them came from a real outage, a real
surprise bill, or a real breach at some company.

**The goal is not to run these forever.** The goal is to fix the underlying
problem so that a check has nothing left to find — tags enforced by policy,
public access blocked at the organization level, roles instead of keys. When a
script comes back clean every single time, you have not wasted it. You have
graduated from it.

Run them read-only. Read the output. Fix the CRITICAL things first. Snapshot
before you delete. And always, always check which account you are in.
