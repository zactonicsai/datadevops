# ---------------------------------------------------------------------------
# versions.tf
#
# Pin the versions so that a teammate running this next month gets exactly the
# same behaviour you got today. Un-pinned Terraform is how "it worked on my
# laptop" happens.
# ---------------------------------------------------------------------------

terraform {
  required_version = ">= 1.5.0" # 1.5+ needed for import blocks and `check`

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.60"
    }
    # Used to write go-green.sh / rollback-blue.sh / status.sh to disk.
    local = {
      source  = "hashicorp/local"
      version = "~> 2.5"
    }
  }

  # STRONGLY RECOMMENDED: keep this stack's state in its OWN file, separate
  # from whatever manages your production infrastructure. If green and blue
  # share a state file, a bad `terraform destroy` can take production with it.
  #
  # backend "s3" {
  #   bucket         = "my-terraform-state"
  #   key            = "nifi/blue-green/terraform.tfstate"
  #   region         = "us-east-1"
  #   dynamodb_table = "terraform-locks"
  #   encrypt        = true
  # }
}

provider "aws" {
  region = var.region

  default_tags {
    tags = {
      ManagedBy = "terraform"
      Project   = "nifi-blue-green-upgrade"
    }
  }
}
