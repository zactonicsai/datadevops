# NiFi Blue/Green Upgrade — Terraform

**What this is:** Terraform that builds a parallel copy of your production NiFi server, hangs it off the same load balancer, and lets you move all real traffic between the two by changing **one word** in a config file.

---

## Part 1 — The Idea, In Plain Words

### What Terraform actually is

Terraform is a **shopping list for cloud infrastructure**.

You write down what you want ("one server, one target group, one security group with these three rules"). Terraform looks at what already exists, works out the difference, and makes reality match your list.

The important part: Terraform **remembers** what it built, in a file called the *state file*. So next time you run it, it doesn't build a second server — it sees "I already made that one" and leaves it alone.

### Why that helps here

Doing the migration by hand means running about forty AWS CLI commands in the right order and remembering the undo for each one. That works, but:

- If you have to do it again in the dev environment, you do all forty again and get it slightly different.
- Six months later nobody remembers *why* the security group is missing that one rule.
- The rollback depends on somebody typing an ARN correctly under pressure.

Terraform fixes all three. The forty commands become one `terraform apply`. The *why* lives in comments next to the code. And the rollback becomes:

```bash
terraform apply -var="active_stack=blue"
```

### The switch, explained

Think of the load balancer as a signpost at a fork in the road. Two paths: blue (the old NiFi) and green (the new one). The signpost has two arrows, and each arrow has a **weight** — a number from 0 to 100 saying what share of travellers go that way.

```
                    ┌─────────────────────────┐
   users ─────────► │  ALB HTTPS Listener     │
                    │                         │
                    │  blue arrow:  weight ?  │
                    │  green arrow: weight ?  │
                    └───────┬────────┬────────┘
                            │        │
              ┌─────────────┘        └─────────────┐
              ▼                                    ▼
      ┌───────────────┐                    ┌───────────────┐
      │  BLUE TG      │                    │  GREEN TG     │
      │  NiFi 1.3     │                    │  NiFi 2.x     │
      │  (untouched)  │                    │  (upgraded)   │
      └───────────────┘                    └───────────────┘
```

`active_stack = "blue"` → blue arrow 100, green arrow 0.
`active_stack = "green"` → blue arrow 0, green arrow 100.

That's it. Both target groups always exist. Both are always attached to the listener. Switching changes **two numbers** — nothing gets created, nothing gets destroyed, so nothing can fail halfway through. That's why rollback is roughly 20 seconds and cannot leave you in a broken half-state.

### Why weights, and not just swapping the target group?

You *could* write `target_group_arn = <the other one>`. It works. But:

| | Weights | ARN swap |
|---|---|---|
| What changes on rollback | Two numbers | The whole action block |
| Risk of typing the wrong ARN at 2am | None — both ARNs are already there | Real |
| Terraform plan output | `~ weight = 100 -> 0` — impossible to misread | A full block replacement |
| Can do a gradual shift | Yes | No |

For NiFi specifically, use **only 100/0 or 0/100**. A 50/50 split sounds appealing but NiFi's UI is session-based, so half your users would be on a different version of the flow — and worse, both servers would be pulling from your data sources at once.

---

## Part 2 — What Terraform Owns, and What It Deliberately Doesn't

This is the most important section. Getting this boundary wrong is how Terraform destroys two days of upgrade work.

### Terraform owns (the box)

| Thing | Why Terraform is right for it |
|---|---|
| The AMI taken from production | Repeatable. Same command every environment. |
| The green EC2 instance | Guarantees green matches blue's size, subnet and IAM role exactly. |
| The isolated security group | The *missing* rules are the safety feature — code with comments is the only good place to record a deliberate omission. |
| The green target group + health check + stickiness | Fiddly settings that are easy to get wrong by hand and easy to copy in code. |
| The test-hostname listener rule | Cheap to create, cheap to delete, needs to be identical every time. |
| The traffic switch | One variable, reviewable in a pull request, recorded in git history. |

### Terraform does **not** own (what's inside the box)

| Thing | Why not |
|---|---|
| Installing NiFi 1.28.1, then 2.x | Multi-step, needs human judgement at each hop. Use Ansible, or do it by hand. |
| Editing `nifi.properties`, `authorizers.xml` | Values differ per version and need eyes on them. |
| Replacing removed processors in the flow | This is design work, not provisioning. |
| Checkpoint snapshots between upgrade hops | Terraform describes a desired end state; it is not a time machine. Use `aws ec2 create-image`. |
| Starting and stopping NiFi processors | That is an operational decision made in the NiFi UI. |

**This is why `instance.tf` has these three lines:**

```hcl
lifecycle {
  ignore_changes = [ami, user_data, tags["LastUpgradeStep"]]
}
```

They tell Terraform: *once green exists, do not rebuild it, no matter what changes upstream.* Without them, a regenerated AMI would make Terraform quietly destroy and recreate green — throwing away every hour of hand-upgrade work, because none of that work lives in a Terraform file.

**Rule of thumb:** Terraform builds and wires the box. A human (or Ansible) changes what's inside it.

---

## Part 3 — The Files

```
nifi-blue-green/
├── versions.tf                       Provider versions + state backend
├── variables.tf                      Every input, with the "why" in the description
├── data.tf                           READ-ONLY lookups of production + the weight math
├── ami.tf                            Photograph of production
├── security_group.tf                 Green's isolated doorman
├── instance.tf                       The green server + safety `check` blocks
├── load_balancer.tf                  Target group, test rule, and THE SWITCH
├── switch_scripts.tf                 Generates go-green.sh / rollback-blue.sh / status.sh
├── outputs.tf                        Instance IDs, connect commands, the 5 rules
├── terraform.tfvars.example          Copy to terraform.tfvars and fill in
└── templates/
    └── green-bootstrap.sh.tftpl      First-boot script that de-fangs the clone
```

### The two files worth reading closely

**`templates/green-bootstrap.sh.tftpl`** — runs once, on green's first boot, before any human can log in. It fastens four seatbelts:

1. Stops NiFi and disables auto-start
2. Sets `nifi.flowcontroller.autoResumeState=false` so every processor boots **stopped**
3. Points ZooKeeper state at a **different** path (`/nifi-green`)
4. Empties the flowfile/content/provenance repositories

Without this, green wakes up with production's flow, production's passwords and production's network access — and starts doing production's job. Two servers doing the same job means duplicate data downstream and corrupted bookmarks upstream.

Seatbelt 3 is the one that matters most and looks least important. Processors like `ListFile`, `ListSFTP`, `ListS3` and database CDC store a bookmark in ZooKeeper meaning *"already handled everything up to here."* If green and blue share that path, green moves blue's bookmark forward and **blue silently skips files it never processed**. The data loss is permanent and nobody notices for days.

**`security_group.tf`** — the safety here is in what is *absent*. No self-referencing rule. No port 11443 (cluster protocol). No port 6342 (load balancing). No ZooKeeper ports. Your original plan was to reuse production's security group — and that's exactly the shortcut that lets green join the production cluster on boot.

---

## Part 4 — Running It, Phase By Phase

### Phase 0 — First-time setup

```bash
cd nifi-blue-green
cp terraform.tfvars.example terraform.tfvars
# edit terraform.tfvars with your real IDs and ARNs

terraform init
terraform validate
terraform plan          # READ THIS. Nothing should say "destroy".
```

Two things to do outside Terraform first:

```bash
# 1. Give the load balancer more patience (NiFi's UI has slow calls)
aws elbv2 modify-load-balancer-attributes \
  --load-balancer-arn <alb-arn> \
  --attributes Key=idle_timeout.timeout_seconds,Value=300

# 2. Add stickiness to the EXISTING blue target group, so rollback behaves the
#    same way as the switch forward
aws elbv2 modify-target-group-attributes \
  --target-group-arn <blue-tg-arn> \
  --attributes Key=stickiness.enabled,Value=true \
               Key=stickiness.type,Value=lb_cookie \
               Key=stickiness.lb_cookie.duration_seconds,Value=86400 \
               Key=deregistration_delay.timeout_seconds,Value=30
```

### Phase 1 — Build green

Stop NiFi on production first if you set `snapshot_without_reboot = false`, so the image is clean.

```bash
terraform apply
```

Takes 15–30 minutes, almost all of it waiting for the AMI. Then:

```bash
# Pin the AMI so no future apply can rebuild it
terraform output green_ami_id_to_pin
# paste that into green_ami_id in terraform.tfvars, then:
terraform apply    # should now show "No changes"
```

Verify the seatbelts actually fastened:

```bash
aws ssm start-session --target $(terraform output -raw green_instance_id)

sudo cat /var/log/nifi-green-bootstrap.log
grep autoResumeState /opt/nifi/conf/nifi.properties      # must be false
grep 'Root Node' /opt/nifi/conf/state-management.xml     # must be /nifi-green
ps -ef | grep -i nifi | grep -v grep                     # must be empty
```

### Phase 2 — Rehearse the rollback (do NOT skip)

Both servers are still identical NiFi 1.3, so switching between them is harmless. This is the moment to prove the mechanism works — while there's no pressure.

```bash
./go-green.sh          # time this
./status.sh            # confirm traffic really moved
./rollback-blue.sh     # time this too
./status.sh
```

If it takes more than 60 seconds, find out why now, not during an outage.

Print `rollback-blue.sh`. Stick it on the wall. Tell the on-call person.

### Phase 3 — Upgrade green by hand

Terraform's job is done for now. Checkpoint before every hop:

```bash
aws ec2 create-image \
  --instance-id $(terraform output -raw green_instance_id) \
  --name "nifi-green-checkpoint-before-1.28.1-$(date +%Y%m%d-%H%M)"
```

If a hop goes badly, set `green_ami_id` to that checkpoint AMI and `terraform apply` — green is rebuilt exactly as it was, in minutes.

The version path is fixed: **1.3.0 → 1.28.1 → 2.x**. You cannot jump straight to 2.x. Java changes at each hop too (8 → 11/17 → 21). Test through the `test_hostname` door the whole time; real users never see any of it.

### Phase 4 — Cut over

```bash
# In terraform.tfvars:
active_stack = "green"

terraform plan
```

**Read the plan.** It must show **only two weight changes**. If it wants to create, replace or destroy anything, stop and work out why.

```bash
terraform apply
```

### Phase 5 — Roll back if needed

```bash
# Fast path, no Terraform needed:
./rollback-blue.sh

# Then reconcile state:
#   set active_stack = "blue" in tfvars
terraform plan     # must show no changes
```

Then, in order: stop green's source processors, restart blue's.

---

## Part 5 — Importing the Listener

`manage_listener = false` by default, because the HTTPS listener already exists and Terraform doesn't know about it. If you apply with `manage_listener = true` before importing, Terraform tries to **create a second listener on port 443** and fails.

To hand the switch over to Terraform:

```bash
# 1. Set manage_listener = true in terraform.tfvars

# 2. Tell Terraform about the listener that already exists
terraform import 'aws_lb_listener.https[0]' \
  arn:aws:elasticloadbalancing:us-east-1:111122223333:listener/app/my-nifi-alb/abc123/def456

# 3. THE CRITICAL CHECK
terraform plan
```

That plan must show **only** the default action changing from a single target group to the weighted pair. If it wants to change the SSL policy, the certificate, or the port, your variables don't match reality — fix the variables, don't let Terraform "correct" production.

Terraform 1.5+ users can use an import block instead, which is nicer because it shows up in the plan:

```hcl
import {
  to = aws_lb_listener.https[0]
  id = "arn:aws:elasticloadbalancing:...:listener/app/my-nifi-alb/abc123/def456"
}
```

The listener has `prevent_destroy = true`. It's production's front door — if Terraform ever decided to recreate it, every user would be offline until it finished. `prevent_destroy` makes Terraform refuse and error out instead.

---

## Part 6 — Gotchas Specific to Terraform

### TF1. The AMI wants to rebuild on every plan
**Cause:** `formatdate(... timestamp())` in the AMI name changes every second.
**Fix:** already handled by `ignore_changes` in `ami.tf`. But **also pin `green_ami_id`** after the first apply — belt and braces.

### TF2. Terraform wants to replace the green instance
**Symptom:** the plan says `# forces replacement` next to green.
**This is the dangerous one.** Replacement destroys the instance you've been upgrading. `ignore_changes = [ami, user_data]` prevents the common causes, but changing `instance_type`, `subnet_id`, or `iam_instance_profile` will still force it.
**Fix:** if you must change one of those, take an AMI checkpoint first, then let it replace, then... you still lose the upgrade. Better: set those values correctly on day one.

### TF3. `terraform destroy` takes production with it
**Cause:** blue and green sharing one state file.
**Fix:** separate backend key for this stack (see `versions.tf`). Everything about production in this module is a read-only `data` block, so a destroy here can't touch blue — *provided the state files are separate*.

### TF4. Drift after using the emergency scripts
**Cause:** `./rollback-blue.sh` changes AWS directly; Terraform's state still thinks green is active.
**Fix:** update `active_stack` in tfvars to match reality, then `terraform plan` and confirm no changes. Do this the same day — drift you leave alone becomes a nasty surprise on the next apply.

### TF5. The `check` blocks warn but don't stop you
`check` blocks in `instance.tf` produce **warnings**, not errors. They'll shout if `zookeeper_root_node` is still `/nifi`, but they won't block the apply. That's intentional — they're reminders, not gates. Read the warnings.

### TF6. Client-certificate login breaks behind an ALB
Not a Terraform problem, but it will stop you dead. **An ALB terminates TLS**, so the client certificate never reaches NiFi. If cert auth is your only login method, nobody can log in through the load balancer at all.

Decide this before building anything:
- Use a **Network Load Balancer** with TCP passthrough, or
- Switch NiFi to LDAP or OIDC/SAML, or
- Use ALB **mTLS** mode and configure NiFi to trust `X-Amzn-Mtls-Clientcert`

### TF7. Health check goes unhealthy with a 401
The health check path is `/nifi-api/access/config` and the matcher is `200-499`, both deliberate. `/nifi-api/system-diagnostics` needs a login, so the ALB gets a 401 and marks a perfectly healthy NiFi as dead.

---

## Part 7 — Honest Pros and Cons

### Terraform vs. the CLI runbook

| | Terraform | CLI commands by hand |
|---|---|---|
| **Repeatability** | Identical in dev, staging, prod | Drifts every time |
| **Documentation** | The *why* lives in comments beside the code | Lives in a wiki page nobody updates |
| **Rollback** | One variable, reviewable in a PR, in git history | One command, but you must find it first |
| **Speed of a single emergency change** | Slower — needs plan, lock, state, credentials, a human typing "yes" | Faster — one API call |
| **Risk of destroying things** | Real. A bad plan can replace the green instance | Low. Nothing cascades |
| **Learning curve** | Real, if the team doesn't use it already | None, if you know the CLI |
| **Handles the NiFi upgrade itself** | No | No |

**The honest answer:** use both, which is why this module generates the shell scripts. Terraform for the planned, reviewed, recorded work. The scripts for the 2am emergency, when you don't want a state lock standing between you and a rollback.

### Terraform vs. Ansible for this job

They're not competitors, they're layers:

- **Terraform** builds the box: server, network, load balancer wiring.
- **Ansible** changes what's inside: install NiFi 1.28.1, edit `nifi.properties`, restart the service.

Trying to do NiFi installation in Terraform (via `user_data` or `remote-exec`) works exactly once, and then any change to that script wants to rebuild the whole server. Don't. `user_data` here does only the four one-time safety steps, and even those are behind `ignore_changes`.

### Alternatives to this whole approach

| Approach | Pros | Cons |
|---|---|---|
| **Blue/green with a load balancer** (this module) | Rollback in ~20s. Both versions provable side by side. | Two servers running = double cost during the migration. |
| **In-place upgrade with a snapshot** | Cheap. Simple. One server. | Rollback means restoring a snapshot: 20–60 minutes of downtime. And if the flow file is already rewritten, rollback may be impossible. |
| **Containers on ECS/EKS** | Best long-term answer. Rollback is a task-definition revision. | Big change to how you run NiFi. Wrong project to attempt it during an already risky version upgrade. |

Given you're jumping from **NiFi 1.3 (2017)** to a modern version, blue/green is the right call. That gap is large enough that something *will* surprise you, and you want the ability to be back on the old version before anyone notices.

---

## Part 8 — The Five Rules

1. **Pin `green_ami_id` after the first apply.** Unpinned, a rebuild can wipe out days of upgrade work.
2. **Never make `zookeeper_root_node` equal to production's.** Shared state causes silent, permanent data loss on production.
3. **Never add production's security group to green.** Self-referencing rules let green join the production cluster.
4. **Always read the plan.** For a traffic switch it should show two weight changes and nothing else.
5. **Rehearse the rollback while both servers are still identical.** Time it. Print the script.
