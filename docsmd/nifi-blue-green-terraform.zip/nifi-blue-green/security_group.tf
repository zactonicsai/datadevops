# ---------------------------------------------------------------------------
# security_group.tf
#
# A security group is a doorman with a list of who is allowed to knock and on
# which door. Green gets its OWN doorman - a near-copy of production's, with
# one crucial rule left out.
#
# Why not just reuse production's group, as originally planned? Because most
# NiFi security groups contain a self-referencing rule ("anything else in this
# group may talk to me on any port") so cluster nodes can find each other. Put
# green in that group and green can reach blue on the cluster ports. On boot it
# will try to join the production cluster. That is the single highest-risk
# shortcut in this whole migration.
# ---------------------------------------------------------------------------

resource "aws_security_group" "green" {
  name_prefix = "${var.name_prefix}-green-"
  description = "Isolated SG for the green (upgrade candidate) NiFi instance"
  vpc_id      = var.vpc_id

  tags = merge(local.common_tags, {
    Name = "${var.name_prefix}-green-sg"
  })

  lifecycle {
    create_before_destroy = true
  }
}

# --- INBOUND -----------------------------------------------------------------

# The load balancer needs to reach the NiFi UI. This is the only rule that is
# always required.
resource "aws_vpc_security_group_ingress_rule" "green_from_alb" {
  security_group_id            = aws_security_group.green.id
  referenced_security_group_id = var.alb_security_group_id
  ip_protocol                  = "tcp"
  from_port                    = var.nifi_port
  to_port                      = var.nifi_port
  description                  = "ALB -> green NiFi web UI"

  tags = { Name = "alb-to-nifi" }
}

# SSH from your bastion, so you can log in and do the upgrade work.
resource "aws_vpc_security_group_ingress_rule" "green_ssh_from_admin" {
  count = var.admin_security_group_id == null ? 0 : 1

  security_group_id            = aws_security_group.green.id
  referenced_security_group_id = var.admin_security_group_id
  ip_protocol                  = "tcp"
  from_port                    = 22
  to_port                      = 22
  description                  = "Bastion -> green SSH"

  tags = { Name = "admin-ssh" }
}

# OPTIONAL and OFF BY DEFAULT.
# One port, one direction: production may push a copy of real traffic into
# green via Site-to-Site, for shadow testing. Green can never push back.
resource "aws_vpc_security_group_ingress_rule" "green_site_to_site_from_blue" {
  count = var.enable_site_to_site_from_blue ? 1 : 0

  security_group_id            = aws_security_group.green.id
  referenced_security_group_id = var.blue_security_group_id
  ip_protocol                  = "tcp"
  from_port                    = var.nifi_port
  to_port                      = var.nifi_port
  description                  = "Blue -> green Site-to-Site (shadow testing only)"

  tags = { Name = "site-to-site-shadow" }
}

# --- OUTBOUND ----------------------------------------------------------------

# Green needs the same outbound reach as blue: Kafka brokers, databases, SFTP
# servers, S3 endpoints, and so on. Allowing all outbound matches how nearly
# every NiFi security group is configured in practice.
resource "aws_vpc_security_group_egress_rule" "green_all_out" {
  security_group_id = aws_security_group.green.id
  ip_protocol       = "-1"
  cidr_ipv4         = "0.0.0.0/0"
  description       = "All outbound - green must reach the same data sources as blue"

  tags = { Name = "all-egress" }
}

# ---------------------------------------------------------------------------
# NOT CREATED, ON PURPOSE:
#
#   * No self-referencing rule.
#   * No rule for port 11443 (nifi.cluster.node.protocol.port).
#   * No rule for port 6342  (nifi.cluster.node.load.balance.port).
#   * No rule for ZooKeeper ports 2181 / 2888 / 3888.
#
# Adding any of these would let green and blue behave as one cluster. Every
# safety measure elsewhere in this module depends on these four omissions.
# ---------------------------------------------------------------------------
