# ---------------------------------------------------------------------------
# outputs.tf
#
# What Terraform tells you when it finishes. The last output is the one you
# will actually read at 2am, so it is written to be read at 2am.
# ---------------------------------------------------------------------------

output "green_instance_id" {
  description = "EC2 instance ID of the green server."
  value       = aws_instance.green.id
}

output "green_private_ip" {
  description = "Private IP of the green server."
  value       = aws_instance.green.private_ip
}

output "green_target_group_arn" {
  description = "ARN of the green target group."
  value       = aws_lb_target_group.green.arn
}

output "green_security_group_id" {
  description = "The isolated security group green uses."
  value       = aws_security_group.green.id
}

output "green_ami_id_to_pin" {
  description = <<-EOT
    PIN THIS. Copy this AMI ID into green_ami_id in your tfvars right after the
    first apply. Once pinned, no future apply can rebuild the image and destroy
    the green server you have been upgrading.
  EOT
  value       = local.green_ami_id
}

output "active_stack" {
  description = "Which stack real users are being sent to right now."
  value       = var.active_stack
}

output "connect_to_green" {
  description = "How to reach the green NiFi UI before it is behind the load balancer."
  value = <<-EOT
    Shell on the box (no SSH keys or open ports needed):
      aws ssm start-session --target ${aws_instance.green.id} --region ${var.region}

    View the UI from your laptop through a bastion tunnel:
      ssh -L 9443:${aws_instance.green.private_ip}:${var.nifi_port} ec2-user@BASTION_IP
      then open  https://localhost:9443/nifi

    Check the first-boot safety script actually ran:
      sudo cat /var/log/nifi-green-bootstrap.log
      ls -l /opt/.nifi-green-bootstrap-complete

    Start NiFi by hand (it is deliberately NOT running):
      sudo -u nifi ${var.nifi_home}/bin/nifi.sh start
      tail -f ${var.nifi_home}/logs/nifi-app.log
  EOT
}

output "check_health" {
  description = "Commands to see whether each stack is healthy."
  value = <<-EOT
    Green:
      aws elbv2 describe-target-health --target-group-arn ${aws_lb_target_group.green.arn} \
        --query 'TargetHealthDescriptions[].[Target.Id,TargetHealth.State,TargetHealth.Reason]' --output table

    Blue:
      aws elbv2 describe-target-health --target-group-arn ${var.blue_target_group_arn} \
        --query 'TargetHealthDescriptions[].[Target.Id,TargetHealth.State,TargetHealth.Reason]' --output table

    What is the listener actually pointing at right now:
      aws elbv2 describe-listeners --listener-arn ${var.listener_arn} \
        --query 'Listeners[0].DefaultActions' --output json
  EOT
}

output "switch_traffic" {
  description = "How to move traffic between blue and green."
  value = var.manage_listener ? <<-EOT
    Terraform owns the switch.

      Go green:     terraform apply -var="active_stack=green"
      Roll back:    terraform apply -var="active_stack=blue"

    Better: put active_stack in terraform.tfvars, commit the change, and let
    your pipeline apply it - so every switch is recorded in git history with a
    name and a timestamp attached.

    ALWAYS read the plan before approving. It should show ONLY two weight
    changes. If it wants to create, destroy, or replace anything, STOP.
  EOT : <<-EOT
    Terraform is NOT managing the switch (manage_listener = false).
    Use the generated scripts:

      ./go-green.sh
      ./rollback-blue.sh

    They are written to this directory by the local_file resources.
    Rehearse both BEFORE the real cutover.
  EOT
}

output "READ_ME_FIRST" {
  description = "The five rules, in the place you cannot miss them."
  value       = <<-EOT

    ==========================================================================
     GREEN NiFi STACK - ${aws_instance.green.id} - traffic on: ${upper(var.active_stack)}
    ==========================================================================

     1. NiFi on green is NOT RUNNING and every processor boots STOPPED.
        Before starting anything, confirm its destination is a TEST target.
        A source processor started here competes with production for the same
        data and produces duplicates downstream.

     2. ZooKeeper state path is ${var.zookeeper_root_node}, separate from production.
        Do not "fix" this to match production. Sharing it causes blue to
        silently skip files it never processed.

     3. Green is in its OWN security group (${aws_security_group.green.id}).
        Never add cluster ports 11443 or 6342, and never add production's SG.

     4. flow.xml.gz is a ONE-WAY DOOR. Once NiFi 1.28 or 2.x opens it, NiFi 1.3
        can never read it again. Keep a pristine read-only copy in S3 forever.

     5. Rehearse the rollback BEFORE you need it, while both servers still run
        identical 1.3. Time it. It should be under 60 seconds.

     Pin your AMI now:  green_ami_id = "${local.green_ami_id}"

    ==========================================================================
  EOT
}
