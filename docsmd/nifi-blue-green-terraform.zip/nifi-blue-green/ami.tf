# ---------------------------------------------------------------------------
# ami.tf
#
# Takes a photograph of the whole production server so we can start an
# identical copy from it.
# ---------------------------------------------------------------------------

resource "aws_ami_from_instance" "blue_clone" {
  # Only build an AMI if you did not pin one in green_ami_id.
  count = var.green_ami_id == null ? 1 : 0

  name               = "${var.name_prefix}-blue-clone-${formatdate("YYYYMMDD-hhmm", timestamp())}"
  source_instance_id = var.blue_instance_id

  # false = AWS reboots blue for a clean image (stop NiFi first)
  # true  = no downtime, but repositories may be mid-write. Our bootstrap
  #         script empties them anyway, so this is usually acceptable.
  snapshot_without_reboot = var.snapshot_without_reboot

  tags = merge(local.common_tags, {
    Name    = "${var.name_prefix}-blue-clone"
    Purpose = "source image for green upgrade test"
  })

  timeouts {
    create = "60m"
  }

  lifecycle {
    # `timestamp()` changes on every single plan. Without this, Terraform would
    # want to rebuild the AMI every time you run it - and rebuilding the AMI
    # would want to replace the green instance, destroying an upgrade you may
    # have spent days on.
    ignore_changes = [
      name,
      source_instance_id,
      snapshot_without_reboot,
    ]
  }
}

# ---------------------------------------------------------------------------
# WHAT TERRAFORM DELIBERATELY DOES NOT DO HERE
#
# Checkpoint snapshots between each upgrade hop (1.3 -> 1.28.1 -> 2.x) are NOT
# managed by Terraform. Terraform describes a desired end state; it is not a
# time machine. If you model checkpoints as resources, then "restoring" means
# telling Terraform to destroy and rebuild - which is slow and risky at the
# exact moment you least want risk.
#
# Take checkpoints with the CLI instead. One line, instant, no state file:
#
#   aws ec2 create-image \
#     --instance-id <green-instance-id> \
#     --name "nifi-green-checkpoint-before-1.28.1-$(date +%Y%m%d-%H%M)" \
#     --description "restore point"
#
# Then if a hop goes wrong, set green_ami_id to that checkpoint AMI and
# terraform apply - green is rebuilt exactly as it was.
# ---------------------------------------------------------------------------
