# ---------------------------------------------------------------------------
# load_balancer.tf
#
# The traffic cop's instructions.
#
# A target group is a named list of servers. The listener forwards to a target
# group, and the target group picks a server. Swapping which target group gets
# the traffic is how we change NiFi versions in about twenty seconds.
# ---------------------------------------------------------------------------

resource "aws_lb_target_group" "green" {
  name        = "${var.name_prefix}-green-tg"
  port        = var.nifi_port
  protocol    = var.nifi_protocol
  vpc_id      = var.vpc_id
  target_type = "instance"

  # How long the load balancer waits for in-flight requests before fully
  # removing a server. AWS defaults to 300s, which makes rollback feel slow.
  deregistration_delay = var.deregistration_delay

  health_check {
    protocol = var.nifi_protocol

    # /nifi-api/access/config answers WITHOUT a login.
    # The obvious choice, /nifi-api/system-diagnostics, requires authentication,
    # so the load balancer gets a 401 and marks a perfectly healthy NiFi as dead.
    path = "/nifi-api/access/config"

    interval            = 30
    timeout             = 10
    healthy_threshold   = 2
    unhealthy_threshold = 3

    # Belt and braces. Even a 401 or 403 proves the server is alive and
    # answering, which is all a health check really needs to know.
    matcher = "200-499"
  }

  stickiness {
    enabled         = true
    type            = "lb_cookie"
    cookie_duration = var.stickiness_duration
  }

  tags = merge(local.common_tags, {
    Name = "${var.name_prefix}-green-tg"
  })

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_lb_target_group_attachment" "green" {
  target_group_arn = aws_lb_target_group.green.arn
  target_id        = aws_instance.green.id
  port             = var.nifi_port
}

# ---------------------------------------------------------------------------
# A private door for testing.
#
# This rule says: "if someone types nifi-test.company.com, send them to green."
# Real users on the normal hostname are completely unaffected, so you can test
# green in production's own network, with production's own data sources
# reachable, whenever you like.
# ---------------------------------------------------------------------------

resource "aws_lb_listener_rule" "green_test" {
  count = var.test_hostname == null ? 0 : 1

  listener_arn = var.listener_arn
  priority     = var.test_rule_priority

  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.green.arn
  }

  condition {
    host_header {
      values = [var.test_hostname]
    }
  }

  tags = merge(local.common_tags, {
    Name = "${var.name_prefix}-green-test-rule"
  })
}

# ---------------------------------------------------------------------------
# THE SWITCH
#
# Only created when manage_listener = true, and only after you have imported
# the existing listener (see README). Until then Terraform builds everything
# else and you flip traffic using the generated shell scripts.
#
# How it works: the listener forwards to BOTH target groups, with weights.
# active_stack = "blue"  -> blue 100, green 0
# active_stack = "green" -> blue 0,   green 100
#
# Why weights instead of swapping the target group ARN? Because the structure
# never changes - only two numbers do. There is no ARN to retype under pressure
# at 2am, and Terraform's plan output is unmistakably readable:
#
#     ~ weight = 100 -> 0
#     ~ weight = 0   -> 100
# ---------------------------------------------------------------------------

resource "aws_lb_listener" "https" {
  count = var.manage_listener ? 1 : 0

  load_balancer_arn = data.aws_lb.nifi.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = var.ssl_policy
  certificate_arn   = var.certificate_arn

  default_action {
    type = "forward"

    forward {
      target_group {
        arn    = data.aws_lb_target_group.blue.arn
        weight = local.blue_weight
      }

      target_group {
        arn    = aws_lb_target_group.green.arn
        weight = local.green_weight
      }

      stickiness {
        enabled  = true
        duration = 3600
      }
    }
  }

  tags = merge(local.common_tags, {
    Name        = "${var.name_prefix}-https-listener"
    ActiveStack = var.active_stack
  })

  lifecycle {
    # This listener is production's front door. If Terraform ever decides to
    # destroy and recreate it, every user is offline until it is rebuilt.
    # prevent_destroy makes Terraform refuse and error out instead.
    #
    # If you genuinely need to remove it, comment this out deliberately - the
    # friction is the point.
    prevent_destroy = true
  }
}

# ---------------------------------------------------------------------------
# Load balancer patience.
#
# Some NiFi UI calls are slow: big provenance searches, loading a huge flow.
# The ALB's 60-second default hangs up on them. 300 is comfortable.
# ---------------------------------------------------------------------------

# NOTE: managing ALB attributes requires importing the aws_lb resource too,
# which is a bigger commitment. Easier to set it once with the CLI:
#
#   aws elbv2 modify-load-balancer-attributes \
#     --load-balancer-arn <alb-arn> \
#     --attributes Key=idle_timeout.timeout_seconds,Value=300
#
# It is a one-time, harmless change to production, so a one-line CLI command
# is a better fit than pulling the whole load balancer into this state file.
