# ---------------------------------------------------------------------------
# variables.tf
#
# Everything you need to fill in lives here. Read the descriptions - they
# explain not just WHAT the value is but WHY it matters.
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# THE BIG ONE - this single variable is your traffic switch
# ---------------------------------------------------------------------------

variable "active_stack" {
  description = <<-EOT
    Which NiFi server real users get sent to.

      "blue"  = the original production server (NiFi 1.3)
      "green" = the new upgraded server

    Change this value and run `terraform apply` to switch traffic.
    Change it back and apply again to roll back. That is the whole mechanism.

    Rolling back takes about 20 seconds because Terraform only has to change
    two numbers on the load balancer listener - nothing is created or destroyed.
  EOT
  type        = string
  default     = "blue"

  validation {
    condition     = contains(["blue", "green"], var.active_stack)
    error_message = "active_stack must be exactly \"blue\" or \"green\"."
  }
}

# ---------------------------------------------------------------------------
# Basics
# ---------------------------------------------------------------------------

variable "region" {
  description = "AWS region, e.g. us-east-1."
  type        = string
}

variable "name_prefix" {
  description = "Prefix for every resource name this module creates."
  type        = string
  default     = "nifi"
}

# ---------------------------------------------------------------------------
# Things that ALREADY EXIST - we look these up, we never create or change them
# ---------------------------------------------------------------------------

variable "blue_instance_id" {
  description = "EC2 instance ID of the running production NiFi server."
  type        = string
}

variable "vpc_id" {
  description = "VPC that everything lives in."
  type        = string
}

variable "subnet_id" {
  description = <<-EOT
    Subnet for the green instance. Use the SAME subnet as blue so that network
    routes, NAT, and latency to your data sources are identical. If they differ,
    a performance problem on green may be the network, not the NiFi upgrade -
    and you will waste a day chasing the wrong thing.
  EOT
  type        = string
}

variable "blue_security_group_id" {
  description = <<-EOT
    The security group production NiFi uses.

    We READ it (to mirror its outbound access) but we do NOT attach green to it.
    Most NiFi security groups contain a self-referencing rule so that cluster
    nodes can find each other. If green joined that group, green could reach
    blue on the cluster ports and would try to join the production cluster.
  EOT
  type        = string
}

variable "alb_security_group_id" {
  description = "Security group attached to the Application Load Balancer."
  type        = string
}

variable "admin_security_group_id" {
  description = "Security group of your bastion / jump host, for SSH into green. Set to null to skip."
  type        = string
  default     = null
}

variable "alb_name" {
  description = "Name of the existing Application Load Balancer."
  type        = string
}

variable "listener_arn" {
  description = <<-EOT
    ARN of the HTTPS listener on the ALB. This is the thing whose default action
    we flip between blue and green.

    NOTE: to have Terraform manage this listener you must import it first -
    see README section "Importing the listener". Until then leave
    manage_listener = false and use the CLI scripts for the switch.
  EOT
  type        = string
}

variable "blue_target_group_arn" {
  description = "ARN of the existing target group that holds the production instance."
  type        = string
}

variable "certificate_arn" {
  description = "ACM certificate ARN on the HTTPS listener. Only needed if manage_listener = true."
  type        = string
  default     = null
}

variable "ssl_policy" {
  description = "TLS policy on the listener. Must match what is there today, or importing will show a diff."
  type        = string
  default     = "ELBSecurityPolicy-TLS13-1-2-2021-06"
}

# ---------------------------------------------------------------------------
# The green instance
# ---------------------------------------------------------------------------

variable "green_ami_id" {
  description = <<-EOT
    If null, Terraform creates a fresh AMI from the blue instance.
    If set, Terraform uses the AMI you name.

    RECOMMENDED WORKFLOW: leave this null for the very first apply, note the
    AMI ID that gets created, then paste it in here. That way future applies
    can never accidentally rebuild the image and wipe out the green server you
    have spent two days upgrading.
  EOT
  type        = string
  default     = null
}

variable "snapshot_without_reboot" {
  description = <<-EOT
    false (default) = AWS reboots blue while taking the image. Cleanest result.
                      Stop NiFi first so nothing is mid-write.
    true            = no reboot, zero production downtime, but the copied
                      repositories may be inconsistent. Safe for us anyway,
                      because the bootstrap script empties them.
  EOT
  type        = bool
  default     = false
}

variable "instance_type" {
  description = "Match production. A smaller green box will give you misleading performance results."
  type        = string
}

variable "iam_instance_profile" {
  description = "Same instance profile name as blue, so green can reach the same S3 buckets, secrets, etc."
  type        = string
}

variable "key_name" {
  description = "EC2 key pair name for SSH. Optional if you only use SSM Session Manager."
  type        = string
  default     = null
}

variable "root_volume_size" {
  description = "Root volume size in GB. Should be at least as large as blue's."
  type        = number
  default     = 100
}

variable "extra_volumes" {
  description = <<-EOT
    Extra EBS volumes, if your NiFi repositories live on separate disks.
    Example:
      [{ device_name = "/dev/sdb", size = 500, type = "gp3", iops = 6000 }]
  EOT
  type = list(object({
    device_name = string
    size        = number
    type        = optional(string, "gp3")
    iops        = optional(number, null)
    throughput  = optional(number, null)
  }))
  default = []
}

# ---------------------------------------------------------------------------
# NiFi settings
# ---------------------------------------------------------------------------

variable "nifi_port" {
  description = "Port the NiFi web UI listens on. 8443 if secured, 8080 if not."
  type        = number
  default     = 8443
}

variable "nifi_protocol" {
  description = "HTTPS or HTTP - what the load balancer speaks to NiFi."
  type        = string
  default     = "HTTPS"
}

variable "nifi_home" {
  description = "Install directory of NiFi on the instance."
  type        = string
  default     = "/opt/nifi"
}

variable "zookeeper_root_node" {
  description = <<-EOT
    ZooKeeper path where green stores processor state.

    THIS MUST BE DIFFERENT FROM PRODUCTION. Processors like ListFile, ListSFTP,
    ListS3 and database CDC keep a bookmark saying "I already handled everything
    up to here". That bookmark lives in ZooKeeper. If green and blue share it,
    green moves blue's bookmark forward and blue silently skips files it never
    processed. That data loss is permanent and nobody notices for days.
  EOT
  type        = string
  default     = "/nifi-green"
}

variable "proxy_hosts" {
  description = <<-EOT
    Comma-separated hostnames that NiFi will accept in the Host header.
    Must include the ALB DNS name, your test hostname, and your production
    hostname. If a hostname is missing, NiFi answers:
      "System Error: The request contained an invalid host header"
    and the user sees a blank page.
  EOT
  type        = string
}

# ---------------------------------------------------------------------------
# Testing and switching behaviour
# ---------------------------------------------------------------------------

variable "test_hostname" {
  description = <<-EOT
    A separate hostname that always goes to green, no matter what active_stack
    says. e.g. "nifi-test.company.com". This is how you test green without any
    real user ever touching it. Set to null to skip.
  EOT
  type        = string
  default     = null
}

variable "test_rule_priority" {
  description = "Listener rule priority for the test hostname. Lower number = evaluated first."
  type        = number
  default     = 10
}

variable "enable_site_to_site_from_blue" {
  description = <<-EOT
    Opens ONE port, in ONE direction: blue -> green on the NiFi port. That lets
    production fork a copy of real traffic into green for shadow testing.
    Leave false until you actually want shadow testing.
  EOT
  type        = bool
  default     = false
}

variable "manage_listener" {
  description = <<-EOT
    false (default) = Terraform builds everything EXCEPT the traffic switch.
                      You flip traffic with the generated shell scripts.
    true            = Terraform owns the listener's default action, so
                      active_stack drives the switch. Requires importing the
                      existing listener first - see README.
  EOT
  type        = bool
  default     = false
}

variable "stickiness_duration" {
  description = <<-EOT
    Seconds a user stays pinned to the same server. NiFi's UI is session-based;
    without stickiness the UI logs people out constantly.
  EOT
  type        = number
  default     = 86400
}

variable "deregistration_delay" {
  description = <<-EOT
    Seconds the load balancer waits for in-flight requests before fully removing
    a server. AWS defaults to 300, which makes rollback feel slow. 30 is a good
    balance for NiFi.
  EOT
  type        = number
  default     = 30
}

variable "tags" {
  description = "Extra tags applied to everything."
  type        = map(string)
  default     = {}
}
