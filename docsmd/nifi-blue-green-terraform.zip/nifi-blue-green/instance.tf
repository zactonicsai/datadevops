# ---------------------------------------------------------------------------
# instance.tf
#
# The green server itself: same size, same subnet, same IAM role as production,
# but with its own security group and a first-boot script that de-fangs it.
# ---------------------------------------------------------------------------

resource "aws_instance" "green" {
  ami                    = local.green_ami_id
  instance_type          = var.instance_type
  subnet_id              = var.subnet_id
  vpc_security_group_ids = [aws_security_group.green.id]
  iam_instance_profile   = var.iam_instance_profile
  key_name               = var.key_name

  # Force IMDSv2. Cheap security win, no downside.
  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = "required"
    http_put_response_hop_limit = 1
  }

  user_data = templatefile("${path.module}/templates/green-bootstrap.sh.tftpl", {
    nifi_home           = var.nifi_home
    zookeeper_root_node = var.zookeeper_root_node
    proxy_hosts         = var.proxy_hosts
  })

  # If user_data changes later, do NOT rebuild the machine. By then you will
  # have hand-upgraded NiFi on it and that work is not in any Terraform file.
  user_data_replace_on_change = false

  root_block_device {
    volume_size           = var.root_volume_size
    volume_type           = "gp3"
    encrypted             = true
    delete_on_termination = true

    tags = merge(local.common_tags, {
      Name = "${var.name_prefix}-green-root"
    })
  }

  dynamic "ebs_block_device" {
    for_each = var.extra_volumes
    content {
      device_name           = ebs_block_device.value.device_name
      volume_size           = ebs_block_device.value.size
      volume_type           = ebs_block_device.value.type
      iops                  = ebs_block_device.value.iops
      throughput            = ebs_block_device.value.throughput
      encrypted             = true
      delete_on_termination = true
    }
  }

  tags = merge(local.common_tags, {
    Name        = "${var.name_prefix}-green"
    Role        = "nifi-upgrade-candidate"
    Temporary   = "true"
    DoNotDelete = "until-blue-is-retired"
  })

  lifecycle {
    # THE MOST IMPORTANT THREE LINES IN THIS MODULE.
    #
    # The upgrade work (installing NiFi 1.28.1, then 2.x, editing config files,
    # replacing removed processors) happens BY HAND on this machine. None of
    # that lives in Terraform.
    #
    # Without ignore_changes, a fresh AMI or a tweaked user_data would make
    # Terraform destroy and rebuild this instance - silently throwing away days
    # of upgrade work. These lines say: once green exists, leave it alone.
    ignore_changes = [
      ami,
      user_data,
      tags["LastUpgradeStep"],
    ]
  }
}

# ---------------------------------------------------------------------------
# A check block - Terraform 1.5+. Runs on every plan and warns you rather than
# failing, which is exactly right for a safety reminder.
# ---------------------------------------------------------------------------

check "green_is_isolated" {
  assert {
    condition     = var.zookeeper_root_node != "/nifi"
    error_message = "zookeeper_root_node is still the default /nifi. Green would share processor state with production and can silently cause data loss on blue. Change it."
  }
}

check "green_not_in_blue_security_group" {
  assert {
    condition     = !contains(tolist(aws_instance.green.vpc_security_group_ids), var.blue_security_group_id)
    error_message = "Green is attached to production's security group. If that group self-references, green can reach blue's cluster ports and will try to join the production cluster."
  }
}
