# ---------------------------------------------------------------------------
# data.tf
#
# "data" blocks are READ-ONLY. Terraform looks these things up but will never
# create, change, or delete them. Everything about production lives in here,
# which is your safety net: nothing in this file can hurt blue.
# ---------------------------------------------------------------------------

data "aws_caller_identity" "current" {}

# The production NiFi server. We read it to copy its shape onto green.
data "aws_instance" "blue" {
  instance_id = var.blue_instance_id
}

# The subnet green will live in.
data "aws_subnet" "target" {
  id = var.subnet_id
}

# Production's security group. We read its outbound rules so green gets the
# same access to Kafka, databases, SFTP servers and so on - without joining it.
data "aws_security_group" "blue" {
  id = var.blue_security_group_id
}

data "aws_lb" "nifi" {
  name = var.alb_name
}

data "aws_lb_listener" "https" {
  arn = var.listener_arn
}

data "aws_lb_target_group" "blue" {
  arn = var.blue_target_group_arn
}

# ---------------------------------------------------------------------------
# locals - small calculations, done once, used everywhere
# ---------------------------------------------------------------------------

locals {
  # The traffic switch, expressed as weights.
  # active_stack = "blue"  ->  100 / 0
  # active_stack = "green" ->  0 / 100
  #
  # For NiFi always use all-or-nothing. A 50/50 split sounds clever but NiFi's
  # session stickiness means half your users would be on a different version
  # of the flow, and the two servers would both be pulling from your sources.
  blue_weight  = var.active_stack == "blue" ? 100 : 0
  green_weight = var.active_stack == "green" ? 100 : 0

  # Use the AMI you pinned, or the one we just built from blue.
  green_ami_id = coalesce(
    var.green_ami_id,
    try(aws_ami_from_instance.blue_clone[0].id, null)
  )

  common_tags = merge(
    var.tags,
    {
      Stack        = "green"
      SourceOfTruth= "terraform"
      BlueInstance = var.blue_instance_id
    }
  )

  # Every port we deliberately keep CLOSED between blue and green, kept here as
  # documentation so the next person understands the omission was on purpose.
  deliberately_blocked_ports = {
    cluster_protocol = "11443 - how NiFi nodes join a cluster. Open this and green joins production."
    load_balance     = "6342  - how nodes hand FlowFiles to each other. Open this and blue gives green real data."
    zookeeper        = "2181/2888/3888 - shared coordination and shared processor state."
  }
}
